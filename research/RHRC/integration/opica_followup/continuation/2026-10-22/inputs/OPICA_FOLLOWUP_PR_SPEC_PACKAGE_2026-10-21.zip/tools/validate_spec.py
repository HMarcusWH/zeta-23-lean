#!/usr/bin/env python3
"""Specification consistency only; deliberately does not compile Lean."""
from pathlib import Path
import json,re,hashlib,sys
R=Path(__file__).resolve().parents[1]; O=R/'deliverables'
M=json.loads((O/'OPICA_FOLLOWUP_BUILD_MANIFEST_2026-10-21.json').read_text())
X=json.loads((O/'OPICA_FOLLOWUP_PAPER_CROSSWALK_2026-10-21.json').read_text())
E=json.loads((O/'OPICA_FOLLOWUP_PARENT_EXTENSION_2026-10-21.json').read_text())
old=json.loads((R/'parent_inputs/OPICA_PR_BUILD_MANIFEST_2026-10-21.json').read_text())
oldinv=json.loads((R/'evidence/base_path_inventory.json').read_text())
parent_paths={r['path'] for r in oldinv}|{r['path'] for r in old['create']}
known_modules={r['path'][:-5].replace('/','.') for r in oldinv if r['path'].endswith('.lean')}
known_modules|={x['module'] for x in old['modules']}
checks=[]
def test(c,name,detail=''):
 checks.append({'check':name,'pass':bool(c),'detail':detail})
 if not c:raise RuntimeError(name+': '+str(detail))

creates=[x['path'] for x in M['create']];modifies=[x['path'] for x in M['modify']];gen=M['regenerate']['paths']
test(len(creates)==len(set(creates)),'unique created paths')
test(len(modifies)==len(set(modifies)),'unique modified paths')
test(not(set(creates)&set(modifies)),'create/modify disjoint')
test(not(set(creates)|set(modifies))&set(gen),'generated versus authoritative disjoint')
test(not M['delete'] and not M['rename'],'no deletes or renames')
for p in creates:
 test(p not in parent_paths,'new path absent in derived parent inventory',p)
 test(not p.startswith('/') and '..' not in Path(p).parts,'safe relative path',p)
for p in modifies+gen:test(p in parent_paths,'existing path in parent inventory',p)
test(set(gen)==set(old['regenerate']['paths']) and len(gen)==62,'exact current generated allowlist')
for p in modifies:
 if p.endswith('.lean'):test(p=='Zeta23/RHRC/RegisteredClaimBindings.lean','no mathematical Lean edit',p)
for p in modifies:test(not p.startswith('.github/workflows/'),'all old workflows unmodified',p)
mods={x['module']:x for x in M['modules']}
test(len(mods)==len(M['modules']),'unique modules')
test(set(x['path'] for x in M['modules'])==set(p for p in creates if p.endswith('.lean')),'all Lean paths have module contract')
for name,x in mods.items():
 test(name.replace('.','/')+'.lean'==x['path'],'module path corresponds',name)
 for d in x['direct_project_imports']:
  test(d in mods or d in known_modules,'project import resolves to proposed or source-derived existing module',name+' <- '+d)
  if x['trust_zone']!='AUDIT_ONLY':test(not(d in mods and mods[d]['trust_zone']=='AUDIT_ONLY'),'normal math avoids audit',name+' <- '+d)
state={}; order=[]
def visit(k):
 if state.get(k)==1:raise RuntimeError('cyclic import '+k)
 if state.get(k)==2:return
 state[k]=1
 for dep in mods[k]['direct_project_imports']:
  if dep in mods:visit(dep)
 state[k]=2;order.append(k)
for k in mods:visit(k)
test(len(order)==len(mods),'acyclic complete project DAG')
def closure(k):
 seen=set();todo=[k]
 while todo:
  z=todo.pop()
  if z in seen:continue
  seen.add(z)
  if z in mods:todo.extend(mods[z]['direct_project_imports'])
 return seen
cl=closure(M['namespace'])
for name,x in mods.items():test((name in cl)==(x['trust_zone']!='AUDIT_ONLY'),'facade exact mathematical reachability',name)
roots=M['primary_roots']
test(len({r['id'] for r in roots})==len(roots),'unique primary IDs')
test(len({r['full_name'] for r in roots})==len(roots),'unique primary names')
parent_names={r['full_name'] for r in old['required_theorem_roots']}
gids={x['paper_id'] for x in X['scope_units']}
test(len(gids)==28 and len(X['scope_units'])==28,'26 paper groups plus2bridges')
ledger=json.loads((R/'paper_inputs/OPICA_Final_Theorem_and_Audit_Ledger_2026-10-21.json').read_text())
test(gids=={r['id'] for r in ledger['records']}|{'J5.2','MS1'},'source complete group coverage')
for r in roots:
 test(r['module'] in mods,'root module exists',r['full_name'])
 test(r['path']==mods[r['module']]['path'],'root has correct defining path',r['full_name'])
 test(r['full_name'].startswith(M['namespace']+'.'),'sibling namespace separates parent inventory',r['full_name'])
 test(r['full_name'] not in parent_names,'no duplicate primary parent result',r['full_name'])
 test(set(r['paper_ids'])<=gids,'root source groups valid',r['full_name'])
 test(bool(r['statement_contract']) and bool(r['expected_type_consumer']),'root contract/type consumer explicit',r['full_name'])
 test(r['status']=='PLANNED_NOT_PROVED','no theorem claim promotion in spec',r['full_name'])
for g in X['scope_units']:
 expect={r['full_name'] for r in roots if g['paper_id'] in r['paper_ids']}
 test(set(g['required_roots'])==expect and bool(expect),'nonempty exact crosswalk',g['paper_id'])
for row in M['paper_sources']:
 p=R/'paper_inputs'/row['source'];b=p.read_bytes()
 test(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'frozen mathematical source identity',p.name)
end=R/'paper_evidence'
for row in M['regression_sources']:
 b=(end/'checks'/row['source']).read_bytes()
 test(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'frozen checker identity (not a rerun)',row['source'])
test(E['new_exact_paths']==creates,'extension exact created paths')
test(E['modified_exact_paths']==modifies,'extension exact edited paths')
test(E['child_claim_ids']==[x['id'] for x in roots],'extension exact claim IDs')
test(M['registry']['expected_total_claims_after_full_proof']==198+len(roots),'registry total consequence')
test(M['registry']['expected_total_bindings_after_full_proof']==194+len(roots),'binding total consequence')
for p in parent_paths:
 test(not any(re.search(r['pattern'],p) for r in M['classification_rules']),'child classes do not shadow old path',p)
for mod in M['modules']:
 hit=next((r for r in M['classification_rules'] if re.search(r['pattern'],mod['path'])),None)
 test(hit is not None and hit['trust_zone']==mod['trust_zone'],'child first-match classification correct',mod['path'])
for lane, targets in M['formal_lane_targets'].items():
 for target in targets:test(target in mods and mods[target]['trust_zone']!='AUDIT_ONLY','formal lane target exists',lane+':'+target)
# No job may silently omit another definition from final summary.
jobs={j['id']:j for j in M['new_jobs']}
test(set(jobs['followup-summary']['needs'])==set(jobs)-{'followup-summary'},'summary accounts for all required jobs')
for j in M['new_jobs']:
 test(set(j['needs'])<=set(jobs),'CI prerequisites exist',j['id'])
test(sum(len(j.get('matrix',[0])) for j in M['new_jobs'])==10,'exact executed child job count')
text=(O/'OPICA_FOLLOWUP_PR_BUILD_SPEC_2026-10-21.md').read_text()
for p in creates+modifies+gen:test(p in text,'all exact path names documented',p)
for r in roots:test(r['full_name'] in text,'all exact primary names documented',r['full_name'])
for s in ['OPEN_DRAFT_NOT_MERGED','PENDING_PARENT_PUBLICATION_HEAD_COMPLETION_AND_COMPLETE_HARVEST']:
 test(M['parent'].get('observed_state')==s or M['parent'].get('final_acceptance')==s,'parent acceptance limitation explicit',s)
report={'schema':'OPICA_FOLLOWUP_SPEC_VALIDATION_V1','status':'PASS_SPEC_STRUCTURE_ONLY','optimized':not __debug__,'python':sys.version.split()[0],'checks':len(checks),'all_passed':True,'new_files':len(creates),'modified_authoritative':len(modifies),'existing_generated_allowlist':len(gen),'lean_modules':len(mods),'mathematical_modules_including_facade':sum(x['trust_zone']!='AUDIT_ONLY' for x in mods.values()),'primary_targets':len(roots),'paper_plus_bridge_units':len(gids),'derived_parent_inventory_paths':len(parent_paths),'parent_inventory_scope':'Original2330source-derivedpathinventory plus50parentcreates; consistent with observed current2380checkout and parent contract. Not a fresh full live-tree download.','topological_order':order,'counts_not_proof_counts':True,'lean_compiled':False,'paper_proofs_independently_verified':False,'new_ci_runs':0,'repo_written':False,'drive_uploaded':False,'results':checks}
(O/('OPICA_FOLLOWUP_SPEC_VALIDATION_OPTIMIZED_2026-10-21.json' if not __debug__ else 'OPICA_FOLLOWUP_SPEC_VALIDATION_2026-10-21.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['results','topological_order']},indent=2))
