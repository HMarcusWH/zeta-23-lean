# OPICA follow-up PR — exact specification package

This package specifies a future implementation. It contains no new Lean proof, repository commit, PR, or compiler-success receipt.

## Start here

Read `deliverables/OPICA_FOLLOWUP_PR_BUILD_SPEC_2026-10-21.md`. The matching build manifest, 100-root inventory, 28-unit paper crosswalk, exact import graph, and parent-extension descriptor are normative together. The old and new paper result counts are not proof counts.

Pinned inspected parent: PR #293, head `553b4263b58d9fec178320de251ff299a0bd702a`, tree `12691099f1a155a8bfa3ad4f6689146175b233b2`. A final metadata re-read still reported this head as open/draft/unmerged. The current PR-event formal run passed on the corresponding same-tree synthetic merge; the last detailed push/materialization and inherited research reads remained incomplete. The intake file separates these facts. Acceptance of the follow-up requires the parent's actual final accepted source and complete workflow harvest, with any changed base explicitly reconciled.

## Exact proposal

- 84 new files, including 43 Lean files: 41 mathematical/facade and two audit files.
- 12 existing authoritative edits; no existing mathematical Lean source is modified.
- 62 existing generated paths are an exact regeneration allowlist, not a promised byte-difference count.
- 100 proposed primary roots cover 26 final paper groups and both analytic bridges J5.2 and MS1.
- The sibling public import is `Zeta23.OPICAFollowup`; existing public roots stay unchanged.
- Full acceptance would add 100 proved supporting claim/binding records, not change the four existing OPEN claim objects or prove RH.

## Reproduce specification consistency checks

Use Python 3.13 or a compatible standard-library-only interpreter:

```sh
python3 -S tools/validate_spec.py
python3 -S -O tools/validate_spec.py
```

The release ran 3,992 structural assertions in each mode. Both passed with the same semantic checks. Order within the per-check log can differ because path sets are iterated; compare normalized records rather than raw log bytes. These checks cover file inventories, namespaces, source hashes, scope mapping, paths, DAGs and acceptance contracts. They do not compile the future Lean declarations or establish analytic proof correctness.

To regenerate the specification documents from their included generator inputs:

```sh
python3 -S tools/make_spec.py
python3 -S tools/write_document.py
python3 -S tools/validate_spec.py
python3 -S -O tools/validate_spec.py
```

Regeneration changes release payload hashes; a new package manifest must then be produced. Do not edit the frozen mathematical input bytes to make checks pass.

## Included evidence and limits

`paper_inputs/` contains the final paper, its exact ledger/contract/audit and historical release manifest. `parent_inputs/` contains the frozen first-PR build manifest. `evidence/base_path_inventory.json` is the preserved pre-OPICA path census; adding the 50 specified parent creates derives a 2,380-path parent inventory consistent with the observed checkout, not a new complete live-tree download. Selected live parent reads and their blob identities are recorded in the intake.

`paper_evidence/checks/` and selected historical receipts are provided as reproducibility inputs. Their 39,920 finite checks per mode and 33 numerical cases are **inherited** results and future replay requirements, not newly executed mathematics in this specification task. Only the six explicitly listed checker files are proposed new repository paths. Extra historical checker copies in this evidence package are provenance, not an enlarged PR file allowlist. The current parent OPICA checker was integration-adapted; its mathematical fixtures are compared with the frozen original, not falsely asserted to have identical script bytes.

The CP1 numerical script has a relative receipt-output path. The implementation wrapper must copy it unchanged into an external temporary `checks/` and `receipts/` layout before execution. It must not write into a tracked checkout.

The final paper has PAPER/DERIVED self-audit authority. This package does not upgrade it to independent review or Lean authority. Required native source identities, physical transforms, measure status, exact forcing and window-rate proofs may not be substituted by caller assumptions.

## Delivery

The new package is available as a local conversation attachment. Google Drive discovery in this turn returned only read actions; no upload action was available after provider search and full connector discovery. No new Drive upload or readback is claimed. The standing intended destination is Path ABC (`1FwRkN6sbJ4_Fhrqe53wpsJtByD2RXILb`). Existing Drive receipts concern earlier paper releases only.

RH, Step 4, A-X, B-Y, C-Schur, OPEN-J46, D2/WP4 and independent boundary-amplitude exclusion remain OPEN.
