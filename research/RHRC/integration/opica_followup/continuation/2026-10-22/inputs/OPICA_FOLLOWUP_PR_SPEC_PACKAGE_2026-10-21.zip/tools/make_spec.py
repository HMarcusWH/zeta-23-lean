#!/usr/bin/env python3
"""Generate a specification, not repository source or theorem authority."""
from pathlib import Path
import json, hashlib, re, shutil
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables'; OUT.mkdir(exist_ok=True)
DATE='2026-10-21'; NS='Zeta23.OPICAFollowup'; D='research/RHRC/integration/opica_followup'
HEAD='553b4263b58d9fec178320de251ff299a0bd702a'; TREE='12691099f1a155a8bfa3ad4f6689146175b233b2'
BASE='97926d6a949fed7af0429a373b47abc772012834'
old=json.loads((ROOT/'parent_inputs/OPICA_PR_BUILD_MANIFEST_2026-10-21.json').read_text())
ledger=json.loads((ROOT/'paper_inputs/OPICA_Final_Theorem_and_Audit_Ledger_2026-10-21.json').read_text())
mods=[]; roots=[]
def mod(name,lane,imports,defs,purpose,native=False):
    m={'module':NS+'.'+name,'path':'Zeta23/OPICAFollowup/'+name+'.lean','lane':lane,'trust_zone':'AUXILIARY_FORMALIZATION','semantic_role':'OPICA_SOURCE_BOUND_NATIVE_ADAPTER' if native else 'OPICA_GENERIC_FORMALIZATION','direct_project_imports':[NS+'.'+x[1:] if x.startswith('@') else x for x in imports],'required_definitions':defs,'responsibility':purpose,'source_status':'PROPOSED_NOT_CREATED'}
    mods.append(m);return name

def rt(module,group,name,statement,premises='',reject='',consumer=''):
    groups=group if isinstance(group,list) else [group]
    roots.append({'id':'OPICA_FOLLOWUP_'+name.upper(),'full_name':NS+'.'+name,'module':NS+'.'+module,'path':'Zeta23/OPICAFollowup/'+module+'.lean','paper_ids':groups,'kind':'THEOREM','statement_contract':statement,'required_premises':premises,'not_accepted_as_replacement':reject or 'A caller-supplied assertion of the displayed conclusion, an opaque native-data premise, a synthetic source, or a proper-subcase theorem.', 'expected_type_consumer':'expected_'+name,'physical_or_domain_consumer':consumer or 'The downstream consumer identified by the import DAG and theorem crosswalk; actual constructors and premises must be discharged there.','required_for_full_pr':True,'register_only_after_proof_and_type_review':True,'status':'PLANNED_NOT_PROVED'})

# A. Literal source and physical transforms. Names here are new target names.
mod('NativeSourceFamily','arithmetic',['Zeta23.CCM.OriginalSincNativeSource','Zeta23.CCM.UniversalSincInverseGevreyBounds'],['sourceOrderFamily','primeFieldFamily','integerDriveFamily','forwardKernel','nativeCausalGap'],'Define j_d=P^d j from the existing one-copy original source; define physical prime and integer translate histories and repeated forward translates. Prove support/regularity and d=0 equalities.',True)
rt('NativeSourceFamily',['R1-NB1','J5.2'],'sourceFamily_zero_eq_original','sourceOrderFamily 0 = CCM.nativeOriginalSource; prime and integer fields at order zero equal the existing nativeOriginalPrimeField and nativeOriginalIntegerDrive.')
rt('NativeSourceFamily',['R1-NB1','R2-Q2'],'sourceFamily_support_smooth_moments','For every d>=0, j_d is smooth with support in [-s0,s0], the physical fields vanish below g=log 2-s0>0, and the required elementary moments vanish with their exact orders.')
mod('NativeSourceTransforms','arithmetic',['@NativeSourceFamily','Zeta23.OPICA.LocalData','Zeta23.CCM.NativeIntegerDriveComplexLaplace','Zeta23.CCM.NativeIntegerPrimeConvolution','Zeta23.ExceptionalZero.NativeOriginalSourceLaplaceVisibility'],['sourceFamilyLaplace','forwardKernelLaplace','nativePrimeTransformGerm'],'Identify actual transforms on their initial safe half-plane and prove analytic continuation/nonvanishing for the exact one-copy source; construct the original visible simple-pole datum.',True)
rt('NativeSourceTransforms',['R1-NB1','J5.2'],'sourceFamily_laplace_identity','J_d(z)=(z^2-1/4)^d J_0(z), with J_0 the actual original-source Laplace transform; J_d(p)!=0 at every actual right zero p=rho-1/2.')
rt('NativeSourceTransforms',['R2-Q2','J5.2'],'forwardKernel_physical_laplace','For d>=ell and Re z>1/2, the actual integral transform of R_d,ell equals -J_d(z) zeta(z+1/2)^ell zeta\'(z+1/2); the RHS extends entirely after the elementary pole cancellation.')
rt('NativeSourceTransforms','R1-NB1','nativePrimeField_visiblePole','Construct SimplePoleData for the meromorphic continuation of the literal prime field with residue -m J_0(p), for every actual right zero of arbitrary multiplicity m. Prove the source/center identity.',reject='P0 native_kernel_completion_consumer with an arbitrary supplied SimplePoleData; the actual prime-transform pole must be constructed.')
mod('NativeFilters','local',['@NativeSourceTransforms','Zeta23.OPICA.NativeArithmeticAdapter'],['NativeCausalState','NativeGenerator','finiteEulerFilter','inverseFiniteEulerFilter','rationalCausalFilter','truncatedInverseResidual'],'Concrete generator definitions as actual local causal actions, their safe-domain transforms and unit factors. Inverse Euler filter is locally finite, not incorrectly global finite variation.',True)
rt('NativeFilters','R1-NB1','nativeGenerator_transform','All seven named generator classes have their stated actual time/transform identities: source differentiation, delay, finite Euler, inverse Euler, rational and inverse rational, finite residual power, completion. Endpoint distributions stay in the correction state.')
rt('NativeFilters','R1-NB1','nativeGenerator_unit_or_completion','At an actual right zero every generator multiplier is an analytic unit except its explicitly counted zeta completion factor; residual multipliers have value one there.')
mod('NativeTransformationWords','local',['@NativeFilters','Zeta23.OPICA.AffineTransport','Zeta23.OPICA.NativeJetAdapter'],['NativeWord','NativeWordHistory','wordCorrection','wordCompletionCount','wordUnitFactor'],'Instantiate the finite correction-aware law on actual native transformations, not a class defined by faithfulness.',True)
rt('NativeTransformationWords','R1-NB1','nativeWord_corrected_transform','For every concrete finite native word, transformedField-correction = U Z^p originalPrimeTransform on the identified germs; U(pole)!=0; the time/source adapters agree.')
rt('NativeTransformationWords','R1-NB1','nativeWord_order_and_leading','The corrected order is p*m-1 and leading coefficient is -m J_0(lambda) U(lambda) (zeta^(m)(rho)/m!)^p; nonzero, including p=0 residue case.')
rt('NativeTransformationWords','R1-NB1','nativeWord_first_nonzero_derivative','For p>=1 all lower derivatives vanish and the derivative of degree p*m-1 is (p*m-1)! times the exact normalized coefficient; retain all affine histories.')
rt('NativeTransformationWords','R1-NB1','nativeWord_factor_costs','Price local leading-value changes from delays, source order, Euler factors, rational factors and completion count; derivative costs include factorial. No global operator bound inferred from a local unit.')

# B. Rate, recovery, and robust local observations.
mod('NormFirstTransfer','local',['Zeta23.OPICA.EnergyRate','Zeta23.OPICA.DivisorMask'],['hilbertEnergy'],'Use existing HorizonSchedule, positiveRate and SubexpAlong. Prove norm-first comparison for real/complex Hilbert fields and allocation without assuming absolute energy error small.')
rt('NormFirstTransfer','R1-AT1','norm_first_log_comparison','If F=S+B and q=||B||^2-l with q,l real, |log(1+||F||^2)-log(1+max(q,0))| <= 2 log(1+||S||)+log(1+|l|).','Real or complex Hilbert space; no native rate assumption.')
rt('NormFirstTransfer','R1-AT1','norm_first_rate_transfer','On a positive cofinal HorizonSchedule, subexponential ||S_n|| and l_n imply rate difference tends to zero; transfer existing limits and extended limsup/liminf.',reject='Requiring subexponential difference of squared energies, or inserting a native Theta equality as the theorem conclusion without proof.')
rt('NormFirstTransfer','R1-AT2','energy_allocation_bound','||F||^2 <= 2||S||^2 + 2 max(q,0)+2|l| for the same exact decomposition.')
rt('NormFirstTransfer','R1-AT2','energy_allocation_rate_lower','With low-mask subexponential and full energy rate Theta>0, liminf log(1+max(||S_n||^2,max(q_n,0)))/(2T_n)>=Theta; no branchwise equality or common maximizing branch asserted.')
mod('JointObservation','local',['Zeta23.OPICA.ObservationCompatibility','@NormFirstTransfer'],['jointObservation','optimalRecoveryCost','orthogonalRecovery'],'Finite-dimensional joint contrast/history observation; exact cost including zero-map convention, extension, noise and incompatible data.')
rt('JointObservation','R2-O1','joint_recovery_iff','Recovery of ell from A=(P,C) exists iff ker P intersect ker C <= ker ell; construct the map on range and extend by orthogonal projection.')
rt('JointObservation','R2-O1','joint_recovery_optimal_norm','The minimum norm is sup_{Ax!=0}|ell(x)|/||Ax||, with zero cost exactly for the zero target on the zero observation; an attained whole-space extension has that norm.')
rt('JointObservation','R2-O2','joint_recovery_noise_bound','If epsilon>=0 and ||y-Ax||<=epsilon then |ell(x)-R y|<=optimalRecoveryCost*epsilon; include history noise in y.')
rt('JointObservation','R2-O2','approx_compatibility_left_null','dist(b,range B)<=epsilon iff an epsilon-approximate solution exists; a unit left-null vector with |<v,b>|>epsilon excludes compatibility.')
rt('JointObservation','R2-O2','recovery_subexp_budget','Subexponential recovery norm and observation/history error yield a subexponential recovered error on the same schedule; no quiet target from a quiet contrast alone.')
mod('RobustLaurent','local',['Zeta23.OPICA.ResidueLimits','@NativeTransformationWords'],['laurentObservedCoefficient','ContourErrorBudget'],'Cauchy coefficient estimates on a genuine common disk; apply to changing completion depth only with the full actual cost.')
rt('RobustLaurent','R2-J1','laurent_coefficient_error_bound','On radius r>0, a common meromorphic neighborhood with only the stated central pole and sup error<=E yields |delta a_j|<=r^(-j) E for integer j>=-1.')
rt('RobustLaurent','R2-J1','laurent_observation_survives','If E<|a_j| r^j, the observed coefficient remains nonzero; equality-sharp monomial counterexample and j! derivative normalization retained.')
rt('RobustLaurent',['R2-J1','R1-NB1'],'nativeWord_contour_consumer','Instantiate j=p*m-1 and the actual word coefficient, affine corrections and any recovery errors; conclude nonvanishing only under the explicit combined circle budget.')

# C. Source localization and true arithmetic identities.
mod('SourceVerticalBounds','arithmetic',['@NativeSourceFamily'],['sourceVerticalDecayConstant'],'Uniform whole-plane product estimate using the prescribed infinite box convolution, then source derivative cost bounds.',True)
rt('SourceVerticalBounds','R2-Q1a','source_product_vertical_bound','For every real sigma,tau, |Q0(sigma+i tau)|<=8 exp(s0|sigma|) exp(-cq sqrt|tau|), cq=(log 8)sqrt(s0)/4; prove passage through the normal product.')
mod('ZetaLeftLineBounds','arithmetic',['Zeta23.GammaFacts.Complete','Zeta23.Analytic.Stirling'],[],'Prove the moving-left-line zeta and derivative envelope using only valid functional equation, fixed-strip gamma and Cauchy estimates; include any needed library adapters here.')
rt('ZetaLeftLineBounds','R2-Q1b','zeta_left_line_uniform_bound','Exists A0>=1, for all integer n>=1 and real tau: |zeta(-n+i tau)|+|zeta\'(-n+i tau)|<=A0^(n+1)(n+2+|tau|)^(n+2).',reject='A family of unspecified constants depending on n, a gamma bound used outside its sector, or any reciprocal-zeta/zero-free premise.')
mod('ForwardLocalization','arithmetic',['@NativeSourceTransforms','@SourceVerticalBounds','@ZetaLeftLineBounds'],[],'Actual inversion, horizontal contour control, uniform factorial envelope and saddle selection.',True)
rt('ForwardLocalization','R2-Q2','forwardKernel_left_contour_budget','For fixed d>=ell>=0 and derivative order k, prove the integral envelope C exp(D n) n^(2(ell+1)n+B) for all integer n>=1 before optimizing n.')
rt('ForwardLocalization','R2-Q2','forwardKernel_double_exp_decay','For fixed orders d>=ell,k>=0, exists A,c>0 independent of t with |R_d,ell^(k)(t)|<=A exp(-c exp(t/(2(ell+1)))) for every t>=0; compact initial interval included.')
mod('BalancedCoefficients','arithmetic',['@NativeFilters','Zeta23.OPICA.DivisorBounds'],['smallInverseCoefficients','balancedInverseCoefficients','typeICoefficients'],'Prove actual finite J17 Dirichlet-convolution identity and divisor envelopes with coprimality palette and repeated products.',True)
rt('BalancedCoefficients','R2-Q3','native_binomial_inverse_identity','For r>=2 and each real Y>=1, v_Q=s_r+c_r for the actual small/large Mobius split and free integer convolutions; prove local finiteness and original field identity.')
rt('BalancedCoefficients',['R1-AT1','R2-Q3'],'balanced_coeff_divisor_bound','For ell=2r-1, |c_r(n)|<=d_ell(n) and |s_r(n)|<=(2^r-1)d_ell(n) for actual coefficients, retaining nonsquarefree total products.')
mod('LogSlackBalance','arithmetic',['@BalancedCoefficients','@ForwardLocalization','Zeta23.OPICA.NativeArithmeticAdapter'],['logSlackY','logSlackZ','typeIField','balancedField'],'Prove logarithmic-slack decomposition with palette frozen per window and its full support-delay budget.',True)
rt('LogSlackBalance','R2-Q3','log_slack_native_decomposition','Fixed r>=2,d>=r-1,C>1,eta>=0,K>C+r eta+2r; Q(T) finite squarefree<=T^eta. With stated real Y,Z obtain exact F_d=E_T+B_T on [T-C log T,T], using actual signed tuples and physical product support.')
rt('LogSlackBalance','R2-Q3','log_slack_typeI_error','Uniform eventual sup bound C1 T^(r eta) exp(T/2-c T^p), p=(K-C-r eta)/(2r)>1. Constants do not depend on future T or the allowed palette, whose full i log Q delay is paid.')
rt('LogSlackBalance','R2-Q3','fixed_two_factor_preparation','Specialize r=2,d=1,C=2,Q=1,K=8: exp(T/2)T^-4<a,b<=exp(T/2-g)T^4 and sup error<=C1 exp(T/2-cT^(3/2)); source is Pj, not j.')
mod('MaskedNativeRate','arithmetic',['@LogSlackBalance','@NormFirstTransfer','Zeta23.OPICA.DivisorMask'],[],'Bound both low-mask realizations at B(t)=exp(sqrt t), and apply norm-first transfer. This module has no Theta-equality assumption or conclusion.',True)
rt('MaskedNativeRate',['R1-AT1','R2-Q3'],'log_slack_both_low_masks_subexp','For fixed orders/palette budget, both unabsorbed and absorbed-kernel low-mask budgets have logarithm<=sqrt T+O(log T); prove measurable native masks and exact regrouping.')
rt('MaskedNativeRate',['R1-AT1','R2-Q3'],'log_slack_masked_energy_rate_difference','Difference of retained positive-part rate and full physical F_d window rate tends to zero; no claim yet identifying either with Theta.')

# D. Previously paper-only analytic bridge explicitly included in this full spec.
mod('NativeExplicitFormula','analytic',['@NativeSourceTransforms','Zeta23.WeilEF.Main','Zeta23.RvM.LocalCount'],['nativeZeroDisplacementSup'],'Specialize the actual zeta explicit formula to translated compact j_d. Derive absolute zero/trivial sums and the multiplicity-weighted source upper, not an assumed rate.',True)
rt('NativeExplicitFormula','J5.2','native_zero_count_summability','Bind zetaZeroConfig, not xi-prime zeros; derive weighted zero summability from actual zeta_local_zero_count, with analytic multiplicities and both imaginary signs.')
rt('NativeExplicitFormula','J5.2','native_source_explicit_formula','For t>s0 prove actual F_d equals the stated absolutely convergent nontrivial and trivial-zero series; retain the canceled elementary term and all signs/source shifts.')
rt('NativeExplicitFormula',['J5.2','MS1'],'native_zero_sup_bounds','Define Theta as supremum of positive right displacements of actual nontrivial zeros, prove 0<=Theta<=1/2 and the correct supremum-selection property; no maximal zero.')
mod('UniformSourceBounds','analytic',['@NativeExplicitFormula','@SourceVerticalBounds','Zeta23.CCM.UniversalSincInverseGevreyBounds'],[],'Uniform in derivative source order: Gevrey L1/Linfty costs, drive L2, and Theta-dependent physical field envelope.',True)
rt('UniformSourceBounds',['J5.2','MS1'],'source_order_uniform_norms','For d>=0 and k=0,1,2, norms of j_d^(k) and ||U_d||_2 are <=exp(C(d+1)log(d+2)) with source-fixed C; physical moments supply continuum cancellation.')
rt('UniformSourceBounds',['J5.2','MS1'],'native_field_theta_envelope','|F_d(t)|<=C_d exp(Theta t) for t>=0 and log(1+C_d)<=C(d+1)log(d+2); independently prove coefficients, trivial tail and finite initial interval bounds.')
mod('AuxiliaryCompletions','analytic',['@NativeSourceTransforms'],['auxCompletionFilter','auxCompletionKernel','auxRationalFactor','auxCompletionAlpha','auxCompletionBound'],'Construct actual c_k,a_k and the uniform beta/endpoint/Poisson estimates A4-A5 from Part II.',True)
rt('AuxiliaryCompletions',['J5.2','MS1'],'aux_completion_actual_transform','Prove the explicit beta-polynomial filter transforms to r_k=(z-1/2)/prod_{j=k+1}^{2k+2}(z+j+1/2), a_k=c_k*N and its true transform domain.')
rt('AuxiliaryCompletions',['J5.2','MS1'],'aux_completion_uniform_decay','For integer k>=1, |a_k(t)|<=A_k exp(-(k+1/2)t), A_k=2 zeta(k+1)(1+2^(3k+4))/(2pi)^(k+1); retain endpoint atom and prove summability.')
rt('AuxiliaryCompletions',['J5.2','MS1'],'aux_completion_ratio_bounds','For fixed actual nontrivial right coordinate p, ||c_k||_1<=2/(k+1)!, ||c_k||_1/|r_k(p)|<=exp(Cp(k+1)), |r_k(p)|/A_k>=exp(-k log(k+1)-Cp(k+1)); constants uniform in k.')
mod('MultiplicityTail','analytic',['@AuxiliaryCompletions','@UniformSourceBounds','Zeta23.ExceptionalZero.NativeActualInputZeroJets'],['nativeTruncatedResidual','tailMemory'],'Arbitrary-multiplicity actual residual and monic shifted Laguerre normalization, including stable-input estimate and finite truncation only.',True)
rt('MultiplicityTail',['J5.2','MS1'],'native_auxiliary_top_moment','Actual y_k,d=c_k*U_d has vanishing moments below zero multiplicity minus one and exact top unnormalized derivative (-1)^m r_k(p)J_d(p) zeta^(m)(rho).')
rt('MultiplicityTail',['J5.2','MS1'],'laguerre_tail_norm','Degree m-1 monic shifted Laguerre times exp(-conj(p)t) on [T,infinity) has norm exp(-delta T)(m-1)!/(2delta)^(m-1/2), with correct shift and conjugation.')
rt('MultiplicityTail',['J5.2','MS1'],'native_auxiliary_tail_residual_lower','Actual finite-truncation residual in L2 has tail norm >=D_rho,d |r_k(p)| exp(delta T), D=(2delta)^(m-1/2)|J_d(p)zeta^(m)(rho)|/(m-1)!.')
rt('MultiplicityTail',['J5.2','MS1'],'native_terminal_memory_lower','Prove exact A6 with positive part and ||y|| subtraction, without assuming global weighted L2 membership of the prime field.')
mod('NativeWindowRate','analytic',['@MultiplicityTail','Zeta23.OPICA.EnergyRate'],['nativeWindowEnergy'],'Full continuous fixed-source limit J5.2 using actual transforms and all uniform estimates; no bare nativeRate hypothesis.',True)
rt('NativeWindowRate','J5.2','native_fixed_source_window_rate','For each fixed d>=0,C>1, Tendsto [log(1+integral_[T-C log T,T]|F_d|^2)/(2T)] atTop (nhds Theta), including the Theta=0 case and arbitrary zero multiplicity.')
mod('MovingSourceWindowRate','analytic',['@NativeWindowRate'],[],'Retain and formalize the optional-for-fixed-application MS1 as an explicit full-package coverage choice.',True)
rt('MovingSourceWindowRate','MS1','native_slow_source_window_rate','For any real cofinal horizons T_n (positive eventually; normalize a finite prefix for HorizonSchedule) and integer d_n with d_n log(d_n+2)=o(T_n), fixed C>1, the actual F_d_n window energy rate tends to Theta; source factor both signs priced.')

# E. Complex measures, dilation, and valid co-Poisson constructions.
mod('ComplexLocalMeasures','heat',['Zeta23.OPICA.LocallyFiniteSignedMeasure'],['LocallyFiniteComplexMeasure','LocalVariationConvergence'],'A genuine complex locally finite measure API compatible with P0 real Jordan pairs, compact restrictions, total variation, S-prime embedding, real/imaginary extraction and linear-growth estimates. Do not use globally finite SignedMeasure as a replacement.')
rt('ComplexLocalMeasures',['R1-CP1','R2-H1'],'complex_local_measure_embedding_faithful','Construct faithful locally finite complex measures/distributions with positive total-variation control and show real parts yield P0 Jordan measures; prove local-TV convergence implies local test convergence and compatible tempered identity under growth.')
mod('DilatedComb','heat',['@ComplexLocalMeasures','Zeta23.OPICA.SincTriangle'],['dilatedComb','combPairing'],'Actual scaled combs D_t on the full integer lattice with linear variation and Fourier transport on Schwartz tests.')
rt('DilatedComb',['R1-HT1','R1-CT1','R1-CP1'],'dilated_comb_fourier','F(D_t)=D_-t with coefficient exp(t/2) and heat convention exp(-2pi i x xi); establish actual Schwartz convergence and point-count bound.')
mod('WeightedMixing','heat',['@DilatedComb','Zeta23.CCM.NativeIntegerPrimeConvolution'],['weightedVariation','weightedDilationMixture','positiveLogMeasure'],'Noncompact absolute mixing class, real/complex measures, actual logarithmic Mobius inverse and leakage. Compact-support proof is not enough.',True)
rt('WeightedMixing','R1-HT1','weighted_mixture_exists_fourier','Under integral exp(a|t|) d|sigma|<infinity, a>1/2, construct actual locally finite linear-growth mixture and Fourier-reflection law, with its exact origin atom.')
rt('WeightedMixing','R1-HT1','weighted_mobius_inverse','In the stated weighted measure algebra prove eta=N*sigma and sigma=M_mu*eta, using absolute Fubini; norm M_mu is zeta(a+1/2)/zeta(2a+1).')
rt('WeightedMixing','R1-HT1','weighted_mixture_sharp_gap','Self-dual mixture with gap (-1,1) except possible origin is c*integerComb; zero origin forces zero. No positivity premise, but strict a>1/2 retained.')
rt('WeightedMixing','R1-HT1','weighted_gap_leakage','Prove exact weighted variation leakage and continuous-density supremum counterpart, including endpoint b supremum distinct from a<b measure integrability.')
mod('NearGapLimits','heat',['@DilatedComb','Zeta23.OPICA.SignedHeatSeparator'],['nearGapCombFamily'],'Near-sharp mass bounds, S-prime compactness/vanishing under a common variation budget, and actual nonmeasure normalized limit.')
rt('NearGapLimits','R1-HT2','near_gap_mass_bound','For gap a in (0,1], fixed R>=1,d in (0,1/2], positivity off Z and self-duality give mass E_R,d <=pi^2 R^2 (1-a)|nu|([-1,1])/(4d^2).')
rt('NearGapLimits','R1-HT2','near_gap_controlled_limit_zero','With one common linear total-variation constant and a_n->1, all Schwartz pairings tend to zero; prove compact-limit extraction and uniform tails, not total-variation convergence.')
rt('NearGapLimits','R1-CT1','dilation_near_gap_family','For 0<L<log2, nu_L=D_L+D_-L-2cosh(L/2)D0 is nonzero, even selfdual, origin0, gap e^-L and offlattice positive with the stated growth.')
rt('NearGapLimits','R1-CT1','dilation_normalized_limit_not_measure','nu_L/L^2 converges on Schwartz tests to sum_n(n^2 delta_n_second -2n delta_n_first); limit nonzero and not order zero.')
mod('RenormalizedCoPoisson','heat',['@DilatedComb'],['renormalizedCombKernel','coPoissonFamily','coPoissonCutoff','finiteSumSrho','normalizationBrho','zeroMeasure'],'Subtract origin/continuum before integration, prove entire tempered family then local total-variation identification as the exact density-plus-atom measure.',True)
rt('RenormalizedCoPoisson','R1-CP1','renormalized_copoisson_tempered_family','K_t=D_t+D_-t-exp(t/2)(delta0+dx), integral exp(-lambda t)K_t is an entire tempered-distribution-valued family, by actual cancellation on Schwartz tests.')
rt('RenormalizedCoPoisson','R1-CP1','renormalized_copoisson_order_zero','On 0<Re rho<1 prove cutoff local-TV convergence to rho^-1 delta0+[S_rho(|x|)+zeta(rho)|x|^(rho-1)+(1-rho)^-1]dx, including origin correction.')
rt('RenormalizedCoPoisson','R1-CP1','zero_measure_exact_properties','For actual nontrivial rho!=1/2, normalized complex measure has exact unit gap, origin0, even selfduality, linear variation and atom -1 at 1; its real part has the corresponding real properties.')
rt('RenormalizedCoPoisson','R1-CP1','zero_measure_first_cell_sign','Prove explicit first-cell negative value for |gamma|>3pi/(2log2), and both-sign conclusion for every nonzero real scalar projection at off-line zeros when |gamma|>2pi/log2; do not remove height/domain qualifiers.')
mod('ProfileEulerMaclaurin','heat',[],['bernoulliOneRight','bernoulliTwo'],'Finite power-sum expansion with explicit endpoint convention and locally uniform parameter remainder, including differentiated finite sums. This is a foundation proof obligation, not an imported unverified formula.')
rt('ProfileEulerMaclaurin',['R2-S1a','R2-H1','F3'],'finite_sum_euler_maclaurin_uniform','Prove finite-sum expansion zeta(s)+x^(1-s)/(1-s)-B1({x})x^-s-s B2({x})x^(-s-1)/2+O_s(x^-Re(s)-2), locally uniformly in the required parameter domain; right integer endpoint retained.')
mod('ZeroProfiles','spectral',['@RenormalizedCoPoisson','@ProfileEulerMaclaurin'],['spectralKappa','zeroProfile'],'Actual h=1-Srho/brho, reflection quotient kappa, tail, integer jumps, integrals and ordinary Fourier identity.',True)
rt('ZeroProfiles','R2-S1a','zero_profile_regular_selfdual','h is even continuous, L1 and L2, equals1 on [-1,1], Fourier-self-dual, with integral on positive halfline1/2; actual zeta zero and functional equation used.')
rt('ZeroProfiles','R2-S1a','zero_profile_tail_and_jumps','h= kappa B2({x})/(2x^2)+O_rho(x^-3), exact differentiated finite sums imply h\'=O(x^-2) between integers and h\'(n+)-h\'(n-)=-kappa/n^2; xh\' belongs L2.')
mod('LogFourierSobolev','spectral',['@ComplexLocalMeasures'],['logFourier','logUnitary','LogFormDomain','logForm'],'Define true log unitary x=exp(t), the frequency convention without 2pi, weak derivatives, H1/H-1 realization and justified dual pairings. Derive convention conversion to pinned Mathlib Fourier; no imaginary separate force transforms.')
rt('LogFourierSobolev',['R2-S1b','F1','F2','F3'],'log_unitary_form_identity','For the stated actual form domain, integral x^2|h\'|^2 = integral |psi\'|^2+(1/4)integral |h|^2 with psi=exp(t/2)h(exp t); prove unitary L2 conversion and weak derivative statement.')
rt('LogFourierSobolev',['F1','F2'],'log_fourier_plancherel','Establish exp(-i xi t) convention and Plancherel factor1/(2pi), differentiation and continuous H^-1,H^1 pairings used by the actual force.')
mod('ForcedEuler','spectral',['@ZeroProfiles','@LogFourierSobolev'],[],'Derive distributional cell equation with every atomic derivative jump and distinguish form versus operator domain.',True)
rt('ForcedEuler','R2-S1b','zero_profile_forced_euler','On positive axis, -(x^2h\')\'=kappa(h-1+sum positive_integer_delta) in distributions; actual jumps produce atoms and no delta derivative.')
rt('ForcedEuler','R2-S1b','zero_profile_not_homogeneous_operator_vector','Actual nonzero atoms prevent its distributional Euler image being an L2 function and hence prevent using the homogeneous self-adjoint eigenvalue inference; form identity retained.')
mod('SamplingCompatibility','spectral',['@ForcedEuler'],['profileGram','profileFormGram','profileSample'],'Native finite multi-zero integrals and samples, exact undivided compatibility, and forced finite-dimensional countercontrol.',True)
rt('SamplingCompatibility','R2-S2','native_sampling_gram_identity','Qij=kappa_i(Nij+conj bj)=conj kappa_j(Nij+bi) after proving all sample sums, integrals and boundary limits; retain linear-first pairing convention explicitly translated to Lean.')
rt('SamplingCompatibility','R2-S2','native_sampling_form_positive','N,Q and Q-N/4 are PSD for any finite actual profiles; divided-difference identity only when denominator nonzero; undivided version retained at conjugate coincidence.')
mod('CoPoissonJets','heat',['@ZeroProfiles'],['normalizedZeroMeasureJet','zeroJetOrder'],'Actual parameter jets up to multiplicity minus one; local inverse rho(kappa), reflection duplicates and realification proved.',True)
rt('CoPoissonJets','R2-H1','copoisson_zero_jets_measures','For derivative index k<multiplicity(rho), normalized kappa jets retain genuine local measures, gap/origin, even selfduality and linear variation; prove parameter limits and differentiated forced chain.')
mod('ConfluentProfiles','heat',['@CoPoissonJets'],['profileJetMatrix','distinctSpectralNodes'],'Actual first-cell density to Hermite interpolation; normalized derivative coefficients and reflection quotient.')
rt('ConfluentProfiles','R2-H2a','profile_jet_confluent_determinant','For distinct nonzero kappa_j and multiplicities m_j, determinant=(-1)^(M(M-1)/2)*prod kappa_j^m_j*prod_{i<j}(kappa_j-kappa_i)^(m_i*m_j), with normalized jets.')
rt('ConfluentProfiles','R2-H2a','finite_zero_jet_independent','Independence of the actual finite jet measures follows from their first-cell matrix; do not count reflected rho and1-rho as different kappa nodes.')
mod('FiniteSpanSeparation','heat',['@ConfluentProfiles','Zeta23.OPICA.SignedHeatSeparator'],['zeroJetRealSpan'],'Instantiate the real signed separator only after all complex-jet realification and variation hypotheses are proved.')
rt('FiniteSpanSeparation','R2-H2b','finite_zero_span_positive_only_zero','Any real finite combination nonnegative off Z is zero, and on an independent real basis all coefficients are zero; this does not classify arbitrary infinite/nonlinear families.')
rt('FiniteSpanSeparation','R2-H2b','fixed_basis_negative_mass_budget','For each fixed independent real basis exists c_basis>0 such that global sinc-weighted negative mass >=c_basis*coefficient Euclidean norm; no uniform collision/growing-set constant.')
mod('FirstCellCost','heat',['@RenormalizedCoPoisson'],[],'Quantitative first-cell density and required repair cost, with the height and delta conditions retained.')
rt('FirstCellCost','R2-H3','first_cell_negative_mass_cost','For |delta|<1/2,|gamma|>=16 on u in [4pi/(3|gamma|),5pi/(3|gamma|)], density<=-|gamma|exp(-u/2)/2; negative mass>=pi/6 and sinc-weighted mass>=8pi/(27gamma^2).')
mod('SquareDefect','heat',['@ZeroProfiles','Zeta23.OPICA.Involution'],['squareGapMeasure','squareDualityDefect'],'Actual nonlinear square, convolution Fourier defect, no tempered lattice-measure repair, gap filling under selfdual projection.')
rt('SquareDefect','R2-S3','square_fourier_defect','For even continuous selfdual nonzero h in L1 intersect L2, h=A on[-1,1] and tending0, tau=|A-h|^2 dx-|A|^2 comb_nonzero has defect (h*conj h-|h|^2)dx and exact gap/sign/origin.')
rt('SquareDefect','R2-S3','square_defect_origin_positive','The continuous C0 defect has value ||h||_2^2-|A|^2>0, including A=0 when h!=0; retain complex conjugation.')
rt('SquareDefect','R2-S3','square_no_lattice_repair','No tempered lattice-supported order-zero correction can make tau selfdual; prove periodicity/atomic-versus-continuous argument, not an assumed absence of corrections.')
rt('SquareDefect','R2-S3','square_selfdual_projection_fills_gap','(tau+F tau)/2 is selfdual but has strictly positive density on a nonempty interval about0 inside the old gap.')

# F. Complete source sampling, not merely the abstract resolvent.
mod('SawtoothForce','spectral',['@LogFourierSobolev','@ProfileEulerMaclaurin'],['sawtoothWeight','nativeLogForce'],'Define the tempered force from the derivative of integrable sawtooth before stating the compact-test lattice-minus-continuum equality.',True)
rt('SawtoothForce','F1','sawtooth_integrable_force_identity','w=exp(-t/2){exp t} is L1 intersect L2; g=-(D+1/2)w is tempered and equals N-exp(t/2)dt only as the initially compact-test difference; n=1 jump retained.')
rt('SawtoothForce','F1','sawtooth_actual_mellin_fourier','For0<Re s<1 derive integral_0^infinity {x}x^(-s-1)=-zeta(s)/s; hence Flog(w)=-zeta(.5+i xi)/(.5+i xi), Flog(g)=zeta(.5+i xi).')
rt('SawtoothForce','F1','sawtooth_norm_weighted_zeta_moment','Prove exact finite integer-cell norm identity and limit ||w||_2^2=log(2pi)-EulerGamma=(1/2pi)integral |zeta(.5+i xi)|^2/(xi^2+1/4); conclude g in H^-1.')
mod('WeightedSpectralMeasure','spectral',['@SawtoothForce'],['arithmeticSpectralMeasure','spectralEnergy','arithmeticStieltjes'],'Positive measure with finite weighted moment; do not impose finite unweighted total mass.',True)
rt('WeightedSpectralMeasure','F2','arithmetic_stieltjes_holomorphic','For kappa outside[1/4,infinity), M=integral d omega/(a-kappa) is locally absolutely convergent and holomorphic, a=xi^2+1/4 and d omega=|zeta(.5+i xi)|^2 dxi/(2pi).')
rt('WeightedSpectralMeasure','F2','arithmetic_stieltjes_sign_budget','For Im kappa!=0, Im M/Im kappa=integral d omega/|a-kappa|^2>0 and explicit weighted-source bounds; no real-sample assertion.')
mod('NativeResolvent','spectral',['@WeightedSpectralMeasure','@SamplingCompatibility'],['nativeLogResolvent'],'Identify actual zero profile with unique H1 forced log-resolvent and its actual sampling functional.',True)
rt('NativeResolvent','F2','native_forced_resolvent_unique','For actual off-line zero kappa nonreal, psi=exp(t/2)h(exp t) is the unique H1 solution (-(D^2)+1/4-kappa)psi=kappa g; actual Fourier quotient kappa zeta(.5+i xi)/(a-kappa).')
rt('NativeResolvent','F2','native_sample_stieltjes_identity','Justify sample b_kappa=sum h(n)-1/2 as H^-1,H1 pairing, then prove b=kappa M(kappa), with all endpoint terms, normalization and conjugation.')
rt('NativeResolvent','F2','native_profile_spectral_norms','Norm and Euler form equal |kappa|^2 integrals d omega/|a-kappa|^2 and a d omega/|a-kappa|^2. Include mixed compatibility and |b|<=|kappa|(1+|kappa|/|Im kappa|)(log(2pi)-EulerGamma).')
mod('BoundaryAmplitude','spectral',['@NativeResolvent','@ProfileEulerMaclaurin'],['genericForcedProfile','boundaryAmplitude'],'Generic nonzero parameter forced solution and plateau coefficient; never register the diagnostic equivalence as an independent zero-exclusion theorem.',True)
rt('BoundaryAmplitude','F3','generic_forced_profile_unique','For 1/2<Re rho<1, Im rho!=0, htilde=1-Srho/brho-zeta(rho)x^(rho-1)/brho lies in the log form domain and uniquely solves the actual force equation; both ends controlled.')
rt('BoundaryAmplitude','F3','generic_boundary_amplitude','On(0,1), htilde=1-zeta(rho)x^(rho-1)/brho; plateau iff zeta(rho)=0. At infinity the retained homogeneous term is -zeta(1-rho)x^-rho/brho plus the Bernoulli tail; no L1 assertion for generic rho.')

# G. Kernel checked countercontrols and genuine complete consumers.
mod('Counterexamples','controls',['@NormFirstTransfer','@JointObservation','@RobustLaurent','@SamplingCompatibility'],[],'Reproduce the finite/functional countercontrols with exact types and no claim they are actual off-line zeros.')
rt('Counterexamples','R1-MC1','coupled_gram_collision_control','Exact two-exponential rational inner model has coupled cost (2-h^2)/(1-h^2) for0<h<1 and limit2 as h tends to0 from above although its Gram inverse becomes singular.')
rt('Counterexamples','R1-AT1','norm_first_strictly_weaker_control','Constant B_n=exp(theta*T_n),S_n=1 has equal energy rate theta but positive-rate raw energy difference; theta>0.')
rt('Counterexamples','R2-O2','history_recovery_cost_control','Rank-one target with history scale epsilon!=0 has minimum recovery norm1/|epsilon|; epsilon=exp(-aT) yields exponential cost.')
rt('Counterexamples','R2-S2','forced_positive_gram_nonreal_control','Positive diagonal A and real forcing g with h_i=kappa_i(A-kappa_i I)^-1g yield the same coupled Gram identities at specified nonreal parameters; prove positivity as applicable, not actual-zero existence.')
mod('Consumers','consumers',['@NativeTransformationWords','@MaskedNativeRate','@NativeWindowRate','@MovingSourceWindowRate','@RobustLaurent','@FiniteSpanSeparation','@FirstCellCost','@SquareDefect','@BoundaryAmplitude','@WeightedMixing','@NearGapLimits','@Counterexamples','Zeta23.ExceptionalZero.Step4OutputSufficiency'],['FollowupNativeOutput'],'Explicit actual-source consumers for arithmetic, multiplicity, co-Poisson, and source sampling. No single packet fabricates contact or real-profile equivalences.',True)
rt('Consumers',['R2-Q3','J5.2'],'fixed_two_factor_mask_rate_theta','On the fixed actual r2,d1,C2,Q1,K8 construction, both high-mask realizations have positive-part rate exactly Theta by proved native J5.2 plus the two-mask norm-first interface.')
rt('Consumers',['R2-Q3','J5.2'],'quiet_balanced_observation_implies_native_cut','Explicitly conditional: a proved cofinal zero-rate upper for this complete actual observation implies Theta=0 and literal d0 all-positive-damping L2 (then consumes existing Step4 cut). Preserve the upper as an open antecedent, never an unconditional RH root.')
rt('Consumers',['R1-NB1','R2-J1'],'step123_word_jet_consumer','For the existing same Step123CompleteOutput, construct actual original field/pole and full native word observation, preserving source, zero, multiplicity, damping and correction identities; optional contour premise explicit.')
rt('Consumers',['R1-CP1','R2-H1','R2-H2b'],'actual_zero_measure_span_consumer','Instantiate true zero profile/jet objects and all P0 separator premises on each actual finite real combination; derive the finite-span exclusion without assuming measure status.')
rt('Consumers',['R2-S1b','F1','F2','F3'],'actual_force_sampling_consumer','Compose actual lattice force, log-unitary profile, spectral density, sample identity and generic boundary amplitude with the two Fourier conventions explicitly related. No homogeneous eigenproblem conclusion.')

# Entry and audit modules. Import all mathematical leaves, never audits.
mathmods=list(mods)
facade={'module':NS,'path':'Zeta23/OPICAFollowup.lean','lane':'entry','trust_zone':'AUXILIARY_FORMALIZATION','semantic_role':'OPICA_GENERIC_FORMALIZATION','direct_project_imports':[NS+'.Consumers'],'required_definitions':[],'responsibility':'Public sibling entrypoint; leaves Zeta23.OPICA and the legacy root unchanged.','source_status':'PROPOSED_NOT_CREATED'}
mods.append(facade)
mods.append({'module':NS+'.Validation','path':'Zeta23/OPICAFollowup/Validation.lean','lane':'audit','trust_zone':'AUDIT_ONLY','semantic_role':'OPICA_AUDIT_ONLY','direct_project_imports':[NS],'required_definitions':['explicit expected type for every primary and companion clause'],'responsibility':'Typed consumers, physical source/constructor obligations, exact scope checks; not imported by facade.','source_status':'PROPOSED_NOT_CREATED'})
mods.append({'module':'Zeta23.RHRC.OpicaFollowupBindings','path':'Zeta23/RHRC/OpicaFollowupBindings.lean','lane':'audit','trust_zone':'AUDIT_ONLY','semantic_role':'OPICA_AUDIT_ONLY','direct_project_imports':[NS+'.Validation','Zeta23.RHRC.OpicaTypeExprExport','Zeta23.RHRC.DeclarationDependencyExport','Zeta23.RHRC.SourceCandidateResolution'],'required_definitions':[],'responsibility':'Own OPICA_FOLLOWUP_COMPILER_V1 protocol, enumerate all child public declarations/constructors and recursive TYPE/VALUE/STRUCTURE closure; reuse unchanged exportType codec only.','source_status':'PROPOSED_NOT_CREATED'})

# New files required for sources, integration and independently reproducible evidence.
create=[{'path':m['path'],'kind':'LEAN_SOURCE','responsibility':m['responsibility']} for m in mods]
nonlean={
'README.md':'One entry point, exact build commands, scope, unresolved claims and no partial-completion wording.',
'BUILD_SPEC.md':'Freeze this specification after base acceptance; amendments require explicit versioned review.',
'BUILD_MANIFEST.json':'Exact child source, edit, regeneration, module and command inventory.',
'PUBLIC_ROOTS.json':'Exact primary target names and expected statements; pending proof status until actual validation.',
'PAPER_CROSSWALK.json':'All26paper groups plusJ5.2/MS1, each subclause, root, physical consumer and rejection tests.',
'SOURCE_REGISTER.json':'Hashes of exact paper inputs, inherited checkers and adaptation provenance; source vs proposed names separated.',
'PARENT_INTAKE.json':'Parent head/tree/merge/event, compiler artifact identities, APIs, complete eventual workflow harvest and acceptance disposition.',
'PARENT_EXTENSION.json':'Exact validated extension of parent path/registry/config projections; no blanket namespace or count exemption.',
'PROTECTED_STATE.json':'Capture every parent tracked path/object from exact accepted pin, except this explicit edit/regeneration allowlist; APIs protected.',
'WORKFLOW_CONTRACT.json':'Required child jobs/lanes, raw receipt schemas, exact command contracts, reviewed type hashes after compilation.',
'REGRESSION_CONTRACT.json':'Frozen script hashes, group counts, expected39920 per mode,33numerical cases and numerical nonauthority.',
'POST_GREEN_RESEARCH.md':'Initially pending; complete actual source/type/workflow/research implications only after green.',
'validate_contract.py':'Fail closed on sources, groups, registry, roles, DAG, scope, protected state and type receipt requirements.',
'parent_extension.py':'Pure strict extension verification and lossless parent-view projection used by the one patched P0 validator.',
'capture_parent.py':'Read-only base/workflow intake and full source inventory; no inferred merge/approval or automatic rebase acceptance.',
'build_receipt.py':'Build exact selected targets and export/validate all child declarations and transitive dependencies; original builder remains unchanged.',
'replay_controls.py':'Run immutable check scripts with external output paths under normal and -O; compare group counts and hashes.',
'harvest_workflows.py':'Paginate all attached runs/jobs/attempts, collect actual dispositions and compare same mathematical fixtures.',
'dependency_delta.py':'Source-bound use graph and premise delta; shared deps do not imply equivalence.',
'requirements-checks.txt':'Lock SymPy1.14.0 and mpmath1.3.0 to the provided recorded exact/numeric environment; no Lean proof dependency.',
'python-checks.lock':'Platform-independent wheel/sdist SHA256 lock captured before network install; refuse unlocked downloads. Do not invent package digests.',
}
# Actual recorded package versions replace estimates if they differ.
end=ROOT/'paper_evidence'
for f in ['final_exact_normal.json','r2_normal.json','final_numeric.json']:
 data=json.loads((end/'receipts'/f).read_text())
 if 'sympy' in data: nonlean['requirements-checks.txt']='Pin SymPy '+data['sympy']+' and mpmath '+json.loads((end/'receipts/final_numeric.json').read_text()).get('mpmath','1.3.0')+' to the supplied receipt environment; lock downloads separately; numerical tests are not Lean premises.'
for n,p in nonlean.items(): create.append({'path':D+'/'+n,'kind':'INTEGRATION','responsibility':p})
tests={
'test_contract.py':'Full source/root/group inventory, duplicate IDs, invalid premises and altered source inputs.',
'test_parent_extension.py':'Reject unauthorized registry deletion/mutation, arbitrary allowlist expansion, source drift, missing descriptor, invalid parent and bypassed P0 proofs.',
'test_receipt.py':'Reject stale head/tree, missing constructor/helper closure, truncated type DAG, unapproved axioms, wrong command exit and SHA records.',
'test_coverage.py':'Reject absent subclauses, swapped j/q*j/Pj, toy-native substitution, actual source property as caller hypothesis, optional-bridge laundering.',
'test_workflow_harvest.py':'Pagination, latest attempts, canceled/still running/skipped dispositions, mixed-source artifacts and output meaning versus process success.',
'test_file_classes.py':'Preserve all preexisting first-match classification and roles; child native modules auxiliary, audit-only unreachable from facade.',
'test_dependency_delta.py':'Verify unchanged old theorem types/axioms/dependencies; no assumed logical consequence from shared edges.',
'test_regression_replay.py':'Normal/-O checks must run, frozen checker identities/counts retained; numerical status cannot promote mathematical claims.'}
for n,p in tests.items(): create.append({'path':D+'/tests/'+n,'kind':'TEST','responsibility':p})
paper_names=['OPICA_Followup_Final_Audited_Paper_2026-10-21.md','OPICA_Final_Theorem_and_Audit_Ledger_2026-10-21.json','OPICA_Final_Followup_Paper_Contract_2026-10-21.md','OPICA_End_to_End_Audit_Report_2026-10-21.md','OPICA_EndToEnd_Final_Release_Manifest_2026-10-21.json']
paper_sources=[]
for n in paper_names:
 data=(ROOT/'paper_inputs'/n).read_bytes(); paper_sources.append({'path':D+'/paper/'+n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source':n})
 create.append({'path':D+'/paper/'+n,'kind':'FROZEN_PAPER','responsibility':'Byte-identical final paper release input; paper/self-audit authority retained.'})
check_names=['frozen_round1_check_round1.py','frozen_round2_check_round2.py','check_final_exact.py','replay_copoisson_numeric.py','frozen_round2_check_round2_numeric.py','check_final_numeric.py']
check_sources=[]
for n in check_names:
 data=(end/'checks'/n).read_bytes();check_sources.append({'path':D+'/checks/'+n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source':n})
 create.append({'path':D+'/checks/'+n,'kind':'FROZEN_CHECKER','responsibility':'Unchanged paper finite/symbolic/numerical reproduction. Use existing P0 check_exact.py for the5112 baseline controls.'})
create.append({'path':'.github/workflows/rhrc_opica_followup.yml','kind':'WORKFLOW','responsibility':'Read-only parent-compatible checks, explicit proof lanes, aggregate current-tree receipts, regressions, generated-state check, and post-green harvest.'})
modify=[
('Zeta23/RHRC/RegisteredClaimBindings.lean','Append exact defining-module imports, #check and #print axioms for compiled child primary roots only; preserve all previous rows.'),
('research/RHRC/CLAIM_REGISTRY.json','Append one route-less supporting theorem object per accepted child primary root; explicit conditional premises retained. No existing object changed.'),
('research/RHRC/REGISTERED_THEOREM_BINDINGS.json','Append exact source/theorem bindings for same accepted child roots. No old binding changed.'),
('research/RHRC/graph/FILE_CLASSES.json','Insert only two child-specific rules before generic zeta_lean; preserve existing first-match meaning.'),
('research/RHRC/graph/SEMANTIC_CLOSURE_CONFIG.json','Append exactly the child standalone module roles; no existing config field or role changed.'),
('research/RHRC/tools/run_suite.py','Add child structural/unit test discovery and parent extension tests; preserve all prior tests and their command semantics.'),
('README.md','Add sibling public import, explicit build, scoped formal status, paper source and unresolved exclusions.'),
('research/RHRC/README.md','Add child integration navigation and evidence/classification conventions.'),
('research/RHRC/CURRENT_RESEARCH_PLAN.md','Record accepted mathematical state and Post-Green research questions; do not close independent obligations.'),
('research/RHRC/integration/opica/validate_contract.py','Narrow wrapper for a strictly validated child extension: project exact child registry/config contributions and augment exact delta allowlist before existing P0 checks; preserve all original frozen constants, roots, checks and release type audit.'),
('research/RHRC/integration/opica/tests/test_contract.py','Add integration tests for historical default behavior and registered child projection; do not remove or weaken original tests.'),
('research/RHRC/integration/opica/README.md','Document that immutable P0 theorem/spec inventory remains unchanged while one exact child extension is supported.')]

rules=[{'id':'opica_followup_audit','pattern':r'^Zeta23/(?:OPICAFollowup/Validation|RHRC/OpicaFollowupBindings)\.lean$','file_class':'LEAN_SOURCE','trust_zone':'AUDIT_ONLY'}, {'id':'opica_followup_math','pattern':r'^Zeta23/OPICAFollowup(?:/.*)?\.lean$','file_class':'LEAN_SOURCE','trust_zone':'AUXILIARY_FORMALIZATION'}]

# Exact source-derived frozen paper crosswalk, implementation targets newly proposed.
statements=[]
for r in ledger['records']:
 pid=r['id']; rec=r.get('source_record',r)
 statements.append({'paper_id':pid,'title':rec['title'],'paper_location':r['paper_location'],'source_premises':rec.get('premises'),'source_conclusion':rec.get('conclusion'),'source_scope':rec.get('scope_limit',rec.get('scope_limits',rec.get('scope'))),'source_authority':r['authority'],'required_roots':[t['full_name'] for t in roots if pid in t['paper_ids']],'coverage':'All source conclusion subclauses plus stated premises, source identities, domains and adverse controls. Presence/name-only coverage is insufficient.'})
for pid in ['J5.2','MS1']:
 statements.append({'paper_id':pid,'title':'Native fixed-source logarithmic-window rate' if pid=='J5.2' else 'Slowly changing native source logarithmic-window rate','paper_location':'Part II.1-II.4','source_authority':'INHERITED_PAPER_EXPANDED_IN_FINAL_MASTER','required_roots':[t['full_name'] for t in roots if pid in t['paper_ids']],'coverage':'Actual physical explicit formula, zero count, source norms, uniform completion, all-multiplicity residual and full limit; a generic rate hypothesis is not a replacement.'})

parent={'pr':293,'url':'https://github.com/HMarcusWH/zeta-23-lean/pull/293','head':HEAD,'head_tree':TREE,'base_main':BASE,'branch':'research/opica-obstruction-preservation','synthetic_merge':'875a321edf0362bbc170cc3177007c18172eeef0','observed_state':'OPEN_DRAFT_NOT_MERGED','final_acceptance':'PENDING_PARENT_PUBLICATION_HEAD_COMPLETION_AND_COMPLETE_HARVEST','compiler_evidence':{'pr_run':39586659233,'formal_job':119177561193,'requested_head':HEAD,'actual_checked_commit':'875a321edf0362bbc170cc3177007c18172eeef0','actual_checked_tree':TREE,'release_contract':'PASS_FROM_JOB_LOG','artifact_id':12342876090,'artifact_sha256':'1ffbc5055e27576599e957f3ad8a0a47ed5c69090d1281bd096d3e5cb4d3ad03','complete_artifact_bytes_downloaded_here':False,'root_count':76},'push_run':39586645608,'push_formal_job':119177298628,'latest_observed_push_steps':{'build_receipt':'SUCCESS','release_contract':'SUCCESS','materialize_derived_state':'IN_PROGRESS','generated_freshness':'PENDING'},'whole_pr_green_claimed':False,'review_scope':'Live metadata, selected proof APIs, exact validator/builder/workflow code and current formal-job log; not a complete independent review of613declarations or every research result.'}

jobs=[
 {'id':'followup-contract','class':'FORMAL_VALIDITY_GATE_STATIC','needs':[],'meaning':'Parent pin and exact source/coverage/protection/extension contract; static pass is not a proof.'},
 {'id':'followup-regression','class':'REGRESSION_GATE','needs':['followup-contract'],'meaning':'Unchanged39920 finite checks per mode including P0, child mutation/unit tests,33 numerical consistency cases explicitly noninterval-certified.'},
 {'id':'followup-formal','class':'FORMAL_VALIDITY_GATE','matrix':['local','arithmetic','heat','spectral'],'needs':['followup-contract'],'meaning':'Actual Lean targets per lane; missing foundation/measure/explicit-formula proof fails; no partial summary from successful easy lane.'},
 {'id':'followup-aggregate','class':'FORMAL_VALIDITY_GATE','needs':['followup-formal'],'meaning':'Build sibling facade, typed Validation, P0 audits, global registered bindings and child exporter at one clean tree; recompute complete merged compiler receipt.'},
 {'id':'followup-generated','class':'REGRESSION_GATE','needs':['followup-aggregate'],'meaning':'Existing canonical producer --check at current tracked tree; no CI repair or changed historical receipt.'},
 {'id':'followup-research-delta','class':'RESEARCH_PRODUCING_CHECK','needs':['followup-aggregate'],'meaning':'Exact clause/native-consumer and TYPE/VALUE/STRUCTURE delta, prior research dispositions; no equivalence inferred from graph connectivity.'},
 {'id':'followup-summary','class':'COMPLETENESS_GATE','needs':['followup-contract','followup-regression','followup-formal','followup-aggregate','followup-generated','followup-research-delta'],'meaning':'Fail on any missing/skipped/canceled/in-progress/failed required lane; record RH/Step4 OPEN and independent-review status separately.'}]

manifest={'schema':'OPICA_FOLLOWUP_PR_SPEC_V1','date':DATE,'status':'EXACT_PROPOSED_SPECIFICATION_NOT_IMPLEMENTATION','repository':'HMarcusWH/zeta-23-lean','parent':parent,'proposed_branch':'research/opica-native-followup','proposed_pr_title':'Formalize native OPICA transport, analytic window rates, and co-Poisson forcing','target_base_policy':'Stacked on the pinned PR293 head for preparation; merge only after accepted parent. If parent changes, explicit source/API/receipt rebase review and revised pin required. No implicit main fallback.','lean_toolchain':old['lean_toolchain'],'mathlib_commit':old['mathlib_commit'],'namespace':NS,'scope':{'paper_groups':26,'analytic_bridges':['J5.2','MS1'],'coverage_units':28,'all_required':True,'optional_in_this_spec':[],'note':'MS1 is unnecessary for fixed two-factor consumer but is deliberately included in full follow-up scope, not counted as new research. F1-F3 included.','excluded_closures':['RH','Step4','A-X','B-Y','C-Schur','OPEN-J46','D2/WP4','independent native boundary-amplitude exclusion']},'create':create,'modify':[{'path':p,'change':c} for p,c in modify],'delete':[],'rename':[],'modules':mods,'primary_roots':roots,'regenerate':old['regenerate'],'registry':{'parent_claims':198,'parent_bindings':194,'new_primary_count':len(roots),'expected_total_claims_after_full_proof':198+len(roots),'expected_total_bindings_after_full_proof':194+len(roots),'old_open_ids':old['registry']['old_open_ids'],'new_status_policy':'Route-less PROVED_UNCONDITIONAL for the exact quantified theorem/implication only after Lean+type review; no paper-only or plan rows in global registry; all legacy objects exact.'},'classification_rules':rules,'paper_sources':paper_sources,'regression_sources':check_sources,'new_jobs':jobs,'formal_lane_targets':{'local':[NS+'.NativeTransformationWords',NS+'.NormFirstTransfer',NS+'.JointObservation',NS+'.RobustLaurent',NS+'.Counterexamples'],'arithmetic':[NS+'.MaskedNativeRate',NS+'.NativeWindowRate',NS+'.MovingSourceWindowRate'],'heat':[NS+'.WeightedMixing',NS+'.NearGapLimits',NS+'.FiniteSpanSeparation',NS+'.FirstCellCost',NS+'.SquareDefect'],'spectral':[NS+'.BoundaryAmplitude',NS+'.SamplingCompatibility']},'required_final_build_targets':['Zeta23.OPICA','Zeta23.OPICA.Validation','Zeta23.RHRC.OpicaBindings',NS,NS+'.Validation','Zeta23.RHRC.OpicaFollowupBindings','Zeta23.RHRC.RegisteredClaimBindings','Zeta23.RHRC.DeclarationDependencyExport','Zeta23.RHRC.SourceCandidateResolution'],'protected_math':'All parent mathematical Lean sources including both original public roots unchanged; import them. Only modified Lean file is AUDIT_ONLY RegisteredClaimBindings.','compiler_status':'NOT_RUN_NO_NEW_THEOREMS','repo_writes':False,'full_parent_harvest_completed_here':False,'drive_upload_status':'UNAVAILABLE_IN_CURRENT_READ_ONLY_CONNECTOR'}

# Evidence labels are intentionally source-scoped, not a fabricated fresh full-tree receipt.
evidence={'schema':'OPICA_FOLLOWUP_PARENT_INTAKE_V1','observations':parent,'live_reads':[
 {'path':'Zeta23/OPICA.lean','git_blob':'b0e62430f93a6998aa208d17a1e46e605d72cd79','scope':'complete'},
 {'path':'Zeta23/OPICA/NativeJetAdapter.lean','git_blob':'e808791a35fa7240be1aa1059d2f83b156a18986','scope':'complete'},
 {'path':'Zeta23/OPICA/NativeArithmeticAdapter.lean','git_blob':'2f691dcb5b46a71f2dd69cf407b12c2858098498','scope':'complete'},
 {'path':'Zeta23/OPICA/LocallyFiniteSignedMeasure.lean','git_blob':'097f4bf09e3f32f7cb1cd534d2ee4502b98194eb','scope':'lines1-190'},
 {'path':'Zeta23/OPICA/EnergyRate.lean','git_blob':'2f0f55aa46beb7c81ea5c16e528b8e58fd58b745','scope':'lines1-120'},
 {'path':'research/RHRC/integration/opica/validate_contract.py','git_blob':'d0babd1faf37bd266f3281182ac4817d53213fde','scope':'complete'},
 {'path':'research/RHRC/integration/opica/build_receipt.py','git_blob':'a48bab881daaf9c8cfda71dd6b4f073888155660','scope':'lines1-160'},
 {'path':'research/RHRC/integration/opica/dependency_delta.py','git_blob':'a1ba6612b152540cb599f453bfc3d17f8193d93f','scope':'lines1-90'},
 {'path':'Zeta23/RHRC/OpicaTypeExprExport.lean','git_blob':'c024a973c2f03a9ae9138da96973a3b0ae2019c1','scope':'lines1-75 and155-200; public exportType : Lean.Expr -> IO String confirmed; unsafe memoization remains audit-only'},
 {'path':'Zeta23/RHRC/OpicaBindings.lean','scope':'initial section; truncated listing not complete exporter review'},
 {'path':'.github/workflows/rhrc_opica.yml','git_blob':'230f2ec40168e58cce1a4f98daecf6faa6201898','scope':'lines1-230'}],
 'previous_source_candidates':[
 {'path':'Zeta23/WeilEF/Main.lean','declaration':'Zeta23.WeilEF.EF_lit_zetaZeroConfig','scope':'Actual zeta compact-test EF exists; new translated native zero-series identification still required.'},
 {'path':'Zeta23/RvM/LocalCount.lean','declaration':'Zeta23.RvM.zetaZeroConfig_local_count','scope':'Actual zeta multiplicity-weighted local count; do not use similarly named XiPrime count.'},
 {'path':'Zeta23/CCM/UniversalSincInverseGevreyBounds.lean','declaration':'Zeta23.CCM.UniversalSinc.norm_iteratedDeriv_inverseCandidate_le_gevrey','scope':'Existing source regularity candidate; actual source-order norm identities remain to prove.'}],
 'source_candidate_authority':'Read in preserved parent-base source; require actual parent blob/type match at implementation intake. Not a new local compiler run.',
 'operational_incidents':['Initial default Python startup timed out; used /usr/bin/python3 -S for stdlib specification generation.','Attempted raw repository archive transport was unavailable; no claim of full live-tree reconstruction.','Drive discovery returned29read-onlyfunctions and no upload/create; plugin search confirmed Drive installed. No upload fabricated.'],
 'new_Lean_roots':0,'new_CI_runs':0,'repo_writes':False}

extension={'schema':'OPICA_FOLLOWUP_PARENT_EXTENSION_V1','parent_head':HEAD,'parent_tree':TREE,'parent_frozen_spec_base':BASE,'child_id':'OPICA_FOLLOWUP_V1','child_namespace':NS,'new_exact_paths':[x['path'] for x in create],'modified_exact_paths':[x['path'] for x in manifest['modify']],'generated_exact_paths':manifest['regenerate']['paths'],'child_claim_ids':[r['id'] for r in roots],'child_classes':rules,'child_roles':{m['module']:m['semantic_role'] for m in mods},'invariants':['Original P0 metadata76roots25families50create9modify26modules and all frozen input hashes unchanged.','No P0 mathematics modified; no backward import of child into P0.','Full current raw registry equals protected parent objects union exact accepted child objects, not an arbitrary superset.','Raw config equals parent config plus exact two class rules and exact child roles; existing classifications identical.','Project validated child additions only for original P0 metadata/global-context predicates. Do not filter source code, axioms, compiler types or parent declaration evidence.','The parent diff allowlist is extended only by validated exact child paths and exact authorized edits; extra path fails.','P0 formal receipt is rebuilt at current checkout and validated by unchanged compiler/type/axiom code.','Absent/malformed child descriptor while any child marker/path/claim exists fails closed; historical checkout without child uses old path unchanged.','New extension tests prove old validation fails before projection and passes only for valid exact extension.']}

for name,data in [('OPICA_FOLLOWUP_BUILD_MANIFEST_2026-10-21.json',manifest),('OPICA_FOLLOWUP_PUBLIC_ROOTS_2026-10-21.json',{'schema':'OPICA_FOLLOWUP_ROOTS_V1','namespace':NS,'roots':roots}),('OPICA_FOLLOWUP_PAPER_CROSSWALK_2026-10-21.json',{'schema':'OPICA_FOLLOWUP_CROSSWALK_V1','paper_sha256':paper_sources[0]['sha256'],'scope_units':statements}),('OPICA_PR293_INTAKE_2026-10-21.json',evidence),('OPICA_FOLLOWUP_PARENT_EXTENSION_2026-10-21.json',extension)]:
 (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
# Full project dependency graph, child nodes and referenced existing modules.
dot=['digraph OPICA_Followup {','  rankdir=LR;']
for m in mods:
 dot.append('  "'+m['module']+'" [shape='+('box' if m['trust_zone']=='AUDIT_ONLY' else 'ellipse')+'];')
 for d in m['direct_project_imports']:dot.append('  "'+d+'" -> "'+m['module']+'";')
dot.append('}')
(OUT/'OPICA_FOLLOWUP_IMPORT_DAG_2026-10-21.dot').write_text('\n'.join(dot)+'\n')
print(json.dumps({'modules':len(mods),'mathematical':sum(m['trust_zone']!='AUDIT_ONLY' for m in mods),'new_files':len(create),'modify':len(modify),'primary_roots':len(roots),'coverage_units':len(statements),'registry_final':manifest['registry']},indent=2))
