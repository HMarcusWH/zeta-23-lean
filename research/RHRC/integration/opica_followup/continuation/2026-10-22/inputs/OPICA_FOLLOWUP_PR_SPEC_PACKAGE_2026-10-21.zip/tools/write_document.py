from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]; O=R/'deliverables'
m=json.loads((O/'OPICA_FOLLOWUP_BUILD_MANIFEST_2026-10-21.json').read_text())
c=json.loads((O/'OPICA_FOLLOWUP_PAPER_CROSSWALK_2026-10-21.json').read_text())
n=len(m['primary_roots']); ns=m['namespace']; head=m['parent']['head']; tree=m['parent']['head_tree']
s=[]
def add(t=''):s.append(t)
add(f'''# OPICA native follow-up — exact PR build specification

**Date:** 21 October 2026  
**Repository:** `HMarcusWH/zeta-23-lean`  
**Parent:** PR #293, inspected source head `{head}`  
**Tree:** `{tree}`  
**Proposed branch:** `research/opica-native-followup`  
**Proposed title:** Formalize native OPICA transport, analytic window rates, and co-Poisson forcing  
**Authority of this document:** implementation specification, not a new theorem or compiler receipt.

## 0. Decision and complete deliverable

Build an additive **sibling** library with public import `Zeta23.OPICAFollowup`. Preserve `Zeta23.OPICA`, all existing mathematical source files, the legacy default import, the toolchain and the historical claim objects. Add an exact, fail-closed child-extension protocol to the parent **validator**, because its current closed inventories correctly reject arbitrary subsequent changes.

This specification elects the **full paper scope**: all 26 result/control groups in the final audited paper, and both direct analytic bridges J5.2 and MS1. MS1 is not needed by the fixed two-factor arithmetic application, but it is included here as a distinct obligation. F1–F3 are included, not deferred. The 25 first-PR families are prerequisites and are not counted again. No independent closing estimate is assumed or claimed.

The exact proposed footprint is **{len(m['create'])} new files**, including **{len(m['modules'])} Lean files** (41 mathematical/facade files and two audit files), **{len(m['modify'])} existing authoritative files modified**, and the **62 existing generated outputs** refreshed through the existing producer. There are no deletions or renames. The generated list is a regeneration allowlist, not a requirement to manufacture different bytes in every file. No existing mathematical Lean body is edited; the only modified `.lean` file is the global audit binding file.

The target interface contains **{n} primary theorem roots**, covering **28 acceptance units**: 26 paper groups plus two inherited analytic bridges. These are proposed declaration names, not claims that {n} proofs have already been written. All additional public definitions, helper theorems, structures, constructors, and transitive private project dependencies must also be exported and audited. There is no fixed predicted helper-declaration count.

The attached JSON manifests and root inventory are normative with this document. File or signature refinements require an explicit versioned amendment and regenerated coverage checks; they must not silently remove a difficult statement. A staged implementation is allowed, but an intermediate slice must remain labelled partial and cannot be merged under the full completion claim.

## 1. Exact parent state and acceptance boundary

The fresh PR metadata reports **open, draft, unmerged**. Main remains the PR #292 base `97926d6a949fed7af0429a373b47abc772012834`. The inspected branch is `research/opica-obstruction-preservation`.

At the inspected head, OPICA PR-event run `39586659233` has five successful component jobs. The formal job `119177561193` actually checked synthetic merge `875a321edf0362bbc170cc3177007c18172eeef0`, whose tree is the same `{tree}`. Its log records a clean checkout, a completed compiler receipt, all 76 primary roots present, and a successful release-contract check. Artifact `12342876090` is `opica-formal.zip` with uploaded ZIP SHA-256 `1ffbc5055e27576599e957f3ad8a0a47ed5c69090d1281bd096d3e5cb4d3ad03`. The artifact's complete bytes were not downloaded for this specification; that digest is log-reported, not a fresh local hash calculation.

The parallel push run `39586645608` was still performing canonical materialization at the last detailed job read. Its compiler and release-contract steps had succeeded; generated-state freshness was pending. The current source-inertia research workflow also still had pending work. Therefore this specification does **not** certify the whole parent PR green or merged. The earlier checkpoint report at `567d78de11ee3e3b7ae7e455fab0bf096ce90c34` is historical evidence, not the current publication head.

### 1.1 Base policy

Implementation may be prepared as a local stacked branch from the pinned head above. Its acceptance base is the **eventually accepted #293 result**. Before marking the follow-up ready, record the accepted parent commit/tree, its actual compiler receipts, API/type fingerprints, constructor inventory, complete paginated job harvest, generated-state freshness and review disposition. If the accepted tree changes, compare the exact mathematical/API and validation surfaces and issue an amended pin. Do not fall back to old main or infer that a merge commit is a tested head.

A merge commit with the same tree can preserve source identity; its new commit identity still needs a fresh provenance record and the appropriate checkout tests. The parent requirement is not human independent review by fiat: compiler authority and human review status remain separate. A pending independent review must remain marked pending even when compiler gates pass.

### 1.2 What was actually inspected for this specification

Fresh live reads covered PR metadata, commit/tree metadata, workflow summaries, detailed OPICA job steps and the formal-job log; the public facade; actual native jet and arithmetic adapters; portions of the real locally finite measure and rate modules; the exact closed validator, receipt builder, exporter and workflow. The attached final paper/ledger/contract and the named relevant historical source bodies were inspected locally. This was not a new full semantic review of every repository theorem or all 16,159 historical pages.

The parent log supports the current 76-root release result. The 613-public-declaration/eight-constructor/143-consumer counts in the PR body describe its reported implementation/checkpoint inventory; this turn has not independently parsed all current type DAGs. The follow-up intake must obtain and validate those artifacts, not merely copy those numbers.

## 2. Frozen mathematical sources and authority

The controlling source is `OPICA_Followup_Final_Audited_Paper_2026-10-21.md`, SHA-256 `9525d5dad6f0a2e3abd6050edeb39e3a234b6a361046e746878a181970a789f0`. Its final ledger, contract, audit report and manifest are copied without changes into the new integration package's `paper/` directory. The PDF is a release artifact, not a second competing proof source in Git.

The paper has PAPER/DERIVED self-audit authority. Compilation changes authority only for exact accepted declarations, not for the paper as a whole or for its OPEN research goals. Preserve its terminology: source order, zero multiplicity, inverse-factor count, completion index, completion depth, palette, compact probe and spectral parameter are distinct.

**In scope:** R1-NB1/AT1/AT2/HT1/HT2/CT1/MC1/CP1; all fifteen R2 families; F1/F2/F3; fully native J5.2 and its explicitly scoped MS1 extension. The constant-scale countercontrols remain countercontrols, not actual zeta counterexamples. Classical analytic formulas are imported from proved declarations or actually proved in their assigned module; citations alone are not Lean imports.

**Not promoted:** RH, Step 4, A-X, B-Y, C-Schur, OPEN-J46, D2/WP4, native boundary-amplitude exclusion, universal impossibility of a class of RH proofs, or global novelty. The conditional quiet-observation consumer keeps its independent upper premise visible.

## 3. Findings from #293 that determine this design

### 3.1 Reuse real source adapters rather than their names

`Zeta23.OPICA.NativeJetAdapter` builds the actual completion and completed-input order witnesses from the existing physical transform theorems. Its completed-input jet and same-state output consumers are useful concrete inputs. However, `native_kernel_completion_consumer` still accepts a supplied `SimplePoleData`. It is not already a construction of the actual prime field's meromorphic pole datum. The follow-up's `nativePrimeField_visiblePole` must supply that missing source-specific datum from the physical transform identity and actual multiplicity.

`NativeArithmeticAdapter` already provides `nativeOriginalBoundedCausalDrive`, the actual original-j low-mask bound, `finitePaletteDrive`, `squarefreePaletteDrive`, and exact absolute palette cost. Reuse them. They do not, by naming, provide every higher differential source or higher forward convolution used in Q2/Q3. The new family begins with exact order-zero equalities to the existing objects and proves its higher-order support, moments, transforms and bounds.

### 3.2 Reuse the actual schedule and measure representations

Use `Zeta23.OPICA.HorizonSchedule`, `magnitudeRate`, `positiveRate`, and `SubexpAlong`; do not define subtly different copies. The norm-first theorem is a new Hilbert-space result using those rates, not the old stronger absolute squared-energy comparison renamed.

The parent `LocallyFiniteSignedMeasure` is a **real Jordan pair with local finiteness and mutual singularity**, not a globally finite signed measure and not a complex-measure API. The new zero profiles and jets are initially complex. `ComplexLocalMeasures.lean` must supply a faithful complex locally finite construction, compact restrictions, variation control, arithmetic and real/imaginary extraction, and prove compatibility with the parent's real separator. A formal distribution with a claimed positivity field is not acceptable.

### 3.3 Do not take the similarly named wrong zero-count theorem

The preserved source contains `Zeta23.RvM.zetaZeroConfig_local_count` and `Zeta23.WeilEF.EF_lit_zetaZeroConfig`. Those are actual zeta inputs. `Zeta23/XiPrime/ZeroCount.lean` concerns zeros of xi-prime and is not the relevant substitute. The native translated explicit-formula specialization still needs to be constructed; the existence of an explicit-formula module does not by itself discharge that source identification.

These existing declarations must be matched to the accepted parent blobs and exact types at implementation intake. Their bodies were inspected in the preserved source, not freshly recompiled here.

### 3.4 The existing audit is intentionally closed

The current parent `validate_contract.py` requires exactly 76 parent roots, 25 paper families, the original file inventory, exactly 198 global claim objects and 194 theorem bindings, and the parent-only semantic configuration. It also rejects tracked or untracked changes outside the first PR's allowlist against the old #292 base. The existing OPICA workflow runs on later main-targeting PRs, so a naive new namespace alone does not solve this.

The first implementation also deliberately classifies native OPICA adapters as `AUXILIARY_FORMALIZATION`, since the frozen source-only RH_FORMAL_CORE producer admits CCM/ExceptionalZero names. Retain that decision. Every child mathematical file receives auxiliary classification with an explicit native semantic role where applicable. Registered claims and compiler/source bindings, not misclassification, provide visibility.

## 4. New file inventory

The following list is exact. The responsibilities are acceptance obligations, not merely documentation headings. Project imports are listed separately in the attached manifest; Mathlib helper imports remain on the frozen revision and must be recorded in the actual source receipt.
''')
add('| New Lean file | Lane | Responsibility |\n|---|---|---|')
for x in m['modules']:
 add(f"| `{x['path']}` | {x['lane']} | {x['responsibility']} |")
add('''
### 4.1 Integration, tests and frozen inputs

The new integration directory is `research/RHRC/integration/opica_followup/`. It does not replace the parent `opica/` package. Its source manifests are committed; source-specific runtime receipts remain workflow artifacts to avoid a self-referential commit hash.
''')
add('| New non-Lean file | Responsibility |\n|---|---|')
for x in m['create']:
 if x['kind']!='LEAN_SOURCE': add(f"| `{x['path']}` | {x['responsibility']} |")
add('''
The dependency lock is populated from real package artifacts before the implementation's CI is accepted. It is not supplied with invented wheel hashes. The frozen receipts record SymPy 1.14.0 and mpmath 1.3.0; the original final audit used Python 3.13.5. Use Python 3.13 for this symbolic/numeric replay lane and record its exact patch version. Parent audit jobs keep their existing Python 3.14 contract. The Lean toolchain and Mathlib pin are unchanged.

## 5. Existing files changed, and files protected
''')
add('| Existing authoritative file | Allowed change |\n|---|---|')
for x in m['modify']:add(f"| `{x['path']}` | {x['change']} |")
add(f'''
No other existing authoritative file may change under this specification. In particular, protect all mathematical sources in `Zeta23/OPICA/`, `Zeta23/CCM/`, `Zeta23/ExceptionalZero/`, other historical mathematics and `comparator/`; protect `Zeta23.lean`, `Zeta23/OPICA.lean`, `lakefile.toml`, `lake-manifest.json`, `lean-toolchain`, `formalization.yaml`; protect all existing workflows, parent exporters/builders/type expectations and frozen P0 manifests; protect historical route data and first-PR provenance reports. The parent README and validator/test files listed above are the only parent-package exceptions.

The new `PROTECTED_STATE.json` is captured from the exact accepted parent checkout **before implementation changes**. It lists every parent tracked file with Git blob and SHA-256, then the exact exceptions above and the 62 generated products. It also captures all 198 parent claim objects, all 194 parent binding objects, parent module roles/classification behavior, and all four OPEN claim IDs. Capturing this against a different main or after modifications is a failure.

This specification includes a scope-labelled parent intake, not a falsely claimed fresh hash of every file in the remote tree. The prior source-derived inventory and successful parent validation help navigate; the complete accepted-parent capture remains a mandatory start gate.

At full completion, adding the {n} listed primary roots yields **{m['registry']['expected_total_claims_after_full_proof']} claim objects and {m['registry']['expected_total_bindings_after_full_proof']} registered theorem bindings**, provided the accepted parent retains its 198/194 inventory. These counts are consequences of the exact ID sets, not substitutes for checking their contents. Every existing object remains unchanged. Additional helper declarations are audited but not automatically promoted to primary registered claims.

## 6. Exact parent-extension protocol

This is the only deliberate change to the parent's validation behavior. Its purpose is to validate a child, not to allow an arbitrary descendant to bypass parent checks.

1. **Historical default remains exact.** With no child descriptor, child source path, child role or child claim present, execute the existing P0 validation unchanged. Missing or malformed child metadata when any child marker exists is an error, not an opt-out.
2. **Recognize one explicit extension ID.** Load `opica_followup/PARENT_EXTENSION.json` through the new audited helper. Check the pinned parent identity, the frozen child specification/root/crosswalk hashes, the full expected path inventory and the exact authorized edits. Reject path traversal, duplicate IDs, symlink escapes and unlisted targets.
3. **Validate raw current state before projection.** The raw global registry must equal the protected parent objects plus exactly the child objects. All parent values must match, not merely IDs. The same rule applies to bindings, roles and class rules. Child claim names alone are not validation.
4. **Project only the validated additions.** For the existing P0 global-context predicates, remove exactly the validated child claim/binding objects and the two child class rules/role entries. The resulting view must equal the original expected P0 state. No source, proof, axiom, constructor or compiler-dependency record is filtered out to make a theorem pass.
5. **Extend the file-diff allowlist exactly.** Against the frozen #292 baseline, the cumulative allowed delta is the original P0 inventory plus this child manifest's exact creates/modifications/regenerations. Against the accepted #293 baseline, only this child delta is allowed. Both checks apply. No wildcard such as “ignore all OPICAFollowup files” is permitted.
6. **Preserve formal validation.** Run the original P0 receipt builder and release checker at the current clean checkout. The full P0 mathematical types, expected hashes, constructor fields, standard-axiom limits and recursive dependency closure are still checked. The parent's historical compiler hash is not a replacement for rebuilding its unchanged source in the child environment.
7. **Verify absence of back edges.** No P0 mathematical module imports the child; no existing mathematical declaration acquires a child dependency. Global audit imports are the sole intentional downstream addition.

The new helper exposes `validate_extension_context(raw_state, parent_baseline, child_contract)`, `project_parent_context(validated_context)` and `allowed_child_delta(validated_context)`. It is pure: it must not invoke the parent validator, child validator, compiler or a subprocess, avoiding a circular validation call chain.

The wrapper in `opica/validate_contract.py` should be small. Its pure original predicates remain testable against historical fixtures. The helper performs strict verification and returns a read-only projected context plus the exact additional path set. It may not override a failed original result or provide fabricated compiler rows. Keep original frozen constants and expected P0 totals; they apply to the projected P0 view. The child validator separately checks the full totals and raw state.

### 6.1 Required negative tests

The test suite must reject: an unlisted extra file; an extra child-looking claim; a duplicate existing theorem name; a changed old claim body; a changed old binding; missing extension metadata; malformed/wrong-base metadata; a new classification rule shadowing a parent file; arbitrary namespace permission; a changed old mathematical file; a dropped parent constructor; a new type premise hidden in a structure; a stale/mixed-tree compiler receipt; a nonzero compiler exit recorded as pass; incomplete dependency channels; a child module imported by P0; and a missing full-scope statement despite successful easy lanes.

Tests must also demonstrate that the original closed validator rejects the raw legitimate child additions before projection, and that the verified projection restores only the old contextual expectations. Run the original test suite unweakened and the new extension tests in normal and optimized Python.

## 7. Precise mathematical boundaries and source definitions

### 7.1 Actual source family

Define `sourceOrderFamily d` by applying the fixed differential operator P^d to `CCM.nativeOriginalSource`, and prove equality to the actual P^(d+2)q construction. Define fields through actual locally finite histories, not by inverse-transform declarations selected for convenience. The order-zero source/drive/field equalities are named roots. Let `g=log 2-s0`, with s0=1/4096, and prove causality for every required member.

`forwardKernel d ell` is the ell-fold actual integer translate action on the d-th drive. Its transform identity is first a convergent integral statement on Re z>1/2. Entire continuation and later inversion follow through proved estimates. No artificial field is permitted merely because it has the target RHS transform.

Finite causal words may have exponential growth and need not be tempered distributions on Schwartz space. Represent their derivative histories on compact tests, or by an equally explicit causal state class, and establish Laplace identities on a common genuine half-plane. A derivative of a zero extension retains its boundary delta derivatives. Do not reuse the tempered heat-measure space indiscriminately for this time-domain state.

Actual-zero theorems consume the existing `zetaZeroConfig` carrier, analytic multiplicity and reflection infrastructure. No simplicity premise, minimum displacement or attaining-zero assumption may be added. A general source structure is allowed as a reusable interface only when its actual constructor discharges every field; its “native” use cannot take the desired rate, range membership, self-duality, sign or transform identity as a caller premise.

### 7.2 Arithmetic and complex Hilbert comparisons

AT1 is genuinely the norm-first estimate in a real or complex Hilbert space. The native gcd sums may use the existing real drive API, but the generic estimate must not be quietly narrowed to real scalars. Positivity refers to the positive part of a real signed quadratic, not to every masked bilinear matrix being PSD.

The primitive low mask is `max(d,e)/gcd(d,e) <= B(t)` and includes the diagonal; the high mask is its strict complement. It is not “both primitive indices exceed B.” Cutoffs must be measurable. For kernel absorption, prove both low-mask budgets and the exact regrouping identity, not just equality of the scalar fields.

For Q3, r, d, C, eta and K are fixed before the horizon limit; the palette is fixed throughout its window and Q(T)<=T^eta. Pay both mass and maximum shift i log Q(T). The concrete instance is r=2,d=1,C=2,Q=1,K=8 and uses Pj. It gives polynomial powers of log X around sqrt X and a negligible Type I error, not a signed upper for the retained field.

### 7.3 J5.2 and MS1: no opaque native-rate premise

The source-parametric compact-test explicit formula, analytic zero multiplicities, actual zeta zero count, source-regularity cost, true drive L2 bound, beta filter, endpoint atom, actual Poisson sum, uniform completion ratios, Laguerre normalization, finite-residual support and terminal-memory inequality must all be bound to proved imports or new proofs. The master paper specifies the equations in Part II. The files above allocate every one of these obligations.

`native_fixed_source_window_rate` must end with the full continuous limit for each fixed source and C>1. `native_slow_source_window_rate` separately retains d_n log(d_n+2)=o(T_n), fixes a chosen hypothetical zero before each limit argument and prices both signs of the source multiplier's logarithm. The proof uses a supremum, not a rightmost zero. For an arbitrary cofinal real sequence, positivity holds eventually; normalize or discard a finite prefix before invoking HorizonSchedule and transfer back by eventual equality, rather than narrowing the native limit claim. Exact compensation means the field is independent of the palette; palette expansion estimates are not hidden inside MS1.

No unconditional theorem named RH or A-X is added. The final quiet-observation consumer is explicitly an implication with the complete signed upper as an open hypothesis. A successful compiler run for that implication cannot promote its antecedent.

### 7.4 Co-Poisson objects are measures before separator use

Use heat Fourier convention exp(-2pi i x xi). Define the renormalized K_t before integrating; neither divergent comb component is assigned a separate convergent integral. Prove entire tempered-family convergence on Schwartz tests. Then prove local total-variation convergence of actual cutoff measures to the explicit density/origin formula. Only after this identification are “measure”, “gap”, “sign” and Jordan parts legitimate.

For actual zeros retain 0<Re rho<1, rho!=1/2 and b_rho=(1-2rho)/(rho(1-rho)). Parameter derivatives stop at actual multiplicity minus one. Reflection rho and1-rho gives the same kappa and must be quotiented before the confluent determinant. Conjugates are retained when constructing real combinations. All native constructions prove their own growth; they do not assume a generic `isMeasure` or a wanted separator hypothesis.

For S1, h=1-g is continuous L1/L2, selfdual and plateau1, but not asserted positive. The forced Euler equation retains every integer atom. It is a form-domain identity, not an eigenfunction of a homogeneous L2 operator. The ordinary exact-cell formula and endpoint jumps must be proved before integration by parts across infinitely many cells.

### 7.5 F1–F3 keep the arithmetic force and both Fourier conventions

In log coordinates use exp(-i xi t), Plancherel factor1/(2pi). Define w(t)=exp(-t/2) frac(exp t) and the tempered force g=-(D+1/2)w. The expression N-exp(t/2)dt is first an equality on compact tests; those two growth terms are not independently transformed as tempered distributions.

The spectral measure is `|zeta(.5+i xi)|^2 dxi/(2pi)` with finite integral of 1/(xi^2+1/4), not finite total mass. The Stieltjes transform is defined off the real spectrum [1/4,infinity), and holomorphy uses locally uniform absolute bounds. For an off-line zero kappa is nonreal. Actual sample sums are identified through a continuous H^-1,H^1 pairing and justified endpoint limits; generic L2 point evaluation is not used.

Use the undivided multi-zero identity at conjugate-coincident parameters. Do not divide by a critical-line zero's vanishing imaginary part. The full master also mentions removable almost-everywhere quotients for actual critical-line zeros: retain that remark as unpromoted unless a separately specified proof is supplied. It is not a blanket principal-value theorem required to interpret the nonreal F2 statement.

F3 is a generic forced resolvent with its exact zeta boundary amplitude. Its plateau equivalence is a diagnostic representation, not independent exclusion. The generic profile is in the log form domain but need not be L1 in the physical variable.

### 7.6 Recovery and Laurent controls

Use P0's exact linear-algebra observation APIs when constructing the joint map A=(P,C). Derive the optimum norm, handle the zero-map/zero-target convention, extend by orthogonal projection and retain all history errors. The theorem does not construct cheap recovery for a particular native contrast unless that application's hypotheses and cost are proved.

A Laurent estimate requires a common meromorphic neighborhood of the closed disk, positive radius and no extra interior pole. Degree is an integer j>=-1. The coefficient error is r^(-j)E; unnormalized derivatives add j!. The strict survival test prices the actual native leading coefficient, changing depth, radius, corrections and observation errors. Compact-time convergence is not substituted for this topology.

## 8. Exact theorem/root crosswalk

The attached `OPICA_FOLLOWUP_PUBLIC_ROOTS_2026-10-21.json` is the normative declaration inventory. Every entry fixes a name, defining file, paper IDs, statement contract, required hypotheses, disallowed substitutes and an expected-type consumer name. Its names are newly proposed, not existing imports.

Below is the source-level family map. The executable crosswalk must test every listed subclause, not just the presence of one theorem name in each family.
''')
for g in c['scope_units']:
 add(f"### {g['paper_id']} — {g['title']}\n\nSource: {g['paper_location']}.\n")
 if g.get('source_premises'):add('Source hypotheses: '+g['source_premises']+'\n')
 if g.get('source_conclusion'):add('Source conclusion: '+g['source_conclusion']+'\n')
 if g.get('source_scope'):add('Scope limit: '+g['source_scope']+'\n')
 for r in m['primary_roots']:
  if g['paper_id'] in r['paper_ids']:
   add(f"- `{r['full_name']}` in `{r['path']}`.")
add('''
## 9. Imports, build entrypoints and proof-lane wiring

The attached DOT graph is directed from dependencies to consumers. The manifest gives every direct project import. Use narrow defining-module imports where possible; do not make a new root import the global registered audit.

```text
existing P0 local/jet/native APIs
  -> actual source family/transforms -> concrete native filters/words
  -> robust Laurent observations -> same-state native consumers

existing P0 rate/mask/divisor APIs
  -> norm-first transfer + actual binomial coefficients
  -> source vertical bound + moving-left-line zeta bound
  -> actual forward localization -> logarithmic-slack arithmetic
  -> both low masks -> retained-rate comparison

actual compact-test EF + actual zeta local zero count
  -> source-specific explicit formula + uniform source costs
  -> explicit auxiliary completions + all-multiplicity tail residual
  -> native fixed-source J5.2 -> native slow-source MS1
  -> retained-rate = Theta consumer

P0 real locally finite measures + sinc/triangle pairing
  -> compatible complex locally finite measures + actual scaled combs
  -> weighted mixing / near-gap limits / renormalized co-Poisson family
  -> actual zero profiles + finite jets + Hermite independence
  -> finite-span separator and first-cell cost / square defect

actual profile + actual log Fourier/Sobolev conversion
  -> forced Euler + exact sampling compatibility
  -> sawtooth force + weighted positive spectral measure
  -> actual Stieltjes samples + generic forced boundary amplitude

all complete mathematical consumers
  -> Zeta23.OPICAFollowup
  -> Zeta23.OPICAFollowup.Validation
  -> Zeta23.RHRC.OpicaFollowupBindings [AUDIT_ONLY]
```

The sibling facade imports `Consumers`, which transitively reaches every new mathematical module. `Validation` and the RHRC exporter are unreachable from that facade. Original `Zeta23.OPICA` and `Zeta23` closures remain unchanged. The global audit `RegisteredClaimBindings` imports accepted child defining modules only downstream.

The four proof lanes are compilation units, not four independent claims of completion:

- `local`: actual word/jet targets, norm-first and joint recovery, with their source prerequisites;
- `arithmetic`: localization, exact balanced masks and both native window bridges;
- `heat`: full order-zero co-Poisson, weighted/near-gap statements, jets, sign budgets and square controls;
- `spectral`: exact profile, log form, source moment, Stieltjes sampling and boundary amplitude.

The exact lane target lists are in `formal_lane_targets` in the manifest. For each lane execute `lake build` on those targets, using the current checkout. `Consumers`, the facade, typed Validation and all audit targets are built by the aggregate command even when all lane builds passed.

Shared prerequisites may build in more than one lane. This does not count their theorem authority twice. Cache keys include toolchain, Mathlib revision and relevant source tree; no stale .olean is accepted as proof of a changed statement. The aggregate job builds every final target and re-exports one source-bound receipt on the same clean tree.

## 10. Compiler proof/type/source contract

The new exporter reuses `Zeta23.RHRC.OpicaTypeExprExport.exportType` without modifying its lossless DAG codec or budgets. It has its own `OPICA_FOLLOWUP_COMPILER_V1` protocol and an explicit defining-module whitelist. Do not mutate parent receipt-builder globals or make the parent primary count variable.

For every child public declaration record name, kind, actual defining module, complete untruncated type DAG, universe/binder information and standard-axiom closure. Record constructor types and fields for every child structure/inductive family. Traverse TYPE, VALUE and STRUCTURE dependencies through private project helpers, retaining source bindings and the explicit Mathlib boundary. Reject sorryAx, all unapproved project axioms, unsafe proof escape and a substituted source proposition. The permitted ordinary proof axioms remain propext, Classical.choice and Quot.sound.

Before using a primary root as accepted, `Validation.lean` must contain an independently written expected type for the intended mathematical statement. A bare `#check name` or a copied actual inferred type is not enough. Crosswalk clauses name their expected-type consumers and actual constructors. Compile them, then review/export full types and freeze approved type hashes. Do not prepopulate those hashes from an uncompiled plan, or auto-approve a changed type because the same source file generated it.

The aggregate receipt must bind requested parent/head, actual checkout commit/tree, synthetic merge parents where applicable, all new and modified authoritative file hashes, toolchain/Mathlib pins, each exact command and exit code, primary/helper/constructor inventories, and private dependency closure. Revalidate that source bytes did not change during compilation. External artifact digest verification is a separate integrity step. All receipt artifacts must belong to the same checked tree; no mix of successful easy-lane logs from different revisions.

Physical consumers are compulsory for native statements. In particular: actual j_d and its drive cannot be replaced by a generic source satisfying a claimed rate; the prime pole datum is constructed, not supplied; the co-Poisson object is proved to be a measure; Fourier duality is proved, not stored as an undisclosed field in a native instance; the sampling force remains present; and the conditional closing consumer visibly requires its still-open upper.

## 11. Registry, graph and canonical derived products

Add the exact child primary names under the `OPICA_FOLLOWUP_` claim-ID prefix after successful proof/type review. Preserve every old claim and binding byte-semantically, including the four OPEN IDs. New generic implication claims describe the implication exactly; “PROVED_UNCONDITIONAL” for a quantified theorem does not prove its mathematical antecedent. No new RH route or unconditional RH claim is introduced.

Insert these two rules before generic `zeta_lean`, and no broad override:

```text
opica_followup_audit
  ^Zeta23/(?:OPICAFollowup/Validation|RHRC/OpicaFollowupBindings)\\.lean$
  LEAN_SOURCE / AUDIT_ONLY

opica_followup_math
  ^Zeta23/OPICAFollowup(?:/.*)?\\.lean$
  LEAN_SOURCE / AUXILIARY_FORMALIZATION
```

Every new module gets its explicit standalone role, matching the current parent's role vocabulary for generic/native/audit entries. Preserve all previous first-match classifications. The child remains visible through its registered theorem objects and actual dependency export; do not relabel it as RH_FORMAL_CORE just to force source-only promotion.

Before generating canonical data, stage all new authoritative files: the existing source census uses tracked paths. Run the unchanged Linux producer over its complete existing output set:

```bash
python research/RHRC/tools/materialize_derived_state.py --write
python research/RHRC/tools/materialize_derived_state.py --check
```

The exact 62 paths are in the manifest and appendix. Commit only actual deterministic byte changes. Never hand-edit a generated graph, edit a historical snapshot, invent extra generated files to silence a checker, or refresh source hashes without regenerating the affected canonical outputs. Any later tracked documentation or source change requires the corresponding final refresh and check.

## 12. Workflows and regression requirements

Create `.github/workflows/rhrc_opica_followup.yml`. Keep every existing workflow byte-identical. Triggers are `pull_request` for `main` and the exact parent branch while the PR is stacked, push for `research/opica-native-followup`, and `workflow_dispatch`. Use read-only contents permissions; no workflow edits to branches, review approval, registry repair or generated-source commits. Pin third-party actions to the inspected immutable SHAs or separately reviewed replacements.

The parent workflow does not automatically run for every stacked parent-branch target, so the child workflow must explicitly run the P0 contract/build validation as part of its aggregate acceptance. Once targeted at main, inherited workflows remain part of the full acceptance harvest as well.
''')
add('| New job | Classification | Exact disposition required |\n|---|---|---|')
for j in m['new_jobs']:add(f"| `{j['id']}`"+(' (four matrix lanes)' if j.get('matrix') else '')+f" | {j['class']} | {j['meaning']} |")
add('''
There are seven workflow job definitions and ten executed child job instances when all four formal lanes run. The final summary uses `if: always()` and rejects all missing, failed, canceled, timed-out, skipped or unfinished required lanes. Do not use `continue-on-error` for a proof, type, source, coverage or freshness gate. A properly documented historical conditional skip is recorded separately; it never substitutes for an unexecuted required child proof.

### 12.1 Frozen regressions

Replay the actual paper controls unchanged, with recorded script hashes and group counts:

| Suite | Expected exact checks per mode | Role |
|---|---:|---|
| Existing P0 `opica/check_exact.py` | 5,112 | Frozen regression, not a new theorem |
| Frozen Round 1 script | 18,862 | Exact finite arithmetic/algebra controls |
| Frozen Round 2 script | 14,672 | Exact rational/symbolic controls |
| Final source-completion script | 1,274 | Exact finite source/resolvent controls |
| Total per normal and optimized mode | 39,920 | Not infinite-analytic validation |

The current parent P0 checker is an integration-adapted script, with source SHA-256 `42a1b29e979a415647b2ad477df4aa8e00b46f1afa52c1748748af4c79aa6985`; its original paper checker has a different byte hash. Preserve the current parent script and compare mathematical group/fixture counts, not falsely claim those two scripts are byte-identical.

The CP1 replay script writes `receipts/copoisson_numeric.json` relative to its package root. The wrapper must copy that unchanged script into an external temporary `checks/` layout, create its sibling `receipts/`, execute it there and harvest the output. Never run it in the tracked integration folder and leave a new untracked receipt.

The 33 numerical consistency cases are a separate result stream, not interval-certified and not actual hypothetical off-line-zero experiments. Freeze code and tolerances; report individual outcomes and any nonreproduction without converting floating-point agreement into proof. The dependency lock protects the recorded SymPy/mpmath environment. Run new validator mutation tests in both modes; Python assertions must not be the sole failure mechanism of a scientific checker.

### 12.2 Exact implementation commands

The commands below are required interfaces for the proposed scripts, not claims those scripts already exist. Each must be implemented with the documented flags. Run from repository root; emit receipts outside the tracked source tree.

```bash
F=research/RHRC/integration/opica_followup
P=research/RHRC/integration/opica
mkdir -p /tmp/opica-followup

python "$F/capture_parent.py" --parent-pr 293 \\
  --expected-head 553b4263b58d9fec178320de251ff299a0bd702a \\
  --expected-tree 12691099f1a155a8bfa3ad4f6689146175b233b2 \\
  --phase source --output /tmp/opica-followup/parent-intake.json

python "$F/validate_contract.py" --phase preflight \\
  --parent-intake /tmp/opica-followup/parent-intake.json \\
  --output /tmp/opica-followup/preflight.json

python -m unittest discover -s "$P/tests" -p 'test_*.py'
python -O -m unittest discover -s "$P/tests" -p 'test_*.py'
python -m unittest discover -s "$F/tests" -p 'test_*.py'
python -O -m unittest discover -s "$F/tests" -p 'test_*.py'
python "$F/replay_controls.py" --modes normal optimized \\
  --include-numerical --output-dir /tmp/opica-followup/regression

lake build Zeta23.OPICA Zeta23.OPICA.Validation \\
  Zeta23.RHRC.OpicaBindings Zeta23.OPICAFollowup \\
  Zeta23.OPICAFollowup.Validation Zeta23.RHRC.OpicaFollowupBindings \\
  Zeta23.RHRC.RegisteredClaimBindings \\
  Zeta23.RHRC.DeclarationDependencyExport Zeta23.RHRC.SourceCandidateResolution

python "$P/build_receipt.py" --requested-head "$FOLLOWUP_HEAD" \\
  --requested-base 97926d6a949fed7af0429a373b47abc772012834 \\
  --output-dir /tmp/opica-followup/parent-current
python "$P/validate_contract.py" --phase release \\
  --formal-receipt /tmp/opica-followup/parent-current/compiler-receipt.json \\
  --output /tmp/opica-followup/parent-current/release.json

python "$F/build_receipt.py" --requested-head "$FOLLOWUP_HEAD" \\
  --requested-base "$ACCEPTED_PARENT" --output-dir /tmp/opica-followup/formal
python "$F/validate_contract.py" --phase release \\
  --parent-intake /tmp/opica-followup/parent-intake.json \\
  --formal-receipt /tmp/opica-followup/formal/compiler-receipt.json \\
  --parent-formal-receipt /tmp/opica-followup/parent-current/compiler-receipt.json \\
  --output /tmp/opica-followup/release.json

python research/RHRC/tools/run_suite.py
python research/RHRC/tools/materialize_derived_state.py --check
python "$F/dependency_delta.py" \\
  --parent-intake /tmp/opica-followup/parent-intake.json \\
  --formal-receipt /tmp/opica-followup/formal/compiler-receipt.json \\
  --output /tmp/opica-followup/dependency-delta.json
python "$F/harvest_workflows.py" --repo HMarcusWH/zeta-23-lean \\
  --head "$FOLLOWUP_HEAD" --output /tmp/opica-followup/workflow-harvest.json
```

The source-phase intake above permits inspection and local work, not merge acceptance. Before a release validation, rerun `capture_parent.py --phase acceptance` with the exact parent compiler receipt/artifact and paginated workflow harvest supplied through `--formal-receipt` and `--workflow-harvest`; overwrite only the external intake path with a new, validated acceptance receipt. A source-only or pending intake is rejected by release mode. Parent receipt and workflow scopes must agree at that point.

`FOLLOWUP_HEAD` and `ACCEPTED_PARENT` are required actual40hex identities, not literals accepted by scripts. The displayed parent intake pin is amended only through the drift procedure when #293's accepted result changes. CI must not treat unresolved environment variables or empty inputs as the current head.

### 12.3 Full workflow harvesting

Enumerate all attached workflows and their paginated job/attempt lists for the final head, relevant merge check and push events. For each job record exact checked source, event, attempt, status, conclusion, conditional skips, artifact digests, commands, mathematical disposition, and comparison with the prior same fixture. Distinguish compiler validity, frozen regression and research-producing checks. A research run can succeed while reporting an unresolved feasibility claim or a falsified candidate.

Never hard-code “all55” or “all61” as permanent success. Do not infer current success from the parent PR body or an earlier checkpoint. Do not treat a running materializer or interval certificate job as finished. At full green, read successful proofs and all scientific outputs before choosing the next mathematical investigation.

## 13. Implementation sequence and stop conditions

**Stage0: accept/capture the parent and source papers.** Reconcile live head/tree, all current parent workflows, expected types, source APIs and immutable input hashes. Parent draft preparation is allowed, but merge readiness is blocked until acceptance is complete. Establish the child extension test harness before adding claims.

**Stage1: cheap exact interfaces.** Implement norm-first/allocation, joint observations/noise, Laurent budgets and elementary countercontrols using P0 APIs. These do not certify the full follow-up.

**Stage2: literal source family and actual generator words.** Prove source order0 identity, actual transforms, visible prime-pole construction and every named generator/source action. Build same-state consumers without weakening the old Step123 output.

**Stage3: quantitative arithmetic and analytic bridge.** Prove vertical source/gamma estimates before selecting moving contours. Construct actual forward kernels and true J17 coefficients, then log-slack and both masks. Separately complete actual translated EF/zero sums, source cost, explicit auxiliary completions and arbitrary-multiplicity residual, then J5.2/MS1 and the Theta consumer. A generic rate assumption is a blocked native milestone.

**Stage4: full measure/domain layer.** Establish complex locally finite measure and Fourier APIs with exact real separator compatibility; actual comb transport, weighted mixing and limits. Then renormalized CP1 local-TV identification before zero jets or sign claims. Prove the profile tail/jumps, finite Hermite determinant, span sign budgets and square controls.

**Stage5: actual sampling source and resolvent.** Prove the weak-derivative log transform, sawtooth Mellin/weighted moment, actual forced H1 resolvent, sample identity and generic boundary coefficient. Keep the lattice forcing and weighted rather than finite total spectral mass.

**Stage6: exact global registration and fresh acceptance.** Only now register every proved primary with its source/type/dependencies. Run full P0 and child validation, all generated-state and inherited jobs, compile actual expected-type consumers, harvest scientific results and complete Post-Green research. No source change after those receipts without another source-bound run.

If a proof reveals a false paper clause or missing classical input, record it explicitly and repair the argument or amend scope with review. Do not manufacture a new axiom, create a record carrying the conclusion as a field and call the consumer native, substitute a compact-support/finite-dimensional result for an infinite one, or rename the completed subset “full”.

## 14. Post-Green research pass and claim firewall

The follow-up's green result would formalize the listed preservation, preparation and countertest statements. It would not provide the independent opposing estimate. The final report must separately record:

- what exact statements became formally true, with assumptions and source head;
- what every compiler/regression/research workflow established, preserved, falsified or left pending;
- changes relative to the paper and parent APIs, including generalizations or stronger required hypotheses;
- upstream opportunities to simplify source families, avoid moving-order costs or remove redundant bridges;
- downstream consumers now backed by actual native rates/measure identities, not assumed conditions;
- historical routes genuinely revived, with their previous failure reasons retested;
- new hypotheses and fastest falsifiers, clearly not proofs;
- highest-information next native restriction to attempt.

Two immediate questions are prescribed by the paper: can one prove a genuine signed upper on the fixed two-factor complete observation, and can one derive an independent restriction on the actual boundary-amplitude functional? The Stieltjes identity is a representation of the force, not a homogeneous spectral exclusion. The newly formalized finite-span and square controls should prevent repeating the already falsified constructions, without declaring all nonlinear or spectral routes impossible.

The four original OPEN claim objects remain OPEN. D2/WP4 and independent human review are not auto-approved. No “quiet regime exists” statement is a theorem in this PR unless its genuine independent proof is separately developed and reviewed; it is not in this specification.

## 15. Acceptance checklist

Full completion requires all28coverage units, every primary and companion clause, all actual source constructors, all infinite-domain identities and all scope-specific countercontrols. Every required module must be reachable from the child mathematical facade, and every audit module excluded from it. All parent math and claims are unchanged. The raw global registry/config is exactly the protected parent plus verified child extension. Both original and child compiler/type/axiom contracts pass on the exact current tree. Every required scientific checker runs in its stated domain, and all generated files are canonical. All attached jobs have recorded dispositions. All source artifacts/digests are retained without claiming they are independent review.

A declaration can be kernel-valid yet prove a weaker proposition than the paper. For that reason, file presence, root count, dependency graph connectivity, static name checks, and absence of sorry do not independently establish mathematical coverage. The expected-type review and physical consumers are mandatory alongside compiler authority.

**Specification status:** exact build design completed against the inspected PR293 source; no repository implementation, new Lean theorem or new CI run produced in this task. Parent-wide publication-head acceptance is not claimed complete. The new artifacts are stored locally; current Drive discovery exposed read operations only, so no new upload is represented as successful.

## Appendix A. Exact generated-file allowlist

These are existing products of the canonical producer, inherited from the parent inventory. Do not create substitute paths.
''')
add('```text\n'+'\n'.join(m['regenerate']['paths'])+'\n```')
add('''
## Appendix B. Root-level mathematical contracts

All names below are proposed under `Zeta23.OPICAFollowup`. Their full names, source groups and expected-consumer names also appear in the root JSON. Mathematical formulas are the acceptance target; elaborated Lean expected-type hashes must be produced and reviewed during implementation.
''')
for r in m['primary_roots']:
 add(f"### `{r['full_name']}`\n\nDefining file: `{r['path']}`. Source: {', '.join(r['paper_ids'])}.\n\n{r['statement_contract']}\n")
 if r['required_premises']:add('Premise qualification: '+r['required_premises']+'\n')
 if not r['not_accepted_as_replacement'].startswith('A caller-supplied'): add('Rejected substitute: '+r['not_accepted_as_replacement']+'\n')
add('''
## Appendix C. Source links and reproducibility

Primary implementation source: https://github.com/HMarcusWH/zeta-23-lean/pull/293 . Every live file reference used for this spec is pinned to `553b4263b58d9fec178320de251ff299a0bd702a`, not moving main. The intake JSON identifies selected fetched blobs and review scope. The successful current PR formal job's source identity is retained separately from the uncompleted full parent harvest.

Final controlling paper: https://drive.google.com/file/d/1maOApH-lKrmHZgzh85Gq3RTc5Ot9WFwW/view . Final ledger: https://drive.google.com/file/d/1LincoDfkmwMWXrHlfYKyZXB6GtaKpoxh/view . Final paper contract: https://drive.google.com/file/d/1vViEEmJaLUYZAoL5OrEPQeOzkepZtUhS/view . Their mounted bytes and hashes are bound in the specification package. The destination used by earlier sessions is https://drive.google.com/drive/folders/1FwRkN6sbJ4_Fhrqe53wpsJtByD2RXILb . Earlier readback receipts certify earlier uploads only.

The included structural validation script checks this proposal's path/DAG/coverage/source consistency, not Lean proof correctness or a successful future PR. The package contains a specification generator, frozen selected mathematical inputs, preserved source navigation evidence, and a release digest manifest. It deliberately does not contain invented Lean proofs or counterfeit compiler outputs.
''')
(O/'OPICA_FOLLOWUP_PR_BUILD_SPEC_2026-10-21.md').write_text('\n'.join(s)+'\n')
print('words',len('\n'.join(s).split()),'bytes',len(('\n'.join(s)+'\n').encode()))
