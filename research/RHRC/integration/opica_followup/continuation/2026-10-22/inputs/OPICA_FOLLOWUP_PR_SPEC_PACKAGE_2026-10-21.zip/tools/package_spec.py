#!/usr/bin/env python3
"""Package the specification, not a repository implementation or proof receipt."""
from pathlib import Path
import hashlib, json, zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent
NAME = 'OPICA_FOLLOWUP_PR_SPEC_PACKAGE_2026-10-21.zip'
SELECT = ['deliverables', 'tools', 'paper_inputs', 'parent_inputs', 'paper_evidence', 'evidence']

def sha(b):
    return hashlib.sha256(b).hexdigest()

def main():
    members = [ROOT / 'README.md']
    for directory in SELECT:
        members.extend(p for p in (ROOT / directory).rglob('*')
                       if p.is_file() and '__pycache__' not in p.parts
                       and p.suffix != '.pyc')
    members = sorted(set(members), key=lambda p:p.relative_to(ROOT).as_posix())
    rows = [{'path':p.relative_to(ROOT).as_posix(), 'bytes':p.stat().st_size,
             'sha256':sha(p.read_bytes())} for p in members]
    payload = {'schema':'OPICA_FOLLOWUP_SPEC_PAYLOADS_V1',
               'scope':'Specification and provenance only; no new Lean implementation',
               'files':rows,'self_hash_excluded':True}
    dst = OUT / NAME
    with zipfile.ZipFile(dst,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p,row in zip(members,rows):
            z.writestr(row['path'],p.read_bytes())
        z.writestr('PAYLOAD_MANIFEST.json',json.dumps(payload,indent=2)+'\n')
    with zipfile.ZipFile(dst) as z:
        if z.testzip() is not None:raise RuntimeError('CRC failure')
        names=set(z.namelist())
        if names != {'PAYLOAD_MANIFEST.json'}|{x['path'] for x in rows}:
            raise RuntimeError('Wrong ZIP membership')
        for row in rows:
            data=z.read(row['path'])
            if len(data)!=row['bytes'] or sha(data)!=row['sha256']:
                raise RuntimeError('Payload mismatch '+row['path'])
    release={'schema':'OPICA_FOLLOWUP_SPEC_RELEASE_V1','date':'2026-10-21',
             'authority':'SPECIFICATION_NOT_FORMALIZATION',
             'parent_head':'553b4263b58d9fec178320de251ff299a0bd702a',
             'parent_tree':'12691099f1a155a8bfa3ad4f6689146175b233b2',
             'parent_draft':True,'parent_merged':False,'whole_parent_green_claimed':False,
             'spec_words_whitespace':len((ROOT/'deliverables/OPICA_FOLLOWUP_PR_BUILD_SPEC_2026-10-21.md').read_text().split()),
             'new_files':84,'new_Lean_files':43,'existing_authoritative_edits':12,
             'existing_generated_allowlist':62,'proposed_primary_roots':100,
             'paper_groups':26,'separate_analytic_bridges':['J5.2','MS1'],
             'structural_assertions_per_mode':3992,'modes':['normal','python -O'],
             'new_Lean_roots':0,'new_CI_runs':0,'repository_writes':False,
             'paper_independently_reviewed':False,'drive_uploaded':False,
             'zip_crc_pass':True,'zip_payloads_verified':len(rows),'zip_entries':len(rows)+1,
             'files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
                      for p in sorted((ROOT/'deliverables').iterdir()) if p.is_file()]
                     +[{'name':NAME,'bytes':dst.stat().st_size,'sha256':sha(dst.read_bytes())}],
             'RH':'OPEN','Step4':'OPEN','self_hash_excluded':True}
    rel=OUT/'OPICA_FOLLOWUP_PR_SPEC_RELEASE_MANIFEST_2026-10-21.json'
    rel.write_text(json.dumps(release,indent=2)+'\n')
    print(json.dumps({'package':str(dst),'release_manifest':str(rel),
                      'payloads_verified':len(rows),'zip_bytes':dst.stat().st_size,
                      'zip_sha256':sha(dst.read_bytes()),'spec_words':release['spec_words_whitespace']},indent=2))

if __name__=='__main__':
    main()
