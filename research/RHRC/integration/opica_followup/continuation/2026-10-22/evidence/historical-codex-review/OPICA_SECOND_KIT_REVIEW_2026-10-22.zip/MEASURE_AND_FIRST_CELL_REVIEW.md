# Measure, comb and first-cell candidate review

Review date: 22 October 2026, Europe/Stockholm. Inputs are the byte-exact files identified in INPUT_MANIFEST.json, overlaid only in the isolated opica-audit28 checkout at baseline 9b6a9a3a2badb4cff62a56c1158d9cef8759d30d. No new primary is accepted by this review.

## ComplexLocalMeasures

The added public root attempts all major parts of the frozen contract: genuine compact complex restrictions and their variation, addition/scaling compatibility, faithful distribution embedding on the linear-growth domain, canonical realification into the parent's Jordan carrier, compact-test convergence, and Schwartz convergence with one common linear-growth budget. The additional common bound is the correct distinction between local convergence and tempered convergence; unrelated individual growth constants would not suffice.

The genuine leaf compile returned exit 1 with 18 error records, including cascading errors. The first failures at lines 833, 840, 845 and 879 concern rewriting `-(R*2^n)` versus `-R*2^n` in interval membership. Line 907 fails a power rewrite in the dyadic-tail estimate. Line 941 fails an integral decomposition rewrite. Line 971 leaves the indicator endpoints implicit. Lines 1052 onward include Jordan arithmetic and local finite-mass proof obligations not discharged by tactics. These errors prevent the new root and the new shared-growth lemmas from being treated as proved. The cached inherited olean remains the old support module; its presence is not acceptance of this upload.

Evidence: complex-compile.log. No candidate source was repaired.

## DilatedComb

The source defines the actual pushforward of integer counting measure under `n -> exp(t)*n`, scaled by `exp(t/2)`. Its proposed root contains the point-count bound, genuine absolute Schwartz summation, exact distribution action and Fourier reflection t -> -t. These match the intended mathematical construction; it does not use a synthetic distribution carrying the desired Fourier law as an input field.

The leaf check returned exit 1. It imports the inherited ComplexLocalMeasures olean, so it is an independent diagnostic and cannot establish compatibility with the failed uploaded complex module. Failures include the nonexistent `measurable_from_countable` at line 26, wrong Int.cast_injective argument at 30, integer/real bounds at 45, missing local-finiteness instance for the scaled measure at 84, unapplied Jordan normalization at 99, Fourier/Schwartz coercions, an actual parser error at 155, missing identifiers and the final Fourier rescaling rewrite. Repair is needed before any acceptance run.

Evidence: comb-compile.log.

## RenormalizedCoPoisson

The literal density is a quotient of the two inclusive finite power sums, with the `floor x` right-integer endpoint and even extension through `|x|`. The sign theorem targets the exact first-cell expression, keeps strict height cutoffs, retains both signs of the ordinate, and reserves the arbitrary complex scalar projection conclusion for nonzero off-line displacement. It does not construct the missing global renormalized measure or establish its global Fourier/tempered properties.

The initial leaf check was blocked by an absent inherited ZetaRealStripNonvanishing olean. Building that exact narrow prerequisite succeeded (3768 jobs, mostly replays). The subsequent genuine leaf diagnostic returned exit 1 with 13 error records. In particular the `<|gamma|` spellings are parsed as the `<|` application token, not the intended less-than followed by an absolute value. There are also an invalid subscript character in a local identifier, missing `Complex.sinh_re` and `Complex.sinh_im`, cast/floor obligations and unsolved algebra. The source therefore does not yet establish zero_measure_first_cell_sign. No source was repaired.

Evidence: renorm-prereq-build.log; renormalized-compile.log (initial missing dependency); renormalized-compile-after-prereq.log (actual source failures).

## FirstCellCost

The proposed root uses the literal preceding density, defines the negative part rather than an artificial negative test, and integrates it over the intended first-cell interval. The second cost uses the parent's sincSquared convention. Its public parameters retain `|delta|<1/2`, `16<=|gamma|`, the full log interval, the density upper bound, the pi/6 mass bound and the 8*pi/(27*gamma^2) weighted bound. At the statement level these match the frozen root contract.

Its actual leaf invocation stopped at missing RenormalizedCoPoisson.olean. The preceding uploaded module failed compilation and cannot supply a checked dependency. FirstCellCost's proof body has therefore not undergone a genuine elaboration in the candidate environment. It remains blocked, not passed and not independently rejected on its mathematics. An imported admitted stub or stale invented olean was not used to manufacture success.

Evidence: firstcell-compile.log.

## Implication limits

Local-TV convergence plus a common growth budget is the right upstream bridge toward actual global co-Poisson measures; it does not produce those measures. The comb Fourier law could support weighted mixtures and near-gap limits once proved. First-cell negativity and quantitative correction cost could constrain actual zero measures once the separate global construction and physical identification are proved. These are dependency observations and mathematical leads, not new formal consequences from the failed uploads. No inference to RH, Step 4, or any independent closing inequality is licensed.
