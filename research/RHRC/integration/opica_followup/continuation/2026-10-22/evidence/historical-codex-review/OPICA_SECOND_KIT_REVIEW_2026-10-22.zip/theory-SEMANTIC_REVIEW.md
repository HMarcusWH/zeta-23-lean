# Second partial kit: auxiliary completion and multiplicity review

This is an audit of the uploaded candidate bytes in the isolated `work/opica-audit28` checkout at base HEAD `9b6a9a3a2badb4cff62a56c1158d9cef8759d30d`. The main repository is unchanged. All candidate sources remain frozen; this reviewer has not repaired or edited them.

Candidate identities:

- AuxiliaryCompletions SHA256 `e638865949655e7429517a81eb05e05589802c0f60f2d555026bbea0d224ff8b`.
- MultiplicityTail SHA256 `5cd8bc952f6a1dcc7894d49b3113569e1d828491149ebdd672cf9d0b8a218780`.

Final compiler status and exact diagnostics belong to the adjacent `theory-*` logs/status artifact. Merely finding a required declaration name does not accept it. Newly accepted required roots from this audit are **zero**. The main accepted state remains 41 proved / 59 missing.

## Contract and mathematical comparison

The frozen BUILD_SPEC requires three auxiliary primaries: actual beta-filter/completed-source transform with its true domain; actual order-uniform completed-source decay with endpoint atom and summability; fixed-right-coordinate ratio bounds uniform in integer order. The candidate states all three under their full required names. No apparent weakening of those mathematical statements was found in source review, but none is established by this semantic review alone.

The original actual filter, integer-completion, compact profile, derivative density and unit endpoint atom definitions remain in place. The new code identifies the literal integral with Mathlib's Fourier convention; rescales the actual profile; proves integer Fourier summability for k>=1; retains the zero mode and both frequency signs; and applies genuine Poisson at every real scale. The formula `a_k(t)=exp(-t/2)*sum_n phi_k(n exp(-t))` has the correct scaling, including n=0 and the causal endpoint. Scaling the Fourier transform contributes `a^k`, followed by `exp(-t/2)`, yielding precisely `exp(-(k+1/2)t)`. The constant keeps the required `2*zeta(k+1)*(1+2^(3k+4))/(2*pi)^(k+1)`.

The candidate enlarged-domain transform is an actual Lebesgue integral, not a stipulated meromorphic field. Actual decay is used to construct weighted L2 membership and then actual integral analyticity for `Re z>-(k+1/2)`. A connected open half-plane identity theorem extends the already established physical equality on `Re z>1/2`. The representative uses actual pole-cleared zeta, rather than raw totalized multiplication. Its required value at z=1/2 is `(k+1)!/(2k+3)!`, which matches the literal denominator product. No k=0 improved-domain Poisson theorem is claimed; k=0 is retained only on the original filter/initial transform domain.

The ratio theorem fixes an actual nontrivial right zero rho, takes p=rho-1/2 and proves p!=1/2 using rho!=1. Its constant is selected before every k>=1. The source proof follows valid bounding formulas: denominator product at most `D^(k+2)*(2k+2)!/k!`, division by `(k+1)!` gives `(k+1)*choose(2k+2,k+1)`, and the binomial is at most `4^(k+1)`. The lower bound uses `|r_k(p)|>=|p-1/2|/[2D(k+1)]^(k+2)` and an exponential envelope on A_k. Dependence on a fixed p, including blow-up as p approaches the removable point or critical boundary, is permitted. There is no uniform-in-zero claim or hidden RH assumption.

MultiplicityTail constructs the actual monic Laguerre polynomial by `(-1)^n*(D-1)^n X^n`, rather than accepting an orthogonality certificate. The integration-by-parts recurrence keeps the origin boundary term; divisibility by powers of X justifies its vanishing during iteration. Its proposed norm calculation is mathematically consistent with Rodrigues normalization: `integral_0^infinity exp(-x)*L_n(x)^2 dx=(n!)^2`.

The actual tail representative is `1_[T,infinity)*(2*Re p)^(-n)*L_n(2*Re p*(t-T))*exp(-conj(p)*t)`. The polynomial in t is monic. Squaring the norm and changing variable x=2*Re p*(t-T) gives `exp(-2*Re p*T)*(n!)^2/(2*Re p)^(2n+1)`. With n=m-1, taking the nonnegative square root gives the frozen norm `exp(-Re p*T)*(m-1)!/(2*Re p)^(m-1/2)`. The candidate quantifies all m>=1, all positive Re p, arbitrary imaginary part and every real T. In particular m=1 and both imaginary signs are not lost. The actual `MemLp` and `.toLp` representative are constructed, not supplied as conclusions in a data structure.

## Missing scope and dependency refinement

MultiplicityTail is only a Laguerre candidate. It does not define the frozen module's `nativeTruncatedResidual` or `tailMemory`, and does not state/prove `native_auxiliary_top_moment`, `native_auxiliary_tail_residual_lower` or `native_terminal_memory_lower`. Actual convolution/stable-input control, native top moments, finite truncation and memory lower bounds remain necessary. The Laguerre calculation alone cannot supply them or the remaining native window-rate theorems.

AuxiliaryCompletions adds the direct project import `Zeta23.OPICA.WeightedLaplace`, while the frozen manifest lists only NativeSourceTransforms. This is a reasonable implementation dependency for actual Laplace analyticity, not an added mathematical hypothesis, but it needs an explicit reviewed dependency refinement before any promotion. The additional Mathlib Fourier/complex/measure imports likewise need to be recorded. MultiplicityTail's three project imports match its frozen plan.

The uploaded build_receipt still selects exactly 41 roots. No independent expected-type consumer for the four newly attempted primaries is included in the uploaded candidate kit. Even a local file compilation would therefore not by itself increase the accepted count; full literal consumers, boundary checks, axiom/dependency export and a new exact-source aggregate receipt are required.

## Concrete initial compiler blocker

The first genuine AuxiliaryCompletions save attempt failed before elaboration because `Zeta23.OPICA.WeightedLaplace.olean` was missing. The inherited auxiliary `.olean` is stale and must never be treated as compilation of the new source. Root authorized the narrow prerequisite target `lake build Zeta23.OPICA.WeightedLaplace` in the isolated checkout. The subsequent exact diagnostics are recorded separately; MultiplicityTail cannot count as a genuine imported candidate until the new auxiliary source has compiled and saved successfully.

## Final compiler outcome and next repairs

The authorized WeightedLaplace prerequisite build passed (3380 scheduled jobs, mostly cached replays). The exact uploaded AuxiliaryCompletions source then failed with **48 compiler error records**, including cascading failures; this is not a claim of 48 independent mathematical errors. The earliest errors are real-polynomial evaluations incorrectly inferred as complex-polynomial evaluations at lines 799, 806 and 809. Other concrete failures include Fourier factor/order conversion at 846, scaling/inverses at 867, bound algebra at 902, unavailable `Summable.re` at 928, integer inverse-power summation/heartbeats, actual lattice scaling at 974/989, unknown `Complex.ofNat_re`/`Complex.ofNat_im` at 1084, analytic quotient and integral-measurability adapters, the elementary-point factorial product, and factorial/logarithm ratio proofs. Full diagnostics are in `theory-auxiliary-save-02.log`; the exact 48-record location index is `theory-auxiliary-errors.json`. No repairs were made.

A first read-only MultiplicityTail diagnostic also found a missing existing `NativeActualInputZeroJets.olean`. Its specifically authorized narrow prerequisite build passed (4187 scheduled jobs, mostly replays). The final read-only diagnostic then found a definite delivered import error: `Mathlib.Analysis.InnerProductSpace.L2Space` is not the pinned package module name. The actual analysis path is lowercase `Mathlib.Analysis.InnerProductSpace.l2Space`. On Windows the mismatched name resolves the same case-insensitive file and collides with the already imported `IsHilbertSum.casesOn`; on case-sensitive Linux the requested uppercase path is absent. The separate function-space module is `Mathlib.MeasureTheory.Function.L2Space`; the author should select the intended actual API, not infer it from the ambiguous spelling. This diagnostic is in `theory-multiplicity-stale-leaf-02.log`.

Crucially, the Multiplicity diagnostic used an explicitly recorded inherited/stale AuxiliaryCompletions object, SHA256 `5fdb4d64e7b8825695a08438764ace554c5675d11744b50bb56b45cffb2794bd`. It was never a genuine imported check of the complete new overlay, and no Multiplicity object was saved. Its body has not been compiler-validated. Once the import is repaired, additional body/API errors may remain. Stop-after-failure instructions were respected; no speculative repair loop was started.

To build this lane, first repair the actual auxiliary type/API proofs until a genuine own-module save succeeds. Then fix the multiplicity import and check its body against that newly compiled dependency. Afterwards add independent literal expected types, small-order/elementary-point/both-sign controls and standard-axiom/full dependency exports. Record the approved implementation dependency refinement, and wire only genuinely accepted roots into a new exact-source aggregate receipt. A stale `.olean`, a larger heartbeat limit or a successful inherited prerequisite does not replace these gates. The missing three native multiplicity/residual/memory primaries remain separate mathematical obligations.

At final review all own compiler/build sessions have ended. The main checkout is still clean at `9b6a9a3a2badb4cff62a56c1158d9cef8759d30d`; candidate source hashes are unchanged; no main source edit, repair, commit or push was performed.

## Fast adversarial controls

- k=0 profile has density 6u-2 and atom -delta_1, so a density-only weak derivative is false. The candidate preserves the atom.
- k>=1 is necessary for the absolute Poisson summation route; no false k=0 continuity conclusion should be accepted.
- Frequency xi=0 is handled by the actual zero mode, not by dividing by zero in the Fourier upper bound.
- At z=1/2 use the filled transform's nonzero value, never raw totalized `r_k*zeta`.
- For m=1, the actual Laguerre test reduces to the causal exponential, with norm `exp(-delta*T)/sqrt(2*delta)`.
- The exact lower endpoint T may be negative in the generic norm theorem; this causes no integrability issue when delta>0 and must not be silently narrowed.

These are semantic checks and required future regression consumers, not new Lean proof authority. RH remains OPEN.
