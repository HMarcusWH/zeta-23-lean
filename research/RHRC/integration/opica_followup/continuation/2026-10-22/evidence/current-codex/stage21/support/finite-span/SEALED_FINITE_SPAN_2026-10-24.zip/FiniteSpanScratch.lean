import Zeta23.OPICAFollowup.CoPoissonJets
import Zeta23.OPICA.SignedHeatSeparator

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform ENNReal NNReal

namespace Zeta23.OPICAFollowup.FiniteSpanScratch

open Zeta23.OPICA

def zeroJordan : LocallyFiniteSignedMeasure :=
  ⟨0, 0, inferInstance, inferInstance, Measure.MutuallySingular.zero_left⟩

def zeroComplex : LocallyFiniteComplexMeasure := ⟨zeroJordan, zeroJordan⟩

lemma zeroComplex_growth : zeroComplex.HasLinearGrowth := by
  refine ⟨0, le_rfl, fun R hR => ?_⟩
  simp [zeroComplex, zeroJordan, LocallyFiniteComplexMeasure.variationControl,
    LocallyFiniteSignedMeasure.totalVariation, Measure.real]

lemma zeroComplex_integral (f : ℝ → ℂ) : zeroComplex.integral f = 0 := by
  simp [zeroComplex, zeroJordan, LocallyFiniteComplexMeasure.integral]

lemma signed_integral_add (μ ν : LocallyFiniteSignedMeasure)
    (f : ℝ → ℂ) (hμp : Integrable f μ.positive) (hμn : Integrable f μ.negative)
    (hνp : Integrable f ν.positive) (hνn : Integrable f ν.negative) :
    (∫ x, f x ∂(localJordanAdd μ ν).positive) -
        (∫ x, f x ∂(localJordanAdd μ ν).negative) =
      ((∫ x, f x ∂μ.positive) - ∫ x, f x ∂μ.negative) +
      ((∫ x, f x ∂ν.positive) - ∫ x, f x ∂ν.negative) := by
  rw [localJordanAdd, localJordanDifference_integral _ _ f
    (integrable_add_measure.mpr ⟨hμp,hνp⟩) (integrable_add_measure.mpr ⟨hμn,hνn⟩),
    integral_add_measure hμp hνp, integral_add_measure hμn hνn]
  ring

lemma signed_integral_scale (a : ℝ) (μ : LocallyFiniteSignedMeasure)
    (f : ℝ → ℂ) (hμp : Integrable f μ.positive) (hμn : Integrable f μ.negative) :
    (∫ x, f x ∂(localJordanScale a μ).positive) -
        (∫ x, f x ∂(localJordanScale a μ).negative) =
      (a : ℂ) * ((∫ x, f x ∂μ.positive) - ∫ x, f x ∂μ.negative) := by
  rw [localJordanScale]
  have hpp : Integrable f (Real.toNNReal a • μ.positive) :=
    hμp.smul_measure (c := (Real.toNNReal a : ℝ≥0∞)) ENNReal.coe_ne_top
  have hpn : Integrable f (Real.toNNReal a • μ.negative) :=
    hμn.smul_measure (c := (Real.toNNReal a : ℝ≥0∞)) ENNReal.coe_ne_top
  have hnp : Integrable f (Real.toNNReal (-a) • μ.positive) :=
    hμp.smul_measure (c := (Real.toNNReal (-a) : ℝ≥0∞)) ENNReal.coe_ne_top
  have hnn : Integrable f (Real.toNNReal (-a) • μ.negative) :=
    hμn.smul_measure (c := (Real.toNNReal (-a) : ℝ≥0∞)) ENNReal.coe_ne_top
  rw [localJordanDifference_integral _ _ f
    (integrable_add_measure.mpr ⟨hpp,hnn⟩)
    (integrable_add_measure.mpr ⟨hpn,hnp⟩),
    integral_add_measure hpp hnn, integral_add_measure hpn hnp]
  simp only [integral_smul_nnreal_measure, NNReal.smul_def, Complex.real_smul]
  have ha : (Real.toNNReal a : ℝ) - (Real.toNNReal (-a) : ℝ) = a := by
    rw [Real.coe_toNNReal',Real.coe_toNNReal']
    rcases le_total 0 a with h|h
    · simp [max_eq_left h, max_eq_right (neg_nonpos.mpr h)]
    · simp [max_eq_right h, max_eq_left (neg_nonneg.mpr h)]
  have hac : ((Real.toNNReal a : ℝ) : ℂ) - ((Real.toNNReal (-a) : ℝ) : ℂ) = (a : ℂ) := by
    exact_mod_cast ha
  rw [←hac]
  ring

lemma signed_scale_integrable_parts (a : ℝ) (μ : LocallyFiniteSignedMeasure)
    (f : ℝ → ℂ) (hp : Integrable f μ.positive) (hn : Integrable f μ.negative) :
    Integrable f (localJordanScale a μ).positive ∧
      Integrable f (localJordanScale a μ).negative := by
  have h : Integrable f (ENNReal.ofReal |a| • μ.totalVariation) :=
    (integrable_add_measure.mpr ⟨hp,hn⟩).smul_measure ENNReal.ofReal_ne_top
  have h' := h.mono_measure (localJordanScale_totalVariation_le a μ)
  exact integrable_add_measure.mp h'

lemma complex_integral_add (μ ν : LocallyFiniteComplexMeasure)
    (hμ : μ.HasLinearGrowth) (hν : ν.HasLinearGrowth) (f : 𝓢(ℝ, ℂ)) :
    (μ.add ν).integral f = μ.integral f + ν.integral f := by
  obtain ⟨hr,hi⟩ := integrable_add_measure.mp (μ.integrable_schwartz hμ f)
  obtain ⟨hmp,hmn⟩ := integrable_add_measure.mp hr
  obtain ⟨hmip,hmin⟩ := integrable_add_measure.mp hi
  obtain ⟨hr,hi⟩ := integrable_add_measure.mp (ν.integrable_schwartz hν f)
  obtain ⟨hnp,hnn⟩ := integrable_add_measure.mp hr
  obtain ⟨hnip,hnin⟩ := integrable_add_measure.mp hi
  dsimp only [LocallyFiniteComplexMeasure.add, LocallyFiniteComplexMeasure.integral]
  rw [signed_integral_add _ _ _ hmp hmn hnp hnn,
    signed_integral_add _ _ _ hmip hmin hnip hnin]
  ring

lemma complex_integral_scale (μ : LocallyFiniteComplexMeasure)
    (hμ : μ.HasLinearGrowth) (c : ℂ) (f : 𝓢(ℝ, ℂ)) :
    (μ.scale c).integral f = c * μ.integral f := by
  obtain ⟨hr,hi⟩ := integrable_add_measure.mp (μ.integrable_schwartz hμ f)
  obtain ⟨hrp,hrn⟩ := integrable_add_measure.mp hr
  obtain ⟨hip,hin⟩ := integrable_add_measure.mp hi
  have hrr := signed_scale_integrable_parts c.re μ.rePart f hrp hrn
  have hri := signed_scale_integrable_parts (-c.im) μ.imPart f hip hin
  have hir := signed_scale_integrable_parts c.im μ.rePart f hrp hrn
  have hii := signed_scale_integrable_parts c.re μ.imPart f hip hin
  dsimp only [LocallyFiniteComplexMeasure.scale, LocallyFiniteComplexMeasure.integral]
  rw [signed_integral_add _ _ _ hrr.1 hrr.2 hri.1 hri.2,
    signed_integral_add _ _ _ hir.1 hir.2 hii.1 hii.2,
    signed_integral_scale _ _ _ hrp hrn, signed_integral_scale _ _ _ hip hin,
    signed_integral_scale _ _ _ hrp hrn, signed_integral_scale _ _ _ hip hin]
  simp only [Complex.ofReal_neg]
  conv_rhs => rw [←Complex.re_add_im c]
  ring_nf
  simp only [Complex.I_sq]
  ring

lemma imPart_fourierSelfdual_of_complex (μ : LocallyFiniteComplexMeasure) (h : μ.HasLinearGrowth)
    (hself : ∀ φ : 𝓢(ℝ, ℂ), μ.integral ((𝓕 φ : 𝓢(ℝ, ℂ)) : ℝ → ℂ) = μ.integral φ)
    (heven : ∀ φ : 𝓢(ℝ, ℂ), μ.integral (schwartzReflect φ) = μ.integral φ) :
    𝓕 (μ.imPart.distributionOfLinearGrowth (μ.im_hasLinearGrowth h)) =
      μ.imPart.distributionOfLinearGrowth (μ.im_hasLinearGrowth h) := by
  have hr := rePart_fourierSelfdual_of_complex μ h hself heven
  ext φ
  have hrφ := congrArg (fun T : TemperedDistribution ℝ ℂ => T φ) hr
  have hcφ := hself φ
  change μ.rePart.distributionOfLinearGrowth (μ.re_hasLinearGrowth h) (𝓕 φ) +
      I * μ.imPart.distributionOfLinearGrowth (μ.im_hasLinearGrowth h) (𝓕 φ) =
    μ.rePart.distributionOfLinearGrowth (μ.re_hasLinearGrowth h) φ +
      I * μ.imPart.distributionOfLinearGrowth (μ.im_hasLinearGrowth h) φ at hcφ
  change μ.rePart.distributionOfLinearGrowth (μ.re_hasLinearGrowth h) (𝓕 φ) =
    μ.rePart.distributionOfLinearGrowth (μ.re_hasLinearGrowth h) φ at hrφ
  change μ.imPart.distributionOfLinearGrowth (μ.im_hasLinearGrowth h) (𝓕 φ) =
    μ.imPart.distributionOfLinearGrowth (μ.im_hasLinearGrowth h) φ
  apply mul_left_cancel₀ I_ne_zero
  exact add_left_cancel (hrφ ▸ hcφ)

/-- Coefficient, actual zeta zero, and normalized kappa-jet order. -/
abbrev JetDatum := ℂ × ℂ × ℕ

def ValidJet (j : JetDatum) : Prop :=
  riemannZeta j.2.1 = 0 ∧ 0 < j.2.1.re ∧ j.2.1.re < 1 ∧
    j.2.2 < zeroJetOrder j.2.1

def actualZeroJetSum : List JetDatum → LocallyFiniteComplexMeasure
  | [] => zeroComplex
  | j :: rest => ((normalizedZeroMeasureJet j.2.1 j.2.2).scale j.1).add (actualZeroJetSum rest)

/-- The canonical real Jordan measure of a finite sum of genuine complex jets.
Taking Re(c nu) includes arbitrary real/imaginary coefficient combinations. -/
def zeroJetRealSpan (data : List JetDatum) : LocallyFiniteSignedMeasure :=
  (actualZeroJetSum data).rePart

lemma actualZeroJetSum_growth (data : List JetDatum) (h : ∀ j ∈ data, ValidJet j) :
    (actualZeroJetSum data).HasLinearGrowth := by
  induction data with
  | nil => exact zeroComplex_growth
  | cons j rest ih =>
    obtain ⟨hz,h0,h1,hk⟩ := h j (by simp)
    exact LocallyFiniteComplexMeasure.hasLinearGrowth_add _ _
      (LocallyFiniteComplexMeasure.hasLinearGrowth_scale _
        (normalizedZeroMeasureJet_hasLinearGrowth h0 h1 (zero_ne_half hz) hk) j.1)
      (ih (fun z hz => h z (by simp [hz])))

lemma actualZeroJetSum_gap (data : List JetDatum) :
    (actualZeroJetSum data).variationControl (Ioo (-1) 1) = 0 := by
  induction data with
  | nil => simp [actualZeroJetSum, zeroComplex, zeroJordan,
      LocallyFiniteComplexMeasure.variationControl, LocallyFiniteSignedMeasure.totalVariation]
  | cons j rest ih =>
    have hs := (normalizedZeroMeasureJet j.2.1 j.2.2).scale_control_le j.1 (Ioo (-1) 1)
    rw [Measure.smul_apply, (normalizedZeroMeasureJet_gap (ρ := j.2.1) j.2.2).1,
      smul_zero] at hs
    have ha := LocallyFiniteComplexMeasure.add_control_le
      ((normalizedZeroMeasureJet j.2.1 j.2.2).scale j.1) (actualZeroJetSum rest) (Ioo (-1) 1)
    rw [Measure.add_apply, ih, add_zero] at ha
    exact le_antisymm (ha.trans hs) zero_le

lemma actualZeroJetSum_fourier (data : List JetDatum) (h : ∀ j ∈ data, ValidJet j)
    (φ : 𝓢(ℝ, ℂ)) :
    (actualZeroJetSum data).integral (𝓕 φ : 𝓢(ℝ, ℂ)) = (actualZeroJetSum data).integral φ := by
  induction data with
  | nil => rw [actualZeroJetSum, zeroComplex_integral, zeroComplex_integral]
  | cons j rest ih =>
    obtain ⟨hz,h0,h1,hk⟩ := h j (by simp)
    have hj := normalizedZeroMeasureJet_hasLinearGrowth h0 h1 (zero_ne_half hz) hk
    have ht : ∀ z ∈ rest, ValidJet z := fun z hz => h z (by simp [hz])
    have hs := LocallyFiniteComplexMeasure.hasLinearGrowth_scale _ hj j.1
    rw [actualZeroJetSum, complex_integral_add _ _ hs (actualZeroJetSum_growth rest ht),
      complex_integral_add _ _ hs (actualZeroJetSum_growth rest ht),
      complex_integral_scale _ hj, complex_integral_scale _ hj,
      normalizedZeroMeasureJet_fourier h0 h1 (zero_ne_half hz) hk, ih ht]

lemma actualZeroJetSum_reflect (data : List JetDatum) (h : ∀ j ∈ data, ValidJet j)
    (φ : 𝓢(ℝ, ℂ)) :
    (actualZeroJetSum data).integral (schwartzReflect φ) = (actualZeroJetSum data).integral φ := by
  induction data with
  | nil => rw [actualZeroJetSum, zeroComplex_integral, zeroComplex_integral]
  | cons j rest ih =>
    obtain ⟨hz,h0,h1,hk⟩ := h j (by simp)
    have hj := normalizedZeroMeasureJet_hasLinearGrowth h0 h1 (zero_ne_half hz) hk
    have ht : ∀ z ∈ rest, ValidJet z := fun z hz => h z (by simp [hz])
    have hs := LocallyFiniteComplexMeasure.hasLinearGrowth_scale _ hj j.1
    rw [actualZeroJetSum, complex_integral_add _ _ hs (actualZeroJetSum_growth rest ht),
      complex_integral_add _ _ hs (actualZeroJetSum_growth rest ht),
      complex_integral_scale _ hj, complex_integral_scale _ hj,
      normalizedZeroMeasureJet_reflect h0 h1 (zero_ne_half hz), ih ht]

lemma zeroJetRealSpan_growth (data : List JetDatum) (h : ∀ j ∈ data, ValidJet j) :
    (zeroJetRealSpan data).HasLinearGrowth :=
  (actualZeroJetSum data).re_hasLinearGrowth (actualZeroJetSum_growth data h)

lemma zeroJetRealSpan_gap (data : List JetDatum) : (zeroJetRealSpan data).HasUnitGap := by
  have h := actualZeroJetSum_gap data
  rw [LocallyFiniteComplexMeasure.variationControl, Measure.add_apply] at h
  have hr := (add_eq_zero.mp h).1
  rw [LocallyFiniteSignedMeasure.totalVariation, Measure.add_apply] at hr
  exact add_eq_zero.mp hr

lemma zeroJetRealSpan_selfdual (data : List JetDatum) (h : ∀ j ∈ data, ValidJet j) :
    (zeroJetRealSpan data).FourierSelfdual (zeroJetRealSpan_growth data h) :=
  rePart_fourierSelfdual_of_complex _ (actualZeroJetSum_growth data h)
    (actualZeroJetSum_fourier data h) (actualZeroJetSum_reflect data h)

/-- Actual finite zero-jet measures cannot enter the off-lattice positive cone.
All analytic hypotheses of the parent separator are proved above from actual jets. -/
theorem finite_zero_span_positive_only_zero (data : List JetDatum)
    (h : ∀ j ∈ data, ValidJet j) (hoff : (zeroJetRealSpan data).OffLatticeNonnegative) :
    (zeroJetRealSpan data).positive = 0 ∧ (zeroJetRealSpan data).negative = 0 := by
  exact signed_sharp_gap_separator _ (zeroJetRealSpan_growth data h)
    (zeroJetRealSpan_selfdual data h) (zeroJetRealSpan_gap data) hoff

#print axioms Zeta23.OPICAFollowup.FiniteSpanScratch.finite_zero_span_positive_only_zero

end Zeta23.OPICAFollowup.FiniteSpanScratch
