from pathlib import Path
import hashlib, json
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
SPAN=HERE.parent/'audit-finite-span'
OVERLAY=HERE/'overlay'
source=(SPAN/'FiniteSpanSeparationFullCandidate.lean').read_bytes()
target=OVERLAY/'Zeta23/OPICAFollowup/FiniteSpanSeparation.lean'
target.write_bytes(source)
consumer=(SPAN/'ConsumersSpanFullCandidate.lean').read_text(encoding='utf-8')
consumer='\n'.join(l for l in consumer.splitlines() if not l.startswith('import '))+'\n'
old=(REPO/'Zeta23/OPICAFollowup/Consumers.lean').read_bytes()
new=b'import Zeta23.OPICAFollowup.FiniteSpanSeparation\n'+old+b'\n'+consumer.encode('utf-8')
(OVERLAY/'Zeta23/OPICAFollowup/Consumers.lean').write_bytes(new)
result={'status':'UNACCEPTED_INSTALLABLE_SCRATCH_SOURCE_NOT_COMPILED',
    'finite_span_source':str(SPAN/'FiniteSpanSeparationFullCandidate.lean'),
    'finite_span_sha256':hashlib.sha256(source).hexdigest(),
    'original_consumers_sha256':hashlib.sha256(old).hexdigest(),
    'proposed_combined_consumers_sha256':hashlib.sha256(new).hexdigest(),
    'scope':'Original Consumers bytes preserved; one required actual finite-span import and the complete physical consumer appended. No owner file edited; independent review remains unset.'}
(HERE/'span-overlay-provenance.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
