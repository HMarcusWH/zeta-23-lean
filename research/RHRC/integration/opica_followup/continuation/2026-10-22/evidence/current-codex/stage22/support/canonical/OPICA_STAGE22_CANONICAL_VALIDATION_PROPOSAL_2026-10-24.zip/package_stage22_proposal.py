from pathlib import Path
import hashlib, json, zipfile
HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
base = json.loads((HERE / 'stage22-overlay-provenance.json').read_text())
rows = []
for row in base['assembly']:
    rows.append({'repository_path': row['path'], 'candidate': 'overlay/' + row['path'],
        'base_source_sha256': row['base_source_sha256'], 'candidate_sha256': row['assembled_sha256'],
        'integration': 'Exact base source bytes plus sealed fragment body after removing standalone self-import.'})
for rel in ['Zeta23/OPICAFollowup/Validation.lean', 'Zeta23/OPICAFollowup.lean']:
    rows.append({'repository_path': rel, 'candidate': 'overlay/' + rel,
        'candidate_sha256': sha(HERE / 'overlay' / rel),
        'integration': 'Complete explicit Validation proposal; facade imports only Consumers.' if '/Validation.' in rel else 'Same one-import Stage21 facade.'})
manifest = {'schema': 'OPICA_STAGE22_INSTALLABLE_PROPOSAL_V1',
    'status': 'OUTSIDE_CHECKOUT_PROPOSAL_ONLY_NOT_INDEPENDENTLY_APPROVED',
    'base_head': base['base_head'], 'base_tree': base['base_tree'], 'files': rows,
    'optional_independent_consumer': {'source': 'ExpectedCanonicalInterfaces.lean', 'sha256': sha(HERE / 'ExpectedCanonicalInterfaces.lean')},
    'required_expected_matrix': {'path': 'full-type-consumer-matrix.json', 'sha256': sha(HERE / 'full-type-consumer-matrix.json')},
    'warm_receipt': {'path': 'stage22-warm-assembled-receipt.json', 'sha256': sha(HERE / 'stage22-warm-assembled-receipt.json')},
    'type_and_negative_controls': {'path': 'stage22-type-control-receipt.json', 'sha256': sha(HERE / 'stage22-type-control-receipt.json')},
    'canonical_sealed_archive': {'path': 'OPICA_CANONICAL_INTERFACES_2026-10-24.zip', 'sha256': sha(HERE / 'OPICA_CANONICAL_INTERFACES_2026-10-24.zip')},
    'pending_source_integration': 'Actual SquareDefect Jordan adapter/physical consumers are a separate sibling proposal. Append its genuine full physical companion before final owner Validation replay; do not transfer this receipt to later bytes.',
    'full100_signatures': '93 required-name type matches plus7 separately retained complete signature companions. All111 explicit expected/companion declarations compiled. No independent semantic approval inferred.',
    'import_refinement': 'Consumers preserves all13 required imports plus necessary preexisting NativeJetAdapter. Facade1 and Validation1. Frozen dependency amendment remains independently unaccepted.',
    'owner_actions_required': ['Review exact proposed bodies and physical domains', 'Integrate genuine separate SquareDefect physical companion',
        'Compile actual final sources and independent consumers at clean new pin', 'Run UNACCEPTED cold100 diagnostic at final clean pin',
        'Obtain independent all100 semantic/type/definition/dependency review without inventing approvals'],
    'review_seal': 'UNSET', 'full_release_accepted': False, 'release_ready': False, 'RH': 'OPEN', 'Step4': 'OPEN'}
(HERE / 'stage22-install-proposal.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
names = [p.name for p in HERE.iterdir() if p.is_file() and p.suffix in {'.py', '.json', '.lean', '.log', '.md', '.txt'}
    and p.name not in {'warm-overlay-receipt.json', 'ValidationProductionProposal.lean', 'ValidationProposal.lean',
        'ValidationProposal.failed-shadow.lean.txt', 'coverage-inventory.json'}]
# Historical diagnostics are labelled in their filenames and kept beside exact sources.
paths = [HERE / name for name in names]
paths += [HERE / row['candidate'] for row in rows]
paths += [HERE / 'OPICA_CANONICAL_INTERFACES_2026-10-24.zip']
archive = HERE / 'OPICA_STAGE22_CANONICAL_VALIDATION_PROPOSAL_2026-10-24.zip'
file_manifest = [{'path': str(p.relative_to(HERE)).replace('\\', '/'), 'sha256': sha(p)} for p in paths]
(HERE / 'stage22-package-files.json').write_text(json.dumps(file_manifest, indent=2) + '\n', encoding='utf-8')
paths += [HERE / 'stage22-package-files.json']
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in paths:
        assert p.suffix != '.olean'
        z.write(p, str(p.relative_to(HERE)).replace('\\', '/'))
print(archive.name, sha(archive), len(paths), 'files;no object files;UNACCEPTED')
