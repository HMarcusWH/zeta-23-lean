import Zeta23.OPICAFollowup.WeightedMixing
noncomputable section
open Set MeasureTheory Filter Complex
open scoped ENNReal Topology FourierTransform SchwartzMap
open Zeta23.OPICA Zeta23.OPICAFollowup
namespace Zeta23.OPICAFollowup.Validation

/- Complete written source signature, retaining every conjunct; independent review remains OPEN. -/
theorem expected_weighted_mobius_inverse (σ : LocallyFiniteComplexMeasure) (a : ℝ) (ha : 1 / 2 < a)
    (hm : mixingExponentialMoment a σ < ∞) :
    (∀ i : Fin 4, positiveLogMeasure (positiveDilationMixture (mixingCoordinate σ i)) =
      integerLogComb ∗ mixingCoordinate σ i) ∧
    (positiveLogMeasure (weightedDilationMixture σ a ha.le hm).rePart.positive +
        integerLogComb ∗ σ.rePart.negative =
      positiveLogMeasure (weightedDilationMixture σ a ha.le hm).rePart.negative +
        integerLogComb ∗ σ.rePart.positive) ∧
    (positiveLogMeasure (weightedDilationMixture σ a ha.le hm).imPart.positive +
        integerLogComb ∗ σ.imPart.negative =
      positiveLogMeasure (weightedDilationMixture σ a ha.le hm).imPart.negative +
        integerLogComb ∗ σ.imPart.positive) ∧
    (moebiusPlusComb ∗ integerLogComb = Measure.dirac 0 + moebiusMinusComb ∗ integerLogComb) ∧
    (σ.rePart.positive +
        (moebiusPlusComb ∗ positiveLogMeasure (weightedDilationMixture σ a ha.le hm).rePart.negative +
          moebiusMinusComb ∗ positiveLogMeasure (weightedDilationMixture σ a ha.le hm).rePart.positive) =
      σ.rePart.negative +
        (moebiusPlusComb ∗ positiveLogMeasure (weightedDilationMixture σ a ha.le hm).rePart.positive +
          moebiusMinusComb ∗ positiveLogMeasure (weightedDilationMixture σ a ha.le hm).rePart.negative)) ∧
    (σ.imPart.positive +
        (moebiusPlusComb ∗ positiveLogMeasure (weightedDilationMixture σ a ha.le hm).imPart.negative +
          moebiusMinusComb ∗ positiveLogMeasure (weightedDilationMixture σ a ha.le hm).imPart.positive) =
      σ.imPart.negative +
        (moebiusPlusComb ∗ positiveLogMeasure (weightedDilationMixture σ a ha.le hm).imPart.positive +
          moebiusMinusComb ∗ positiveLogMeasure (weightedDilationMixture σ a ha.le hm).imPart.negative)) ∧
    (∀ i : Fin 4, weightedLogNorm a (mixingCoordinate σ i) < ∞) ∧
    (weightedLogNorm a (positiveLogMeasure (weightedDilationMixture σ a ha.le hm).rePart.positive) < ∞ ∧
      weightedLogNorm a (positiveLogMeasure (weightedDilationMixture σ a ha.le hm).rePart.negative) < ∞ ∧
      weightedLogNorm a (positiveLogMeasure (weightedDilationMixture σ a ha.le hm).imPart.positive) < ∞ ∧
      weightedLogNorm a (positiveLogMeasure (weightedDilationMixture σ a ha.le hm).imPart.negative) < ∞) ∧
    (∀ (μ ρ : Measure ℝ) [SFinite ρ],
      weightedLogNorm a (μ ∗ ρ) = weightedLogNorm a μ * weightedLogNorm a ρ) ∧
    (weightedLogNorm a integerLogComb = ENNReal.ofReal (∑' n : ℕ, (n : ℝ) ^ (-(a + 1 / 2))) ∧
      ((∑' n : ℕ, (n : ℝ) ^ (-(a + 1 / 2)) : ℝ) : ℂ) = riemannZeta ((a + 1 / 2 : ℝ) : ℂ)) ∧
    (moebiusPlusComb ⟂ₘ moebiusMinusComb ∧
      weightedLogNorm a (moebiusPlusComb + moebiusMinusComb) =
        ENNReal.ofReal (∑' n : ℕ, (|ArithmeticFunction.moebius n| : ℝ) * (n : ℝ) ^ (-(a + 1 / 2))) ∧
      ((∑' n : ℕ, (|ArithmeticFunction.moebius n| : ℝ) * (n : ℝ) ^ (-(a + 1 / 2)) : ℝ) : ℂ) =
        riemannZeta ((a + 1 / 2 : ℝ) : ℂ) / riemannZeta ((2 * a + 1 : ℝ) : ℂ)) := by
  exact weighted_mobius_inverse σ a ha hm

/- Complete written source signature, retaining every conjunct; independent review remains OPEN. -/
theorem expected_weighted_mixture_sharp_gap (σ : LocallyFiniteComplexMeasure) (a : ℝ) (ha : 1 / 2 < a)
    (hm : mixingExponentialMoment a σ < ∞)
    (hself : 𝓕 ((weightedDilationMixture σ a ha.le hm).distributionOfLinearGrowth
        (weightedDilationMixture_growth σ a ha.le hm)) =
      (weightedDilationMixture σ a ha.le hm).distributionOfLinearGrowth
        (weightedDilationMixture_growth σ a ha.le hm))
    (hgap : (weightedDilationMixture σ a ha.le hm).variationControl (Ioo (-1) 1 \ {0}) = 0) :
    (∀ i : Fin 4, mixingCoordinate σ i = mixingCoordinate σ i {0} • Measure.dirac 0) ∧
    σ.variationControl ({0}ᶜ) = 0 ∧
    (weightedDilationMixture σ a ha.le hm).distributionOfLinearGrowth
        (weightedDilationMixture_growth σ a ha.le hm) =
      σ.integral (fun _ => 1) • dilatedCombDistribution 0 ∧
    (weightedDilationMixture σ a ha.le hm).compactRestriction {0} isCompact_singleton {0} =
      σ.integral (fun _ => 1) ∧
    ((weightedDilationMixture σ a ha.le hm).compactRestriction {0} isCompact_singleton {0} = 0 →
      (∀ i : Fin 4, mixingCoordinate σ i = 0) ∧
      (weightedDilationMixture σ a ha.le hm).distributionOfLinearGrowth
        (weightedDilationMixture_growth σ a ha.le hm) = 0 ∧
      (weightedDilationMixture σ a ha.le hm).variationControl = 0) := by
  exact weighted_mixture_sharp_gap σ a ha hm hself hgap

/- Complete written source signature, retaining every conjunct; independent review remains OPEN. -/
theorem expected_weighted_gap_leakage :
    (∀ (σ : LocallyFiniteComplexMeasure) (a : ℝ) (ha : 1 / 2 < a)
        (hm : mixingExponentialMoment a σ < ∞),
      ENNReal.ofReal ((riemannZeta ((2 * a + 1 : ℝ) : ℂ) / riemannZeta ((a + 1 / 2 : ℝ) : ℂ)).re) *
          ∫⁻ t in Iio 0, ENNReal.ofReal (Real.exp (-a * t)) ∂σ.totalVariation ≤
        ∫⁻ x in Ioo 0 1, ENNReal.ofReal (x ^ (-a - 1 / 2))
          ∂(weightedDilationMixture σ a ha.le hm).totalVariation ∧
      ENNReal.ofReal ((riemannZeta ((2 * a + 1 : ℝ) : ℂ) / riemannZeta ((a + 1 / 2 : ℝ) : ℂ)).re) *
          ∫⁻ t in Iio 0, ENNReal.ofReal (Real.exp (-a * t)) ∂σ.rePart.totalVariation ≤
        ∫⁻ x in Ioo 0 1, ENNReal.ofReal (x ^ (-a - 1 / 2))
          ∂(weightedDilationMixture σ a ha.le hm).rePart.totalVariation ∧
      ENNReal.ofReal ((riemannZeta ((2 * a + 1 : ℝ) : ℂ) / riemannZeta ((a + 1 / 2 : ℝ) : ℂ)).re) *
          ∫⁻ t in Iio 0, ENNReal.ofReal (Real.exp (-a * t)) ∂σ.imPart.totalVariation ≤
        ∫⁻ x in Ioo 0 1, ENNReal.ofReal (x ^ (-a - 1 / 2))
          ∂(weightedDilationMixture σ a ha.le hm).imPart.totalVariation ∧
      ENNReal.ofReal ((riemannZeta ((2 * a + 1 : ℝ) : ℂ) / riemannZeta ((a + 1 / 2 : ℝ) : ℂ)).re) *
          ∫⁻ t in Iio 0, ENNReal.ofReal (Real.exp (-a * t)) ∂σ.variationControl ≤
        ∫⁻ x in Ioo 0 1, ENNReal.ofReal (x ^ (-a - 1 / 2))
          ∂(weightedDilationMixture σ a ha.le hm).variationControl) ∧
    (∀ (h : ℝ → ℂ) (H b : ℝ), 1 / 2 < b → Continuous h → (∀ t, h (-t) = h t) →
      (∀ t, ‖h t‖ ≤ H * Real.exp (-b * |t|)) →
      ENNReal.ofReal ((riemannZeta ((2 * b + 1 : ℝ) : ℂ) / riemannZeta ((b + 1 / 2 : ℝ) : ℂ)).re) *
          (⨆ t ∈ Ici (0 : ℝ), ENNReal.ofReal (Real.exp (b * t) * ‖h t‖)) ≤
        ⨆ x ∈ Ioo (0 : ℝ) 1, ENNReal.ofReal (x ^ (1 / 2 - b) * ‖mixtureDensity h x‖)) ∧
    (∀ (h : ℝ → ℂ) (H a b : ℝ), a < b → (∀ t, ‖h t‖ ≤ H * Real.exp (-b * |t|)) →
      ∫⁻ t, ENNReal.ofReal (Real.exp (a * |t|) * ‖h t‖) < ∞) ∧
    (∀ b : ℝ, 1 / 2 < b → ∃ h : ℝ → ℂ, Continuous h ∧ (∀ t, h (-t) = h t) ∧
      (∀ t, ‖h t‖ ≤ 1 * Real.exp (-b * |t|)) ∧
      ∫⁻ t, ENNReal.ofReal (Real.exp (b * |t|) * ‖h t‖) = ∞) ∧
    (∀ (h : ℝ → ℂ) (hc : Continuous h) (H b : ℝ), 1 / 2 < b →
      (∀ t, ‖h t‖ ≤ H * Real.exp (-b * |t|)) →
      (∀ a : ℝ, a < b → mixingExponentialMoment a (densityMixer h hc) < ∞) ∧
      (∀ i : Fin 4, ∀ s : Set ℝ, MeasurableSet s → s ⊆ Ioi 0 →
        positiveDilationMixture (mixingCoordinate (densityMixer h hc) i) s =
          ∫⁻ x in s, positiveMixtureDensity
            (fun t => ENNReal.ofReal (densityCoordinate h i t)) x) ∧
      (∀ i : Fin 4, ∀ x : ℝ, 0 < x →
        positiveMixtureDensity (fun t => ENNReal.ofReal (densityCoordinate h i t)) x < ∞) ∧
      (∀ x : ℝ, 0 < x → mixtureDensity h x =
        (((positiveMixtureDensity (fun t => ENNReal.ofReal (densityCoordinate h 0 t)) x).toReal -
          (positiveMixtureDensity (fun t => ENNReal.ofReal (densityCoordinate h 1 t)) x).toReal :
            ℝ) : ℂ) +
        Complex.I * (((positiveMixtureDensity
            (fun t => ENNReal.ofReal (densityCoordinate h 2 t)) x).toReal -
          (positiveMixtureDensity (fun t => ENNReal.ofReal (densityCoordinate h 3 t)) x).toReal :
            ℝ) : ℂ))) := by
  exact weighted_gap_leakage

end Zeta23.OPICAFollowup.Validation
