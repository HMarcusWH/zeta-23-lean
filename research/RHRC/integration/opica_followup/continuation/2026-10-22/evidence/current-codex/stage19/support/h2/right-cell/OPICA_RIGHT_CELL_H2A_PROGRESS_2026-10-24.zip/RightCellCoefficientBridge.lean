import ActualJetTaylor
import ShCoefficientExtraction

noncomputable section
set_option maxHeartbeats 800000
open Set Filter Complex
open scoped Topology
namespace OPICARightCellTaylor

variable {ι : Type*} [Fintype ι]

/-- A vanishing finite combination of the actual analytic right-cell jets has
zero polynomial Hermite rows. This uses only finite uniform remainders. -/
theorem rightCell_combination_coefficients_zero (node : ι → ℂ) (order : ι → ℕ)
    (a : ι → ℂ) {ε : ℝ} (hε : 0 < ε)
    (hvan : ∀ u : ℝ, 0 < u → u < ε → ∑ i, a i * rightCellJet (node i) (order i) u = 0) :
    ∀ n : ℕ, ∑ i, a i * oddJetCoefficient (node i) (order i) n = 0 := by
  classical
  apply OPICAShCoefficientExtraction.odd_coefficients_eq_zero_of_remainder_bound _
    (ε := min ε 1) (lt_min hε zero_lt_one)
  intro n
  let C : ι → ℝ := fun i =>
    (‖node i‖ + 2) ^ (n + 2) * expMajorant (‖node i‖ + 2)
  refine ⟨∑ i, ‖a i‖ * C i, ?_⟩
  intro u hu hmin
  have huε : u < ε := (lt_min_iff.mp hmin).1
  have hu1 : |u| ≤ 1 := by rw [abs_of_pos hu]; exact le_of_lt (lt_min_iff.mp hmin).2
  have heq : (∑ j ∈ Finset.range (n + 1),
      (∑ i, a i * oddJetCoefficient (node i) (order i) j) * (u : ℂ) ^ (2 * j + 1)) =
      ∑ i, a i * partialJet (node i) (order i) u n := by
    simp_rw [Finset.sum_mul]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i hi
    rw [partialJet_eq, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j hj
    ring
  rw [heq]
  have hres : (∑ i, a i * partialJet (node i) (order i) u n) =
      ∑ i, a i * (partialJet (node i) (order i) u n - rightCellJet (node i) (order i) u) := by
    simp_rw [mul_sub]
    rw [Finset.sum_sub_distrib, hvan u hu huε, sub_zero]
  rw [hres]
  calc
    ‖∑ i, a i * (partialJet (node i) (order i) u n - rightCellJet (node i) (order i) u)‖
      ≤ ∑ i, ‖a i * (partialJet (node i) (order i) u n - rightCellJet (node i) (order i) u)‖ :=
        norm_sum_le _ _
    _ ≤ ∑ i, ‖a i‖ * (C i * u ^ (2 * n + 3)) := by
      apply Finset.sum_le_sum
      intro i hi
      rw [norm_mul, norm_sub_rev]
      apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
      simpa [C, abs_of_pos hu] using normalized_jet_remainder (node i) (order i) hu1 n
    _ = (∑ i, ‖a i‖ * C i) * u ^ (2 * n + 3) := by
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro i hi
      ring

theorem rightCell_combination_polynomial_rows_zero (node : ι → ℂ) (order : ι → ℕ)
    (a : ι → ℂ) {ε : ℝ} (hε : 0 < ε)
    (hvan : ∀ u : ℝ, 0 < u → u < ε → ∑ i, a i * rightCellJet (node i) (order i) u = 0) :
    ∀ n : ℕ, ∑ i, a i *
      (iteratedDeriv (order i) (fun w : ℂ => w * (1 / 4 - w) ^ n) (node i) /
        ((order i).factorial : ℂ)) = 0 := by
  intro n
  have h := rightCell_combination_coefficients_zero node order a hε hvan n
  unfold oddJetCoefficient at h
  simp_rw [← mul_div_assoc] at h
  rw [← Finset.sum_div] at h
  have hr := (div_eq_zero_iff.mp h).resolve_right
    (by exact_mod_cast Nat.factorial_ne_zero (2 * n + 1))
  simpa only [mul_div_assoc] using hr

#print axioms rightCell_combination_coefficients_zero
#print axioms rightCell_combination_polynomial_rows_zero
end OPICARightCellTaylor
