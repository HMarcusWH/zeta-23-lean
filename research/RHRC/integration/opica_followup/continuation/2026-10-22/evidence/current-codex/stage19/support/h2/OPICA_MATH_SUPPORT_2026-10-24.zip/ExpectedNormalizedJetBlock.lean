import NormalizedJetBlock

namespace OPICAIndependent
open OPICAAudit

theorem expected_local_multiplication_kernel {K : Type*} [Field K]
    (m : ℕ) (κ : K) (hκ : κ ≠ 0) (a : ℕ → K)
    (h : ∀ k < m, κ * a k + (if k = 0 then 0 else a (k - 1)) = 0) :
    ∀ k < m, a k = 0 :=
  (normalizedJetMul_zero_iff hκ a).mp h

theorem expected_local_multiplication_injective {K : Type*} [Field K]
    (m : ℕ) (κ : K) (hκ : κ ≠ 0) (a b : ℕ → K)
    (h : ∀ k < m,
      κ * a k + (if k = 0 then 0 else a (k - 1)) =
        κ * b k + (if k = 0 then 0 else b (k - 1))) :
    ∀ k < m, a k = b k :=
  normalizedJetMul_injective_on_truncation hκ a b h

#print axioms expected_local_multiplication_kernel
#print axioms expected_local_multiplication_injective
end OPICAIndependent
