$ErrorActionPreference = 'Continue'
$repoPath = 'C:\Users\macka\.codex\.chatgpt-projects\g-p-6a353c7268b08191b685956e466d73e4\work\opica-followup-repo'
$outputPath = 'C:\Users\macka\.codex\.chatgpt-projects\g-p-6a353c7268b08191b685956e466d73e4\work\opica-stage19\python\unsandboxed-parent'
$pythonPath = 'C:\Users\macka\.codex\.chatgpt-projects\g-p-6a353c7268b08191b685956e466d73e4\work\tools\python-3.13.5-embed-amd64\python.exe'
New-Item -ItemType Directory -Path $outputPath -Force | Out-Null
$env:TEMP = Join-Path $outputPath 'temp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Path $env:TEMP -Force | Out-Null
Set-Location -LiteralPath $repoPath
$before = @{head=(& git rev-parse HEAD);tree=(& git rev-parse 'HEAD^{tree}');status=@(& git status --porcelain=v1);utc=[DateTime]::UtcNow.ToString('o');python=$pythonPath}
$before | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $outputPath 'source-before.json') -Encoding utf8NoBOM
$commandRows = [System.Collections.Generic.List[object]]::new()
function Invoke-AuditPython {
 param([string]$Label,[string[]]$PyArgs)
 $start = [DateTime]::UtcNow.ToString('o')
 $logPath = Join-Path $outputPath ($Label+'.log')
 & $pythonPath @PyArgs > $logPath 2>&1
 $rc = $LASTEXITCODE
 $row = @{label=$Label;program=$pythonPath;args=$PyArgs;cwd=$repoPath;exit_code=$rc;started_at=$start;finished_at=[DateTime]::UtcNow.ToString('o');log=$logPath;log_sha256=(Get-FileHash -LiteralPath $logPath -Algorithm SHA256).Hash.ToLowerInvariant()}
 $commandRows.Add($row)
 $commandRows | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $outputPath 'commands.json') -Encoding utf8NoBOM
 Write-Output ($Label+' exit='+$rc)
}
Invoke-AuditPython -Label 'environment' -PyArgs @('-B','-c','import sys,platform; print(sys.version); print(platform.platform()); import mpmath; print("mpmath",mpmath.__version__)')


Invoke-AuditPython -Label 'parent-contract-normal' -PyArgs @('-B','-m','unittest','discover','-s','research/RHRC/integration/opica/tests','-p','test_contract.py')
Invoke-AuditPython -Label 'parent-contract-optimized' -PyArgs @('-B','-O','-m','unittest','discover','-s','research/RHRC/integration/opica/tests','-p','test_contract.py')
# Frozen replay is preserved independently by the initial script.
$after = @{head=(& git rev-parse HEAD);tree=(& git rev-parse 'HEAD^{tree}');status=@(& git status --porcelain=v1);utc=[DateTime]::UtcNow.ToString('o')}
$after | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $outputPath 'source-after.json') -Encoding utf8NoBOM
