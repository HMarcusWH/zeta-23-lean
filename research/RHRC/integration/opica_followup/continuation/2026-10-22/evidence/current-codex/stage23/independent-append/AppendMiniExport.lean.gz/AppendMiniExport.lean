import Zeta23.OPICAFollowup
import Zeta23.OPICAFollowup.AuxiliaryCompletions
import Zeta23.OPICAFollowup.BalancedCoefficients
import Zeta23.OPICAFollowup.BoundaryAmplitude
import Zeta23.OPICAFollowup.CoPoissonJets
import Zeta23.OPICAFollowup.ComplexLocalMeasures
import Zeta23.OPICAFollowup.ConfluentProfiles
import Zeta23.OPICAFollowup.Consumers
import Zeta23.OPICAFollowup.Counterexamples
import Zeta23.OPICAFollowup.DilatedComb
import Zeta23.OPICAFollowup.FiniteSpanSeparation
import Zeta23.OPICAFollowup.FirstCellCost
import Zeta23.OPICAFollowup.ForcedEuler
import Zeta23.OPICAFollowup.ForwardLocalization
import Zeta23.OPICAFollowup.JointObservation
import Zeta23.OPICAFollowup.LogFourierSobolev
import Zeta23.OPICAFollowup.LogSlackBalance
import Zeta23.OPICAFollowup.MaskedNativeRate
import Zeta23.OPICAFollowup.MovingSourceWindowRate
import Zeta23.OPICAFollowup.MultiplicityTail
import Zeta23.OPICAFollowup.NativeExplicitFormula
import Zeta23.OPICAFollowup.NativeFilters
import Zeta23.OPICAFollowup.NativeResolvent
import Zeta23.OPICAFollowup.NativeSourceFamily
import Zeta23.OPICAFollowup.NativeSourceTransforms
import Zeta23.OPICAFollowup.NativeTransformationWords
import Zeta23.OPICAFollowup.NativeWindowRate
import Zeta23.OPICAFollowup.NearGapLimits
import Zeta23.OPICAFollowup.NormFirstTransfer
import Zeta23.OPICAFollowup.ProfileEulerMaclaurin
import Zeta23.OPICAFollowup.RenormalizedCoPoisson
import Zeta23.OPICAFollowup.RobustLaurent
import Zeta23.OPICAFollowup.SamplingCompatibility
import Zeta23.OPICAFollowup.SawtoothForce
import Zeta23.OPICAFollowup.SourceVerticalBounds
import Zeta23.OPICAFollowup.SquareDefect
import Zeta23.OPICAFollowup.UniformSourceBounds
import Zeta23.OPICAFollowup.Validation
import Zeta23.OPICAFollowup.WeightedMixing
import Zeta23.OPICAFollowup.WeightedSpectralMeasure
import Zeta23.OPICAFollowup.ZeroProfiles
import Zeta23.OPICAFollowup.ZetaLeftLineBounds
import Zeta23.OPICAFollowup.Validation
import Zeta23.RHRC.OpicaTypeExprExport
import Lean.Util.FoldConsts
import Zeta23.RHRC.SourceCandidateResolution
import Lean.Util.CollectAxioms
import Lean.Meta.Eqns

/-! AUDIT_ONLY source-bound enumeration of the implemented subset.
The remaining planned roots are absent, never counted as proved. -/
open Lean Lean.Elab Command
namespace Zeta23.RHRC

namespace FollowupDependencyExport
private def moduleOf? (env : Environment) (decl : Name) : Option Name :=
  match env.getModuleIdxFor? decl with
  | none => none
  | some modIdx => some env.allImportedModuleNames[modIdx.toNat]!

private def isProjectLocalModule : Option Name → Bool
  | none => false
  | some modName =>
      let s := modName.toString
      s == "Zeta23" || s.startsWith "Zeta23."

private def kindString : ConstantInfo → String
  | .axiomInfo _ => "AXIOM"
  | .defnInfo _ => "DEFINITION"
  | .thmInfo _ => "THEOREM"
  | .opaqueInfo _ => "OPAQUE"
  | .quotInfo _ => "QUOTIENT"
  | .inductInfo _ => "INDUCTIVE"
  | .ctorInfo _ => "CONSTRUCTOR"
  | .recInfo _ => "RECURSOR"

private def structuralDependencies : ConstantInfo → Array Name
  | .inductInfo info => (info.ctors ++ info.all).toArray
  | .ctorInfo info => #[info.induct]
  | .recInfo info => info.all.toArray
  | _ => #[]

private def emitDeclaration (env : Environment) (decl : Name) : CommandElabM Unit := do
  let some info := env.find? decl
    | throwError "RHKG dependency export: unknown declaration {decl}"
  let moduleText := match moduleOf? env decl with
    | some modName => modName.toString
    | none => "-"
  let privateOrInternalText := if decl.isInternal || isPrivateName decl then "1" else "0"
  liftIO <| IO.println s!"RHKG_DEP_DECL\t{decl}\t{moduleText}\t{kindString info}\t{privateOrInternalText}"

private def emitChannel
    (source : Name) (deps : NameSet) (channel : String) : CommandElabM Unit := do
  let mut line := s!"RHKG_DEP_CHANNEL\t{source}\t{channel}"
  for dep in deps do
    line := line ++ "\t" ++ dep.toString
  liftIO <| IO.println line

private partial def visit
    (env : Environment) (pending : List Name)
    (visited emitted scheduled : NameHashSet) : CommandElabM Unit := do
  match pending with
  | [] => return
  | decl :: rest =>
      if visited.contains decl then
        visit env rest visited emitted scheduled
      else
        let some info := env.find? decl
          | throwError "RHKG dependency export: unknown declaration {decl}"
        let mut emitted := emitted
        if !(emitted.contains decl) then
          emitDeclaration env decl
          emitted := emitted.insert decl
        -- The receipt records presence-by-channel, not occurrence multiplicity.
        -- NameSet prevents repeated appearances in a large proof term from
        -- creating duplicate protocol edges or duplicate traversal work.
        let typeDeps := info.type.getUsedConstantsAsSet
        let valueDeps := match info.value? (allowOpaque := true) with
          | some value => value.getUsedConstantsAsSet
          | none => ({} : NameSet)
        let structureDeps :=
          (NameSet.ofArray (structuralDependencies info)).filter fun dep => dep != decl

        -- Preserve exact expression-level self references if Lean emits them.
        -- Structural membership self-links are excluded because they are
        -- declaration-family bookkeeping rather than constant use.
        for dep in typeDeps do
          if !(emitted.contains dep) then
            emitDeclaration env dep
            emitted := emitted.insert dep
        for dep in valueDeps do
          if !(emitted.contains dep) then
            emitDeclaration env dep
            emitted := emitted.insert dep
        for dep in structureDeps do
          if !(emitted.contains dep) then
            emitDeclaration env dep
            emitted := emitted.insert dep

        -- Emit at most one protocol record per declaration/channel rather than
        -- one IO.println per edge. The Python side reconstructs the same exact
        -- channel presence relation from the batched records.
        emitChannel decl typeDeps "TYPE"
        emitChannel decl valueDeps "VALUE"
        emitChannel decl structureDeps "STRUCTURE"

        -- A visited set alone does not deduplicate declarations that are
        -- queued many times before their first visit. Track scheduled names
        -- so highly shared dependencies enter the pending list only once.
        let mut next := rest
        let mut scheduled := scheduled
        for dep in typeDeps do
          if isProjectLocalModule (moduleOf? env dep) && !(scheduled.contains dep) then
            next := dep :: next
            scheduled := scheduled.insert dep
        for dep in valueDeps do
          if isProjectLocalModule (moduleOf? env dep) && !(scheduled.contains dep) then
            next := dep :: next
            scheduled := scheduled.insert dep
        for dep in structureDeps do
          if isProjectLocalModule (moduleOf? env dep) && !(scheduled.contains dep) then
            next := dep :: next
            scheduled := scheduled.insert dep
        visit env next (visited.insert decl) emitted scheduled

/--
Emit the local Zeta23 dependency closure rooted at the supplied declarations.
External constants are emitted as boundary nodes but are not recursively expanded.
-/
public def exportDependencies (roots : Array Name) : CommandElabM Unit := do
  let env ← getEnv
  let mut scheduled : NameHashSet := {}
  for root in roots do
    scheduled := scheduled.insert root
  visit env roots.toList {} {} scheduled



end FollowupDependencyExport

private def opicaKind : ConstantInfo → String
  | .axiomInfo _ => "AXIOM"
  | .defnInfo _ => "DEFINITION"
  | .thmInfo _ => "THEOREM"
  | .opaqueInfo _ => "OPAQUE"
  | .quotInfo _ => "QUOTIENT"
  | .inductInfo _ => "INDUCTIVE"
  | .ctorInfo _ => "CONSTRUCTOR"
  | .recInfo _ => "RECURSOR"

/-- Lean reserves these names for equations of an existing safe definition.
The equation still receives the full public type, axiom and dependency audit. -/
private def reservedEquationOrigin? (env : Environment) (name : Name)
    (info : ConstantInfo) : Option Name := do
  if opicaKind info != "THEOREM" then none else do
    let (origin, suffix) ← Lean.Meta.declFromEqLikeName env name
    if name == Lean.Meta.mkEqLikeNameFor env origin suffix then some origin else none

run_cmd do
  let queries : Array SourceCandidateQuery := #[
    ({ sourceId := "OPICA_APPEND_MINI_1", moduleName := "Zeta23.OPICAFollowup.Validation", shortName := "Zeta23.OPICAFollowup.Validation.independentlyIntendedComplexMobius", sourceKind := "DEFINITION" } : SourceCandidateQuery),
    ({ sourceId := "OPICA_APPEND_MINI_2", moduleName := "Zeta23.OPICAFollowup.Validation", shortName := "Zeta23.OPICAFollowup.Validation.postSealMobiusAuxiliaryInterface", sourceKind := "DEFINITION" } : SourceCandidateQuery),
    ({ sourceId := "OPICA_APPEND_MINI_3", moduleName := "Zeta23.OPICAFollowup.Validation", shortName := "Zeta23.OPICAFollowup.Validation.expected_independent_complete_complex_mobius", sourceKind := "THEOREM" } : SourceCandidateQuery),
    ({ sourceId := "OPICA_APPEND_MINI_4", moduleName := "Zeta23.OPICAFollowup.Validation", shortName := "Zeta23.OPICAFollowup.Validation.expected_independent_complex_mobius_full_interface", sourceKind := "THEOREM" } : SourceCandidateQuery),
    ({ sourceId := "OPICA_APPEND_MINI_5", moduleName := "Zeta23.OPICAFollowup.Validation", shortName := "Zeta23.OPICAFollowup.Validation.expected_square_original_and_full_distribution_domain", sourceKind := "THEOREM" } : SourceCandidateQuery)]
  resolveSourceCandidates queries
  let env ← getEnv
  let names : Array Name := #[
    ``Zeta23.OPICAFollowup.Validation.independentlyIntendedComplexMobius,
    ``Zeta23.OPICAFollowup.Validation.postSealMobiusAuxiliaryInterface,
    ``Zeta23.OPICAFollowup.Validation.expected_independent_complete_complex_mobius,
    ``Zeta23.OPICAFollowup.Validation.expected_independent_complex_mobius_full_interface,
    ``Zeta23.OPICAFollowup.Validation.expected_square_original_and_full_distribution_domain]
  for name in names do
    let info ← getConstInfo name
    if name.isInternal || isPrivateName name then
      throwError "Append selector chose an internal name: {name}"
    let some index := env.getModuleIdxFor? name
      | throwError "Append declaration has no imported origin: {name}"
    let moduleName := env.allImportedModuleNames[index.toNat]!
    unless moduleName.toString == "Zeta23.OPICAFollowup.Validation" do
      throwError "Append declaration has wrong defining module: {name} in {moduleName}"
    let typeDag ← liftIO <| OpicaTypeExprExport.exportType info.type
    let axioms ← Lean.collectAxioms name
    for ax in axioms do
      unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
        throwError "Append unadmitted mathematical axiom: {name} uses {ax}"
    let axiomText := String.intercalate "," (axioms.toList.map Name.toString)
    liftIO <| IO.println s!"OPICA_FOLLOWUP_DECL\t{name}\t{moduleName}\t{opicaKind info}\t{typeDag}\t{axiomText}"
    if opicaKind info == "DEFINITION" then
      let some body := info.value? (allowOpaque := true)
        | throwError "Append definition has no actual expression body: {name}"
      let bodyDag ← liftIO <| OpicaTypeExprExport.exportType body
      liftIO <| IO.println s!"OPICA_APPEND_DEFINITION_BODY\t{name}\t{bodyDag}"
  liftIO <| IO.println s!"OPICA_FOLLOWUP_PUBLIC_COUNT\t{names.size}"
  FollowupDependencyExport.exportDependencies names
  liftIO <| IO.println s!"OPICA_FOLLOWUP_COMPLETE\t{names.size}"

end Zeta23.RHRC
