from pathlib import Path
import datetime,hashlib,json,re,shutil,zipfile
P=Path(__file__).resolve().parent
name='SEALED_TEMPERED_LATTICE_2026-10-24'
D=P/name
assert not D.exists(), 'Seal directory must be new.'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
gates={}
for label,want in [('cutoff7',0),('bridge1',0),('expected1',0),('negative1',1),('final-axioms',0)]:
    r=json.loads((P/(label+'.receipt.json')).read_text())
    assert r['exit_code']==want and r['source_unchanged'],label
    assert sha(P/(label+'.log'))==r['log_sha256'],label
    for path,h in r['source_after'].items():
        assert sha(Path(path))==h,(label,path)
    gates[label]={'exit_code':r['exit_code'],'expected_exit_code':want,
        'source_unchanged':True,'head':r['head'],'tree':r['tree'],
        'log_sha256':r['log_sha256'],'receipt_sha256':sha(P/(label+'.receipt.json'))}
audit=(P/'final-axioms.log').read_text(encoding='utf-8')
rows=re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",audit,re.S)
assert len(rows)==17,len(rows)
std={'propext','Classical.choice','Quot.sound'}
assert all(set(map(str.strip,axs.split(',')))<=std for _,axs in rows)
sources=['SchwartzCompactApprox.lean','TemperedLatticeNoRepair.lean',
    'ExpectedTemperedLatticeNoRepair.lean','TemperedLatticeAxiomAudit.lean',
    'NegativeOmitsCompactCompatibility.lean']
assert not any(re.search(r'\b(?:sorry|axiom|admit)\b',(P/f).read_text(encoding='utf-8')) for f in sources)
extras=['SquareDefectFullDomainAssembled.lean','ExpectedSquareDefectFullDomainAssembled.lean',
    'ExpectedSquareDefectFullDomainProduction.lean','assembly-preparation.json',
    'POST_GREEN_TEMPERED_LATTICE_2026-10-24.md','assemble_production.py',
    'run_scratch.py','print_lean_path.py','seal_delivery.py']
files=sources+extras
for label in gates:
    files += [label+'.log',label+'.receipt.json']
for stem in ['SchwartzCompactApprox','TemperedLatticeNoRepair','ExpectedTemperedLatticeNoRepair','TemperedLatticeAxiomAudit']:
    for suffix in ['.olean','.olean.private','.olean.server']:
        if (P/(stem+suffix)).exists():files.append(stem+suffix)
D.mkdir()
for f in files: shutil.copyfile(P/f,D/f)
base=P.parent/'audit-square-physical'/'SquareDefectPhysicalFullCandidate.lean'
(D/'physical-base').mkdir()
shutil.copyfile(base,D/'physical-base'/base.name)
inventory={str(f.relative_to(D)).replace('\\','/'):{'sha256':sha(f),'bytes':f.stat().st_size}
    for f in sorted(D.rglob('*')) if f.is_file()}
row={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope':'Native narrow full-distribution-tempered correction proof and consumers; assembled canonical production source is prepared only; owner replay/aggregate gates remain required.',
    'gates':gates,'axiom_audit':{n:[x.strip() for x in a.split(',')] for n,a in rows},
    'files':inventory,'source_only_policy':'No owner checkout, synced sources, cache, pin, workflow, registry or review seal mutation.'}
(D/'SEAL_MANIFEST.json').write_text(json.dumps(row,indent=2)+'\n')
z=P/(name+'.zip')
assert not z.exists()
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as zipout:
    for f in sorted(D.rglob('*')):
        if f.is_file():zipout.write(f,str(Path(name)/f.relative_to(D)))
summary={'zip':str(z),'zip_sha256':sha(z),'manifest':str(D/'SEAL_MANIFEST.json'),
    'manifest_sha256':sha(D/'SEAL_MANIFEST.json'),'files':len(inventory),
    'native_green':True,'standard_axiom_declarations':len(rows),
    'production_assembly_sha256':sha(P/'SquareDefectFullDomainAssembled.lean')}
(P/'SEALED_DELIVERY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
