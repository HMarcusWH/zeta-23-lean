from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent
B=P.parent/'audit-budget'
def inline(path):
    return '\n'.join(x for x in path.read_text(encoding='utf-8').splitlines()
        if not x.startswith(('import ','#print axioms '))).strip()+'\n'
base=inline(P/'FiniteSpanSeparationCandidate.lean')
imports='''import Zeta23.OPICAFollowup.ConfluentProfiles
import Zeta23.OPICA.SignedHeatSeparator
import Mathlib.MeasureTheory.Measure.WithDensity
import Mathlib.MeasureTheory.VectorMeasure.Variation.SignedMeasure
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Topology.Order.Compact
import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Tactic

'''
sources=[B/'SincWeightedMeasures.lean',B/'PositiveHomogeneousBudget.lean',B/'TVSignedBudget.lean',P/'FiniteSpanWeighted.lean',B/'ActualFixedBudget.lean']
full=imports+base+'\n'+'\n'.join(inline(p) for p in sources)
full=full.replace('FiniteSpanScratch','FiniteSpan')
full=full.replace('OPICAFixedBasisSupport','Zeta23.OPICAFollowup.FixedBasisSupport')
full=full.replace('have ha := independent_real_span_basis_coefficients_zero basis valid independent',
    'have ha := Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero.2 n basis valid independent')
full+='''
#print axioms Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero
#print axioms Zeta23.OPICAFollowup.fixed_basis_negative_mass_budget
#print axioms Zeta23.OPICAFollowup.actual_basis_negative_mass_even
#print axioms Zeta23.OPICAFollowup.FiniteSpan.signed_eq_of_compactRestrictions
'''
(P/'FiniteSpanSeparationFullCandidate.lean').write_text(full,encoding='utf-8')
replacements={
 'ConsumersSpanFullCandidate.lean':('ConsumersSpanCandidate.lean','import FiniteSpanSeparationCandidate','import FiniteSpanSeparationFullCandidate'),
 'ExpectedFullFiniteSpanFinal.lean':('ExpectedFullFiniteSpan.lean','import FiniteSpanSeparationCandidate','import FiniteSpanSeparationFullCandidate'),
 'ExpectedSpanPhysicalConsumerFinal.lean':('ExpectedSpanPhysicalConsumer.lean','import ConsumersSpanCandidate','import ConsumersSpanFullCandidate'),
 'NegativeFullFiniteSpanFinal.lean':('NegativeFullFiniteSpan.lean','import FiniteSpanSeparationCandidate','import FiniteSpanSeparationFullCandidate'),
}
for target,(source,old,new) in replacements.items():
    content=(P/source).read_text(encoding='utf-8').replace(old,new)
    if target=='ConsumersSpanFullCandidate.lean':
        content=content.replace('FiniteSpan.finite_zero_span_positive_only_zero data h',
          'Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero.1 data h')
        content=content.replace('exact independent_real_span_basis_coefficients_zero basis hb hind a hoff',
          'exact Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero.2 n basis hb hind a hoff')
        content=content.replace('have hp := zero_profile_regular_selfdual j.2.1 hz h0 h1',
          'have hp := zero_profile_regular_selfdual j.2.1 hz h0 h1\n    have hjets := copoisson_zero_jets_measures j.2.1 hz h0 h1 j.2.2 hk')
        content=content.replace('fun hk0 => by rw [hk0, normalizedZeroMeasureJet_zero]',
          'hjets.2.2.2.2.2.2.1')
    (P/target).write_text(content,encoding='utf-8')
expected=(B/'ExpectedActualFixedBudget.lean').read_text(encoding='utf-8').replace('import ActualFixedBudget','import FiniteSpanSeparationFullCandidate').replace('FiniteSpanScratch','FiniteSpan')
expected=re.sub(r'(?<![.\w])zeroJetRealSpan\b','Zeta23.OPICAFollowup.FiniteSpan.zeroJetRealSpan',expected)
expected=expected.replace('EuclideanSpace.norm_eq,realBasisCombinationData,scaleJetData,','EuclideanSpace.norm_eq,realBasisCombinationData,scaleJetData,Zeta23.OPICAFollowup.zeroJetRealSpan,')
expected=expected.replace('#print axioms expected_full_actual_euclidean_budget','#print axioms IndependentActualFixedBudget.expected_full_actual_euclidean_budget').replace('#print axioms no_positive_budget_without_independence','#print axioms IndependentActualFixedBudget.no_positive_budget_without_independence')
(P/'ExpectedActualFixedBudgetFinal.lean').write_text(expected,encoding='utf-8')
for name,source,old in [('NegativeBudgetIndependenceFinal.lean','NegativeMissingIndependence.lean','import ActualFixedBudget'),('WeightedControlsFinal.lean','WeightedControls.lean','import SincWeightedMeasures')]:
    content=(B/source).read_text(encoding='utf-8').replace(old,'import FiniteSpanSeparationFullCandidate').replace('FiniteSpanScratch','FiniteSpan')
    content=content.replace('#print axioms diracTwo_','#print axioms IndependentWeightedBudgetControls.diracTwo_')
    (P/name).write_text(content,encoding='utf-8')
print(json.dumps({'source_components':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'full_candidate_sha256':hashlib.sha256((P/'FiniteSpanSeparationFullCandidate.lean').read_bytes()).hexdigest()}))
