import FiniteSpanSeparationCandidate

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform
namespace Zeta23.OPICAFollowup
open Zeta23.OPICA FiniteSpan

/-- Full physical composition: actual zeta zeros and multiplicity-bounded jets
produce genuine measures, actual zero profiles and all separator premises. -/
theorem actual_zero_measure_span_consumer (data : List JetDatum)
    (h : ∀ j ∈ data, ValidJet j) :
    (∀ j ∈ data, Continuous (zeroProfile j.2.1) ∧ Integrable (zeroProfile j.2.1) ∧
      MemLp (zeroProfile j.2.1) 2 ∧ 𝓕 (zeroProfile j.2.1) = zeroProfile j.2.1 ∧
      (j.2.2 = 0 → normalizedZeroMeasureJet j.2.1 j.2.2 = zeroMeasure j.2.1)) ∧
    (∃ hg : (zeroJetRealSpan data).HasLinearGrowth,
      (zeroJetRealSpan data).FourierSelfdual hg ∧ (zeroJetRealSpan data).HasUnitGap ∧
      ((zeroJetRealSpan data).OffLatticeNonnegative →
        (zeroJetRealSpan data).positive = 0 ∧ (zeroJetRealSpan data).negative = 0)) ∧
    (∀ n : ℕ, ∀ basis : Fin n → List JetDatum,
      ∀ hb : ∀ i, ∀ j ∈ basis i, ValidJet j,
      LinearIndependent ℝ (fun i => (zeroJetRealSpan (basis i)).distributionOfLinearGrowth
        (zeroJetRealSpan_growth _ (hb i))) →
      ∀ a : Fin n → ℝ,
      (zeroJetRealSpan (realBasisCombinationData basis a)).OffLatticeNonnegative → a = 0) := by
  refine ⟨?_, ⟨zeroJetRealSpan_growth data h, zeroJetRealSpan_selfdual data h,
    zeroJetRealSpan_gap data, FiniteSpan.finite_zero_span_positive_only_zero data h⟩, ?_⟩
  · intro j hj
    obtain ⟨hz,h0,h1,hk⟩ := h j hj
    have hp := zero_profile_regular_selfdual j.2.1 hz h0 h1
    exact ⟨hp.2.1, hp.2.2.1, hp.2.2.2.1, hp.2.2.2.2.2.1,
      fun hk0 => by rw [hk0, normalizedZeroMeasureJet_zero]⟩
  · intro n basis hb hind a hoff
    exact independent_real_span_basis_coefficients_zero basis hb hind a hoff

end Zeta23.OPICAFollowup
#print axioms Zeta23.OPICAFollowup.actual_zero_measure_span_consumer
