"""Unaccepted cold compiler evidence, separate from the sealed full producer.

This tool never establishes independent review, registry acceptance or release.
It calls unchanged pinned contract/export/parser/isolation code for computable
evidence only and deliberately never calls reviewed_full_contract or fabricates
its input. Use --run only on the final clean all100 implementation pin.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, subprocess, sys, time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
builder=REPO/'research/RHRC/integration/opica_followup/build_receipt.py'
spec=importlib.util.spec_from_file_location('unaltered_full_receipt_diagnostic',builder)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def dump(path,value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head',required=True)
    parser.add_argument('--base',default=module.ACCEPTED_PARENT)
    parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--lake',default='lake')
    parser.add_argument('--run',action='store_true')
    args=parser.parse_args()
    output=args.output_dir.absolute()
    module.require(not output.resolve().is_relative_to(REPO.resolve()),'diagnostic output must be outside checkout')
    module.require(not output.exists() or not any(output.iterdir()),'fresh empty diagnostic output required')
    contract=module.full_contract(REPO)
    identity=module.full_checkout_identity(REPO,args.head,args.base)
    source=module.full_source_manifest(REPO)
    mathlib=module.verify_mathlib_checkout(REPO,contract)
    queries=contract['roots']  # No invented expected hashes or reviewed consumers.
    driver=module.render_full_exporter(REPO,contract,{'queries':queries})
    result={'schema':'OPICA_UNACCEPTED_COLD100_DIAGNOSTIC_V1','status':'PLAN_ONLY_NOT_COMPILED',
        'purpose':'Compute source/type/axiom/private-dependency evidence for independent review; not an accepted compiler receipt.',
        **identity,'frozen_input_sha256':contract['input_sha256'],'source_manifest':source,
        'source_manifest_sha256':module.object_sha256(source),'mathlib_commit':mathlib,
        'producer_source_sha256':hashlib.sha256(builder.read_bytes()).hexdigest(),
        'exporter_template_sha256':module.FULL_TEMPLATE_SHA256,'exporter_driver_sha256':hashlib.sha256(driver).hexdigest(),
        'original_root_queries':queries,'commands':[],'review_seal_present':module.FULL_REVIEW_SHA256 is not None,
        'independent_expected_type_and_domain_review':'NOT_ESTABLISHED',
        'registered_projection':'NOT_ACCEPTED','parent_release':'NOT_ESTABLISHED',
        'full_release_accepted':False,'release_ready':False,'RH':'OPEN','Step4':'OPEN'}
    output.mkdir(parents=True,exist_ok=True)
    (output/'UnacceptedFull100Export.lean').write_bytes(driver)
    dump(output/'diagnostic.json',result)
    if not args.run:
        print('Plan and unchanged-template driver written; no compiler run, no review seal established.')
        return
    try:
        # No inherited project objects: the unchanged full producer's cold isolation.
        workspace,isolation=module.cold_compiler_checkout(REPO,output.parent,identity,source)
        result['compiler_isolation']=isolation
        environment=os.environ.copy()
        for key in ('LEAN_PATH','LEAN_SRC_PATH'): environment.pop(key,None)
        environment['LEAN_NUM_THREADS']='1'
        environment['LAKE_ARTIFACT_CACHE']='false'
        for argv,log in module.full_commands(contract):
            actual=[args.lake if token=='lake' and i==0 else
                str(output/'UnacceptedFull100Export.lean') if token=='@EXTERNAL_FULL_EXPORTER@' else
                str(output/'UnacceptedFull100Export.olean') if token=='@EXTERNAL_FULL_OLEAN@' else token
                for i,token in enumerate(argv)]
            started=time.monotonic()
            p=subprocess.run(actual,cwd=workspace,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=7200)
            (output/log).write_bytes(p.stdout)
            result['commands'].append({'argv':argv,'actual_argv':actual,'log':log,'exit_code':p.returncode,
                'seconds':time.monotonic()-started,'log_sha256':hashlib.sha256(p.stdout).hexdigest()})
            module.require(p.returncode==0,'diagnostic compiler failed: '+log)
        module.require(source==module.full_source_manifest(REPO),'owner source changed during diagnostic')
        module.require(source==module.full_source_manifest(workspace),'cold source changed during diagnostic')
        module.require(identity==module.full_checkout_identity(REPO,args.head,args.base),'head changed during diagnostic')
        module.require(module.pinned_package_cache(REPO)==isolation['package_pins'],'dependency pins changed')
        parsed=module.parse_compiler_output((output/'bindings.log').read_text(encoding='utf-8'),queries,
            mathematical_modules=contract['export_modules'])
        dump(output/'compiler-export.json',parsed)
        result['compiler_export_sha256']=hashlib.sha256((output/'compiler-export.json').read_bytes()).hexdigest()
        result['status']='UNACCEPTED_COLD100_COMPILER_DIAGNOSTIC_COMPLETE'
        result['review_input_root_type_sha256']={r['name']:r['type_sha256'] for r in parsed['declarations']
            if r['name'] in {q['full_name'] for q in queries}}
        # Deliberately no validate_consumer_provenance, required-definition review,
        # registry projection, or release acceptance: these need separate reviewed inputs.
    except Exception as exc:
        result['status']='UNACCEPTED_DIAGNOSTIC_FAILED'
        result['failure']=type(exc).__name__+': '+str(exc)
        dump(output/'diagnostic.json',result)
        raise
    dump(output/'diagnostic.json',result)
    print(result['status']+'; release, independent review, RH and Step4 remain OPEN.')

if __name__=='__main__': main()
