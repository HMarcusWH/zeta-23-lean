import AffineConfluent

noncomputable section
open Polynomial Finset
open scoped BigOperators
namespace OPICAConfluentIndependent

theorem independent_order {K : Type*} [CommRing K] [DecidableEq K]
    {M : ℕ} (node : Fin M → K) (j : Fin M) :
    OPICAConfluentAudit.repeatedJetOrder node j =
      ((Finset.Iio j).filter (fun t => node t = node j)).card := by
  unfold OPICAConfluentAudit.repeatedJetOrder OPICAConfluentAudit.priorMatches
  rw [Finset.filter_congr_decidable]

theorem independent_gaps {K : Type*} [CommRing K] [DecidableEq K]
    {M : ℕ} (node : Fin M → K) (i : Fin M) :
    OPICAConfluentAudit.priorNonmatches node (node i) i =
      (Finset.Iio i).filter (fun t => node t ≠ node i) := by
  unfold OPICAConfluentAudit.priorNonmatches
  apply Finset.filter_congr_decidable

theorem independent_matrix {K : Type*} [CommRing K] [DecidableEq K]
    {M : ℕ} (node : Fin M → K) (p : Fin M → K[X]) :
    (Matrix.of (fun i j : Fin M =>
      (Polynomial.hasseDeriv (((Finset.Iio j).filter (fun t => node t = node j)).card)
        (p i)).eval (node j))) =
      OPICAConfluentAudit.functionalMatrix
        (fun j => OPICAConfluentAudit.hasseFunctional (node j)
          (OPICAConfluentAudit.repeatedJetOrder node j)) p := by
  ext i j
  change (Polynomial.hasseDeriv _ (p i)).eval (node j) =
    (Polynomial.hasseDeriv _ (p i)).eval (node j)
  rw [independent_order]

theorem expected_normalized_Hermite {K : Type*} [CommRing K] [Nontrivial K]
    [DecidableEq K] {M : ℕ} (node : Fin M → K) :
    (Matrix.of (fun i j : Fin M =>
      (Polynomial.hasseDeriv (((Finset.Iio j).filter (fun t => node t = node j)).card)
        (X ^ (i : ℕ) : K[X])).eval (node j))).det =
      ∏ i : Fin M, ∏ j ∈ (Finset.Iio i).filter (fun t => node t ≠ node i),
        (node i - node j) := by
  rw [independent_matrix]
  simpa only [independent_gaps] using OPICAConfluentAudit.normalizedHermite_determinant node

theorem expected_profile_polynomial_matrix {K : Type*} [CommRing K] [Nontrivial K]
    [DecidableEq K] {M : ℕ} (node : Fin M → K) (hnode : ∀ i, node i ≠ 0) (a : K) :
    (Matrix.of (fun i j : Fin M =>
      (Polynomial.hasseDeriv (((Finset.Iio j).filter (fun t => node t = node j)).card)
        (X * (C a - X) ^ (i : ℕ) : K[X])).eval (node j))).det =
      (-1 : K) ^ (M * (M - 1) / 2) * (∏ i : Fin M, node i) *
        ∏ i : Fin M, ∏ j ∈ (Finset.Iio i).filter (fun t => node t ≠ node i),
          (node i - node j) := by
  rw [independent_matrix]
  simpa only [independent_gaps] using
    OPICAConfluentAudit.profilePolynomial_confluent_expanded_determinant node hnode a

theorem expected_two_node_sign :
    (Matrix.of ![![(2 : ℚ), 3], ![-7 / 2, -33 / 4]]).det = -6 := by
  norm_num [Matrix.det_fin_two]

theorem expected_raw_factorial_multiplier :
    (Matrix.of ![![(2 : ℚ), 1, 0], ![-7 / 2, -15 / 4, -2],
      ![49 / 8, 161 / 16, 11]]).det = -16 := by
  norm_num [Matrix.det_fin_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]

theorem expected_zero_node_degeneracy :
    (Matrix.of ![![(0 : ℚ), 3], ![0, -33 / 4]]).det = 0 := by norm_num [Matrix.det_fin_two]

theorem expected_duplicate_original_blocks :
    (Matrix.of ![![(2 : ℚ), 2], ![-7 / 2, -7 / 2]]).det = 0 := by norm_num [Matrix.det_fin_two]

#print axioms expected_normalized_Hermite
#print axioms expected_profile_polynomial_matrix
#print axioms expected_two_node_sign
#print axioms expected_raw_factorial_multiplier
#print axioms expected_zero_node_degeneracy
#print axioms expected_duplicate_original_blocks
end OPICAConfluentIndependent
