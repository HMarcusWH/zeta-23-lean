import ShCoefficientExtraction

noncomputable section
open Set Filter Complex
open scoped Topology
namespace OPICAShCoefficientExtraction

/-- Right accumulation, rather than a full interval of zeros, suffices.
This form can consume an almost-everywhere physical density identity. -/
theorem odd_coefficients_eq_zero_along_sequence (c : ℕ → ℂ) (u : ℕ → ℝ)
    (hu : ∀ m, 0 < u m) (hlim : Tendsto u atTop (𝓝 0))
    (h : ∀ n : ℕ, ∃ C : ℝ, ∀ᶠ m : ℕ in atTop,
      ‖∑ j ∈ Finset.range (n + 1), c j * (u m : ℂ) ^ (2 * j + 1)‖ ≤
        C * (u m) ^ (2 * n + 3)) : ∀ n : ℕ, c n = 0 := by
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    obtain ⟨C, hC⟩ := h n
    have hevent : ∀ᶠ m : ℕ in atTop, ‖c n‖ ≤ C * (u m) ^ 2 := by
      filter_upwards [hC] with m hm
      have hs : (∑ j ∈ Finset.range (n + 1), c j * (u m : ℂ) ^ (2 * j + 1)) =
          c n * (u m : ℂ) ^ (2 * n + 1) := by
        apply Finset.sum_eq_single n
        · intro j hj hjn
          have hjlt : j < n := by have := Finset.mem_range.mp hj; omega
          rw [ih j hjlt, zero_mul]
        · simp
      rw [hs, norm_mul, norm_pow, Complex.norm_real, Real.norm_eq_abs,
        abs_of_pos (hu m)] at hm
      have hpow : 0 < (u m) ^ (2 * n + 1) := pow_pos (hu m) _
      apply (mul_le_mul_iff_of_pos_right hpow).mp
      calc
        ‖c n‖ * (u m) ^ (2 * n + 1) ≤ C * (u m) ^ (2 * n + 3) := hm
        _ = (C * (u m) ^ 2) * (u m) ^ (2 * n + 1) := by
          rw [show 2 * n + 3 = 2 + (2 * n + 1) by omega, pow_add]
          ring
    have hl : Tendsto (fun m : ℕ => C * (u m) ^ 2) atTop (𝓝 0) := by
      simpa using tendsto_const_nhds.mul (hlim.pow 2)
    have hn : ‖c n‖ ≤ 0 := le_of_tendsto_of_tendsto tendsto_const_nhds hl hevent
    exact norm_eq_zero.mp (le_antisymm hn (norm_nonneg _))

#print axioms odd_coefficients_eq_zero_along_sequence
end OPICAShCoefficientExtraction
