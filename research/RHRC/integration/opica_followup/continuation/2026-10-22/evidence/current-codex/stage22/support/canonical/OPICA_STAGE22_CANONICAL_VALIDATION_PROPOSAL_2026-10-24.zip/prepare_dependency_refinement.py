from pathlib import Path
import json,hashlib,shutil
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
path=HERE/'overlay/Zeta23/OPICAFollowup/Consumers.lean'
shutil.copyfile(path,HERE/'Consumers.failed-frozen-13-imports.lean.txt')
before=path.read_bytes()
text='import Zeta23.OPICA.NativeJetAdapter\n'+before.decode('utf-8')
path.write_bytes(text.encode('utf-8'))
report={'schema':'OPICA_IMPLEMENTATION_DEPENDENCY_REFINEMENT_PROPOSAL_V1','status':'PROPOSAL_ONLY_NOT_REVIEWED_OR_ACCEPTED',
    'module':'Zeta23.OPICAFollowup.Consumers','path':'Zeta23/OPICAFollowup/Consumers.lean',
    'retain_every_frozen_direct_project_import':True,'add_direct_project_import':['Zeta23.OPICA.NativeJetAdapter'],
    'reason':'Actual GeneratedStep123CompleteOutput/nativeZeroJetRightZero/step123OpicaView/step123_output_opica_view_correct and completed-input obstruction APIs are unavailable through all13frozen direct imports. The original13-only source fails native compilation; the extra is an already existing protected-parent module, not an assumed native-data packet.',
    'negative_control_source':'Consumers.failed-frozen-13-imports.lean.txt','negative_control_log':'ConsumersFrozenDag.log',
    'frozen_13_source_sha256':hashlib.sha256(before).hexdigest(),'proposed_14_source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
    'no_frozen_contract_or_register_change':True,'mathematical_statement_or_domain_change':False,
    'required_next_gate':'Explicit separately reviewed implementation amendment before exact full-release dependency acceptance. This JSON is only a proposal; it is not approval.',
    'RH':'OPEN','Step4':'OPEN'}
(HERE/'ConsumersDependencyRefinementProposal.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
