from pathlib import Path
import json,hashlib,re
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
old=(REPO/'Zeta23/OPICAFollowup/Consumers.lean').read_bytes()
body=(HERE/'FollowupNativeOutputProposal.lean').read_bytes().split(b'\n',1)[1]
new=old+b'\n'+body
path=HERE/'overlay/Zeta23/OPICAFollowup/Consumers.lean'
path.write_bytes(new)
manifest=json.loads((REPO/'research/RHRC/integration/opica_followup/BUILD_MANIFEST.json').read_text())
expected=next(m for m in manifest['modules'] if m['module']=='Zeta23.OPICAFollowup.Consumers')['direct_project_imports']
actual=re.findall(r'(?m)^import\s+(Zeta23(?:\.[A-Za-z0-9_]+)*)',new.decode())
assert set(actual)==set(expected)|{'Zeta23.OPICA.NativeJetAdapter'},actual
report=json.loads((HERE/'stage22-overlay-provenance.json').read_text())
report['old_consumers_source_is_exact_byte_prefix']=new.startswith(old)
report['consumers_direct_project_imports']=actual
report['NativeJetAdapter_amendment_status']='REQUIRED_REFINEMENT_PROPOSAL_ONLY_NO_INDEPENDENT_ACCEPTANCE'
for row in report['assembly']:
    if row['path'].endswith('/Consumers.lean'):row['assembled_sha256']=hashlib.sha256(new).hexdigest()
(HERE/'stage22-overlay-provenance.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
