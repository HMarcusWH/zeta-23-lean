import AffineConfluent
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Data.Fintype.EquivFin

noncomputable section
set_option maxHeartbeats 800000
open Finset
namespace OPICAGroupedConfluent

def blockStart {r : ℕ} (m : Fin r → ℕ) (j : Fin r) : ℕ := ∑ i ∈ Iio j, m i

theorem prefix_add_le_total {r : ℕ} (m : Fin r → ℕ) (j : Fin r) :
    blockStart m j + m j ≤ ∑ i, m i := by
  calc
    blockStart m j + m j = ∑ i ∈ insert j (Iio j), m i := by
      rw [Finset.sum_insert (by simp)]
      exact Nat.add_comm _ _
    _ ≤ ∑ i, m i := Finset.sum_le_sum_of_subset (Finset.subset_univ _)

theorem prefix_add_le_prefix {r : ℕ} (m : Fin r → ℕ) {i j : Fin r} (hij : i < j) :
    blockStart m i + m i ≤ blockStart m j := by
  have hs : insert i (Iio i) ⊆ Iio j := by
    intro l hl
    rcases mem_insert.mp hl with rfl | hl
    · exact mem_Iio.mpr hij
    · exact mem_Iio.mpr ((mem_Iio.mp hl).trans hij)
  calc
    blockStart m i + m i = ∑ l ∈ insert i (Iio i), m l := by
      rw [Finset.sum_insert (by simp)]
      exact Nat.add_comm _ _
    _ ≤ blockStart m j := Finset.sum_le_sum_of_subset hs

def groupIndex {r : ℕ} (m : Fin r → ℕ) (p : (j : Fin r) × Fin (m j)) : Fin (∑ j, m j) :=
  ⟨blockStart m p.1 + p.2, (Nat.add_lt_add_left p.2.isLt _).trans_le (prefix_add_le_total m p.1)⟩

theorem groupIndex_first_lt {r : ℕ} (m : Fin r → ℕ)
    {p q : (j : Fin r) × Fin (m j)} (h : p.1 < q.1) : groupIndex m p < groupIndex m q := by
  have hp := p.2.isLt
  have hb := prefix_add_le_prefix m h
  change blockStart m p.1 + (p.2 : ℕ) < blockStart m q.1 + (q.2 : ℕ)
  omega

theorem groupIndex_injective {r : ℕ} (m : Fin r → ℕ) : Function.Injective (groupIndex m) := by
  rintro ⟨j, k⟩ ⟨l, t⟩ h
  have hv := congrArg Fin.val h
  change blockStart m j + (k : ℕ) = blockStart m l + (t : ℕ) at hv
  rcases lt_trichotomy j l with hjl | hjl | hjl
  · have hs := groupIndex_first_lt m (p := ⟨j, k⟩) (q := ⟨l, t⟩) hjl
    rw [h] at hs
    exact (lt_irrefl _ hs).elim
  · subst l
    have hkt : k = t := Fin.ext (Nat.add_left_cancel hv)
    subst t
    rfl
  · have hs := groupIndex_first_lt m (p := ⟨l, t⟩) (q := ⟨j, k⟩) hjl
    rw [h] at hs
    exact (lt_irrefl _ hs).elim

def groupEquiv {r : ℕ} (m : Fin r → ℕ) :
    ((j : Fin r) × Fin (m j)) ≃ Fin (∑ j, m j) :=
  Equiv.ofBijective (groupIndex m)
    ((Fintype.bijective_iff_injective_and_card _).mpr
      ⟨groupIndex_injective m, by simp⟩)

def groupedNode {K : Type*} {r : ℕ} (κ : Fin r → K) (m : Fin r → ℕ)
    (i : Fin (∑ j, m j)) : K := κ ((groupEquiv m).symm i).1

theorem groupedNode_at {K : Type*} {r : ℕ} (κ : Fin r → K) (m : Fin r → ℕ)
    (p : (j : Fin r) × Fin (m j)) : groupedNode κ m (groupIndex m p) = κ p.1 := by
  change κ ((groupEquiv m).symm (groupEquiv m p)).1 = _
  rw [Equiv.symm_apply_apply]

theorem prior_nonmatch_condition {K : Type*} {r : ℕ} (κ : Fin r → K)
    (hκ : Function.Injective κ) (m : Fin r → ℕ)
    (p q : (j : Fin r) × Fin (m j)) :
    (groupIndex m p < groupIndex m q ∧ κ p.1 ≠ κ q.1) ↔ p.1 < q.1 := by
  constructor
  · rintro ⟨hidx, hne⟩
    rcases lt_trichotomy p.1 q.1 with h | h | h
    · exact h
    · exact (hne (congrArg κ h)).elim
    · exact ((not_lt_of_gt (groupIndex_first_lt m h)) hidx).elim
  · intro h
    exact ⟨groupIndex_first_lt m h, fun he => (ne_of_lt h) (hκ he)⟩

theorem grouped_node_product {K : Type*} [CommMonoid K] {r : ℕ}
    (κ : Fin r → K) (m : Fin r → ℕ) :
    (∏ i, groupedNode κ m i) = ∏ j, κ j ^ m j := by
  rw [← (groupEquiv m).prod_comp]
  simp [groupedNode, Fintype.prod_sigma]

#print axioms groupIndex_injective
#print axioms grouped_node_product
end OPICAGroupedConfluent

