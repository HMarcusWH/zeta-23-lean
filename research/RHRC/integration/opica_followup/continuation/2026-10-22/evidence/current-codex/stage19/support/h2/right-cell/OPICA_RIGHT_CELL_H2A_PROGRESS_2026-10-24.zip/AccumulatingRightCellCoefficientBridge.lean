import FiniteJetCombinationRemainder
import ShAccumulatingCoefficientExtraction

noncomputable section
set_option maxHeartbeats 800000
open Set Filter Complex
open scoped Topology
namespace OPICARightCellTaylor

variable {ι : Type*} [Fintype ι]

theorem accumulating_rightCell_combination_coefficients_zero (node : ι → ℂ)
    (order : ι → ℕ) (a : ι → ℂ)
    (hacc : ∀ ε : ℝ, 0 < ε → ∃ u : ℝ, 0 < u ∧ u < ε ∧
      ∑ i, a i * rightCellJet (node i) (order i) u = 0) :
    ∀ n : ℕ, ∑ i, a i * oddJetCoefficient (node i) (order i) n = 0 := by
  apply OPICAShCoefficientExtraction.odd_coefficients_eq_zero_of_accumulating_remainder_bound
  intro n
  refine ⟨combinationTaylorConstant node a n, ?_⟩
  intro ε hε
  obtain ⟨u, hu0, huε1, hzero⟩ := hacc (min ε 1) (lt_min hε zero_lt_one)
  have huε : u < ε := (lt_min_iff.mp huε1).1
  have hu1 : |u| ≤ 1 := by rw [abs_of_pos hu0]; exact le_of_lt (lt_min_iff.mp huε1).2
  refine ⟨u, hu0, huε, ?_⟩
  have hb := finite_combination_remainder node order a hu1 n
  rw [hzero, sub_zero, abs_of_pos hu0] at hb
  exact hb

theorem accumulating_rightCell_combination_polynomial_rows_zero (node : ι → ℂ)
    (order : ι → ℕ) (a : ι → ℂ)
    (hacc : ∀ ε : ℝ, 0 < ε → ∃ u : ℝ, 0 < u ∧ u < ε ∧
      ∑ i, a i * rightCellJet (node i) (order i) u = 0) :
    ∀ n : ℕ, ∑ i, a i *
      (iteratedDeriv (order i) (fun w : ℂ => w * (1 / 4 - w) ^ n) (node i) /
        ((order i).factorial : ℂ)) = 0 := by
  intro n
  have h := accumulating_rightCell_combination_coefficients_zero node order a hacc n
  unfold oddJetCoefficient at h
  simp_rw [← mul_div_assoc] at h
  rw [← Finset.sum_div] at h
  have hr := (div_eq_zero_iff.mp h).resolve_right
    (by exact_mod_cast Nat.factorial_ne_zero (2 * n + 1))
  simpa only [mul_div_assoc] using hr

#print axioms accumulating_rightCell_combination_coefficients_zero
#print axioms accumulating_rightCell_combination_polynomial_rows_zero
end OPICARightCellTaylor
