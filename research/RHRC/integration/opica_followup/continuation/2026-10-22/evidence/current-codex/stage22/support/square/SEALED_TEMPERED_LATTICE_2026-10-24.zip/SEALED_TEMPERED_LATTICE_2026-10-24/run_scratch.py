from pathlib import Path
import datetime, hashlib, json, os, re, subprocess, sys, time
P=Path(__file__).resolve().parent
R=P.parent/'opica-followup-repo'
S=P.parent/'audit-square-physical'
B=P.parent/'audit-budget'
LAKE=Path('C:/Users/macka/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lake.exe')
LEAN=LAKE.with_name('lean.exe')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=dict(os.environ,LEAN_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1')
line=subprocess.check_output([str(LAKE),'env',sys.executable,str(P/'print_lean_path.py')],cwd=R,env=env,text=True).strip()
env['LEAN_PATH']=';'.join(map(str,[P,S,B]))+';'+line
name=sys.argv[1]
label=sys.argv[2] if len(sys.argv)>2 else name
out=P/(label+'.log')
start=time.monotonic()
cmd=[str(LEAN),'-R',str(P),'-o',str(P/(name+'.olean')),'-DautoImplicit=false',str(P/(name+'.lean'))]
sources={P/(name+'.lean'),R/'lean-toolchain',R/'lake-manifest.json'}
queue=[P/(name+'.lean')]
while queue:
    current=queue.pop()
    for module in re.findall(r'^import\s+([A-Za-z0-9_.]+)\s*$',current.read_text(encoding='utf-8'),re.M):
        relative=Path(*module.split('.')).with_suffix('.lean')
        source=next((x for x in [P/relative,S/relative,B/relative,R/relative] if x.exists()),None)
        if source is not None and source not in sources:
            sources.add(source); queue.append(source)
            obj=(R/'.lake/build/lib/lean'/relative.with_suffix('.olean')) if source.is_relative_to(R) else source.with_suffix('.olean')
            for suffix in ('','.private','.server'):
                artifact=Path(str(obj)+suffix)
                if artifact.exists(): sources.add(artifact)
before={str(x):sha(x) for x in sorted(sources)}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip()
with out.open('wb') as f:
    result=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
after={str(x):sha(x) for x in sorted(sources)}
row={'date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'cwd':str(R),'exit_code':result.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(out),'source_before':before,'source_after':after,'source_unchanged':before==after,'head':head,'tree':tree,'compiler_version':subprocess.check_output([str(LEAN),'--version'],text=True).strip(),'scope':'Scratch native narrow proof only; no production/root/RH promotion.'}
(P/(label+'.receipt.json')).write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps({k:row[k] for k in ['date','exit_code','seconds','log_sha256','source_unchanged','head','tree','scope']}))
sys.exit(result.returncode or (0 if before==after else 2))
