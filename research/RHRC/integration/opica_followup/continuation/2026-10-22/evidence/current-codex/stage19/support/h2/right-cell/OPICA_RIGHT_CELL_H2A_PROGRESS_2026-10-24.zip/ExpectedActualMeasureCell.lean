import ActualMeasureCellAE
import ShAccumulatingCoefficientExtraction

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform

namespace OPICAExpectedActualMeasureCell
open Zeta23.OPICAFollowup

theorem expected_actual_measure_ae {ι : Type*} [Fintype ι]
    (c : ι → ℂ) (ρ : ι → ℂ) (k : ι → ℕ)
    (h0 : ∀ i, 0 < (ρ i).re) (h1 : ∀ i, (ρ i).re < 1)
    (hh : ∀ i, ρ i ≠ 1 / 2) (hk : ∀ i, k i < zeroJetOrder (ρ i))
    (hzero : (∑ i, c i • (normalizedZeroMeasureJet (ρ i) (k i)).distributionOfLinearGrowth
      (normalizedZeroMeasureJet_hasLinearGrowth (h0 i) (h1 i) (hh i) (hk i))) = 0) :
    ∀ᵐ x : ℝ, x ∈ Ioo (1 : ℝ) 2 →
      (∑ i, c i * zeroJetDensity (spectralKappa (ρ i)) (k i) x) = 0 :=
  OPICAActualMeasureCell.actual_jet_combination_first_cell_ae_zero c ρ k h0 h1 hh hk hzero

theorem expected_accumulating_coefficients (c : ℕ → ℂ)
    (h : ∀ n : ℕ, ∃ C : ℝ, ∀ ε : ℝ, 0 < ε → ∃ u : ℝ, 0 < u ∧ u < ε ∧
      ‖∑ j ∈ Finset.range (n + 1), c j * (u : ℂ) ^ (2 * j + 1)‖ ≤
        C * u ^ (2 * n + 3)) : ∀ n : ℕ, c n = 0 :=
  OPICAShCoefficientExtraction.odd_coefficients_eq_zero_of_accumulating_remainder_bound c h

/-- Falsification control for the uniformity quantifier: allowing C to
depend on the requested radius permits the nonzero coefficient 1. -/
theorem parameter_dependent_bound_nonzero :
    (∀ ε : ℝ, 0 < ε → ∃ C u : ℝ, 0 < u ∧ u < ε ∧
      ‖(1 : ℂ) * (u : ℂ) ^ 1‖ ≤ C * u ^ 3) ∧ (1 : ℂ) ≠ 0 := by
  constructor
  · intro ε hε
    let u : ℝ := ε / 2
    have hu : 0 < u := by dsimp [u]; linarith
    refine ⟨(u ^ 2)⁻¹, u, hu, ?_, ?_⟩
    · dsimp [u]; linarith
    · simp only [one_mul, pow_one, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hu]
      have he : (u ^ 2)⁻¹ * u ^ 3 = u := by
        field_simp
      rw [he]
  · norm_num

#print axioms expected_actual_measure_ae
#print axioms expected_accumulating_coefficients
#print axioms parameter_dependent_bound_nonzero

end OPICAExpectedActualMeasureCell
