import Mathlib.MeasureTheory.VectorMeasure.Variation.SignedMeasure
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
import Mathlib.Analysis.Normed.Module.FiniteDimension
import PositiveHomogeneousBudget

noncomputable section
open Set MeasureTheory
namespace OPICAFixedBasisSupport

local instance : Norm (SignedMeasure ℝ) := ⟨fun μ => μ.totalVariation.real univ⟩

theorem signed_variation_norm_core : NormedSpace.Core ℝ (SignedMeasure ℝ) where
  norm_nonneg μ := ENNReal.toReal_nonneg
  norm_smul a μ := by
    change (a • μ).totalVariation.real univ = ‖a‖ * μ.totalVariation.real univ
    simp only [SignedMeasure.totalVariation_eq_variation,VectorMeasure.variation_smul,
      Measure.real,Measure.smul_apply,Measure.nnreal_smul_coe_apply,
      ENNReal.toReal_mul,ENNReal.coe_toReal,coe_nnnorm]
  norm_triangle μ ν := by
    change (μ+ν).totalVariation.real univ ≤ μ.totalVariation.real univ+ν.totalVariation.real univ
    have h := VectorMeasure.variation_add_le (μ := μ) (ν := ν) univ
    rw [←SignedMeasure.totalVariation_eq_variation,
      ←SignedMeasure.totalVariation_eq_variation,
      ←SignedMeasure.totalVariation_eq_variation,Measure.add_apply] at h
    exact (ENNReal.toReal_mono (by finiteness) h).trans_eq
      (ENNReal.toReal_add (by finiteness) (by finiteness))
  norm_eq_zero_iff μ := by
    change μ.totalVariation.real univ=0 ↔ μ=0
    constructor
    · intro h
      have hz : μ.totalVariation univ=0 :=
        (ENNReal.toReal_eq_zero_iff _).mp h |>.resolve_right (by finiteness)
      exact VectorMeasure.variation_eq_zero.mp
        (SignedMeasure.totalVariation_eq_variation μ ▸ (Measure.measure_univ_eq_zero.mp hz))
    · intro h
      simp [h,SignedMeasure.totalVariation_zero,Measure.real]

local instance : NormedAddCommGroup (SignedMeasure ℝ) :=
  NormedAddCommGroup.ofCore signed_variation_norm_core
local instance : NormedSpace ℝ (SignedMeasure ℝ) :=
  NormedSpace.ofCore signed_variation_norm_core

/-- Every fixed injective finite-dimensional map into actual finite signed
measures has a strictly positive total-variation lower bound. The normed
signed-measure structure is local to this supporting proof. -/
theorem fixed_linear_signed_variation_budget
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    (L : E →ₗ[ℝ] SignedMeasure ℝ) (injective : Function.Injective L) :
    ∃ c : ℝ, 0 < c ∧ ∀ x : E, c*‖x‖ ≤ (L x).totalVariation.real univ := by
  apply fixed_space_positive_homogeneous_budget (fun x => ‖L x‖)
  · exact L.continuous_of_finiteDimensional.norm
  · intro x hx
    exact norm_pos_iff.mpr (fun h => hx (injective (by simpa using h)))
  · intro a ha x
    rw [map_smul,norm_smul,Real.norm_eq_abs,abs_of_nonneg ha]

#print axioms fixed_linear_signed_variation_budget
end OPICAFixedBasisSupport
