"""Assemble copies only, preserving the exact original SquareDefect byte prefix."""
from pathlib import Path
import hashlib, json
P=Path(__file__).resolve().parent
components=['SquarePhysicalCandidate.lean','SquarePhysicalNoRepair.lean',
            'SquarePhysicalProjection.lean','SquarePhysicalComposition.lean']
original=(P/'PinnedSquareDefect.lean').read_bytes()
assert hashlib.sha256(original).hexdigest()=='da73276d089068c1711f3854a9520fbcbbbc877d77ccc33fe20cb9ceb83d64d1'
def inline(name):
    return '\n'.join(line for line in (P/name).read_text(encoding='utf-8').splitlines()
                     if not line.startswith(('import ','#print axioms '))).strip()+'\n'
full=original+b'\n\n'+('\n'.join(inline(name) for name in components)).encode('utf-8')
prints=['square_fourier_defect','square_defect_origin_positive','square_no_lattice_repair',
        'square_selfdual_projection_fills_gap','squareGapJordan_growth','squareGapJordan_pairing',
        'squareGapJordan_gap','squareGapJordan_origin','squareGapJordan_off_lattice',
        'squareGapJordan_even','squareGapJordan_fourier_defect','square_actual_no_tempered_measure_repair',
        'square_actual_projection_fills_gap','square_actual_no_selfdual_and_measure_repair']
full+=('\n'+''.join('#print axioms Zeta23.OPICAFollowup.'+name+'\n' for name in prints)).encode('utf-8')
(P/'SquareDefectPhysicalFullCandidate.lean').write_bytes(full)
for source,target in [('ExpectedSquarePhysical.lean','ExpectedSquarePhysicalFinal.lean'),
                      ('NegativeSquarePhysical.lean','NegativeSquarePhysicalFinal.lean'),
                      ('SquareSpanComposition.lean','SquareSpanCompositionFinal.lean')]:
    content=(P/source).read_text(encoding='utf-8')
    content=content.replace('import SquarePhysicalNoRepair\nimport SquarePhysicalProjection',
                            'import SquareDefectPhysicalFullCandidate')
    content=content.replace('import SquarePhysicalNoRepair','import SquareDefectPhysicalFullCandidate')
    content=content.replace('import SquarePhysicalComposition','import SquareDefectPhysicalFullCandidate')
    (P/target).write_text(content,encoding='utf-8')
print(json.dumps({'original_prefix_sha256':hashlib.sha256(original).hexdigest(),
                  'full_candidate_sha256':hashlib.sha256(full).hexdigest(),
                  'component_sha256':{name:hashlib.sha256((P/name).read_bytes()).hexdigest()
                                       for name in components}}))
