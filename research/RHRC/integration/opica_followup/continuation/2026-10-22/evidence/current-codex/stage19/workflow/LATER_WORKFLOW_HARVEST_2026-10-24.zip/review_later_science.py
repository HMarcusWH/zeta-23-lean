import hashlib, json, re, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def objects(text):
    decoder = json.JSONDecoder()
    cleaned = re.sub(r'^\d{4}-\d\d-\d\dT[\d:.]+Z ', '', text, flags=re.M)
    cleaned = re.sub(r'\x1b\[[0-9;]*m', '', cleaned)
    out = []
    end = -1
    for match in re.finditer(r'(?m)^\s*\{', cleaned):
        start = match.start()
        if start < end:
            continue
        try:
            value, length = decoder.raw_decode(cleaned[start:].lstrip())
            if isinstance(value, dict):
                out.append(value)
                end = start + length
        except json.JSONDecodeError:
            pass
    return out

def scientific_fields(obj, prefix='', out=None):
    out = [] if out is None else out
    if isinstance(obj, dict):
        for key, value in obj.items():
            path = prefix + '.' + key if prefix else key
            if isinstance(value, (dict, list)):
                scientific_fields(value, path, out)
            elif re.search('status|disposition|classification|claim|nonclaim|scope|warning|interpretation|conclusion|certified|falsified|unresolved|gate', key, re.I):
                out.append({'field': path, 'value': value})
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            scientific_fields(item, prefix + '[' + str(i) + ']', out)
    return out

dataset = json.loads((ROOT/'later-science/POST268_ALL44_SCIENCE.json').read_text())
rows = []
for row in dataset['results']:
    archive = ROOT/'later-artifacts'/row['verified_archive']
    if not archive.exists():
        archive = ROOT/row['verified_archive']
    with zipfile.ZipFile(archive) as z:
        matches = [name for name in z.namelist() if name == row['log'] or name.endswith('/'+row['log'])]
        assert len(matches) == 1, (row['id'], matches)
        raw = z.read(matches[0])
    assert hashlib.sha256(raw).hexdigest() == row['log_sha256'], row['id']
    text = raw.decode('utf-8', errors='replace')
    parsed = objects(text)
    rows.append({'id': row['id'], 'archive': archive.relative_to(ROOT).as_posix(),
                 'full_log_sha256_verified': True, 'baseline_disposition': row['baseline_disposition'],
                 'comparison': row['comparison'], 'execution_disposition': row['execution_disposition'],
                 'mathematical_change_established_by_comparison_label': False,
                 'json_outputs': parsed, 'scientific_fields': [p for o in parsed for p in scientific_fields(o)],
                 'nonjson_summary': text[-1800:] if not parsed else None})
assert len(rows) == 44
(ROOT/'later-science/ALL44_REVIEWED_OUTPUTS.json').write_text(json.dumps(rows, indent=2)+'\n')

archive = ROOT/'later-artifacts/12564610299.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'b68f7c022ce573dd88cf4a744598af3e8422d25484e0aa9feb6e711777da223c'
files = []
with zipfile.ZipFile(archive) as z:
    for name in z.namelist():
        if name.endswith('.json'):
            raw = z.read(name)
            d = json.loads(raw)
            files.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                          'root_keys': list(d) if isinstance(d, dict) else None,
                          'scientific_fields': scientific_fields(d), 'content': d})
        elif name.endswith('.txt'):
            raw = z.read(name)
            files.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                          'text': raw.decode('utf-8', errors='replace')})
(ROOT/'later-science/FINAL_SOURCE_FALSIFIER_OUTPUTS.json').write_text(json.dumps(files, indent=2)+'\n')
print(json.dumps({'all44_verified': len(rows), 'source_archive_digest_matches': True,
                  'source_artifact_members_reviewed': len(files)}))
for row in rows:
    fields = [x for x in row['scientific_fields'] if len(x['field'].split('.')) <= 3]
    print(json.dumps({'id': row['id'], 'baseline': row['baseline_disposition'],
                      'science': fields[:12], 'nonjson': row['nonjson_summary']}, ensure_ascii=True))
print('SOURCE_ARTIFACT_TOP_LEVEL_DISPOSITIONS')
for item in files:
    fields = [x for x in item.get('scientific_fields', []) if len(x['field'].split('.')) <= 3]
    print(json.dumps({'file': item['file'], 'science': fields[:15], 'text': item.get('text')}, ensure_ascii=True))
