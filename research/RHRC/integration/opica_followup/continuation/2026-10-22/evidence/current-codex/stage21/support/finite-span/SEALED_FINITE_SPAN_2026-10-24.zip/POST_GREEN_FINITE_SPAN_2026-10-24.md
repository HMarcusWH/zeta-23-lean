# Actual finite zero-jet span — 24 October 2026

Base code commit `9a8b2a4baee49f2056c7945b1544a7bc2893735b`, tree
`6aa53d22d50d2aa24046d73b128c64a1d262f7f3`. The assembled scratch module
`FiniteSpanSeparationFullCandidate.lean` has SHA256
`8e69e7c90abb572cf45d71bd70c0446b6844372d4ae954aeb8274ea3e1f1e5ef`.
It is outside the checkout. Its native exact-source compilation passed with
all consumed project sources/objects unchanged and standard axioms only.
The final physical consumer SHA256 is
`a5ec14ea0c5754ba762034420b58047f6134baa1e8b52fc405c9c06e3872cc6e`.
Its compilation and the final independent suites completed at owner record
commit `36b677c26b01fafeac719413753092c5988c38d3`, tree
`919a8f82f804c0389253412fb2b61330ac173dc7`, with all imported code and
objects unchanged. The primary module completed at the code commit above.
Exact final consumers and controls are listed in the companion final receipt.
Production integration, cold100 compilation and release approval are separate.

**What became formally true.** A finite complex combination of actual
normalized zero jets is formed by genuine complex-measure scale/add and then
canonically realified. Every member has proved linear variation growth,
unit gap and Fourier selfduality. Off-lattice nonnegativity therefore forces
both Jordan parts to vanish. Coordinates on any independent real basis of
actual finite combinations vanish as well. The original quantitative
fixed-basis theorem supplies a positive constant times the Euclidean norm
below the actual global off-lattice sinc-squared negative mass. Multiplicities
are unrestricted within the actual available jet order; no finite-region
replacement, synthetic source or conclusion-shaped analytic packet is used.

**Workflow harvest.** These are scratch compiler/expected-type/axiom and
negative controls, not GitHub checks or aggregate acceptance. The distinct
old-head all-workflow harvest remains pinned to cea7b2f6:22 runs/66 jobs,
56 success/6 failure/4 skipped, with every scientific scope preserved in
`work/audit-workflows/LATER_HARVEST.json`. It does not validate this code.
The owner must harvest exact new-head CI after integration and push.

**What changed.** The missing finite-span physical instantiation now closes
the proposed finite linear multi-zero positivity repair for this actual
family. The coefficient result uses the original independent-real-basis
condition. It does not assert that arbitrary Re/Im generators are independent.
The supplied physical consumer also retains true zero-profile regularity and
the zero-order jet/zero-measure identity. It consumes the public
`copoisson_zero_jets_measures`, `zero_profile_regular_selfdual` and both
clauses of `finite_zero_span_positive_only_zero`; the budget injectivity
proof also consumes the public coefficient-zero clause. No unused fake
dependency or conclusion-shaped packet was added. Root counts remain an owner ledger
decision after exact production replay.

**Upstream implications.** Equality of all canonical signed compact
restrictions determines a locally finite Jordan carrier without any growth
premise. Compact Jordan uniqueness and exhaustion prove this directly. It
eliminated a proposed global weighted-test limiting argument. Generic growth
closure and weighted add/scale algebra then identify the actual coefficient
combination with a literal finite sum of weighted basis measures.

**Downstream implications.** The sinc-squared weighted image is finite even
when the original Jordan measures have infinite global mass. Exact signed
sinc/triangle balance makes its total variation twice the negative weighted
mass. On a fixed independent actual real basis the coefficient map is
injective, yielding the original quantitative bound. DERIVED: that negative
mass is a genuine symmetric norm on this fixed coefficient space, so bounded
negative budget bounds every coefficient and its finite-dimensional sublevel
sets are compact. Evenness under simultaneous coefficient reversal is
separately formalized; full norm-law packaging is not separately claimed.

**Resurrected routes.** Finite-span separation can now be composed with the
actual multiplicity-sensitive jet construction and first-cell independence.
The formal route through canonical compact restrictions is reusable wherever
local Jordan algebra formerly required a new global distribution argument.
An unrestricted finite linear repair of positivity is closed; nonlinear or
controlled infinite constructions remain separate open routes.

**New RH-relevant clues.** LEAD: derive explicit basis constants from the
confluent first-cell matrix and ODE observability, then combine those bounds
with actual force/sampling and source-window estimates. This could turn an
abstract fixed-basis obstruction into computable costs for a specified finite
hypothetical zero configuration. No hypothetical off-critical zero is excluded
by the present result alone. The same source restrictions also apply to
critical-line zeros.

**Falsification checks.** Empty data give the zero measure; a dependent zero
basis has no positive coefficient lower bound. Repeated basis vectors cannot
be independent, and rho/1-rho give the same jet. A Dirac mass at integer2 has
growth and unit gap but zero sinc-weighted image; its failure of Fourier
selfduality is proved. Thus the weighted map is not faithful on arbitrary
Jordan measures. Missing off-lattice positivity, multiplicity order and real
basis independence remain rejected contract changes. The missing budget
independence control is specifically an API-domain rejection; the separate
zero-basis theorem supplies the mathematical counterexample to an unrestricted
positive budget. Scaling a basis toward
zero rules out any basis-independent positive constant. Colliding nodes,
growing dimension and high-frequency limits require their own estimates.

**Highest-leverage next moves.** Perform exact production integration and
full original-type/axiom/negative gates, then cold100 and the separate parent,
registry/dependency, canonical graph and review obligations. Test explicit
first-cell constants against collision and large-height degenerations before
building a new RH-relevant claim around them. Preserve the distinction between
actual finite-span obstruction, prospective source bridges and universal
positivity. The compactness, Jordan uniqueness and norm-equivalence mechanisms
are classical; the present work verifies their specific actual-jet realization
from the frozen H2b contracts. No new literature priority claim is made here.

RH, Step4 and independent closing inequalities remain OPEN.

Temporal import provenance: the primary module used ConfluentProfiles source
1773e320 at code9a8. Owner subsequently installed its namespace-compatible
sourcea84c72 before the downstream scratch checks; their recursive source walk
and the actually consumed cached objects are recorded separately. This lane
does not claim to have compiled that relocated dependency. The original
Confluent source is preserved in historical/ConfluentProfiles_at9a8.lean.
Exact production builds on all owner-installed sources remain required.
