from pathlib import Path
import hashlib, json, os, subprocess, sys, time
HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'opica-followup-repo'
TESTS = HERE / 'research/RHRC/integration/opica_followup/tests'
env = os.environ.copy(); env['OPICA_TEST_REPO'] = str(REPO)
temporary = HERE / 'temporary-fixtures'; temporary.mkdir(exist_ok=True)
env['TEMP'] = str(temporary); env['TMP'] = str(temporary)
rows = []
sources = [HERE / 'research/RHRC/integration/opica_followup/dependency_delta.py', *sorted(TESTS.glob('test_*.py'))]
before = {str(p.relative_to(HERE)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
for mode, flags in [('normal', []), ('optimized', ['-O'])]:
    argv = [sys.executable, '-B', *flags, '-m', 'unittest', 'discover', '-s', str(TESTS), '-p', 'test_*.py', '-v']
    started = time.monotonic()
    result = subprocess.run(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = HERE / ('runtime-checks.' + mode + '.log'); log.write_bytes(result.stdout)
    row = {'mode': mode, 'argv': argv, 'exit_code': result.returncode, 'seconds': time.monotonic() - started,
        'log': log.name, 'log_sha256': hashlib.sha256(result.stdout).hexdigest()}
    rows.append(row)
    print(mode, result.returncode, flush=True)
    if result.returncode != 0:
        print('Failure details preserved in', log)
        raise SystemExit(1)
after = {str(p.relative_to(HERE)).replace('\\', '/'): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
if before != after:
    raise SystemExit('Candidate source changed during tests; no source-pinned positive receipt may be written.')
receipt = {'schema': 'OPICA_PLANNED_RUNTIME_PROPOSAL_TESTS_V1',
    'status': 'NORMAL_AND_OPTIMIZED_PROTOCOL_TESTS_PASS_NO_RELEASE_AUTHORITY',
    'commands': rows, 'owner_head': subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip(),
    'owner_status_at_record': subprocess.check_output(['git', '-C', str(REPO), 'status', '--porcelain'], text=True).splitlines(),
    'sources': before, 'candidate_sources_unchanged_during_tests': True,
    'test_fixtures': 'Existing synthetic full-receipt/parent-extension protocol fixtures, never mathematical or approval authority; actual production validators and classifier functions are executed.',
    'positive_real_full_parent_child_receipts': 'NOT_AVAILABLE_NOT_TESTED',
    'independent_semantic_review': 'NOT_ESTABLISHED', 'release_ready': False, 'full_release_accepted': False, 'RH': 'OPEN', 'Step4': 'OPEN'}
(HERE / 'runtime-proposal-test-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(receipt['status'])
