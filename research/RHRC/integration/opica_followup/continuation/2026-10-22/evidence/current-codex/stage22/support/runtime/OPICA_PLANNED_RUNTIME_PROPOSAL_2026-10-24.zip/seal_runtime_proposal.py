from pathlib import Path
import hashlib, json, subprocess, zipfile
HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'opica-followup-repo'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipt = json.loads((HERE / 'runtime-proposal-test-receipt.json').read_text())
assert receipt['status'] == 'NORMAL_AND_OPTIMIZED_PROTOCOL_TESTS_PASS_NO_RELEASE_AUTHORITY'
assert receipt['candidate_sources_unchanged_during_tests']
for row in receipt['commands']:
    assert row['exit_code'] == 0 and sha(HERE / row['log']) == row['log_sha256']
    assert 'Ran 43 tests' in (HERE / row['log']).read_text()
rows = []
for relative, expected in receipt['sources'].items():
    assert sha(HERE / relative) == expected
    rows.append({'repository_path': relative, 'candidate': relative, 'sha256': expected,
        'frozen_manifest_planned_path': True, 'owner_installation': 'SOURCE_REVIEW_AND_FRESH_COMBINED_TEST_REPLAY_REQUIRED'})
production_paths = ['research/RHRC/integration/opica_followup/build_receipt.py',
    'research/RHRC/integration/opica/build_receipt.py',
    'research/RHRC/integration/opica_followup/parent_extension.py',
    'research/RHRC/integration/opica_followup/tests/test_receipt.py',
    'research/RHRC/integration/opica_followup/tests/test_parent_extension.py',
    'research/RHRC/graph/build.py', 'research/RHRC/routes/R003_ccm_bridge/post290/lean_expr_dag.py']
manifest = {'schema': 'OPICA_FOUR_PLANNED_RUNTIME_INSTALL_PROPOSAL_V1',
    'status': 'FOUR_REAL_IMPLEMENTATIONS_TESTED_NOT_RELEASE_ACCEPTANCE', 'files': rows,
    'normal_tests': 43, 'optimized_tests': 43,
    'test_receipt_sha256': sha(HERE / 'runtime-proposal-test-receipt.json'),
    'supporting_production_source_hashes_at_collection': {p: sha(REPO / p) for p in production_paths},
    'production_source_snapshot_limit': 'Supporting source hashes collected after tests; owner status is recorded in the receipt. This is an outside-checkout protocol test, not a cold accepted source build.',
    'extra_P0_inputs': ['--parent-formal-receipt', '--current-parent-formal-receipt'],
    'extra_P0_input_reason': 'Original source-phase parent intake has no types, axioms, constructors or private dependency graph. Both real source/log-bound P0 compiler receipts are necessary to discharge the unchanged-parent-type requirement.',
    'full_end_to_end_real_receipts': 'NOT_AVAILABLE_NOT_TESTED',
    'independent_full_review': 'NOT_ESTABLISHED', 'parent_acceptance': 'NOT_CREATED',
    'source_register_or_registry_written': False, 'release_ready': False, 'full_release_accepted': False,
    'RH': 'OPEN', 'Step4': 'OPEN'}
manifest_path = HERE / 'runtime-install-proposal.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
paths = [HERE / r['candidate'] for r in rows]
paths += [manifest_path, HERE / 'README.md', HERE / 'run_runtime_checks.py', HERE / 'seal_runtime_proposal.py',
    HERE / 'runtime-proposal-test-receipt.json', HERE / 'runtime-checks.normal.log', HERE / 'runtime-checks.optimized.log',
    HERE / 'runtime-checks.initial-sandbox-temp-failure.log',
    HERE / 'runtime-proposal-test-receipt.initial-mixed-source-unaccepted.json',
    HERE / 'runtime-proposal-test-receipt.first41-superseded.json']
archive = HERE / 'OPICA_PLANNED_RUNTIME_PROPOSAL_2026-10-24.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in paths: z.write(p, str(p.relative_to(HERE)).replace('\\', '/'))
print(archive.name, sha(archive), len(paths), 'files;43normal+43optimized;NO_RELEASE_AUTHORITY')
