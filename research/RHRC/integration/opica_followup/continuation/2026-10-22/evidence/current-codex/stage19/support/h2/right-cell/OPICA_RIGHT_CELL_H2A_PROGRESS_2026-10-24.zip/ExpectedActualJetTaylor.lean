import ActualJetTaylor
import ActualFirstCell

noncomputable section
open Zeta23.OPICAFollowup

namespace OPICAIndependentActualTaylor

/-- Independent expected type includes the actual physical density, both
factorials, the full finite sum, and the genuine first-cell domain. -/
theorem expected_actual_normalized_finite_taylor (κ : ℂ) (k n : ℕ) {u : ℝ}
    (hu0 : 0 ≤ u) (hucell : u < Real.log 2) (hu1 : |u| ≤ 1) :
    ‖(Real.exp (u / 2) : ℂ) * zeroJetDensity κ k (Real.exp u) -
      ∑ j ∈ Finset.range (n + 1),
        (iteratedDeriv k (fun w : ℂ => w * (1 / 4 - w) ^ j) κ /
          (k.factorial : ℂ) / ((2 * j + 1).factorial : ℂ)) * (u : ℂ) ^ (2 * j + 1)‖ ≤
      (‖κ‖ + 2) ^ (n + 2) * OPICARightCellTaylor.expMajorant (‖κ‖ + 2) *
        |u| ^ (2 * n + 3) := by
  rw [OPICAActualFirstCellAudit.actual_normalized_jet_first_log_cell κ k hu0 hucell]
  change ‖OPICARightCellTaylor.rightCellJet κ k u -
    ∑ j ∈ Finset.range (n + 1), OPICARightCellTaylor.oddJetCoefficient κ k j *
      (u : ℂ) ^ (2 * j + 1)‖ ≤ _
  rw [← OPICARightCellTaylor.partialJet_eq]
  exact OPICARightCellTaylor.normalized_jet_remainder κ k hu1 n

#print axioms expected_actual_normalized_finite_taylor
end OPICAIndependentActualTaylor
