import RightCellCoefficientBridge
import AffineConfluent
import HasseNormalizedDerivative
import Mathlib.LinearAlgebra.Matrix.Nondegenerate

noncomputable section
set_option maxHeartbeats 800000
open Polynomial Finset
namespace OPICARightCellTaylor
open OPICAConfluentAudit

theorem actual_polynomial_row (κ : ℂ) (k n : ℕ) :
    (Polynomial.hasseDeriv k (X * (C (1 / 4 : ℂ) - X) ^ n)).eval κ =
      iteratedDeriv k (fun w : ℂ => w * (1 / 4 - w) ^ n) κ / (k.factorial : ℂ) := by
  rw [hasse_eq_normalized_iteratedDeriv]
  congr 2
  funext w
  simp

/-- Independence of the explicit right-cell continuations, in occurrence-count
order. This is analytic support for H2a; no actual zero-measure premise is
introduced here and no original theorem root is promoted. -/
theorem expanded_rightCell_independent {M : ℕ} (node : Fin M → ℂ)
    (hnode : ∀ i, node i ≠ 0) (a : Fin M → ℂ) {ε : ℝ} (hε : 0 < ε)
    (hvan : ∀ u : ℝ, 0 < u → u < ε →
      ∑ i, a i * rightCellJet (node i) (repeatedJetOrder node i) u = 0) : a = 0 := by
  classical
  let A : Matrix (Fin M) (Fin M) ℂ := functionalMatrix
    (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
    (fun i => X * (C (1 / 4 : ℂ) - X) ^ (i : ℕ))
  have hdet : A.det ≠ 0 := by
    rw [show A = _ from rfl, profilePolynomial_confluent_expanded_determinant node hnode]
    apply mul_ne_zero
    · exact mul_ne_zero (pow_ne_zero _ (by norm_num)) (Finset.prod_ne_zero_iff.mpr (fun i _ => hnode i))
    · apply Finset.prod_ne_zero_iff.mpr
      intro i hi
      apply Finset.prod_ne_zero_iff.mpr
      intro j hj
      have hjne : node j ≠ node i := (Finset.mem_filter.mp hj).2
      exact sub_ne_zero.mpr (Ne.symm hjne)
  apply Matrix.eq_zero_of_mulVec_eq_zero hdet
  ext i
  have h := rightCell_combination_polynomial_rows_zero node (repeatedJetOrder node) a hε hvan (i : ℕ)
  change ∑ j, A i j * a j = 0
  have hrow (j : Fin M) : A i j = iteratedDeriv (repeatedJetOrder node j)
      (fun w : ℂ => w * (1 / 4 - w) ^ (i : ℕ)) (node j) /
        ((repeatedJetOrder node j).factorial : ℂ) := by
    exact actual_polynomial_row (node j) (repeatedJetOrder node j) (i : ℕ)
  simp_rw [hrow, mul_comm]
  exact h

#print axioms actual_polynomial_row
#print axioms expanded_rightCell_independent
end OPICARightCellTaylor
