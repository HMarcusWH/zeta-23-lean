import Zeta23.OPICAFollowup.Consumers

noncomputable section
namespace Zeta23.OPICAFollowup
open Zeta23 Zeta23.CCM Zeta23.OPICA Zeta23.ExceptionalZero

/-- The actual existing generated Step123 complete output, with the same
zero, aperture, phase and horizon parameters. No new assertion packet. -/
abbrev FollowupNativeOutput (rho : zetaZeroConfig.carrier) (beta : ℝ)
    (phase : ReversalParity) (late : ℝ) :=
  GeneratedStep123CompleteOutput rho beta phase late

theorem followupNativeOutput_actual_source_and_input
    {rho : zetaZeroConfig.carrier} {beta : ℝ} {phase : ReversalParity} {late : ℝ}
    (out : FollowupNativeOutput rho beta phase late) :
    (step123OpicaView out).source = nativeOriginalIntegerDrive ∧
    (step123OpicaView out).field = nativeOriginalPrimeField ∧
    (step123OpicaView out).input = nativeCompletedInput ∧
    Step123SameStateFieldRecord out.generated.native ∧
    GeneratedStep123RangeObstruction rho out.generated.offLine :=
  step123_output_opica_view_correct out

theorem followupNativeOutput_eachPhase (rho : zetaZeroConfig.carrier) {beta : ℝ}
    (hbeta : 0 < beta) (hgap : beta < |(rho : ℂ).re - 1 / 2|) :
    ∀ (phase : ReversalParity) (late : ℝ),
      ∃ out : FollowupNativeOutput rho beta phase late,
        max late step123SameStateThreshold <
          fixedOriginalSincTrialAperture out.generated.sourceData.separation ∧
        (step123OpicaView out).source = nativeOriginalIntegerDrive ∧
        (step123OpicaView out).field = nativeOriginalPrimeField ∧
        (step123OpicaView out).input = nativeCompletedInput ∧
        Step123SameStateFieldRecord out.generated.native ∧
        GeneratedStep123RangeObstruction rho out.generated.offLine :=
  step123_eachPhase_opica_consumer rho hbeta hgap

end Zeta23.OPICAFollowup

#print axioms Zeta23.OPICAFollowup.followupNativeOutput_actual_source_and_input
#print axioms Zeta23.OPICAFollowup.followupNativeOutput_eachPhase
