import FiniteSpanWeighted
import TVSignedBudget
import Mathlib.Analysis.InnerProductSpace.PiL2

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
namespace Zeta23.OPICAFollowup
open Zeta23.OPICA FiniteSpanScratch FixedBudgetSupport

/-- The map contains the literal sinc-weighted signed measures of each
fixed actual realified zero-jet basis vector. -/
def actualFixedBasisWeightedMap {n : ℕ} (basis : Fin n → List JetDatum)
    (valid : ∀ i, ∀ j ∈ basis i, ValidJet j) :
    EuclideanSpace ℝ (Fin n) →ₗ[ℝ] SignedMeasure ℝ where
  toFun a := ∑ i, a i • sincWeightedSigned (zeroJetRealSpan (basis i))
    (zeroJetRealSpan_growth _ (valid i))
  map_add' a b := by
    simp only [PiLp.add_apply,add_smul,Finset.sum_add_distrib]
  map_smul' c a := by
    simp only [PiLp.smul_apply,smul_eq_mul,Finset.smul_sum,smul_smul,RingHom.id_apply]

theorem actualFixedBasisWeightedMap_eq_combination {n : ℕ}
    (basis : Fin n → List JetDatum) (valid : ∀ i, ∀ j ∈ basis i, ValidJet j)
    (a : EuclideanSpace ℝ (Fin n)) :
    actualFixedBasisWeightedMap basis valid a=
      sincWeightedSigned (zeroJetRealSpan (realBasisCombinationData basis (fun i => a i)))
        (zeroJetRealSpan_growth _ (realBasisCombination_valid basis valid _)) :=
  (realBasisCombination_weightedSigned basis valid (fun i => a i)).symm

theorem actualFixedBasisWeightedMap_injective {n : ℕ}
    (basis : Fin n → List JetDatum) (valid : ∀ i, ∀ j ∈ basis i, ValidJet j)
    (independent : LinearIndependent ℝ (fun i =>
      (zeroJetRealSpan (basis i)).distributionOfLinearGrowth (zeroJetRealSpan_growth _ (valid i)))) :
    Function.Injective (actualFixedBasisWeightedMap basis valid) := by
  intro a b hab
  apply sub_eq_zero.mp
  have hw : actualFixedBasisWeightedMap basis valid (a-b)=0 := by
    rw [map_sub,hab,sub_self]
  rw [actualFixedBasisWeightedMap_eq_combination] at hw
  let data := realBasisCombinationData basis (fun i => (a-b) i)
  have hv := realBasisCombination_valid basis valid (fun i => (a-b) i)
  have hz := (sincWeightedSigned_zero_iff_zero (zeroJetRealSpan data)
    (zeroJetRealSpan_growth data hv) (zeroJetRealSpan_selfdual data hv)
    (zeroJetRealSpan_gap data)).mp hw
  have hoff : (zeroJetRealSpan data).OffLatticeNonnegative := by
    rw [LocallyFiniteSignedMeasure.OffLatticeNonnegative,hz.2]
    simp
  have ha := independent_real_span_basis_coefficients_zero basis valid independent
    (fun i => (a-b) i) hoff
  exact PiLp.ext fun i => congrFun ha i

/-- Original fixed-independent-real-basis budget. Every basis vector is a
finite genuine zero-jet combination; the actual Jordan negative measure is
globally sinc weighted off the integer lattice. The coefficient norm is the
Euclidean norm. No constant is asserted uniformly over different bases. -/
theorem fixed_basis_negative_mass_budget {n : ℕ}
    (basis : Fin n → List JetDatum) (valid : ∀ i, ∀ j ∈ basis i, ValidJet j)
    (independent : LinearIndependent ℝ (fun i =>
      (zeroJetRealSpan (basis i)).distributionOfLinearGrowth (zeroJetRealSpan_growth _ (valid i)))) :
    ∃ c_basis : ℝ, 0<c_basis ∧ ∀ a : EuclideanSpace ℝ (Fin n),
      c_basis*‖a‖ ≤ ∫ x in integerLatticeᶜ, sincSquared x
        ∂(zeroJetRealSpan (realBasisCombinationData basis (fun i => a i))).negative := by
  obtain ⟨c,hc,hbound⟩ := OPICAFixedBasisSupport.fixed_linear_signed_variation_budget
    (actualFixedBasisWeightedMap basis valid) (actualFixedBasisWeightedMap_injective basis valid independent)
  refine ⟨c/2,by positivity,fun a => ?_⟩
  have h := hbound a
  rw [actualFixedBasisWeightedMap_eq_combination] at h
  let data := realBasisCombinationData basis (fun i => a i)
  have hv := realBasisCombination_valid basis valid (fun i => a i)
  rw [weighted_variation_eq_twice_negative (zeroJetRealSpan data)
    (zeroJetRealSpan_growth data hv) (zeroJetRealSpan_selfdual data hv)
    (zeroJetRealSpan_gap data)] at h
  have hoff := negative_sinc_off_lattice_eq_global (zeroJetRealSpan data).negative
    ((zeroJetRealSpan data).negative_hasLinearGrowth (zeroJetRealSpan_growth data hv))
    (singleton_zero_of_unit_gap _ (zeroJetRealSpan_gap data).2)
  change c/2*‖a‖ ≤ ∫ x in integerLatticeᶜ,sincSquared x ∂(zeroJetRealSpan data).negative
  rw [hoff]
  linarith

/-- The exact signed sinc balance makes negative mass even on the actual
finite coefficient space; no independence premise is needed for this identity. -/
theorem actual_basis_negative_mass_even {n : ℕ}
    (basis : Fin n → List JetDatum) (valid : ∀ i, ∀ j ∈ basis i, ValidJet j)
    (a : EuclideanSpace ℝ (Fin n)) :
    (∫ x,sincSquared x ∂(zeroJetRealSpan
      (realBasisCombinationData basis (fun i => (-a) i))).negative)=
    (∫ x,sincSquared x ∂(zeroJetRealSpan
      (realBasisCombinationData basis (fun i => a i))).negative) := by
  have hpos := weighted_variation_eq_twice_negative
    (zeroJetRealSpan (realBasisCombinationData basis (fun i => a i)))
    (zeroJetRealSpan_growth _ (realBasisCombination_valid basis valid _))
    (zeroJetRealSpan_selfdual _ (realBasisCombination_valid basis valid _))
    (zeroJetRealSpan_gap _)
  have hneg := weighted_variation_eq_twice_negative
    (zeroJetRealSpan (realBasisCombinationData basis (fun i => (-a) i)))
    (zeroJetRealSpan_growth _ (realBasisCombination_valid basis valid _))
    (zeroJetRealSpan_selfdual _ (realBasisCombination_valid basis valid _))
    (zeroJetRealSpan_gap _)
  rw [←actualFixedBasisWeightedMap_eq_combination basis valid a] at hpos
  rw [←actualFixedBasisWeightedMap_eq_combination basis valid (-a)] at hneg
  rw [map_neg,SignedMeasure.totalVariation_neg] at hneg
  linarith

#print axioms fixed_basis_negative_mass_budget
#print axioms actual_basis_negative_mass_even
end Zeta23.OPICAFollowup
