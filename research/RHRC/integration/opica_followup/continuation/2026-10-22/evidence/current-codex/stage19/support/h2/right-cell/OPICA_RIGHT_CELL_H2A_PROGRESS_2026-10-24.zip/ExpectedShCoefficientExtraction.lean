import ShCoefficientExtraction

noncomputable section
open Set Filter Complex
open scoped Topology

namespace OPICAExpectedShCoefficientExtraction

theorem expected_odd_coefficients (c : ℕ → ℂ) {ε : ℝ} (hε : 0 < ε)
    (h : ∀ n : ℕ, ∃ C : ℝ, ∀ u : ℝ, 0 < u → u < ε →
      ‖∑ j ∈ Finset.range (n + 1), c j * (u : ℂ) ^ (2 * j + 1)‖ ≤
        C * u ^ (2 * n + 3)) : ∀ n : ℕ, c n = 0 :=
  OPICAShCoefficientExtraction.odd_coefficients_eq_zero_of_remainder_bound c hε h

/-- Falsification control: a same-order bound allows a nonzero leading
coefficient, so the two extra orders in the expected consumer matter. -/
theorem same_order_bound_nonzero :
    (∀ u : ℝ, 0 < u → u < 1 →
      ‖(1 : ℂ) * (u : ℂ) ^ 1‖ ≤ 1 * u ^ 1) ∧ (1 : ℂ) ≠ 0 := by
  constructor
  · intro u hu _
    simp [Complex.norm_real, Real.norm_eq_abs, abs_of_pos hu]
  · norm_num

#print axioms expected_odd_coefficients
#print axioms same_order_bound_nonzero

end OPICAExpectedShCoefficientExtraction
