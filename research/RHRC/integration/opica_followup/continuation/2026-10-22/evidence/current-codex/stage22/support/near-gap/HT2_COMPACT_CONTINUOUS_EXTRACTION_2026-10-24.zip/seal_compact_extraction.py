from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile
h=Path(__file__).resolve().parent
r=h.parent/'opica-followup-repo'
def info(p):
    p=Path(p)
    return {'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for name,wanted in [('ExpectedFullContracts.lean','c7e5936ff169cafa803cd31282ef5a5b4efa56b01675903f4ab306e4dd94ab15'),
                    ('ORIGINAL_PRE_ELABORATION.lean','3e9dedc694dbe6c32b9db82842456064bd1eddce50c5bca84c18067b2011f414')]:
    assert info(h/name)['sha256']==wanted,(name,'sealed seven-consumer bytes changed')
files=['CompactContinuousExtraction.lean','CompactContinuousExtraction.olean',
       'ExpectedCompactContinuousExtraction.lean','ExpectedCompactContinuousExtraction.olean',
       'ExpectedCompactContinuousExtraction.setup.json',
       'ExpectedCompactContinuousExtractionProduction.lean',
       'NearGapLimitsCompactExtraction.append.lean',
       'NegativeNoCommonBudget.lean','NegativeNoCommonBudget.setup.json',
       'compact-attempt1.log','compact-attempt2.log','compact-attempt3.log',
       'compact-positive-consumer.log','compact-negative-no-common-budget.log',
       'HT2_COMPACT_EXTRACTION_README.md','seal_compact_extraction.py']
source=r/'Zeta23/OPICAFollowup/NearGapLimits.lean'
obj=r/'.lake/build/lib/lean/Zeta23/OPICAFollowup/NearGapLimits.olean'
m=r/'.lake/packages/mathlib'
receipt={'schema':'OPICA_HT2_COMPACT_CONTINUOUS_EXTRACTION_V1',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'head':subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'],text=True).strip(),
 'head_tree':subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD^{tree}'],text=True).strip(),
 'checked_source_state':'Dirty Stage22 assembly; existing native NearGap object read-only; new helper and consumer freshly compiled to scratch outputs.',
 'compiler':'Lean4.33.0-rc2 Windows native, d8b18978322de05a8f3dba51ef03cf5461676c17',
 'mathlib':'51e6992efd06126df61a496bebf8f49482a4e129',
 'new_primary_roots':0,
 'gates':{'helper_native':{'exit_code':0,'log':'compact-attempt3.log'},
          'literal_consumer_native':{'exit_code':0,'log':'compact-positive-consumer.log'},
          'negative_missing_common_TV':{'exit_code':1,'log':'compact-negative-no-common-budget.log',
             'meaning':'Rejected at missing CommonLinearMassBound premise; interface control, not a counterexample theorem.'}},
 'theorems':['Zeta23.OPICAFollowup.IndependentCompactExtraction.'+x for x in
    ['compact_continuous_schwartz_approximation','compact_pairing_difference_bound',
     'schwartz_zero_implies_compact_continuous_zero','expected_near_gap_compact_continuous_limit_zero',
     'expected_near_gap_genuine_zero_measure_extraction']]+[
       'Zeta23.OPICAFollowup.IndependentCompactExtractionConsumer.expected_full_HT2_compact_continuous_extraction'],
 'all_printed_axioms':['propext','Classical.choice','Quot.sound'],
 'topology':'Every continuous compactly supported complex test, actual signed Jordan integrals; actual zero signed-measure limit and strictMono identity subsequence.',
 'scope_limits':['Not general Radon weak-star compactness for arbitrary bounded sequences.',
    'Not convergence of Jordan positive and negative parts separately.',
    'Not total-variation convergence.',
    'Production append and production-import consumer require owner exact-source replay.',
    'No human approval, review seal, CI pass, full-release acceptance, RH or Step4 theorem is asserted.'],
 'domain':'Arbitrary original HT2 signed measures with one common actual linear TV bound, Fourier self-duality, positivity off integers, literal gaps 0<a_n<=1 and a_n->1. Explicit per-member growth witnesses are consequences of the common bound.',
 'original_seven_preserved':[info(h/x) for x in ['ExpectedFullContracts.lean','ORIGINAL_PRE_ELABORATION.lean','INDEPENDENT_EXPECTED_CONSUMERS_RECEIPT.json']],
 'dependencies':[info(source),info(obj),info(m/'Mathlib/Analysis/Calculus/BumpFunction/SmoothApprox.lean'),
                 info(m/'.lake/build/lib/lean/Mathlib/Analysis/Calculus/BumpFunction/SmoothApprox.olean')],
 'files':[info(h/x) for x in files]}
p=h/'HT2_COMPACT_CONTINUOUS_EXTRACTION_RECEIPT.json'
p.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
bundle=h/'HT2_COMPACT_CONTINUOUS_EXTRACTION_2026-10-24.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
    for x in files+[p.name]: z.write(h/x,x)
print(json.dumps({'receipt':info(p),'bundle':info(bundle),
    'append':info(h/'NearGapLimitsCompactExtraction.append.lean'),
    'production_consumer':info(h/'ExpectedCompactContinuousExtractionProduction.lean')},indent=2))
