from pathlib import Path
import json, re, subprocess, hashlib

HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
BASE=REPO/'research/RHRC/integration/opica_followup'
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
roots=json.loads((BASE/'PUBLIC_ROOTS.json').read_text())['roots']
manifest=json.loads((BASE/'BUILD_MANIFEST.json').read_text())
descriptor=json.loads((BASE/'PARENT_EXTENSION.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO,text=True).strip()
dirty=subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True)
paths=['Zeta23/OPICAFollowup/Validation.lean']+[p.relative_to(REPO).as_posix() for p in sorted((BASE/'continuation/2026-10-22/consumers').glob('*.lean'))]
decls=[]
for path in paths:
    text=(REPO/path).read_text(encoding='utf-8')
    # Static syntax inventory only; native Lean later determines full qualified names/types.
    for match in re.finditer(r'(?m)^[ \t]*(?:(?:noncomputable|private|protected)\s+)*(theorem|lemma|def|abbrev)\s+(\w+)',text):
        decls.append({'name':match[2],'path':path,'line':text.count('\n',0,match.start())+1,'kind':match[1]})
coverage=[]
for root in roots:
    expected=root['expected_type_consumer']
    hits=[d for d in decls if d['name']==expected]
    uses=[]
    short=root['full_name'].split('.')[-1]
    for path in paths:
        text=(REPO/path).read_text(encoding='utf-8')
        if re.search(r'\b'+re.escape(short)+r'\b',text): uses.append(path)
    coverage.append({'root':root['full_name'],'expected_name':expected,'exact_basename_candidates':hits,'source_use_candidates':uses,'status':'STATIC_CANDIDATES_NOT_COMPILER_OR_DOMAIN_REVIEWED' if hits else 'NO_EXACT_EXPECTED_BASENAME'})
tracked=set(subprocess.check_output(['git','ls-files'],cwd=REPO,text=True).splitlines())
parent=set(subprocess.check_output(['git','ls-tree','-r','--name-only',descriptor['parent_tree']],cwd=REPO,text=True).splitlines())
creates=set(descriptor['new_exact_paths'])
expected=parent|creates
result={'schema':'OPICA_UNACCEPTED_FULL100_PREPARATION_V1','status':'UNACCEPTED_STATIC_INVENTORY','head':head,'tree':tree,'dirty':bool(dirty),'git_status':dirty,'root_count':len(roots),'source_hashes':{p:sha(REPO/p) for p in paths},'coverage':coverage,'exact_basename_candidate_count':sum(bool(x['exact_basename_candidates']) for x in coverage),'uncovered':[x['root'] for x in coverage if not x['exact_basename_candidates']],'parent_extension':{'expected_count':len(expected),'tracked_count':len(tracked),'unlisted_tracked':sorted(tracked-expected),'missing_required':sorted(expected-tracked),'frozen_descriptor_sha256':sha(BASE/'PARENT_EXTENSION.json')},'missing_manifest_modules':[m['path'] for m in manifest['modules'] if not (REPO/m['path']).exists()],'claim_firewall':{'independent_review':'NOT_ESTABLISHED','full_acceptance':'OPEN','RH':'OPEN','Step4':'OPEN'}}
(HERE/'coverage-inventory.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ('head','tree','dirty','root_count','exact_basename_candidate_count','uncovered','missing_manifest_modules')},indent=2))
print('parent extension unlisted:',len(result['parent_extension']['unlisted_tracked']),'missing:',len(result['parent_extension']['missing_required']))
print('all inventory:',HERE/'coverage-inventory.json')
