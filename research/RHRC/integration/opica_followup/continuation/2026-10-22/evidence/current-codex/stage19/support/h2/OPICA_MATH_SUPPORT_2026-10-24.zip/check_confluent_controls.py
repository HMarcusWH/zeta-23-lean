"""Exact finite H2a normalization controls, not a general proof or RH check."""
from pathlib import Path
import hashlib
import json
import math
import sympy as S

z = S.Symbol('z')

def matrix(nodes, multiplicities, normalized=True):
    size = sum(multiplicities)
    return S.Matrix([
        [S.diff(z*(S.Rational(1,4)-z)**n, z, k).subs(z, node) /
         (math.factorial(k) if normalized else 1)
         for node, m in zip(nodes, multiplicities) for k in range(m)]
        for n in range(size)]) if size else S.eye(0)

def expected(nodes, multiplicities):
    size = sum(multiplicities)
    return ((-1)**(size*(size-1)//2) *
            S.prod(node**m for node,m in zip(nodes,multiplicities)) *
            S.prod((nodes[j]-nodes[i])**(multiplicities[i]*multiplicities[j])
                   for i in range(len(nodes)) for j in range(i+1,len(nodes))))

cases=[]
systems=[([], []),([2],[1]),([2],[2]),([2],[3]),([2],[4]),
         ([2,3],[1,1]),([2,3],[2,1]),([2,3],[1,2]),([2,3],[2,2]),
         ([2,3],[2,3]),([2,3,5],[1,1,1]),([2,3,5],[1,2,1]),
         ([S.Rational(1,4),3],[2,1]),([1+S.I,1-S.I],[2,2]),
         ([0,3],[1,2]),([0],[3]),([2,2],[1,2])]
for nodes,multiplicities in systems:
    actual=S.factor(matrix(nodes,multiplicities).det())
    target=S.factor(expected(nodes,multiplicities))
    assert S.simplify(actual-target)==0,(nodes,multiplicities,actual,target)
    raw=S.factor(matrix(nodes,multiplicities,False).det())
    factorials=S.prod(math.factorial(k) for m in multiplicities for k in range(m))
    assert S.simplify(raw-actual*factorials)==0
    cases.append(dict(nodes=list(map(str,nodes)),multiplicities=multiplicities,
                      determinant=str(actual),raw_derivative_determinant=str(raw),
                      factorial_multiplier=str(factorials)))

a,b,eps=S.symbols('a b eps')
two=matrix([a,b],[1,1]).det().factor()
assert S.simplify(two+a*b*(b-a))==0
collision=S.factor(two.subs({a:1,b:1+eps}))
assert S.simplify(collision+eps*(1+eps))==0
normalized_three=matrix([2],[3]).det()
raw_three=matrix([2],[3],False).det()
assert normalized_three != raw_three
wrong_sign_two=S.simplify(two-a*b*(b-a))
assert wrong_sign_two != 0

xi=S.Rational(1,7)
rate_controls=[]
for t in (100,1000,10000,100000,1000000):
    tf=float(t)
    k=max(1,math.floor(float(xi)*tf/math.log(tf)))
    rate_controls.append(dict(T=t,k=k,k_log_k1_div_T=k*math.log(k+1)/tf,
                              k_log_T_div_T=k*math.log(tf)/tf,
                              k_div_T=k/tf))

result=dict(status='PASS_EXACT_FINITE_CONTROLS_ONLY',sympy=S.__version__,
            source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            cases=cases,controls=dict(two_node_formula=str(two),
             coalescence=str(collision),normalized_three=str(normalized_three),
             raw_three=str(raw_three),wrong_sign_residual=str(wrong_sign_two)),
            rate_numerics=dict(status='NUMERICAL_SANITY_ONLY',xi=str(xi),cases=rate_controls))
Path(__file__).with_name('confluent-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],exact_systems=len(cases),
                     controls=result['controls'],rate_numerics=result['rate_numerics']),indent=2))
