import ConfluentAlgebra
import Mathlib.Tactic.Ring

noncomputable section
open Polynomial Finset
open scoped BigOperators

namespace OPICAConfluentAudit
variable {K : Type*} [CommRing K] {M : ℕ}

def priorMatches (node : Fin M → K) (κ : K) (i : Fin M) : Finset (Fin M) := by
  classical
  exact (Finset.Iio i).filter (fun j => node j = κ)

def priorNonmatches (node : Fin M → K) (κ : K) (i : Fin M) : Finset (Fin M) := by
  classical
  exact (Finset.Iio i).filter (fun j => node j ≠ κ)

def repeatedJetOrder (node : Fin M → K) (i : Fin M) : ℕ :=
  (priorMatches node (node i) i).card

theorem taylor_newtonPolynomial (node : Fin M → K) (κ : K) (i : Fin M) :
    Polynomial.taylor κ (newtonPolynomial node i) =
      X ^ (priorMatches node κ i).card *
        ∏ j ∈ priorNonmatches node κ i, (X + C (κ - node j)) := by
  classical
  rw [newtonPolynomial, Polynomial.taylor_apply, Polynomial.prod_comp]
  have hterm (j : Fin M) :
      (X - C (node j)).comp (X + C κ) = (X + C (κ - node j) : K[X]) := by
    simp only [Polynomial.sub_comp, Polynomial.X_comp, Polynomial.C_comp, map_sub]
    ring
  simp_rw [hterm]
  rw [← Finset.prod_filter_mul_prod_filter_not (Finset.Iio i)
    (fun j => node j = κ) (fun j => (X + C (κ - node j) : K[X]))]
  have hmatch : (∏ j ∈ priorMatches node κ i, (X + C (κ - node j) : K[X])) =
      X ^ (priorMatches node κ i).card := by
    calc
      _ = ∏ j ∈ priorMatches node κ i, (X : K[X]) := by
        apply Finset.prod_congr rfl
        intro j hj
        have hjκ : node j = κ := (Finset.mem_filter.mp hj).2
        simp [hjκ]
      _ = _ := Finset.prod_const _
  exact congrArg (fun p : K[X] => p *
    ∏ j ∈ priorNonmatches node κ i, (X + C (κ - node j))) hmatch

theorem priorMatches_strict (node : Fin M → K) {i j : Fin M} (hji : j < i) :
    repeatedJetOrder node j < (priorMatches node (node j) i).card := by
  classical
  have hjnot : j ∉ priorMatches node (node j) j := by simp [priorMatches]
  have hsub : insert j (priorMatches node (node j) j) ⊆ priorMatches node (node j) i := by
    intro l hl
    rcases Finset.mem_insert.mp hl with hl | hl
    · subst l
      simp [priorMatches, hji]
    · have hl' := Finset.mem_filter.mp hl
      simp only [priorMatches, Finset.mem_filter, Finset.mem_Iio] at hl' ⊢
      exact ⟨lt_trans hl'.1 hji, hl'.2⟩
  have hcard := Finset.card_le_card hsub
  rw [Finset.card_insert_of_notMem hjnot] at hcard
  exact Nat.lt_of_succ_le hcard

theorem hasseFunctional_newton_below (node : Fin M → K) {i j : Fin M} (hji : j < i) :
    hasseFunctional (node j) (repeatedJetOrder node j) (newtonPolynomial node i) = 0 := by
  rw [hasseFunctional_eq_taylor_coeff, taylor_newtonPolynomial,
    Polynomial.coeff_X_pow_mul', if_neg (not_le.mpr (priorMatches_strict node hji))]

theorem hasseFunctional_newton_diagonal (node : Fin M → K) (i : Fin M) :
    hasseFunctional (node i) (repeatedJetOrder node i) (newtonPolynomial node i) =
      ∏ j ∈ priorNonmatches node (node i) i, (node i - node j) := by
  rw [hasseFunctional_eq_taylor_coeff, taylor_newtonPolynomial]
  rw [repeatedJetOrder, Polynomial.coeff_X_pow_mul']
  simp [Polynomial.coeff_zero_prod]

theorem normalizedHermite_determinant [Nontrivial K] (node : Fin M → K) :
    (functionalMatrix (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
      (fun i => X ^ (i : ℕ))).det =
      ∏ i : Fin M, ∏ j ∈ priorNonmatches node (node i) i, (node i - node j) := by
  rw [← det_functionalMatrix_monic_basis _ (newtonPolynomial node)
    (newtonPolynomial_natDegree node) (newtonPolynomial_monic node)]
  have hu : (functionalMatrix (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
      (newtonPolynomial node)).IsUpperTriangular := by
    intro i j hji
    exact hasseFunctional_newton_below node hji
  rw [Matrix.det_of_isUpperTriangular hu]
  apply Finset.prod_congr rfl
  intro i hi
  exact hasseFunctional_newton_diagonal node i

#print axioms taylor_newtonPolynomial
#print axioms priorMatches_strict
#print axioms hasseFunctional_newton_below
#print axioms hasseFunctional_newton_diagonal
#print axioms normalizedHermite_determinant
end OPICAConfluentAudit
