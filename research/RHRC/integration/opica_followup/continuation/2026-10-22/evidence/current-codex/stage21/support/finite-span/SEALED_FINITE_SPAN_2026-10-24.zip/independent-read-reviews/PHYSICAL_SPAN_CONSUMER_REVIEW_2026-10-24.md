# Physical span consumer dependency review — 2026-10-24

Read-only review of `work/audit-finite-span/ConsumersSpanFullCandidate.lean`,
SHA-256 `a5ec14ea0c5754ba762034420b58047f6134baa1e8b52fc405c9c06e3872cc6e`,
against the full public root types in pinned production source.

The profile clauses now project `zero_profile_regular_selfdual`: continuity,
integrability, L² membership, and Fourier self-duality are respectively its
second, third, fourth, and sixth conjuncts. The projection paths used in the
consumer select exactly those actual `zeroProfile rho` statements.

The zero-order identification projects the seventh conjunct of
`copoisson_zero_jets_measures rho hz h0 h1 k hk`. Its precise type is
`k = 0 → normalizedZeroMeasureJet rho k = zeroMeasure rho`. The consumer
retains the literal actual zero, open-strip and available-multiplicity
hypotheses needed for that theorem. It does not replace a nonzero jet by the
zero-order measure or assume all zeros are simple.

Both public H2b clauses are consumed explicitly: the first yields zero
canonical positive and negative parts from actual off-lattice nonnegativity;
the second yields zero coefficients for an arbitrary fixed independent
actual real basis. Actual span growth, gap and Fourier properties are still
constructed by the already reviewed actual-jet helpers. No implicit reality
packet, fake measure, positivity premise on all jets, or unconditional
zero-location conclusion is introduced.

Verdict: no mathematical problem found in these public-root dependency
changes. The final actual consumer's theorem type retains the full physical
properties and arbitrary multiplicity domain. The owning agent reports
native compilation with standard axioms; this read-only review does not
substitute for the owner's exact-source compiler receipt.

This is supporting agent review, not external human approval or a full-100
independent review seal. The separate assembled-module delta review is
`FINITE_SPAN_ASSEMBLY_REVIEW_DELTA_2026-10-24.md` (SHA-256
`fa9a1d1cb624b3eb69695addb4f6a09ba7e07128873a4000ea7a8233a1b552d2`).

