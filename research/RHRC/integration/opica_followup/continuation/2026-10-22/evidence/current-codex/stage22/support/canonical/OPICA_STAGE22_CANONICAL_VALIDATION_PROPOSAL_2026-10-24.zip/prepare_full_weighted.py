"""Explicit full-clause source proposals; never an independent review seal.

These copy written source signatures rather than reflect compiler types. The
separate existing physical consumers remain in Validation. Every frozen clause
and actual-domain identity still requires independent review.
"""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
path=REPO/'Zeta23/OPICAFollowup/WeightedMixing.lean'
text=path.read_text(encoding='utf-8')
rows=[];pieces=[]
for name,args in [('weighted_mobius_inverse','σ a ha hm'),('weighted_mixture_sharp_gap','σ a ha hm hself hgap'),('weighted_gap_leakage','')]:
    start=text.index('theorem '+name)
    end=text.index(':= by',start)
    signature=text[start:end]
    signature=signature.replace('theorem '+name,'theorem expected_'+name,1)
    pieces.append('/- Complete written source signature, retaining every conjunct; independent review remains OPEN. -/\n'+signature+':= by\n  exact '+name+(' '+args if args else '')+'\n')
    rows.append({'root':name,'source':str(path),'line':text[:start].count('\n')+1,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'expected_name':'expected_'+name,'status':'EXPLICIT_COMPLETE_WRITTEN_SIGNATURE_PROPOSAL_NOT_INDEPENDENT_REVIEW'})
out='import Zeta23.OPICAFollowup.WeightedMixing\nnoncomputable section\nopen Set MeasureTheory Filter Complex\nopen scoped ENNReal Topology FourierTransform SchwartzMap\nopen Zeta23.OPICA Zeta23.OPICAFollowup\nnamespace Zeta23.OPICAFollowup.Validation\n\n'+'\n'.join(pieces)+'\nend Zeta23.OPICAFollowup.Validation\n'
(HERE/'FullWeightedClauseOverrides.lean').write_text(out,encoding='utf-8')
(HERE/'full-weighted-provenance.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
