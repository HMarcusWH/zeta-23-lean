import RateSourceCosts
import RateMemoryWindow
import RateCompletionIndex

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23.CCM Zeta23.ExceptionalZero Zeta23.OPICA
namespace Zeta23.OPICAFollowup.Stage19Rate.Asymptotic

theorem multiplicityTailConstant_source_factor (d : ℕ) (rho : zetaZeroConfig.carrier) :
    nativeMultiplicityTailConstant d rho =
      ‖((rho : ℂ)-1/2)^2-1/4‖^d*nativeMultiplicityTailConstant 0 rho := by
  dsimp [nativeMultiplicityTailConstant]
  rw [sourceFamilyLaplace_factor,sourceFamilyLaplace_factor]
  simp only [pow_zero,one_mul,norm_mul,norm_pow]
  ring

theorem multiplicityTailConstant_log_div_time_tendsto_zero
    (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    (rho : zetaZeroConfig.carrier) (hright : 1/2 < (rho : ℂ).re) :
    Tendsto (fun n => Real.log (nativeMultiplicityTailConstant (d n) rho)/T.time n)
      atTop (𝓝 0) := by
  let p : ℂ := (rho : ℂ)-1/2
  have hp := norm_ne_zero_iff.mpr (right_zero_source_factor_ne_zero rho hright)
  have hJ := norm_ne_zero_iff.mpr
    (nativeOriginalSourceLaplace_ne_zero_at_off_line_zero rho (ne_of_gt hright))
  have hD := (nativeMultiplicityTailConstant_pos 0 rho hright).ne'
  have he (n : ℕ) : Real.log (nativeMultiplicityTailConstant (d n) rho)/T.time n =
      Real.log ‖sourceFamilyLaplace (d n) p‖/T.time n+
        (Real.log (nativeMultiplicityTailConstant 0 rho)-Real.log ‖nativeOriginalSourceLaplace p‖)/T.time n := by
    rw [multiplicityTailConstant_source_factor,sourceFamilyLaplace_factor,norm_mul,norm_pow,
      Real.log_mul (pow_ne_zero (d n) hp) hD,Real.log_mul (pow_ne_zero (d n) hp) hJ,
      Real.log_pow]
    dsimp [p]
    ring
  have hc : Tendsto (fun n =>
      (Real.log (nativeMultiplicityTailConstant 0 rho)-Real.log ‖nativeOriginalSourceLaplace p‖)/T.time n)
      atTop (𝓝 0) := tendsto_const_nhds.div_atTop T.cofinal
  have h := (sourceFactor_log_div_time_tendsto_zero T d hd rho hright).add hc
  simpa only [add_zero] using h.congr (fun n => (he n).symm)

theorem auxiliaryDriveCausalVector_norm_eq (d : ℕ) :
    ‖auxiliaryDriveCausalVector d‖ = ‖integerDriveFamilyL2 d‖ := by
  have hc : (auxiliaryDriveCausalVector d : NativeCompletionL2) =ᵐ[volume]
      (fun t : ℝ => (integerDriveFamily d t : ℂ)) :=
    (auxiliaryDrive_complex_memLp_two d).coeFn_toLp
  have hnorm : ‖(auxiliaryDriveCausalVector d : NativeCompletionL2)‖^2 =
      ∫ t : ℝ, |integerDriveFamily d t|^2 := by
    rw [← real_inner_self_eq_norm_sq,L2.inner_def]
    apply integral_congr_ae
    filter_upwards [hc] with t ht
    simp only [ht,real_inner_self_eq_norm_sq,Complex.norm_real,Real.norm_eq_abs]
  have hreal : ‖integerDriveFamilyL2 d‖^2 = ∫ t : ℝ, |integerDriveFamily d t|^2 := by
    rw [integerDriveFamilyL2_norm_eq,Real.sq_sqrt (integral_nonneg fun _ => sq_nonneg _)]
  exact (sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _)).mp (hnorm.trans hreal.symm)

theorem actualInput_div_rational_bound (rho : zetaZeroConfig.carrier)
    (hright : 1/2 < (rho : ℂ).re) :
    ∃ Cp Cs : ℝ, 0 < Cp ∧ 0 < Cs ∧ ∀ k d : ℕ, 1 ≤ k →
      ‖nativeAuxiliaryStableVector k d‖/‖auxRationalFactor k ((rho : ℂ)-1/2)‖ ≤
        Real.exp (Cp*((k : ℝ)+1)+Cs*((d : ℝ)+1)*Real.log ((d : ℝ)+2)) := by
  obtain ⟨Cp,hCp,hp⟩ := aux_completion_ratio_bounds rho hright
  obtain ⟨Cs,hCs,hs⟩ := source_order_uniform_norms
  refine ⟨Cp,Cs,hCp,hCs,fun k d hk => ?_⟩
  have hd := (hs d).2.2.1
  have hnorm : ‖auxiliaryDriveCausalVector d‖ ≤ Real.exp (Cs*((d : ℝ)+1)*Real.log ((d : ℝ)+2)) := by
    rw [auxiliaryDriveCausalVector_norm_eq]
    exact hd
  calc
    _ ≤ ((∫ s : ℝ, ‖auxCompletionFilter k s‖)*‖auxiliaryDriveCausalVector d‖)/
        ‖auxRationalFactor k ((rho : ℂ)-1/2)‖ :=
      div_le_div_of_nonneg_right (nativeAuxiliaryStableVector_norm_le k d) (norm_nonneg _)
    _ = ((∫ s : ℝ, ‖auxCompletionFilter k s‖)/‖auxRationalFactor k ((rho : ℂ)-1/2)‖)*
        ‖auxiliaryDriveCausalVector d‖ := by ring
    _ ≤ Real.exp (Cp*((k : ℝ)+1))*Real.exp (Cs*((d : ℝ)+1)*Real.log ((d : ℝ)+2)) :=
      mul_le_mul (hp k hk).2.1 hnorm (norm_nonneg _) (Real.exp_nonneg _)
    _ = _ := (Real.exp_add _ _).symm

#print axioms multiplicityTailConstant_source_factor
#print axioms multiplicityTailConstant_log_div_time_tendsto_zero
#print axioms auxiliaryDriveCausalVector_norm_eq
#print axioms actualInput_div_rational_bound
end Zeta23.OPICAFollowup.Stage19Rate.Asymptotic
