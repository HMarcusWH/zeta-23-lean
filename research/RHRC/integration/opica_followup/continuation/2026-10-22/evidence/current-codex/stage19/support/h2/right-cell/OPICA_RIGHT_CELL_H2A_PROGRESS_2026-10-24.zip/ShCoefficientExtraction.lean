import Zeta23.OPICAFollowup.CoPoissonJets

noncomputable section
open Set Filter Complex
open scoped Topology

namespace OPICAShCoefficientExtraction

/-- A coefficient vanishes if its norm is bounded by a quadratic error on a
nonempty interval approaching zero from the right. No differentiability is used. -/
theorem eq_zero_of_small_pos_norm_bound (c : ℂ) {ε : ℝ} (hε : 0 < ε) (C : ℝ)
    (h : ∀ u : ℝ, 0 < u → u < ε → ‖c‖ ≤ C * u ^ 2) : c = 0 := by
  have hlim : Tendsto (fun u : ℝ => C * u ^ 2) (𝓝[>] 0) (𝓝 0) := by
    have hc : Continuous (fun u : ℝ => C * u ^ 2) :=
      continuous_const.mul (continuous_id.pow 2)
    simpa only [zero_pow two_ne_zero, mul_zero] using
      (hc.tendsto (0 : ℝ)).mono_left nhdsWithin_le_nhds
  have hevent : ∀ᶠ u : ℝ in 𝓝[>] 0, ‖c‖ ≤ C * u ^ 2 := by
    apply mem_nhdsGT_iff_exists_Ioo_subset.mpr
    exact ⟨ε, hε, fun u hu => h u hu.1 hu.2⟩
  have hn : ‖c‖ ≤ 0 := le_of_tendsto_of_tendsto tendsto_const_nhds hlim hevent
  exact norm_eq_zero.mp (le_antisymm hn (norm_nonneg c))

/-- Division by the positive leading monomial turns a higher-order remainder
bound into a vanishing coefficient. -/
theorem eq_zero_of_small_pos_monomial_bound (c : ℂ) (d : ℕ) {ε : ℝ}
    (hε : 0 < ε) (C : ℝ)
    (h : ∀ u : ℝ, 0 < u → u < ε → ‖c * (u : ℂ) ^ d‖ ≤ C * u ^ (d + 2)) :
    c = 0 := by
  apply eq_zero_of_small_pos_norm_bound c hε C
  intro u hu hεu
  have hp : 0 < u ^ d := pow_pos hu d
  have hb := h u hu hεu
  rw [norm_mul, norm_pow, Complex.norm_real, Real.norm_eq_abs, abs_of_pos hu,
    pow_add] at hb
  apply (mul_le_mul_iff_of_pos_right hp).mp
  calc ‖c‖ * u ^ d ≤ C * (u ^ d * u ^ 2) := hb
    _ = (C * u ^ 2) * u ^ d := by ring

/-- An odd polynomial whose truncations have two extra vanishing orders at
zero has no nonzero coefficient. This consumes quantitative right-cell
remainders without asserting differentiability of the physical density. -/
theorem odd_coefficients_eq_zero_of_remainder_bound (c : ℕ → ℂ) {ε : ℝ}
    (hε : 0 < ε)
    (h : ∀ n : ℕ, ∃ C : ℝ, ∀ u : ℝ, 0 < u → u < ε →
      ‖∑ j ∈ Finset.range (n + 1), c j * (u : ℂ) ^ (2 * j + 1)‖ ≤
        C * u ^ (2 * n + 3)) : ∀ n : ℕ, c n = 0 := by
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    obtain ⟨C, hC⟩ := h n
    apply eq_zero_of_small_pos_monomial_bound (c n) (2 * n + 1) hε C
    intro u hu hεu
    have hs : (∑ j ∈ Finset.range (n + 1), c j * (u : ℂ) ^ (2 * j + 1)) =
        c n * (u : ℂ) ^ (2 * n + 1) := by
      apply Finset.sum_eq_single n
      · intro j hj hjn
        have hjlt : j < n := by have := Finset.mem_range.mp hj; omega
        rw [ih j hjlt, zero_mul]
      · simp
    have hb := hC u hu hεu
    rw [hs] at hb
    simpa [show 2 * n + 1 + 2 = 2 * n + 3 by omega] using hb

#print axioms eq_zero_of_small_pos_norm_bound
#print axioms eq_zero_of_small_pos_monomial_bound
#print axioms odd_coefficients_eq_zero_of_remainder_bound

end OPICAShCoefficientExtraction
