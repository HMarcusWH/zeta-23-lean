import ActualMeasureCell
import Mathlib.Analysis.Distribution.AEEqOfIntegralContDiff

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform ContDiff

namespace OPICAActualMeasureCell
open Zeta23.OPICAFollowup

/-- The actual finite measure relation forces the physical first-cell
density combination to vanish almost everywhere. No density-zero premise
or auxiliary replacement measure is supplied. -/
theorem actual_jet_combination_first_cell_ae_zero {ι : Type*} [Fintype ι]
    (c : ι → ℂ) (ρ : ι → ℂ) (k : ι → ℕ)
    (h0 : ∀ i, 0 < (ρ i).re) (h1 : ∀ i, (ρ i).re < 1)
    (hh : ∀ i, ρ i ≠ 1 / 2) (hk : ∀ i, k i < zeroJetOrder (ρ i))
    (hzero : (∑ i, c i • (normalizedZeroMeasureJet (ρ i) (k i)).distributionOfLinearGrowth
      (normalizedZeroMeasureJet_hasLinearGrowth (h0 i) (h1 i) (hh i) (hk i))) = 0) :
    ∀ᵐ x : ℝ, x ∈ Ioo (1 : ℝ) 2 →
      (∑ i, c i * zeroJetDensity (spectralKappa (ρ i)) (k i) x) = 0 := by
  have hli : LocallyIntegrable
      (fun x : ℝ => ∑ i, c i * zeroJetDensity (spectralKappa (ρ i)) (k i) x) volume := by
    apply locallyIntegrable_finsetSum Finset.univ
    intro i _
    simpa only [Pi.smul_def, smul_eq_mul] using
      (locallyIntegrable_zeroJetDensity (spectralKappa (ρ i)) (k i)).smul (c i)
  apply isOpen_Ioo.ae_eq_zero_of_integral_contDiff_smul_eq_zero
    (hli.locallyIntegrableOn (Ioo 1 2))
  intro g hg hc hs
  have hc' : HasCompactSupport (Complex.ofRealCLM ∘ g) := hc.comp_left rfl
  have hg' : ContDiff ℝ ∞ (Complex.ofRealCLM ∘ g) := by fun_prop
  let φ : 𝓢(ℝ, ℂ) := hc'.toSchwartzMap hg'
  have hφ : Function.support (φ : ℝ → ℂ) ⊆ Ioo 1 2 := by
    intro x hx
    apply hs
    apply subset_tsupport g
    change g x ≠ 0
    intro h
    apply hx
    change (g x : ℂ) = 0
    simp [h]
  have he := actual_jet_combination_first_cell_integral_zero c ρ k h0 h1 hh hk hzero φ hφ
  change (∫ x, (∑ i, c i * zeroJetDensity (spectralKappa (ρ i)) (k i) x) * (g x : ℂ)) = 0 at he
  simpa only [Complex.real_smul, mul_comm] using he

#print axioms actual_jet_combination_first_cell_ae_zero

end OPICAActualMeasureCell
