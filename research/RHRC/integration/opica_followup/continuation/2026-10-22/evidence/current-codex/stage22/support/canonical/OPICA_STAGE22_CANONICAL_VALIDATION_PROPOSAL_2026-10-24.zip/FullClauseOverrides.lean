import Zeta23.OPICAFollowup.Consumers

noncomputable section
open Set MeasureTheory Filter
open scoped Topology ENNReal
open Zeta23 Zeta23.CCM Zeta23.OPICA Zeta23.ExceptionalZero Zeta23.OPICAFollowup
namespace Zeta23.OPICAFollowup.Validation

/- Explicit compound signatures. These preserve both mask branches and every
conclusion of the conditional consumer; they are proposals until compiled and
independently reviewed against all frozen clauses. -/
theorem expected_fixed_two_factor_mask_rate_theta :
    Tendsto (fun T : ℝ => Real.log (1+max
      (∫ t in Icc (T-2*Real.log T) T,
        finiteHighPair (nativeRawPaletteDrive 1 1) (driveIndexBound T)
          (balancedInverseCoefficients 1 (Real.exp (T/2-(8/2)*Real.log T)) 2)
          (balancedInverseCoefficients 1 (Real.exp (T/2-(8/2)*Real.log T)) 2)
          (fun u : ℝ => Real.exp (Real.sqrt u)) t) 0)/(2*T))
      atTop (𝓝 nativeZeroDisplacementSup) ∧
    Tendsto (fun T : ℝ => Real.log (1+max
      (∫ t in Icc (T-2*Real.log T) T,
        finiteHighPair (nativeAbsorbedPaletteDrive 1 2 1 (by norm_num)) (driveIndexBound T)
          ((nativeLargeCoefficients 1 (Real.exp (T/2-(8/2)*Real.log T))^2 : ArithmeticFunction ℝ))
          ((nativeLargeCoefficients 1 (Real.exp (T/2-(8/2)*Real.log T))^2 : ArithmeticFunction ℝ))
          (fun u : ℝ => Real.exp (Real.sqrt u)) t) 0)/(2*T))
      atTop (𝓝 nativeZeroDisplacementSup) :=
  fixed_two_factor_mask_rate_theta

theorem expected_quiet_balanced_observation_implies_native_cut
    (time : ℕ → ℝ) (cofinal : Tendsto time atTop atTop)
    (quiet :
      (∀ epsilon : ℝ, 0 < epsilon → ∀ᶠ n : ℕ in atTop,
        Real.log (1+max (nativeRawHigh 1 2 1 (logSlackY 2 8 (time n)) 2 (time n)) 0)/(2*time n) ≤ epsilon) ∨
      (∀ epsilon : ℝ, 0 < epsilon → ∀ᶠ n : ℕ in atTop,
        Real.log (1+max (nativeAbsorbedHigh 1 2 1 (by norm_num)
          (logSlackY 2 8 (time n)) 2 (time n)) 0)/(2*time n) ≤ epsilon)) :
    nativeZeroDisplacementSup=0 ∧
    (∀ epsilon : ℝ, 0 < epsilon → MemLp
      (fun t : ℝ => ((Real.exp (-epsilon*t)*primeFieldFamily 0 t : ℝ) : ℂ)) 2 volume) ∧
    NativeOriginalPrimeFieldAllDampedL2 ∧
    NativeOriginalPrimeFieldAllDampedIntegral ∧ RiemannHypothesis :=
  quiet_balanced_observation_implies_native_cut time cofinal quiet

end Zeta23.OPICAFollowup.Validation

#print axioms Zeta23.OPICAFollowup.Validation.expected_fixed_two_factor_mask_rate_theta
#print axioms Zeta23.OPICAFollowup.Validation.expected_quiet_balanced_observation_implies_native_cut
