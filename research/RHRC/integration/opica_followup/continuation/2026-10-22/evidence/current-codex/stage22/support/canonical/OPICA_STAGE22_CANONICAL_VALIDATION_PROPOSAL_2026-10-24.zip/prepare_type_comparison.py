from pathlib import Path
import json
HERE=Path(__file__).resolve().parent
roots=json.loads((HERE.parent/'opica-followup-repo/research/RHRC/integration/opica_followup/PUBLIC_ROOTS.json').read_text())['roots']
header='''import Zeta23.OPICAFollowup.Validation
import Lean
open Lean Lean.Elab Command Lean.Meta
set_option maxHeartbeats 800000
/- Computable diagnostic only. A mismatch may be an equivalent physical
reformulation or a weaker subcase; a match is not independent semantic review. -/
elab "opica_type_comparison " r:ident " against " c:ident : command => do
  let rn ← resolveGlobalConstNoOverload r
  let cn ← resolveGlobalConstNoOverload c
  let ri ← getConstInfo rn
  let ci ← getConstInfo cn
  let status ← if ri.levelParams.length != ci.levelParams.length then
      pure "UNIVERSE_PARAMETER_COUNT_DIFFERS"
    else liftTermElabM do
      let us := (List.range ri.levelParams.length).map
        (fun i => Level.param (Name.mkSimple ("diagnostic_u" ++ toString i)))
      let rt := ri.type.instantiateLevelParams ri.levelParams us
      let ct := ci.type.instantiateLevelParams ci.levelParams us
      let eq ← withReducible (isDefEq rt ct)
      pure (if eq then "DEFINITIONALLY_EQUAL" else "DIFFERENT_REVIEW_REQUIRED")
  liftIO <| IO.println s!"OPICA_DIAGNOSTIC_TYPE_COMPARISON\\t{rn}\\t{cn}\\t{status}"
'''
tail='\n'.join('opica_type_comparison '+r['full_name']+' against Zeta23.OPICAFollowup.Validation.'+r['expected_type_consumer'] for r in roots)+'\n'
(HERE/'CompareFullExpectedTypes.lean').write_text(header+tail,encoding='utf-8')
(HERE/'CompareFullExpectedTypesDefault.lean').write_text((header+tail).replace('withReducible (isDefEq rt ct)','isDefEq rt ct'),encoding='utf-8')
