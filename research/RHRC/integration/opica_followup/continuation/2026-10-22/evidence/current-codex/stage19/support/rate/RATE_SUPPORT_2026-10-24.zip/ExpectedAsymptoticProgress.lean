import NativeInputSurvival

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23 Zeta23.OPICA Zeta23.OPICAFollowup
namespace Stage19IndependentAsymptotic

theorem expected_literal_slow_window_upper (T : HorizonSchedule) (d : ℕ → ℕ)
    (slow : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    {C epsilon : ℝ} (C_nonneg : 0 ≤ C) (epsilon_pos : 0 < epsilon) :
    ∀ᶠ n : ℕ in atTop,
      Real.log (1+(∫ t : ℝ in Icc (T.time n-C*Real.log (T.time n)) (T.time n),
        |primeFieldFamily (d n) t|^2))/(2*T.time n) < nativeZeroDisplacementSup+epsilon :=
  Stage19Rate.Asymptotic.slowSource_window_rate_eventually_lt_theta_add T d slow C_nonneg epsilon_pos

theorem expected_literal_theta_zero_slow_limit (T : HorizonSchedule) (d : ℕ → ℕ)
    (slow : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    {C : ℝ} (C_nonneg : 0 ≤ C) (theta_zero : nativeZeroDisplacementSup=0) :
    Tendsto (fun n => Real.log (1+(∫ t : ℝ in Icc (T.time n-C*Real.log (T.time n)) (T.time n),
        |primeFieldFamily (d n) t|^2))/(2*T.time n)) atTop (𝓝 0) :=
  Stage19Rate.Asymptotic.slowSource_window_rate_tendsto_zero_of_theta_zero T d slow C_nonneg theta_zero

theorem expected_full_multiplicity_coefficient_cost (T : HorizonSchedule) (d : ℕ → ℕ)
    (slow : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    (rho : zetaZeroConfig.carrier) (right_zero : 1/2 < (rho : ℂ).re) :
    Tendsto (fun n => Real.log (nativeMultiplicityTailConstant (d n) rho)/T.time n)
      atTop (𝓝 0) :=
  Stage19Rate.Asymptotic.multiplicityTailConstant_log_div_time_tendsto_zero T d slow rho right_zero

theorem expected_actual_subtraction_survives (T : HorizonSchedule) (d : ℕ → ℕ)
    (slow : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    (rho : zetaZeroConfig.carrier) (right_zero : 1/2 < (rho : ℂ).re)
    (xi : ℝ) (xi_nonneg : 0 ≤ xi) :
    ∀ᶠ n : ℕ in atTop,
      ‖nativeAuxiliaryStableVector (max 1 (Nat.floor (xi*T.time n/Real.log (T.time n)))) (d n)‖ ≤
        nativeMultiplicityTailConstant (d n) rho*
          ‖auxRationalFactor (max 1 (Nat.floor (xi*T.time n/Real.log (T.time n)))) ((rho : ℂ)-1/2)‖*
            Real.exp (((rho : ℂ)-1/2).re*T.time n)/2 :=
  Stage19Rate.Asymptotic.actual_completed_input_eventually_half_leading T d slow rho right_zero xi xi_nonneg

/-- Auxiliary falsification: an upper rate bound by positive theta is compatible
with positive rate. This is not an additional native source or zeta system. -/
theorem upper_bound_does_not_force_zero_control {T : ℝ} (hT : 0 < T) :
    Real.log (1+(Real.exp (2*T)-1))/(2*T)=1 := by
  rw [show 1+(Real.exp (2*T)-1)=Real.exp (2*T) by ring,Real.log_exp]
  exact div_self (by positivity)

#print axioms expected_literal_slow_window_upper
#print axioms expected_literal_theta_zero_slow_limit
#print axioms expected_full_multiplicity_coefficient_cost
#print axioms expected_actual_subtraction_survives
#print axioms upper_bound_does_not_force_zero_control
end Stage19IndependentAsymptotic
