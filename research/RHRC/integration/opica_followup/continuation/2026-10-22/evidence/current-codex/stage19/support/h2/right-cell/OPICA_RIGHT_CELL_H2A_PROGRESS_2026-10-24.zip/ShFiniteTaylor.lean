import Zeta23.OPICAFollowup.CoPoissonJets

/-! Finite right-cell Taylor remainders, prior to any κ differentiation.
These are statements about the explicit entire kernel, not derivatives of
the global physical density at the first lattice boundary. -/

noncomputable section
set_option maxHeartbeats 800000
open Set Filter Complex
open scoped Topology
namespace OPICARightCellTaylor
open Zeta23.OPICAFollowup

def expMajorant (B : ℝ) : ℝ := ∑' m : ℕ, B ^ m / (m.factorial : ℝ)

theorem expMajorant_nonneg {B : ℝ} (hB : 0 ≤ B) : 0 ≤ expMajorant B :=
  tsum_nonneg (fun m => div_nonneg (pow_nonneg hB _) (Nat.cast_nonneg _))

def shPartial (w : ℂ) (u : ℝ) (n : ℕ) : ℂ :=
  ∑ j ∈ Finset.range (n + 1),
    w ^ j * (u : ℂ) ^ (2 * j + 1) / ((2 * j + 1).factorial : ℂ)

theorem shKernel_sub_partial (w : ℂ) (u : ℝ) (n : ℕ) :
    shKernel w u - shPartial w u n =
      ∑' m : ℕ, w ^ (m + (n + 1)) * (u : ℂ) ^ (2 * (m + (n + 1)) + 1) /
        ((2 * (m + (n + 1)) + 1).factorial : ℂ) := by
  have h := (summable_shKernel w u).sum_add_tsum_nat_add (n + 1)
  exact (eq_sub_iff_add_eq.mpr (by simpa [shKernel, shPartial, add_comm] using h)).symm

theorem shKernel_sub_partial_norm {B : ℝ} (hB : 0 ≤ B) {w : ℂ} (hw : ‖w‖ ≤ B)
    {u : ℝ} (hu : |u| ≤ 1) (n : ℕ) :
    ‖shKernel w u - shPartial w u n‖ ≤
      B ^ (n + 1) * |u| ^ (2 * n + 3) * expMajorant B := by
  rw [shKernel_sub_partial]
  have hs := (Real.summable_pow_div_factorial B).hasSum.mul_left
    (B ^ (n + 1) * |u| ^ (2 * n + 3))
  apply tsum_of_norm_bounded hs
  intro m
  rw [norm_div, norm_mul, norm_pow, norm_pow, Complex.norm_real,
    Real.norm_eq_abs, Complex.norm_natCast]
  have hp : |u| ^ (2 * m) ≤ 1 := pow_le_one₀ (abs_nonneg _) hu
  have hf : (m.factorial : ℝ) ≤ ((2 * (m + (n + 1)) + 1).factorial : ℝ) := by
    exact_mod_cast Nat.factorial_le (by omega : m ≤ 2 * (m + (n + 1)) + 1)
  have hn : 2 * (m + (n + 1)) + 1 = 2 * m + (2 * n + 3) := by omega
  have hwp : ‖w‖ ^ (m + (n + 1)) = ‖w‖ ^ m * ‖w‖ ^ (n + 1) := pow_add _ _ _
  have hup : |u| ^ (2 * (m + (n + 1)) + 1) = |u| ^ (2 * m) * |u| ^ (2 * n + 3) := by
    rw [hn, pow_add]
  rw [hwp, hup]
  calc
    ‖w‖ ^ m * ‖w‖ ^ (n + 1) * (|u| ^ (2 * m) * |u| ^ (2 * n + 3)) /
        ((2 * (m + (n + 1)) + 1).factorial : ℝ)
      ≤ B ^ m * B ^ (n + 1) * (1 * |u| ^ (2 * n + 3)) / (m.factorial : ℝ) := by
        gcongr
    _ = _ := by ring

#print axioms shKernel_sub_partial
#print axioms shKernel_sub_partial_norm
end OPICARightCellTaylor
