import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Topology.Order.Compact
import Mathlib.Tactic

noncomputable section
open Set Metric
namespace OPICAFixedBasisSupport

/-- Compactness supplies a constant for one fixed finite-dimensional space.
This generic supporting lemma asserts no uniformity over changing bases. -/
theorem fixed_space_positive_homogeneous_budget
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [FiniteDimensional ℝ E]
    (f : E → ℝ) (continuous_f : Continuous f)
    (positive : ∀ x : E, x ≠ 0 → 0 < f x)
    (homogeneous : ∀ (a : ℝ), 0 ≤ a → ∀ x : E, f (a • x) = a * f x) :
    ∃ c : ℝ, 0 < c ∧ ∀ x : E, c * ‖x‖ ≤ f x := by
  have f_zero : f 0 = 0 := by simpa using homogeneous 0 le_rfl (0 : E)
  rcases subsingleton_or_nontrivial E with hs | hn
  · letI := hs
    refine ⟨1, zero_lt_one, fun x => ?_⟩
    rw [Subsingleton.elim x 0, norm_zero, mul_zero, f_zero]
  · letI := hn
    obtain ⟨v, hv⟩ := exists_ne (0 : E)
    have nv : ‖v‖ ≠ 0 := norm_ne_zero_iff.mpr hv
    have unit_norm {x : E} (hx : x ≠ 0) : ‖(‖x‖⁻¹ : ℝ) • x‖ = 1 := by
      rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (inv_nonneg.mpr (norm_nonneg x))]
      exact inv_mul_cancel₀ (norm_ne_zero_iff.mpr hx)
    have nonempty_sphere : (sphere (0 : E) 1).Nonempty :=
      ⟨(‖v‖⁻¹ : ℝ) • v, by simpa only [mem_sphere, dist_zero_right] using unit_norm hv⟩
    obtain ⟨u, hu, hmin⟩ := (isCompact_sphere (0 : E) 1).exists_isMinOn
      nonempty_sphere continuous_f.continuousOn
    have nu : ‖u‖ = 1 := by simpa only [mem_sphere, dist_zero_right] using hu
    have une : u ≠ 0 := fun h => by simpa [h] using nu
    refine ⟨f u, positive u une, fun x => ?_⟩
    by_cases hx : x = 0
    · simp [hx, f_zero]
    · have hunit : (‖x‖⁻¹ : ℝ) • x ∈ sphere (0 : E) 1 := by
        simpa only [mem_sphere, dist_zero_right] using unit_norm hx
      have h := mul_le_mul_of_nonneg_right (hmin hunit) (norm_nonneg x)
      rw [homogeneous _ (inv_nonneg.mpr (norm_nonneg x)) x] at h
      simpa only [mul_assoc, mul_comm ‖x‖⁻¹ (f x), inv_mul_cancel₀ (norm_ne_zero_iff.mpr hx), mul_one] using h

#print axioms fixed_space_positive_homogeneous_budget
end OPICAFixedBasisSupport
