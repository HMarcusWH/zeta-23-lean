import NormalizedJetBlock

open OPICAAudit

-- EXPECTED REJECTION: at κ=0 multiplication on the one-dimensional local jet
-- block is the zero map, so the zero-node exclusion cannot be dropped.
example {K : Type*} [Field K] (a : ℕ → K) :
    (∀ k < 1, normalizedJetMul (0 : K) a k = 0) ↔ ∀ k < 1, a k = 0 :=
  normalizedJetMul_zero_iff (by simp) a
