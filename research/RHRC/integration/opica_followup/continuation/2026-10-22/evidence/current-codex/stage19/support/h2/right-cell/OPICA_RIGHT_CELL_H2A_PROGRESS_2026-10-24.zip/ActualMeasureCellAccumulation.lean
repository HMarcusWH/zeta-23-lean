import ActualMeasureCellAE
import ActualFirstCell

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform

namespace OPICAActualMeasureCell
open Zeta23.OPICAFollowup

/-- Actual first-cell density vanishing almost everywhere supplies
arbitrarily small positive logarithmic parameters at which the exact
analytic right-cell jet combination vanishes. No continuity or change of
variables theorem for a.e. sets is needed. -/
theorem first_cell_ae_zero_gives_accumulating_right_cell_zeros
    {ι : Type*} [Fintype ι] (c : ι → ℂ) (κ : ι → ℂ) (k : ι → ℕ)
    (hAE : ∀ᵐ x : ℝ, x ∈ Ioo (1 : ℝ) 2 →
      (∑ i, c i * zeroJetDensity (κ i) (k i) x) = 0)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ u : ℝ, 0 < u ∧ u < ε ∧ u < Real.log 2 ∧
      (∑ i, c i * (iteratedDeriv (k i)
        (fun w : ℂ => w * shKernel (1 / 4 - w) u) (κ i) /
          ((k i).factorial : ℂ))) = 0 := by
  let δ : ℝ := min ε (Real.log 2)
  have hlog : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hδ : 0 < δ := lt_min hε hlog
  have hb : 1 < Real.exp δ := Real.one_lt_exp_iff.mpr hδ
  have hb2 : Real.exp δ ≤ 2 := by
    calc Real.exp δ ≤ Real.exp (Real.log 2) := Real.exp_le_exp.mpr (min_le_right _ _)
      _ = 2 := Real.exp_log (by norm_num)
  have hm : volume (Ioo (1 : ℝ) (Real.exp δ)) ≠ 0 := by
    rw [Real.volume_Ioo]
    exact ENNReal.ofReal_ne_zero_iff.mpr (by linarith)
  obtain ⟨x, hx, hz⟩ := Measure.exists_mem_of_measure_ne_zero_of_ae hm (ae_restrict_of_ae hAE)
  have hx0 : 0 < x := by linarith [hx.1]
  have hxcell : x ∈ Ioo (1 : ℝ) 2 := ⟨hx.1, hx.2.trans_le hb2⟩
  have hu0 : 0 < Real.log x := Real.log_pos hx.1
  have huδ : Real.log x < δ := (Real.log_lt_iff_lt_exp hx0).mpr hx.2
  have huε : Real.log x < ε := huδ.trans_le (min_le_left _ _)
  have hu2 : Real.log x < Real.log 2 := huδ.trans_le (min_le_right _ _)
  refine ⟨Real.log x, hu0, huε, hu2, ?_⟩
  calc
    (∑ i, c i * (iteratedDeriv (k i)
        (fun w : ℂ => w * shKernel (1 / 4 - w) (Real.log x)) (κ i) /
          ((k i).factorial : ℂ))) =
      (Real.exp (Real.log x / 2) : ℂ) *
        (∑ i, c i * zeroJetDensity (κ i) (k i) (Real.exp (Real.log x))) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i _
      rw [← OPICAActualFirstCellAudit.actual_normalized_jet_first_log_cell
        (κ i) (k i) hu0.le hu2]
      ring
    _ = 0 := by rw [Real.exp_log hx0, hz hxcell, mul_zero]

#print axioms first_cell_ae_zero_gives_accumulating_right_cell_zeros

end OPICAActualMeasureCell
