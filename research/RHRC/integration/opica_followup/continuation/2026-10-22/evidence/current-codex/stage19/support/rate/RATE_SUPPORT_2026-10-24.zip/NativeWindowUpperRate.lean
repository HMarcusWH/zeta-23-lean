import RateSourceCosts
import RateWindowBounds

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23.OPICA
namespace Zeta23.OPICAFollowup.Stage19Rate.Asymptotic

theorem windowStart_eventually_nonneg (C : ℝ) :
    ∀ᶠ T : ℝ in atTop, 1 ≤ T ∧ 0 ≤ T-C*Real.log T := by
  have hl : Tendsto (fun T : ℝ => Real.log T/T) atTop (𝓝 0) := by
    simpa using Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 (by norm_num)
  have hs : ∀ᶠ T : ℝ in atTop, C*(Real.log T/T)<1 :=
    (tendsto_order.1 (hl.const_mul C)).2 1 (by norm_num)
  filter_upwards [hs,eventually_ge_atTop (1 : ℝ)] with T hs hT
  refine ⟨hT,?_⟩
  have hTp : 0 < T := by linarith
  have hCT : C*Real.log T<T := by
    rw [←mul_div_assoc] at hs
    simpa only [one_mul] using (div_lt_iff₀ hTp).mp hs
  linarith

theorem nativeWindowLogRate_upper_bound (d : ℕ) {C T : ℝ} (hC : 0 ≤ C)
    (hT : 1 ≤ T) (hstart : 0 ≤ T-C*Real.log T) :
    nativeWindowLogRate d C T ≤ nativeZeroDisplacementSup+
      (Real.log (1+C)+Real.log T+2*Real.log (1+nativeFieldOrderConstant d))/(2*T) := by
  obtain ⟨A,hA,hEnv⟩ := native_field_theta_envelope
  let K := nativeFieldOrderConstant d
  let L := C*Real.log T
  let B := 2*nativeZeroDisplacementSup*T
  have hK : 0 < K := (hEnv d).1
  have hL : 0 ≤ L := mul_nonneg hC (Real.log_nonneg hT)
  have hTp : 0 < T := by linarith
  have hB : 0 ≤ B := by
    dsimp [B]
    positivity [native_zero_sup_bounds.1]
  have he : 1 ≤ Real.exp B := Real.one_le_exp hB
  have hEnergy := nativeWindowEnergy_upper d hC hT hstart
  have hFactor : 1+nativeWindowEnergy d C T ≤ Real.exp B*((1+L)*(1+K)^2) := by
    have h1 : 1+nativeWindowEnergy d C T ≤ Real.exp B*(1+L*K^2) := by
      dsimp [B,L,K] at *
      nlinarith
    have h2 : 1+L*K^2 ≤ (1+L)*(1+K)^2 := by
      nlinarith [mul_nonneg hL hK.le,sq_nonneg K]
    exact h1.trans (mul_le_mul_of_nonneg_left h2 (Real.exp_nonneg _))
  have hLog := Real.log_le_log (by linarith [nativeWindowEnergy_nonneg d C T]) hFactor
  rw [Real.log_mul (Real.exp_ne_zero _) (by positivity),Real.log_exp,
    Real.log_mul (by positivity) (by positivity),Real.log_pow] at hLog
  have hLogT : Real.log T ≤ T := (Real.log_le_sub_one_of_pos hTp).trans (by linarith)
  have hSpan : 1+L ≤ (1+C)*T := by
    dsimp [L]
    nlinarith [mul_nonneg hC (sub_nonneg.mpr hLogT)]
  have hLogSpan := Real.log_le_log (by positivity : 0 < 1+L) hSpan
  rw [Real.log_mul (by positivity) hTp.ne'] at hLogSpan
  have hAll : Real.log (1+nativeWindowEnergy d C T) ≤
      2*nativeZeroDisplacementSup*T+Real.log (1+C)+Real.log T+2*Real.log (1+nativeFieldOrderConstant d) := by
    dsimp [B,K] at hLog
    norm_num only [Nat.cast_ofNat] at hLog
    linarith
  unfold nativeWindowLogRate
  calc
    _ ≤ (2*nativeZeroDisplacementSup*T+Real.log (1+C)+Real.log T+
        2*Real.log (1+nativeFieldOrderConstant d))/(2*T) :=
      div_le_div_of_nonneg_right hAll (by positivity)
    _ = _ := by field_simp; ring

theorem slowSource_upper_error_tendsto_zero (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0)) (C : ℝ) :
    Tendsto (fun n => (Real.log (1+C)+Real.log (T.time n)+
      2*Real.log (1+nativeFieldOrderConstant (d n)))/(2*T.time n)) atTop (𝓝 0) := by
  have hc : Tendsto (fun n => Real.log (1+C)/T.time n) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop T.cofinal
  have hl : Tendsto (fun n => Real.log (T.time n)/T.time n) atTop (𝓝 0) := by
    have h : Tendsto (fun t : ℝ => Real.log t/t) atTop (𝓝 0) := by
      simpa using Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 (by norm_num)
    exact h.comp T.cofinal
  have hk := fieldEnvelope_log_div_time_tendsto_zero T d hd
  have h := ((hc.add hl).add (hk.const_mul 2)).div_const 2
  convert h using 1
  · ext n; ring
  · norm_num

theorem slowSource_window_rate_eventually_lt_theta_add
    (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    {C epsilon : ℝ} (hC : 0 ≤ C) (hepsilon : 0 < epsilon) :
    ∀ᶠ n : ℕ in atTop, nativeWindowLogRate (d n) C (T.time n) < nativeZeroDisplacementSup+epsilon := by
  have hs := T.cofinal.eventually (windowStart_eventually_nonneg C)
  have he := (tendsto_order.1 (slowSource_upper_error_tendsto_zero T d hd C)).2 epsilon hepsilon
  filter_upwards [hs,he] with n hs he
  exact (nativeWindowLogRate_upper_bound (d n) hC hs.1 hs.2).trans_lt (by linarith)

theorem slowSource_window_rate_tendsto_zero_of_theta_zero
    (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    {C : ℝ} (hC : 0 ≤ C) (hTheta : nativeZeroDisplacementSup = 0) :
    Tendsto (fun n => nativeWindowLogRate (d n) C (T.time n)) atTop (𝓝 0) := by
  apply squeeze_zero' (Eventually.of_forall fun n => nativeWindowLogRate_nonneg (d n) C (T.time n) (T.positive n)) _
    (slowSource_upper_error_tendsto_zero T d hd C)
  filter_upwards [T.cofinal.eventually (windowStart_eventually_nonneg C)] with n hn
  simpa only [hTheta,zero_add] using nativeWindowLogRate_upper_bound (d n) hC hn.1 hn.2

#print axioms windowStart_eventually_nonneg
#print axioms nativeWindowLogRate_upper_bound
#print axioms slowSource_upper_error_tendsto_zero
#print axioms slowSource_window_rate_eventually_lt_theta_add
#print axioms slowSource_window_rate_tendsto_zero_of_theta_zero
end Zeta23.OPICAFollowup.Stage19Rate.Asymptotic
