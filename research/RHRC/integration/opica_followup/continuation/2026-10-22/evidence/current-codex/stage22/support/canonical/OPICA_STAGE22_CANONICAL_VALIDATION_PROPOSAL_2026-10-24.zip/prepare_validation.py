"""Prepare source copies only. Compiler and independent domain review remain separate."""
from pathlib import Path
import json, re, hashlib
from inventory import REPO, BASE, HERE, roots, manifest, paths

span_extra_files=['ExpectedFullFiniteSpanFinal.lean','ExpectedActualFixedBudgetFinal.lean','ExpectedSpanPhysicalConsumerFinal.lean']
for name in span_extra_files:
    if (HERE.parent/'audit-finite-span'/name).exists():paths.append('../audit-finite-span/'+name)
sources={p:(REPO/p).read_text(encoding='utf-8') for p in paths}
for path in list(sources):
    if path.startswith('../audit-finite-span/'):
        sources[path]=sources[path].replace('import FiniteSpanSeparationFullCandidate','import Zeta23.OPICAFollowup.FiniteSpanSeparation').replace('import ConsumersSpanFullCandidate','import Zeta23.OPICAFollowup.Consumers')
for path in list(sources):
    compatible=HERE/'overlay'/path
    if path.endswith('/consumers/ExpectedConfluentProfiles.lean') and compatible.exists():
        sources[path]=compatible.read_text(encoding='utf-8')
override_path=HERE/'FullClauseOverrides.lean'
override_text=override_path.read_text(encoding='utf-8')
weighted_override=HERE/'FullWeightedClauseOverrides.lean'
if weighted_override.exists():override_text+='\nend\n'+weighted_override.read_text(encoding='utf-8')
signature_companions=HERE/'FullSignatureCompanions.lean'
if signature_companions.exists():override_text+='\nend\n'+signature_companions.read_text(encoding='utf-8')
canonical_interfaces=HERE/'ExpectedCanonicalInterfaces.lean'
if canonical_interfaces.exists():override_text+='\nend\n'+canonical_interfaces.read_text(encoding='utf-8')
override_names=set(re.findall(r'(?m)^theorem\s+(\w+)',override_text))
legacy_path='Zeta23/OPICAFollowup/Validation.lean'
legacy_text=sources[legacy_path]
# Preserve the old canonical and parent-namespace expected declarations.
# The nine foreign continuation helpers are explicitly relocated for the full parser.
legacy_text=legacy_text.replace('namespace OPICAContinuationChecks','namespace Zeta23.OPICAFollowup.Validation').replace('end OPICAContinuationChecks','end Zeta23.OPICAFollowup.Validation').replace('OPICAContinuationChecks.','Zeta23.OPICAFollowup.Validation.')
current_namespace='';preserved_canonical=set()
for line in legacy_text.splitlines():
    m=re.match(r'^namespace\s+(\S+)',line)
    if m:current_namespace=m[1]
    if re.match(r'^end\s+',line):current_namespace=''
    m=re.match(r'^\s*(?:theorem|lemma|def|abbrev)\s+(\w+)',line)
    if m and current_namespace=='Zeta23.OPICAFollowup.Validation':preserved_canonical.add(m[1])
declaration=re.compile(r'(?m)^[ \t]*(?:(?:noncomputable|private|protected)\s+)*(theorem|lemma|def|abbrev|example)\b(?:\s+(\w+))?')
items=[]
for path, text in sources.items():
    ms=list(declaration.finditer(text))
    for i,m in enumerate(ms):
        # An example has no declared name; any following token is part of its type.
        name=m[2] if m[1]!='example' else None
        end=ms[i+1].start() if i+1<len(ms) else len(text)
        block=text[m.start():end]
        # Remove trailing commands/comments from root-use matching, not copied source.
        block=re.split(r'(?m)^(?:#print|end\b|namespace\b|open\b|section\b|noncomputable section\b)',block)[0]
        uses=[r['full_name'] for r in roots if re.search(r'\b'+re.escape(r['full_name'].split('.')[-1])+r'\b',block)]
        items.append({'path':path,'start':m.start(),'line':text.count('\n',0,m.start())+1,'kind':m[1],'name':name,'uses':uses,'text':block})

chosen={}
mapping=[]
for root in roots:
    exact=[it for it in items if it['name']==root['expected_type_consumer']]
    direct=[it for it in items if root['full_name'] in it['uses']]
    # Exact expected signatures take precedence; otherwise prefer an explicit
    # consumer whose proof directly names the root, retaining original source.
    candidates=exact or direct
    if candidates:
        # Full rate consumers precede their specializations in source.
        pick=min(candidates,key=lambda it:(len(it['uses']),it['path'].endswith('Validation.lean') is False,it['line']))
        # One source theorem cannot be renamed to two independently required consumers.
        key=(pick['path'],pick['start'])
        if key in chosen: pick=None
        if pick and root['expected_type_consumer'] not in preserved_canonical|override_names:
            chosen[key]=root['expected_type_consumer']
    else: pick=None
    mapping.append({'root':root['full_name'],'required_expected_name':root['expected_type_consumer'],'selected':{k:pick[k] for k in ('path','line','kind','name','uses')} if pick else None,'status':'MECHANICAL_EXPLICIT_SOURCE_PROPOSAL_DOMAIN_REVIEW_REQUIRED' if pick else 'NO_CANDIDATE_DO_NOT_ADD_PLACEHOLDER'})
    if root['expected_type_consumer'] in override_names:
        mapping[-1]['selected']={'path':str(override_path),'name':root['expected_type_consumer'],'kind':'theorem','line':override_text[:override_text.index('theorem '+root['expected_type_consumer'])].count('\n')+1,'uses':[root['full_name']]}
        mapping[-1]['status']='EXPLICIT_FULL_COMPOUND_OVERRIDE_COMPILER_AND_DOMAIN_REVIEW_REQUIRED'

imports=set()
pieces=[]
imports.update(re.findall(r'(?m)^import\s+([A-Za-z0-9_.]+)',legacy_text))
legacy_text=re.sub(r'(?m)^import\s+[^\n]+\n','',legacy_text)
legacy_opens=len(re.findall(r'(?m)^(?:namespace\s|(?:noncomputable\s+)?section\b)',legacy_text))
legacy_closes=len(re.findall(r'(?m)^end\b',legacy_text))
pieces.append('/- PRESERVED LEGACY VALIDATION; only foreign continuation helper namespace relocated. -/\nsection\n'+legacy_text+'\n'+'end\n'*(legacy_opens-legacy_closes+1))
for ix,(path,text) in enumerate(sources.items()):
    imports.update(re.findall(r'(?m)^import\s+([A-Za-z0-9_.]+)',text))
    stem='FullAudit'+str(ix)+'_'
    replacements={}
    for it in items:
        if it['path']!=path or not it['name']: continue
        replacements[it['name']]=chosen.get((path,it['start']),stem+it['name'])
    # Rename every anonymous example, including chosen full-contract candidates.
    edits=[]
    for it in items:
        if it['path']!=path or it['kind']!='example': continue
        name=chosen.get((path,it['start']),stem+'example_'+str(it['line']))
        start=text.index('example',it['start'])
        edits.append((start,start+len('example'),'theorem '+name))
    for start,end,value in reversed(edits): text=text[:start]+value+text[end:]
    text=re.sub(r'(?m)^import\s+[^\n]+\n','',text)
    # Relocation into an ancestor of Zeta23 exposes its older conditional
    # riemannZeta_conj. Preserve the original consumers' global Mathlib identity.
    if path.endswith('/consumers/ExpectedNativeResolvent.lean') or path.endswith('/consumers/ExpectedSamplingCompatibility.lean'):
        text=text.replace('[riemannZeta_conj, hz, map_zero]','[_root_.riemannZeta_conj, hz, map_zero]')
    # Relocate only explicit top-level namespaces; no theorem contracts are changed.
    namespaces=re.findall(r'(?m)^namespace\s+([^\s]+)',text)
    for ns in sorted(set(namespaces),key=len,reverse=True):
        text=re.sub(r'(?m)^(namespace|end)\s+'+re.escape(ns)+r'\s*$',r'\1 Zeta23.OPICAFollowup.Validation',text)
        if ns not in ('Zeta23.OPICAFollowup','Zeta23.OPICAFollowup.Validation'):
            text=text.replace(ns+'.','Zeta23.OPICAFollowup.Validation.')
    if replacements:
        text=re.sub(r'\b(?:'+ '|'.join(map(re.escape,sorted(replacements,key=len,reverse=True)))+r')\b',lambda m:replacements[m[0]],text)
    # Axioms are requested only after checking actual final qualified names.
    text=re.sub(r'(?m)^#print axioms[^\n]*\n?','',text)
    opens=len(re.findall(r'(?m)^(?:namespace\s|(?:noncomputable\s+)?section\b)',text))
    closes=len(re.findall(r'(?m)^end\b',text))
    assert opens>=closes,(path,opens,closes)
    pieces.append('/- SOURCE COPY: '+path+'; SHA256 '+hashlib.sha256((REPO/path).read_bytes()).hexdigest()+' -/\nsection\n'+text+'\n'+'end\n'*(opens-closes+1))

imports.update(re.findall(r'(?m)^import\s+([A-Za-z0-9_.]+)',override_text))
override_text=re.sub(r'(?m)^import\s+[^\n]+\n','',override_text)
override_text=re.sub(r'(?m)^#print axioms[^\n]*\n?','',override_text)
override_opens=len(re.findall(r'(?m)^(?:namespace\s|(?:noncomputable\s+)?section\b)',override_text))
override_closes=len(re.findall(r'(?m)^end\b',override_text))
pieces.append('section\n'+override_text+'\n'+'end\n'*(override_opens-override_closes+1))
header='\n'.join('import '+n for n in sorted(imports))+'\n\n/-! UNACCEPTED explicit consumer assembly proposal. This is mechanically relocated\nsource, not independent review, a full compiler receipt, or release authority.\nNo placeholder is inserted for an absent original root. RH and Step4 remain OPEN. -/\n\nset_option maxHeartbeats 800000\n\n'
expected=[r['required_expected_name'] for r in mapping if r['selected']]
prints='\n'.join('#print axioms Zeta23.OPICAFollowup.Validation.'+n for n in expected)+'\n'
prints+='\n'.join('#print axioms Zeta23.OPICAFollowup.Validation.'+n for n in sorted(override_names) if n.endswith('_full_signature'))+'\n'
prints+='\n'.join('#print axioms Zeta23.OPICAFollowup.Validation.'+n for n in sorted(override_names) if n in {'expected_canonical_recovery','expected_filter_causal_actions','expected_followup_native_output','expected_followup_native_output_each_phase'})+'\n'
(HERE/'ValidationProposal.lean').write_text(header+'\n'.join(pieces)+prints,encoding='utf-8')
(HERE/'overlay/Zeta23/OPICAFollowup/Validation.lean').write_text(header+'\n'.join(pieces)+prints,encoding='utf-8')
facade_imports=[m['module'] for m in manifest['modules'] if m['trust_zone']!='AUDIT_ONLY' and m['module']!='Zeta23.OPICAFollowup']
facade='\n'.join('import '+n for n in facade_imports)+'\n\n/-! All original mathematical modules. Compiler validity does not establish full release or RH. -/\n'
(HERE/'OPICAFollowupFacadeProposal.lean').write_text(facade,encoding='utf-8')
(HERE/'overlay/Zeta23/OPICAFollowup.lean').write_text(facade,encoding='utf-8')
(HERE/'consumer-proposal-map.json').write_text(json.dumps({'status':'UNACCEPTED_MECHANICAL_PROPOSAL','covered':len(expected),'missing':[r['root'] for r in mapping if not r['selected']],'roots':mapping,'source_note':'Every candidate needs exact compiler and original-clause/domain review; root use alone is insufficient.'},indent=2)+'\n',encoding='utf-8')
clause_rows=[]
for frozen,row in zip(roots,mapping):
    selected=row['selected']
    it=next((i for i in items if selected and i['path']==selected['path'] and i['line']==selected['line']),None)
    short=frozen['full_name'].split('.')[-1]
    projection=bool(it and re.search(r'\b'+re.escape(short)+r'\.[12]',it['text']))
    clause_rows.append({'root':frozen['full_name'],'statement_contract':frozen['statement_contract'],
        'required_premises':frozen['required_premises'],'not_accepted_as_replacement':frozen['not_accepted_as_replacement'],
        'candidate':selected,'direct_projection_warning':projection,
        'full_frozen_clause_review':'OPEN_INDEPENDENT_REVIEW_NOT_ESTABLISHED',
        'instruction':'Compare every conjunct, quantifier order, bounds, actual constructors and domains. A proper subcase/projection never suffices as the full expected-type consumer.'})
(HERE/'full-clause-review-input.json').write_text(json.dumps({'schema':'OPICA_FULL100_UNACCEPTED_CLAUSE_REVIEW_INPUT_V1','status':'REVIEW_INPUT_NOT_APPROVAL','roots':clause_rows},indent=2)+'\n',encoding='utf-8')
print('proposal covered',len(expected),'missing',[r['root'] for r in mapping if not r['selected']])
