from pathlib import Path
P=Path(__file__).resolve().parent
def body(name):
    lines=(P/name).read_text(encoding='utf-8').splitlines()
    skip=('import ','noncomputable section','open ','open scoped ','namespace ','end Zeta23.','#print axioms ')
    return '\n'.join(x for x in lines if not x.startswith(skip)).strip()+'\n'
header='''import Zeta23.OPICAFollowup.ConfluentProfiles
import Zeta23.OPICA.SignedHeatSeparator

/-! Actual finite realified zero-jet measures and their sharp-gap restriction.
The original R2-H2b domain is finite combinations of the actual normalized
jets below each actual zero multiplicity. No measure status, growth, gap,
self-duality, positivity conclusion or independent-coefficient conclusion
is assumed in a packet. The independent real-basis clause quantifies actual
basis vectors in this span and retains independence explicitly. -/
noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform ENNReal NNReal

namespace Zeta23.OPICAFollowup.FiniteSpan
open Zeta23.OPICA

'''
contents=header+'\n'.join(body(x) for x in ['FiniteSpanScratch.lean','FiniteSpanCoefficients.lean','FiniteSpanCompact.lean','FiniteSpanCombination.lean'])
contents=contents.replace('FiniteSpanScratch','FiniteSpan')
contents+='''
end Zeta23.OPICAFollowup.FiniteSpan

namespace Zeta23.OPICAFollowup
open Zeta23.OPICA FiniteSpan

/-- The actual canonical real Jordan carrier of a finite normalized zero-jet sum. -/
abbrev zeroJetRealSpan := FiniteSpan.zeroJetRealSpan

/-- Original R2-H2b, both clauses: every finite actual realified zero-jet
combination that is nonnegative off the integer lattice is the zero Jordan
measure, and its coordinates on any fixed independent real basis vanish. -/
theorem finite_zero_span_positive_only_zero :
    (∀ data : List JetDatum, ∀ h : ∀ j ∈ data, ValidJet j,
      (zeroJetRealSpan data).OffLatticeNonnegative →
        (zeroJetRealSpan data).positive = 0 ∧ (zeroJetRealSpan data).negative = 0) ∧
    (∀ n : ℕ, ∀ basis : Fin n → List JetDatum,
      ∀ h : ∀ i, ∀ j ∈ basis i, ValidJet j,
      LinearIndependent ℝ (fun i => (zeroJetRealSpan (basis i)).distributionOfLinearGrowth
        (zeroJetRealSpan_growth _ (h i))) →
      ∀ a : Fin n → ℝ,
      (zeroJetRealSpan (realBasisCombinationData basis a)).OffLatticeNonnegative → a = 0) := by
  exact ⟨FiniteSpan.finite_zero_span_positive_only_zero,
    fun _ basis h hind a hoff => independent_real_span_basis_coefficients_zero basis h hind a hoff⟩

end Zeta23.OPICAFollowup
#print axioms Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero
'''
(P/'FiniteSpanSeparationCandidate.lean').write_text(contents,encoding='utf-8')
consumer='''import FiniteSpanSeparationCandidate

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform
namespace Zeta23.OPICAFollowup
open Zeta23.OPICA FiniteSpan

'''+body('ActualZeroMeasureSpanConsumer.lean').replace('FiniteSpanScratch','FiniteSpan')+'''
end Zeta23.OPICAFollowup
#print axioms Zeta23.OPICAFollowup.actual_zero_measure_span_consumer
'''
# Explicitly use the internal Jordan clause rather than the full conjunction root.
consumer=consumer.replace('finite_zero_span_positive_only_zero data h','FiniteSpan.finite_zero_span_positive_only_zero data h')
(P/'ConsumersSpanCandidate.lean').write_text(consumer,encoding='utf-8')
print('Assembled complete root and physical consumer candidates, original import DAG.')
