import FiniteSpanScratch

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform

namespace Zeta23.OPICAFollowup.FiniteSpanScratch
open Zeta23.OPICA

def scaleJetData (a : ℝ) (data : List JetDatum) : List JetDatum :=
  data.map (fun j => ((a : ℂ) * j.1, j.2.1, j.2.2))

def realBasisCombinationData {n : ℕ} (basis : Fin n → List JetDatum)
    (a : Fin n → ℝ) : List JetDatum :=
  (List.ofFn (fun i => scaleJetData (a i) (basis i))).flatten

lemma realBasisCombination_valid {n : ℕ} (basis : Fin n → List JetDatum)
    (h : ∀ i, ∀ j ∈ basis i, ValidJet j) (a : Fin n → ℝ) :
    ∀ j ∈ realBasisCombinationData basis a, ValidJet j := by
  intro j hj
  obtain ⟨l,hl,hj⟩ := List.mem_flatten.mp hj
  obtain ⟨i,rfl⟩ := List.mem_ofFn.mp hl
  obtain ⟨z,hz,rfl⟩ := List.mem_map.mp hj
  exact h i z hz

lemma zeroComplex_compactRestriction (K : Set ℝ) (hK : IsCompact K) :
    zeroComplex.compactRestriction K hK = 0 := by
  ext E hE
  apply Complex.ext <;> simp [LocallyFiniteComplexMeasure.compactRestriction, zeroComplex, zeroJordan,
    localSignedCompactRestriction, SignedMeasure.toComplexMeasure_apply]

lemma actualZeroJetSum_append_compactRestriction (data rest : List JetDatum)
    (K : Set ℝ) (hK : IsCompact K) :
    (actualZeroJetSum (data ++ rest)).compactRestriction K hK =
      (actualZeroJetSum data).compactRestriction K hK +
        (actualZeroJetSum rest).compactRestriction K hK := by
  induction data with
  | nil => simp [actualZeroJetSum, zeroComplex_compactRestriction]
  | cons j data ih =>
    simp only [List.cons_append, actualZeroJetSum,
      LocallyFiniteComplexMeasure.compactRestriction_add]
    rw [ih, add_assoc]

lemma actualZeroJetSum_scale_compactRestriction (a : ℝ) (data : List JetDatum)
    (K : Set ℝ) (hK : IsCompact K) :
    (actualZeroJetSum (scaleJetData a data)).compactRestriction K hK =
      (a : ℂ) • (actualZeroJetSum data).compactRestriction K hK := by
  induction data with
  | nil =>
    rw [scaleJetData, List.map_nil, actualZeroJetSum, zeroComplex_compactRestriction]
    ext E hE
    change (0 : ℂ) = (a : ℂ) * 0
    simp
  | cons j data ih =>
    simp only [scaleJetData, List.map_cons, actualZeroJetSum,
      LocallyFiniteComplexMeasure.compactRestriction_add,
      LocallyFiniteComplexMeasure.compactRestriction_scale]
    rw [←scaleJetData, ih, smul_add, smul_smul]

lemma actualZeroJetSum_flatten_compactRestriction (data : List (List JetDatum))
    (K : Set ℝ) (hK : IsCompact K) :
    (actualZeroJetSum data.flatten).compactRestriction K hK =
      (data.map (fun row => (actualZeroJetSum row).compactRestriction K hK)).sum := by
  induction data with
  | nil => simp [actualZeroJetSum, zeroComplex_compactRestriction]
  | cons row data ih =>
    simp only [List.flatten_cons, actualZeroJetSum_append_compactRestriction,
      List.map_cons, List.sum_cons]
    rw [ih]

lemma realBasisCombination_complexCompactRestriction {n : ℕ}
    (basis : Fin n → List JetDatum) (a : Fin n → ℝ) (K : Set ℝ) (hK : IsCompact K) :
    (actualZeroJetSum (realBasisCombinationData basis a)).compactRestriction K hK =
      ∑ i, (a i : ℂ) • (actualZeroJetSum (basis i)).compactRestriction K hK := by
  simp only [realBasisCombinationData, actualZeroJetSum_flatten_compactRestriction,
    List.map_ofFn, List.sum_ofFn, Function.comp_apply, actualZeroJetSum_scale_compactRestriction]

lemma re_complex_smul_real (a : ℝ) (μ : ComplexMeasure ℝ) :
    ComplexMeasure.re ((a : ℂ) • μ) = a • ComplexMeasure.re μ := by
  ext E hE
  change ((a : ℂ) * μ E).re = a * (μ E).re
  simp

lemma realBasisCombination_compactRestriction {n : ℕ}
    (basis : Fin n → List JetDatum) (a : Fin n → ℝ) (K : Set ℝ) (hK : IsCompact K) :
    localSignedCompactRestriction (zeroJetRealSpan (realBasisCombinationData basis a)) K hK =
      ∑ i, a i • localSignedCompactRestriction (zeroJetRealSpan (basis i)) K hK := by
  have hc := realBasisCombination_complexCompactRestriction basis a K hK
  have hr := congrArg ComplexMeasure.re hc
  simpa only [map_sum, re_complex_smul_real,
    LocallyFiniteComplexMeasure.compactRestriction_re, zeroJetRealSpan] using hr

end Zeta23.OPICAFollowup.FiniteSpanScratch
