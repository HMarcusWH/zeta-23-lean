from pathlib import Path
import json,hashlib,shutil,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
OVERLAY=HERE/'overlay'
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
assert head=='139c1a0d88cc0fb2d8a0d8ea71e152b25b14c36e',head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).strip(),'owner must remain at clean Stage21 source pin'
shutil.copytree(REPO/'.lake/build/lib/lean/Zeta23',OVERLAY/'Zeta23',dirs_exist_ok=True)
rows=[]
for module,proposal in [('NativeFilters','CanonicalFilterActionsProposal.lean'),('JointObservation','CanonicalRecoveryProposal.lean'),('Consumers','FollowupNativeOutputProposal.lean')]:
    relative='Zeta23/OPICAFollowup/'+module+'.lean'
    old=(REPO/relative).read_bytes()
    content=(HERE/proposal).read_bytes()
    body=content.split(b'\n',1)[1] # Only the standalone self-import is omitted.
    new=old+b'\n'+body
    target=OVERLAY/relative;target.write_bytes(new)
    rows.append({'path':relative,'base_source_sha256':sha(old),'proposal_fragment':proposal,'fragment_sha256':sha(content),'assembled_sha256':sha(new)})
for relative in ['Zeta23/OPICAFollowup.lean','Zeta23/OPICAFollowup/FiniteSpanSeparation.lean','Zeta23/OPICAFollowup/ConfluentProfiles.lean','Zeta23/OPICAFollowup/SquareDefect.lean']:
    target=OVERLAY/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((REPO/relative).read_bytes())
(HERE/'stage22-overlay-provenance.json').write_text(json.dumps({'schema':'OPICA_STAGE22_CANONICAL_OVERLAY_PROPOSAL_V1','base_head':head,'base_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO,text=True).strip(),'status':'SOURCE_ASSEMBLED_COMPILER_REPLAY_PENDING','preserved_old_mathematical_source_bytes':True,'assembly':rows,'independent_review':'NOT_ESTABLISHED','RH':'OPEN','Step4':'OPEN'},indent=2)+'\n',encoding='utf-8')
print('assembled canonical7 bodies against clean',head)
