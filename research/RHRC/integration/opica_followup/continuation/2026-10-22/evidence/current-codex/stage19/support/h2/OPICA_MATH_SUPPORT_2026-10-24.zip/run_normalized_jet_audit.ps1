$ErrorActionPreference = 'Stop'
$opicaAuditRepo = Join-Path $PSScriptRoot '../opica-followup-repo'
$opicaAuditLean = 'C:/Users/macka/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean.exe'
$opicaAuditPaths = @(Get-ChildItem "$opicaAuditRepo/.lake/packages" -Directory | ForEach-Object { Join-Path $_.FullName '.lake/build/lib/lean' })
$opicaAuditPaths += Join-Path $opicaAuditRepo '.lake/build/lib/lean'
$opicaAuditPaths += $PSScriptRoot
$env:LEAN_PATH = $opicaAuditPaths -join ';'
Push-Location $PSScriptRoot
try {
  $opicaAuditResults = @()
  foreach ($opicaAuditName in @('NormalizedJetBlock', 'ExpectedNormalizedJetBlock', 'NegativeZeroNode')) {
    $opicaAuditArgs = @('-o', "$opicaAuditName.olean", "$opicaAuditName.lean")
    & $opicaAuditLean @opicaAuditArgs *> "$opicaAuditName.log"
    $opicaAuditCode = $LASTEXITCODE
    $opicaAuditResults += [ordered]@{
      source = "$opicaAuditName.lean"
      source_sha256 = (Get-FileHash "$opicaAuditName.lean" -Algorithm SHA256).Hash.ToLower()
      compiler = $opicaAuditLean
      arguments = $opicaAuditArgs
      exit_code = $opicaAuditCode
      expected_disposition = $(if ($opicaAuditName -eq 'NegativeZeroNode') { 'REJECT' } else { 'PASS' })
      log = "$opicaAuditName.log"
      log_sha256 = (Get-FileHash "$opicaAuditName.log" -Algorithm SHA256).Hash.ToLower()
    }
  }
  [ordered]@{
    schema = 'OPICA_SCRATCH_SUPPORT_ONLY_V1'
    date_utc = [DateTime]::UtcNow.ToString('o')
    repository_head = (& git -C $opicaAuditRepo rev-parse HEAD)
    repository_committed_tree = (& git -C $opicaAuditRepo rev-parse 'HEAD^{tree}')
    compiler_version = (& $opicaAuditLean --version)
    results = $opicaAuditResults
    primary_root_authority = 'NONE; neither H2a original root is promoted'
  } | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 normalized-jet-receipt.json
  Get-Content normalized-jet-receipt.json
} finally {
  Pop-Location
}
