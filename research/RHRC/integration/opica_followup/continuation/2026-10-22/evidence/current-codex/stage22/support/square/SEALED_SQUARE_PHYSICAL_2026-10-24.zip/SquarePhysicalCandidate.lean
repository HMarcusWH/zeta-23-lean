import PinnedSquareDefect

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology FourierTransform SchwartzMap
open scoped NNReal ENNReal
namespace Zeta23.OPICAFollowup
open Zeta23.OPICA

/-- The genuine positive density and negative punctured comb of the nonlinear square.
Their singularity makes these its canonical Jordan parts, without global finiteness. -/
def squareGapJordan (h : ℝ → ℂ) (A : ℂ) (hcont : Continuous h) :
    LocallyFiniteSignedMeasure where
  positive := volume.withDensity (fun x => ENNReal.ofReal (‖A-h x‖^2))
  negative := ENNReal.ofReal (‖A‖^2) • puncturedLattice
  positive_locallyFinite := isLocallyFinite_withDensity_ofReal
    ((continuous_const.sub hcont).norm.pow 2).locallyIntegrable
  negative_locallyFinite := by
    have : IsFiniteMeasureOnCompacts (ENNReal.ofReal (‖A‖^2) • puncturedLattice) :=
      IsFiniteMeasureOnCompacts.smul _ ENNReal.ofReal_ne_top
    infer_instance
  mutuallySingular := by
    exact ((volume_mutuallySingular_puncturedLattice.mono_ac
      (withDensity_absolutelyContinuous _ _) Measure.AbsolutelyContinuous.rfl).symm.smul
        (ENNReal.ofReal (‖A‖^2))).symm

namespace SquarePhysicalSupport

theorem bounded_of_continuous_tendsto_zero {h : ℝ → ℂ} (hcont : Continuous h)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) : ∃ B : ℝ, 0 ≤ B ∧ ∀ x, ‖h x‖ ≤ B := by
  obtain ⟨K,hK,hKs⟩ : ∃ K : Set ℝ, IsCompact K ∧ ∀ x ∉ K, ‖h x‖ < 1 := by
    have ht := hvan (Metric.ball_mem_nhds 0 one_pos)
    rw [Filter.mem_map, Filter.mem_cocompact] at ht
    obtain ⟨K,hK,hKs⟩ := ht
    exact ⟨K,hK,fun x hx => by simpa using hKs hx⟩
  obtain ⟨B,hB⟩ := hK.exists_bound_of_continuousOn hcont.continuousOn
  exact ⟨max B 1,le_trans zero_le_one (le_max_right _ _),fun x => by
    by_cases hx : x∈K
    · exact (hB x hx).trans (le_max_left _ _)
    · exact (hKs x hx).le.trans (le_max_right _ _)⟩

theorem density_bound {h : ℝ → ℂ} (hcont : Continuous h)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) (A : ℂ) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ x, ‖A-h x‖^2 ≤ B := by
  obtain ⟨B,hB,hbound⟩ := bounded_of_continuous_tendsto_zero hcont hvan
  exact ⟨(‖A‖+B)^2,sq_nonneg _,fun x =>
    pow_le_pow_left₀ (norm_nonneg _) ((norm_sub_le _ _).trans (by linarith [hbound x])) 2⟩

theorem linearMassGrowth_smul (c : ℝ≥0) (μ : Measure ℝ) [IsLocallyFiniteMeasure μ]
    (hμ : LinearMassGrowth μ) : LinearMassGrowth ((c:ℝ≥0∞) • μ) := by
  obtain ⟨C,hC,hbound⟩ := hμ
  refine ⟨c*C,mul_nonneg c.coe_nonneg hC,fun R hR => ?_⟩
  rw [Measure.real,Measure.smul_apply,smul_eq_mul,ENNReal.toReal_mul,ENNReal.coe_toReal]
  exact (mul_le_mul_of_nonneg_left (hbound R hR) c.coe_nonneg).trans_eq (by ring)

theorem square_density_integrable {h : ℝ → ℂ} (hcont : Continuous h)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) (A : ℂ) (φ : 𝓢(ℝ,ℂ)) :
    Integrable (fun x => ((‖A-h x‖^2:ℝ):ℂ)*φ x) := by
  obtain ⟨B,hB,hbound⟩ := density_bound hcont hvan A
  apply φ.integrable.bdd_mul (c:=B) (by fun_prop)
  exact Eventually.of_forall fun x => by
    rw [Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (sq_nonneg (‖A-h x‖))]
    exact hbound x

end SquarePhysicalSupport

theorem squareGapJordan_growth {h : ℝ → ℂ} (hcont : Continuous h)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) (A : ℂ) :
    (squareGapJordan h A hcont).HasLinearGrowth := by
  obtain ⟨B,hB,hbound⟩ := SquarePhysicalSupport.density_bound hcont hvan A
  let b : ℝ≥0 := B.toNNReal
  let a : ℝ≥0 := (‖A‖^2).toNNReal
  have hd : volume.withDensity (fun x => ENNReal.ofReal (‖A-h x‖^2)) ≤
      (b:ℝ≥0∞) • volume := by
    rw [←withDensity_const]
    exact withDensity_mono (Eventually.of_forall fun x => ENNReal.ofReal_le_ofReal (hbound x))
  haveI : IsFiniteMeasureOnCompacts ((b:ℝ≥0∞) • (volume:Measure ℝ)) :=
    IsFiniteMeasureOnCompacts.smul _ ENNReal.coe_ne_top
  haveI : IsFiniteMeasureOnCompacts ((a:ℝ≥0∞) • puncturedLattice) :=
    IsFiniteMeasureOnCompacts.smul _ ENNReal.coe_ne_top
  have hg := linearMassGrowth_add (linearMassGrowth_smul_volume b)
    (SquarePhysicalSupport.linearMassGrowth_smul a _ puncturedLattice_linearGrowth)
  apply hg.mono
  change volume.withDensity _ + ENNReal.ofReal _ • puncturedLattice ≤ _
  exact add_le_add hd le_rfl

theorem squareGapJordan_pairing {h : ℝ → ℂ} (hcont : Continuous h)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) (A : ℂ) (φ : 𝓢(ℝ,ℂ)) :
    (squareGapJordan h A hcont).distributionOfLinearGrowth (squareGapJordan_growth hcont hvan A) φ =
      squareGapMeasure h A φ := by
  rw [LocallyFiniteSignedMeasure.distributionOfLinearGrowth_apply]
  change (∫ x,φ x ∂volume.withDensity (fun x => ENNReal.ofReal (‖A-h x‖^2))) -
    (∫ x,φ x ∂ENNReal.ofReal (‖A‖^2) • puncturedLattice) = _
  have hm : Measurable (fun x:ℝ => ‖A-h x‖^2) := by fun_prop
  have hd := integral_withDensity_ofReal (h:=fun x:ℝ => ‖A-h x‖^2) hm
    φ.continuous.aestronglyMeasurable (SquarePhysicalSupport.square_density_integrable hcont hvan A φ)
  rw [hd.2,integral_smul_measure,(integral_puncturedLattice φ).2,ENNReal.toReal_ofReal (sq_nonneg _)]
  simp only [max_eq_left (sq_nonneg _),Complex.real_smul,squareGapMeasure]

theorem squareGapJordan_gap {h : ℝ → ℂ} (hcont : Continuous h) (A : ℂ)
    (hpl : ∀ x, |x|≤1 → h x=A) :
    (squareGapJordan h A hcont).positive (Ioo (-1) 1)=0 ∧
      (squareGapJordan h A hcont).negative (Ioo (-1) 1)=0 := by
  constructor
  · exact withDensity_ofReal_gap (fun x hx => by simp [hpl x hx.le])
  · simp only [squareGapJordan,Measure.smul_apply,puncturedLattice_gap,smul_zero]

theorem squareGapJordan_origin {h : ℝ → ℂ} (hcont : Continuous h) (A : ℂ) :
    (squareGapJordan h A hcont).positive {0}=0 ∧ (squareGapJordan h A hcont).negative {0}=0 := by
  refine ⟨withDensity_singleton_zero _ _, ?_⟩
  have hz : puncturedLattice {0}=0 := measure_mono_null
    (singleton_subset_iff.mpr (by constructor <;> norm_num)) puncturedLattice_gap
  simp only [squareGapJordan,Measure.smul_apply,hz,smul_zero]

theorem squareGapJordan_off_lattice {h : ℝ → ℂ} (hcont : Continuous h) (A : ℂ) :
    (squareGapJordan h A hcont).negative (Set.range (fun n:ℤ => (n:ℝ)))ᶜ=0 := by
  simp only [squareGapJordan,Measure.smul_apply,puncturedLattice_support,smul_zero]

theorem squareGapJordan_even {h : ℝ → ℂ} (hcont : Continuous h) (A : ℂ)
    (hev : ∀ x,h (-x)=h x) :
    Measure.map (fun x:ℝ => -x) (squareGapJordan h A hcont).positive =
      (squareGapJordan h A hcont).positive ∧
    Measure.map (fun x:ℝ => -x) (squareGapJordan h A hcont).negative =
      (squareGapJordan h A hcont).negative := by
  constructor
  · exact map_neg_withDensity_even
      (ENNReal.measurable_ofReal.comp ((continuous_const.sub hcont).norm.pow 2).measurable)
      (fun x => by rw [hev])
  · simp only [squareGapJordan,Measure.map_smul,puncturedLattice_map_neg]

/-- The Fourier defect of the distribution of the actual Jordan measure is
the literal continuous Lebesgue density from the original square root. -/
theorem squareGapJordan_fourier_defect {h : ℝ → ℂ} (hcont : Continuous h)
    (hint : Integrable h) (hL2 : MemLp h 2) (hsd : 𝓕 h=h) (hev : ∀ x,h (-x)=h x)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) (A : ℂ) (φ : 𝓢(ℝ,ℂ)) :
    𝓕 ((squareGapJordan h A hcont).distributionOfLinearGrowth (squareGapJordan_growth hcont hvan A)) φ -
      (squareGapJordan h A hcont).distributionOfLinearGrowth (squareGapJordan_growth hcont hvan A) φ =
        ∫ x,squareDualityDefect h x*φ x := by
  rw [TemperedDistribution.fourier_apply,squareGapJordan_pairing hcont hvan A (𝓕 φ),
    squareGapJordan_pairing hcont hvan A φ]
  exact squareGapMeasure_fourier_defect hint hL2 hsd hev A φ

end Zeta23.OPICAFollowup
#print axioms Zeta23.OPICAFollowup.squareGapJordan_growth
#print axioms Zeta23.OPICAFollowup.squareGapJordan_pairing
#print axioms Zeta23.OPICAFollowup.squareGapJordan_gap
#print axioms Zeta23.OPICAFollowup.squareGapJordan_origin
#print axioms Zeta23.OPICAFollowup.squareGapJordan_off_lattice
#print axioms Zeta23.OPICAFollowup.squareGapJordan_even
#print axioms Zeta23.OPICAFollowup.squareGapJordan_fourier_defect
