from pathlib import Path
import hashlib, json
HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
mapping = json.loads((HERE / 'consumer-proposal-map.json').read_text())['roots']
companions = {r['root']: r for r in json.loads((HERE / 'full-signature-companion-provenance.json').read_text())}
notes = {
 'source_order_uniform_norms': 'Existing physical consumer omits the additional pointwise plus L1 estimate; full companion retains it.',
 'native_field_theta_envelope': 'Existing physical consumer existentializes the order constant; full companion retains canonical nativeFieldOrderConstant and all conclusions.',
 'near_gap_mass_bound': 'Existing physical consumer packages growth/selfduality through separate complex hypotheses; full companion retains literal signed-measure interface and both conclusions.',
 'near_gap_controlled_limit_zero': 'Existing physical consumer uses a reformulated complex distribution interface; full companion retains the literal signed Jordan family, uniform mass bound and limit.',
 'dilation_near_gap_family': 'Existing physical consumer changes packaging of explicit actual comb construction and conjunction; full companion retains every production clause.',
 'dilation_normalized_limit_not_measure': 'Existing physical consumer changes packaging and limit object; full companion retains canonical distribution, normalization and non-measure conclusion.',
 'fixed_basis_negative_mass_budget': 'Existing physical consumer states plain Fin coefficients with sqrt(sum squares); full companion retains literal EuclideanSpace norm and entire coefficient/unit-sphere interface.'
}
rows = []
for row in mapping:
    root = row['root']; name = 'Zeta23.OPICAFollowup.Validation.' + row['required_expected_name']
    comp = companions.get(root)
    rows.append({'root': root, 'required_expected_name': name,
        'selected_written_source': row['selected'],
        'required_expected_type_comparison': 'DIFFERENT_REVIEW_REQUIRED' if comp else 'DEFINITIONALLY_EQUAL',
        'full_signature_companion': comp['companion'] if comp else None,
        'chosen_full_type_check_consumer': comp['companion'] if comp else name,
        'chosen_full_type_comparison': 'DEFINITIONALLY_EQUAL',
        'difference_review_note': notes[root.rsplit('.', 1)[1]] if comp else None,
        'independent_original_clause_physical_domain_review': 'OPEN'})
result = {'schema': 'OPICA_FULL100_CONSUMER_REVIEW_MATRIX_V1', 'status': 'COMPILER_EVIDENCE_REVIEW_INPUT_ONLY',
    'root_count': len(rows), 'required_names_exact_type_matches': 93, 'extra_full_signature_companions': 7,
    'selected_full_type_matches': 100, 'source': 'overlay/Zeta23/OPICAFollowup/Validation.lean',
    'source_sha256': sha(HERE / 'overlay/Zeta23/OPICAFollowup/Validation.lean'),
    'all100_type_check_source': 'CompareFullSignatureCoverage.lean',
    'all100_type_check_source_sha256': sha(HERE / 'CompareFullSignatureCoverage.lean'),
    'all100_type_check_log': 'CompareFullSignatureCoverage.log',
    'all100_type_check_log_sha256': sha(HERE / 'CompareFullSignatureCoverage.log'),
    'type_comparison_limit': 'Default Lean definitional equality after ordered universe-parameter renaming; does not certify frozen semantics, independent consumer authorship, physical adequacy or approval.',
    'review_seal': 'UNSET', 'full_release_accepted': False, 'RH': 'OPEN', 'Step4': 'OPEN', 'rows': rows}
(HERE / 'full-type-consumer-matrix.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print('Prepared100 rows:93 required exact signatures plus7 retained full-signature companions; independent physical reviewOPEN.')
