import AffineConfluent

-- EXPECTED REJECTION: the raw k=2 derivative column is twice the normalized
-- one. At a single κ=2 node of multiplicity three, the raw determinant is −16.
example : (Matrix.of ![![(2 : ℚ), 1, 0], ![-7 / 2, -15 / 4, -2],
    ![49 / 8, 161 / 16, 11]]).det = -8 := by
  norm_num [Matrix.det_fin_three, Matrix.cons_val_two, Matrix.vecHead, Matrix.vecTail]
