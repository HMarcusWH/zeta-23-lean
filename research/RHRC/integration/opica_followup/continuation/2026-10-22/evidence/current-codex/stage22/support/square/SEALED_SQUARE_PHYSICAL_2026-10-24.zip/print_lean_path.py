import os
print(os.environ['LEAN_PATH'])
