"""Seal completed scratch evidence without touching the owner checkout/cache."""
from pathlib import Path
import datetime,hashlib,json,re,shutil,zipfile
P=Path(__file__).resolve().parent
R=P.parent/'opica-followup-repo'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
primary=['SquareDefectPhysicalFullCandidate.lean','SquareSpanCompositionFinal.lean',
         'ExpectedSquarePhysicalFinal.lean','ExpectedSquareSpanCompositionFinal.lean',
         'NegativeSquarePhysicalFinal.lean']
labels=['full-square-physical-module','final-physical-expected-types',
        'final-actual-span-composition','final-actual-span-expected-type2',
        'final-square-negative-contracts']
assert sha(P/'PinnedSquareDefect.lean')=='da73276d089068c1711f3854a9520fbcbbbc877d77ccc33fe20cb9ceb83d64d1'
assert (P/primary[0]).read_bytes().startswith((P/'PinnedSquareDefect.lean').read_bytes())
assert sha(P/primary[0])=='c65b7b8eb6894a89a12a85e36ea660c97ca8deeb47900392786b20ae81b4ee58'
gates=[]
axiom_total=0
for label in labels:
    file=P/(label+'.receipt.json');row=json.loads(file.read_text(encoding='utf-8'))
    log=P/(label+'.log');text=log.read_text(encoding='utf-8')
    assert sha(log)==row['log_sha256']
    assert row['source_unchanged'] and row['source_before']==row['source_after']
    axiom_lists=re.findall(r'depends on axioms:\s*\[([^]]*)\]',text,re.S)
    for ax in axiom_lists:
        assert set(re.sub(r'\s','',ax).split(',')) <= {'propext','Classical.choice','Quot.sound'}
    axiom_total+=len(axiom_lists)
    errors=len(re.findall(r': error(?:\(|:)',text))
    if label=='final-square-negative-contracts':
        assert row['exit_code']==1 and errors==3
        assert text.count('Type mismatch')==2 and 'σ.totalVariation.HasTemperateGrowth' in text
        assert not any(x in text for x in ['unexpected token','Unknown identifier','object file'])
        disposition='PASS_EXPECTED_REJECTION: missing plateau, lattice support and legitimate temperate embedding'
    else:
        assert row['exit_code']==0 and errors==0 and axiom_lists and 'sorryAx' not in text
        disposition='PASS_EXACT_SCRATCH_STANDARD_AXIOMS_ONLY'
    gates.append({'label':label,'disposition':disposition,'exit_code':row['exit_code'],
                  'seconds':row['seconds'],'axiom_print_count':len(axiom_lists),'error_count':errors,
                  'input_count':len(row['source_before']),'input_pins_unchanged_during_gate':True,
                  'head_begin':row['head_begin'],'head_end':row['head'],
                  'tree_begin':row['tree_begin'],'tree_end':row['tree'],
                  'receipt_sha256':sha(file),'log_sha256':sha(log)})
assert axiom_total==22
for name in primary[:2]:
    code=(P/name).read_text(encoding='utf-8')
    code=re.sub(r'/\-.*?\-/|--[^\n]*','',code,flags=re.S)
    assert not re.search(r'\b(?:sorry|admit)\b',code)
    assert not re.search(r'(?m)^\s*(?:private\s+)?(?:axiom|constant|opaque)\b',code)
receipt={
 'schema':'OPICA_ACTUAL_SQUARE_PHYSICAL_SCRATCH_RECEIPT_V1',
 'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base_code_commit':'139c1a0d88cc0fb2d8a0d8ea71e152b25b14c36e',
 'base_code_tree':'3e63b0c72fc04da7bab45388d6096e82e95c4acb',
 'source_sha256':{name:sha(P/name) for name in primary},
 'original_square_prefix_sha256':sha(P/'PinnedSquareDefect.lean'),
 'original_four_roots_statements_proofs_imports_exact_byte_prefix_preserved':True,
 'gates':gates,'standard_axiom_print_count':axiom_total,
 'physical_measure':'Canonical mutually singular, locally finite positive=|A-h|²dx, negative=|A|² punctured comb; linear variation growth and exact actual distribution pairing proved.',
 'actual_measure_clauses':['exact positive/negative formulas','mutual singularity/local finiteness',
   'derived total variation linear growth','measure-level gap/origin/off-lattice sign/evenness',
   'actual tempered embedding equals original raw square pairing','literal continuous real C0 Fourier-defect density'],
 'correction_domain':{
   'carrier':'arbitrary LocallyFiniteComplexMeasure',
   'growth':'true Euclidean totalVariation.HasTemperateGrowth: some inverse polynomial weight integrable; no fixed degree or linear bound',
   'support':'true totalVariation of integer-lattice complement equals zero',
   'embedding':'four actual coordinate Jordan tempered embeddings derived internally via variationControl≤TV+TV',
   'distribution_extension_only_to_TV_growth_bridge':'OPEN_IN_LEAN; classical equivalence for uniformly discrete support cited separately; not promoted to kernel authority'},
 'projection_domain':'actual tempered distribution (T_tau+F T_tau)/2 with exact global/local density identities; no separate global projected Jordan carrier claimed',
 'mixed_composition':'actual zero-profile square at plateau one + arbitrary actual finite multiplicity-bounded zero-jet span + arbitrary true-TV-temperate lattice measure is not selfdual; jet-basis independence not required',
 'falsification':['A=1,h=0 has gap positive mass2 when plateau omitted','integer1 negative atom retained',
   'zero h,A=0 gives zero measure','omission of actual plateau/support/growth rejected'],
 'original_contract_source':{'path':'research/RHRC/integration/opica_followup/BUILD_SPEC.md',
   'sha256':sha(R/'research/RHRC/integration/opica_followup/BUILD_SPEC.md')},
 'claim_firewall':{'new_original_root_count':0,'full100_domain_acceptance':False,
   'production_replay':'REQUIRED','distribution_extension_bridge':'OPEN','aggregate_release':'OPEN',
   'RH':'OPEN','Step4':'OPEN','external_or_complete_independent_release_approval':'NOT_CLAIMED'},
}
file=P/'SQUARE_PHYSICAL_FINAL_RECEIPT_2026-10-24.json'
file.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
literature={
 'primary_paper':{'authors':'Michael Baake and Nicolae Strungaru','title':'A note on tempered measures',
   'journal':'Colloquium Mathematicum 172 (2023),15–30','doi':'10.4064/cm8796-7-2022',
   'published_record':'https://www.impan.pl/en/publishing-house/journals-and-series/colloquium-mathematicum/all/172',
   'author_manuscript':'https://arxiv.org/pdf/2202.09175','version':'v2,17 October2022',
   'locations':['Definition2.1,p1','Theorem2.7,pp5–6','Theorem4.4 and Corollary4.5,p11'],
   'relevance':'Distribution-tempered and total-variation temperate are distinct generally; the uniformly discrete case supplies their classical equivalence. This equivalence is not formalized here.'}}
(P/'PRIMARY_LITERATURE_EVIDENCE.json').write_text(json.dumps(literature,indent=2)+'\n',encoding='utf-8')
names=primary+['PinnedSquareDefect.lean','SquarePhysicalCandidate.lean','SquarePhysicalNoRepair.lean',
 'SquarePhysicalProjection.lean','SquarePhysicalComposition.lean','SquareSpanComposition.lean',
 'ExpectedSquarePhysical.lean','NegativeSquarePhysical.lean','assemble_square_physical.py',
 'seal_square_physical.py','run_scratch.py','print_lean_path.py','TOOLCHAIN_IDENTITY.json',
 'PRIMARY_LITERATURE_EVIDENCE.json','POST_GREEN_SQUARE_PHYSICAL_2026-10-24.md','HANDOFF.md',file.name]
names += [label+ext for label in labels for ext in ('.log','.receipt.json')]
historical=['pinned-square-parent2','square-attempt4','no-repair-attempt2','projection-attempt2',
            'composition-attempt2','expected-square-attempt2','negative-square-contracts2']
names += [label+ext for label in historical for ext in ('.log','.receipt.json')]
out=P/'SEALED_SQUARE_PHYSICAL_2026-10-24'
assert not out.exists(),'Never overwrite sealed evidence'
out.mkdir()
for name in names:
    shutil.copyfile(P/name,out/name)
manifest={f.name:sha(f) for f in sorted(out.iterdir()) if f.is_file()}
manifest_file=out/'FILE_MANIFEST_SHA256.json'
manifest_file.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
archive=P/'SEALED_SQUARE_PHYSICAL_2026-10-24.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for f in sorted(out.iterdir()):z.write(f,f.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps({'receipt_sha256':sha(file),'archive_sha256':sha(archive),
 'manifest_sha256':sha(manifest_file),'manifest_entries':len(manifest),'archive_bytes':archive.stat().st_size,
 'source_sha256':receipt['source_sha256'],'gates':gates},indent=2))
