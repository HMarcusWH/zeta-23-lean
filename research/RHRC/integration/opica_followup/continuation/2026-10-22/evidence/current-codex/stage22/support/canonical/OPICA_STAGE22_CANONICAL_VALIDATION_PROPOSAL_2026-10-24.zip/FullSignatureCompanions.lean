import Zeta23.OPICAFollowup
noncomputable section
open Set MeasureTheory Filter Complex
open scoped ENNReal Topology FourierTransform SchwartzMap
open Zeta23 Zeta23.OPICA Zeta23.OPICAFollowup Zeta23.OPICAFollowup.FiniteSpan
namespace Zeta23.OPICAFollowup.Validation
/- Complete explicit source-signature companions retain old consumer APIs.
No reflection-generated theorem type or independent review seal is used. -/
theorem expected_source_order_uniform_norms_full_signature :
    ∃ C : ℝ, 0<C ∧ ∀ d : ℕ,
      (∀ k : ℕ, k≤2 →
        (∀ x : ℝ, |iteratedDeriv k (sourceOrderFamily d) x| +
          (∫ u : ℝ, |iteratedDeriv k (sourceOrderFamily d) u|) ≤
            Real.exp (C*((d:ℝ)+1)*Real.log ((d:ℝ)+2))) ∧
        eLpNorm (iteratedDeriv k (sourceOrderFamily d)) (⊤:ENNReal) volume ≤
          ENNReal.ofReal (Real.exp (C*((d:ℝ)+1)*Real.log ((d:ℝ)+2))) ∧
        (eLpNorm (iteratedDeriv k (sourceOrderFamily d)) (⊤:ENNReal) volume).toReal +
          (∫ u : ℝ, |iteratedDeriv k (sourceOrderFamily d) u|) ≤
            Real.exp (C*((d:ℝ)+1)*Real.log ((d:ℝ)+2))) ∧
      MemLp (integerDriveFamily d) 2 volume ∧
      ‖integerDriveFamilyL2 d‖ ≤ Real.exp (C*((d:ℝ)+1)*Real.log ((d:ℝ)+2)) ∧
      (∀ t : ℝ, (∫ x : ℝ, uniform_nativeOrderLogDriveSummand d t x) = 0) := by
  exact source_order_uniform_norms

theorem expected_native_field_theta_envelope_full_signature :
    ∃ C : ℝ, 0<C ∧ ∀ d : ℕ,
      0<nativeFieldOrderConstant d ∧
      (∀ t : ℝ, 0≤t → |primeFieldFamily d t| ≤
        nativeFieldOrderConstant d*Real.exp (nativeZeroDisplacementSup*t)) ∧
      Real.log (1+nativeFieldOrderConstant d) ≤ C*((d:ℝ)+1)*Real.log ((d:ℝ)+2) := by
  exact native_field_theta_envelope

theorem expected_near_gap_mass_bound_full_signature (nu : LocallyFiniteSignedMeasure)
    (hnu : nu.HasLinearGrowth) (hself : nu.FourierSelfdual hnu)
    {a R d : ℝ} (ha : 0<a) (ha1 : a≤1) (hgap : hasNearGap nu a)
    (hoff : nu.OffLatticeNonnegative) (hR : 1≤R) (hd : 0<d) (_hdhalf : d≤1/2) :
    nu.negative (signedBudgetRegion R d)=0 ∧
    nu.positive.real (signedBudgetRegion R d)≤
      (Real.pi^2*R^2/(4*d^2))*(1-a)*nu.totalVariation.real (Icc (-1) 1) := by
  exact near_gap_mass_bound nu hnu hself ha ha1 hgap hoff hR hd _hdhalf

theorem expected_near_gap_controlled_limit_zero_full_signature
    (nu : ℕ → LocallyFiniteSignedMeasure) (C : ℝ)
    (hC : ∀ n, CommonLinearMassBound C (nu n).totalVariation)
    (hself : ∀ n, (nu n).FourierSelfdual (hC n).linearGrowth)
    (a : ℕ → ℝ) (ha : ∀ n, 0 < a n) (ha1 : ∀ n, a n ≤ 1)
    (hgap : ∀ n, hasNearGap (nu n) (a n))
    (hoff : ∀ n, (nu n).OffLatticeNonnegative)
    (hlim : Tendsto a atTop (𝓝 1)) (φ : SchwartzMap ℝ ℂ) :
    Tendsto (fun n => (nu n).distributionOfLinearGrowth (hC n).linearGrowth φ)
      atTop (𝓝 0) := by
  exact near_gap_controlled_limit_zero nu C hC hself a ha ha1 hgap hoff hlim φ

theorem expected_dilation_near_gap_family_full_signature
    (L : ℝ) (hL : 0 < L) (hu : L < Real.log 2) :
    (∀ K : Set ℝ, ∀ hK : IsCompact K,
      localSignedCompactRestriction (nearGapCombFamily L) K hK =
        localSignedCompactRestriction (dilatedCombJordan L) K hK +
        localSignedCompactRestriction (dilatedCombJordan (-L)) K hK -
        (2 * Real.cosh (L / 2)) •
          localSignedCompactRestriction (dilatedCombJordan 0) K hK) ∧
    (nearGapCombFamily L).HasLinearGrowth ∧
    CommonLinearMassBound 18 (nearGapCombFamily L).totalVariation ∧
    (nearGapCombFamily L).FourierSelfdual (nearGapCombFamily_growth L) ∧
    (∀ f : SchwartzMap ℝ ℂ,
      nearGapCombDistribution L
        (SchwartzMap.compCLMOfContinuousLinearEquiv ℂ
          (LinearIsometryEquiv.neg ℝ (E := ℝ)) f) =
        nearGapCombDistribution L f) ∧
    hasNearGap (nearGapCombFamily L) (Real.exp (-L)) ∧
    ((1 / 2 : ℝ) < Real.exp (-L) ∧ Real.exp (-L) < 1) ∧
    (nearGapCombFamily L).OffLatticeNonnegative ∧
    ((nearGapCombFamily L).positive ({0} : Set ℝ) = 0 ∧
      (nearGapCombFamily L).negative ({0} : Set ℝ) = 0) ∧
    (nearGapCombFamily L).positive ≠ 0 ∧
    (Measure.map (fun x : ℝ => -x) (nearGapCombFamily L).positive =
        (nearGapCombFamily L).positive ∧
      Measure.map (fun x : ℝ => -x) (nearGapCombFamily L).negative =
        (nearGapCombFamily L).negative) ∧
    ((nearGapCombFamily L).positive.real ({Real.exp (-L)} : Set ℝ) =
        Real.exp (-L / 2) ∧
      (nearGapCombFamily L).negative ({Real.exp (-L)} : Set ℝ) = 0) := by
  exact dilation_near_gap_family L hL hu

theorem expected_dilation_normalized_limit_not_measure_full_signature :
    Tendsto (fun L : ℝ => ((L : ℂ) ^ 2)⁻¹ • nearGapCombDistribution L) (𝓝[≠] 0)
        (𝓝 ct1NormalizedLimit) ∧
    (∀ φ : SchwartzMap ℝ ℂ,
      Tendsto (fun L : ℝ => nearGapCombDistribution L φ / (L : ℂ) ^ 2) (𝓝[≠] 0)
        (𝓝 (∑' n : ℤ, ((n : ℂ) ^ 2 * deriv (deriv φ) n + 2 * n * deriv φ n)))) ∧
    (∀ φ : SchwartzMap ℝ ℂ,
      HasSum (fun n : ℤ => ((n : ℂ) ^ 2 • TemperedDistribution.derivCLM ℂ
          (TemperedDistribution.derivCLM ℂ (TemperedDistribution.delta (n : ℝ))) -
        (2 * (n : ℂ)) • TemperedDistribution.derivCLM ℂ
          (TemperedDistribution.delta (n : ℝ))) φ) (ct1NormalizedLimit φ)) ∧
    (∀ (n : ℤ) (φ : SchwartzMap ℝ ℂ), tsupport φ ⊆ Icc ((n : ℝ) - 1 / 2) (n + 1 / 2) →
      ct1NormalizedLimit φ = (n : ℂ) ^ 2 * deriv (deriv φ) n + 2 * n * deriv φ n) ∧
    ct1NormalizedLimit ≠ 0 ∧
    (∀ n : ℤ, n ≠ 0 → ¬ ∃ C : ℝ, ∀ φ : SchwartzMap ℝ ℂ,
      tsupport φ ⊆ Icc ((n : ℝ) - 1 / 2) (n + 1 / 2) →
        ‖ct1NormalizedLimit φ‖ ≤ C * SchwartzMap.seminorm ℝ 0 0 φ) ∧
    (¬ ∃ μ : LocallyFiniteSignedMeasure, ∀ φ : SchwartzMap ℝ ℂ,
      (∫ x, φ x ∂μ.positive) - (∫ x, φ x ∂μ.negative) = ct1NormalizedLimit φ) ∧
    Tendsto (fun L : ℝ =>
        (nearGapCombFamily L).totalVariation.real (Icc (1 / 2) (3 / 2)) / L ^ 2)
      (𝓝[>] 0) atTop := by
  exact dilation_normalized_limit_not_measure

theorem expected_fixed_basis_negative_mass_budget_full_signature {n : ℕ}
    (basis : Fin n → List JetDatum) (valid : ∀ i, ∀ j ∈ basis i, ValidJet j)
    (independent : LinearIndependent ℝ (fun i =>
      (zeroJetRealSpan (basis i)).distributionOfLinearGrowth (zeroJetRealSpan_growth _ (valid i)))) :
    ∃ c_basis : ℝ, 0<c_basis ∧ ∀ a : EuclideanSpace ℝ (Fin n),
      c_basis*‖a‖ ≤ ∫ x in integerLatticeᶜ, sincSquared x
        ∂(zeroJetRealSpan (realBasisCombinationData basis (fun i => a i))).negative := by
  exact fixed_basis_negative_mass_budget basis valid independent

end Zeta23.OPICAFollowup.Validation
