import CT13

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
namespace Zeta23.OPICAFollowup.CT13Support
open Zeta23.OPICA

theorem sinc_identity_original {L : ℝ} (hL : 0 < L) (hu : L < Real.log 2) :
    (nearGapCombFamily L).integral sincSquared =
      2 * (Real.exp L - 1) / (Real.exp L) ^ (3 / 2 : ℝ) := by
  rw [sinc_identity hL hu, Real.rpow_def_of_pos (Real.exp_pos L), Real.log_exp]
  rw [show L * (3 / 2 : ℝ) = L + L / 2 by ring, Real.exp_add,
    show -L / 2 = -(L / 2) by ring, Real.exp_neg, Real.exp_neg]
  field_simp

lemma explicit_sinc_slope :
    Tendsto (fun L : ℝ => (2 * Real.exp (-L / 2) * (1 - Real.exp (-L))) / L)
      (𝓝[>] 0) (𝓝 2) := by
  have h₁ : HasDerivAt (fun L : ℝ => Real.exp (-L / 2)) (-(1 / 2)) 0 := by
    simpa [Function.comp_def, div_eq_mul_inv] using
      (Real.hasDerivAt_exp (-((0 : ℝ)) / 2)).comp 0 (((hasDerivAt_id (0 : ℝ)).neg).div_const 2)
  have h₂ : HasDerivAt (fun L : ℝ => 1 - Real.exp (-L)) 1 0 := by
    simpa [Function.comp_def] using
      ((Real.hasDerivAt_exp (-((0 : ℝ)))).comp 0 ((hasDerivAt_id (0 : ℝ)).neg)).const_sub 1
  have h := ((h₁.const_mul 2).mul h₂).tendsto_slope_zero_right
  simpa [div_eq_mul_inv, mul_comm] using h

theorem positive_sinc_mass_slope :
    Tendsto (fun L : ℝ => (∫ x, sincSquared x ∂(nearGapCombFamily L).positive) / L)
      (𝓝[>] 0) (𝓝 2) := by
  apply explicit_sinc_slope.congr'
  have hlog : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
  filter_upwards [self_mem_nhdsWithin,
    (eventually_lt_nhds hlog).filter_mono nhdsWithin_le_nhds] with L hL hu
  rw [positive_sinc_mass hL hu]

theorem positive_sinc_mass_normalization_cost :
    Tendsto (fun L : ℝ => (∫ x, sincSquared x ∂(nearGapCombFamily L).positive) / L ^ 2)
      (𝓝[>] 0) atTop := by
  have h := positive_sinc_mass_slope.pos_mul_atTop (by norm_num : (0 : ℝ) < 2)
    (tendsto_inv_nhdsGT_zero : Tendsto (fun L : ℝ => L⁻¹) (𝓝[>] 0) atTop)
  convert h using 1
  ext L
  simp [div_eq_mul_inv, pow_two]
  ring

end Zeta23.OPICAFollowup.CT13Support
#print axioms Zeta23.OPICAFollowup.CT13Support.sinc_identity_original
#print axioms Zeta23.OPICAFollowup.CT13Support.positive_sinc_mass_slope
#print axioms Zeta23.OPICAFollowup.CT13Support.positive_sinc_mass_normalization_cost
