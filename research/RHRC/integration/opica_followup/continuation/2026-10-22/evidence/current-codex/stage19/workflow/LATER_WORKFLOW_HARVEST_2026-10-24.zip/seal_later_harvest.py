"""Seal a later, exact-job read-only harvest without changing original evidence."""
from pathlib import Path
import collections, copy, datetime, hashlib, json

P = Path(__file__).resolve().parent
def read(p): return json.loads((P / p).read_text(encoding='utf-8-sig'))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, obj): (P / p).write_text(json.dumps(obj, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
original = read('HARVEST.json')
snap = read('LATER_API_SNAPSHOT.json')
final = read('LATER_FINAL_API_SNAPSHOT.json')
delta = read('later-science/WORKFLOW_DELTA.json')
comparison = read('later-science/PRECEDING_HEAD_COMPARISON.json')
science44 = read('later-science/POST268_ALL44_SCIENCE.json')
outputs44 = read('later-science/ALL44_REVIEWED_OUTPUTS.json')
source = read('later-science/FINAL_SOURCE_FALSIFIER_OUTPUTS.json')
oldjobs = {j['id']: j for r in original['runs'] for j in r['jobs']}
deltas = {j['id']: j for j in delta['delta_jobs']}
finalsource = {j['id']: j for j in final['source_run_jobs']}
runs = {r['id']: r for r in final['workflow_runs']}
jobs = []
notes = {
120881607061: ('RESEARCH-PRODUCING CHECK', 'EXECUTION_SUCCESS; 41 artifact members inspected. Exact regressions, bounded interval certificates and numerical probes are individually scoped in source_scientific_dispositions. WP4 inside this suite is UNRESOLVED 7/18; no continuous K3 positivity or closing inequality.'),
120883714346: ('FORMAL VALIDITY GATE', 'PASS_EXACT_SOURCE_IMPLEMENTED_SUBSET: 41 original historical roots; 1379 public declarations, 16 constructors, 7658 dependency nodes. Remaining 59 roots are not covered by this subset gate; full100 release=false.'),
120885910624: ('FORMAL VALIDITY GATE', 'PASS_EXACT_SOURCE_IMPLEMENTED_SUBSET in this exact push job: 41 original historical roots; 1379 public declarations, 16 constructors, 7658 dependency nodes; remaining59, full100 release=false.'),
120885910754: ('FORMAL VALIDITY GATE', 'PASS_NARROW_ONLY in this exact push job on cea7b2f6/tree377c7f6f: 20 modules, 25 consumer files, 228 axiom closures, source_unchanged=true. Full100 aggregate and release=false. Not the later Stage19 21/28/246 receipt.'),
120885910775: ('REGRESSION GATE', 'PASS in this exact push job:185 child and82 focused parent tests in normal and optimized Python; frozen5112/18862/14672/1274 controls per mode; three numerical suites CONSISTENCY_ONLY. No theorem promotion.'),
120881731694: ('FORMAL VALIDITY GATE', 'PASS: existing Track A contact targets built and axiom/proof-escape audit steps succeeded; inherited hypotheses and global closing inequalities remain open.'),
120881731780: ('REGRESSION GATE', 'PASS: fast integrity and parallel-track harvest controls; terminal NO_RH_CLOSURE_ALL_PARALLEL_TRACKS_HARVESTED. An integrity replay supplies no closing theorem.'),
120881731792: ('FORMAL VALIDITY GATE', 'PASS: existing Track B targets and their prescribed compiler/axiom/proof-escape gates; no discharge of independent closing inequalities.'),
120881731816: ('FORMAL VALIDITY GATE', 'PASS: existing Track A targets and prescribed compiler/axiom/proof-escape gates; frozen mathematical hypotheses retained.'),
120881731885: ('FORMAL VALIDITY GATE', 'PASS: existing Track C targets and prescribed compiler/axiom/proof-escape gates; no new full100 OPICA authority.'),
120891104061: ('REGRESSION GATE', 'PASS: campaign completion aggregation after required jobs. The completion echo has no mathematical theorem content.'),
120881695136: ('RESEARCH-PRODUCING CHECK', 'PASS execution:88 parsed JSON outputs from normalization/scope audits. Read individual dispositions; canonical realizability layers3-5, source/discrepancy mechanisms and uncertified ambient tails remain open. Full logs retained.'),
120882073396: ('RESEARCH-PRODUCING CHECK', 'EXECUTION_INTEGRITY_ONLY: finite contact calibration inputs produced.11 examined rows, no eligible inherited contact; near-contact replay is not exact-contact authority. Detailed comparison and raw intervals retained.'),
120882073539: ('FORMAL VALIDITY GATE', 'PASS: contact-completion Lean targets and their compiler/standard-axiom/proof-escape gates. A conditional contact completion does not supply missing physical hypotheses.'),
120890941521: ('RESEARCH-PRODUCING CHECK', 'EXECUTION_INTEGRITY_ONLY:11 Q-overlap rows,8 curvature,8 physical-remainder,8 response certifications and18 seam controls; X01 NO_ELIGIBLE_INHERITED_CONTACT (0), X02 NEAR_CONTACT_TRANSPORT_DEFECT_PANEL_COMPLETED. exact_contact_authority=false.'),
120892536692: ('REGRESSION GATE', 'PASS: completion aggregation checks tracks A/B/C/D succeeded; no new contact or RH authority.'),
120901031666: ('REGRESSION GATE', 'EXECUTION_HARVEST:44/44 checks executed successfully and all log hashes verified. READ_EACH_SCIENTIFIC_DISPOSITION. 32 CHANGED_REVIEW_LOG labels concern historical execution availability, not32 mathematical discoveries.'),
}
for j in snap['jobs']:
    x = copy.deepcopy(j)
    prev = oldjobs.get(x['id'], {})
    for k in ('classification','scientific_disposition','previous_job','comparison'):
        if k in prev: x[k] = copy.deepcopy(prev[k])
    if x['id'] in deltas:
        d = deltas[x['id']]
        for k in ('log','log_sha256','parsed'): 
            if k in d: x[k] = d[k]
        x['earlier_bounded_snapshot'] = {'status':prev.get('status'), 'conclusion':prev.get('conclusion')}
    if x['id'] in finalsource:
        f = finalsource[x['id']]
        for k in ('status','conclusion','steps'): x[k] = f[k]
    if x['id'] in notes:
        x['classification'], x['scientific_disposition'] = notes[x['id']]
    elif x['id'] in deltas and x['name'].startswith('Extended audit shard'):
        shard = x['name'].rsplit(' ',1)[1]
        x['classification'] = 'RESEARCH-PRODUCING CHECK'
        x['scientific_disposition'] = f'PASS_EXECUTION shard{shard}: all assigned historical checks executed; individual bounded/exact/numerical dispositions in post268_all44. Wrapper success is not a global positivity or bridge theorem.'
    x['run_url'] = runs[x['run_id']]['html_url']
    x['head_sha'] = runs[x['run_id']]['head_sha']
    x['source_tree'] = original['tree']
    x['theorem_promotion_from_workflow_replay'] = False
    log = P / 'later-logs' / f"{x['id']}.log"
    if log.exists():
        x['log'] = log.relative_to(P).as_posix()
        x['log_sha256'] = digest(log)
    assert x.get('classification') in ('FORMAL VALIDITY GATE','REGRESSION GATE','RESEARCH-PRODUCING CHECK'), x['id']
    assert x.get('scientific_disposition'), x['id']
    assert 'exact job' not in x['scientific_disposition'] or x['conclusion'] in ('skipped','failure'), x['id']
    assert x['status'] == 'completed', (x['id'],x['status'])
    jobs.append(x)
assert len(jobs)==66 and len({j['id'] for j in jobs})==66
jc = dict(collections.Counter(j['conclusion'] for j in jobs))
rc = dict(collections.Counter(r['conclusion'] for r in runs.values()))
assert jc == {'success':56,'failure':6,'skipped':4}, jc
assert rc == {'success':18,'failure':4}, rc
assert all(r['status']=='completed' for r in runs.values())
source_dispositions = [
 ('F01/F02/F07', 'NUMERICAL_AGREEMENT_DISCOVERY_NOT_LEAN; rank-two Laplace model is elementary source only.'),
 ('F03/F04/F05', 'Fourier-convolution numerical agreement; integer-moment and beta-integral exact executable regressions plus numerical jet/convergence tests. Separate entrywise Lean evidence is not enlarged here.'),
 ('F06/F08/F09/F12', 'Interior inertia and filtered samples /201-point spectral flow /index-action numerical checks only; no certified simple or distinct crossings or all-interior-window result. Existing omega=1/2 Lean results are separate.'),
 ('F10/F11/M30/M24', 'Exact regressions preserved. Cubic tangency and rank-one intertwining coexist with a negative even eigenvalue; M24 leading change is order9, not uncancelled order7.'),
 ('M41/M43/log3', 'Interval sign-change before log2, prime-free indefiniteness on two legal vectors, and H(log3)>0 for (1,-4,6,-4,1), M4=24; research certificates on specified domains.'),
 ('M74/GateA-D', 'Exact identities/theorem regressions pass; countermodel survives M74 identities. Gate sharpness/crudeness estimates are numerical signals.'),
 ('M55/M71/M45', '79997-point Abel regression;224 certified Andreief sign cells with0 unresolved;232 odd-endpoint cases at256 bits. Aperture/parity/stronger-constant negative controls retain their intended failures; no domain expansion.'),
 ('M27/M08/M09/M61', 'Root-slope/cubic-Schur/weighted-remainder/source-balance regressions; M09 numerical50 cases, M61 96 rows/288 vectors. These are scoped replays.'),
 ('M49/M50/M34/M44/M29/M63', 'EXPERIMENTAL_SIGNAL or numerical regression: near-edge and older-prime budget,84 oscillation rows,216 entering-prime rows,27 resolvent rows with65 skipped below floor,4 route contacts. Floating gap-based row selection is unstable near zero.'),
 ('M51', '128-bit K2 even-bottom interval certificate only for L in [1/400,U], U=2772588722239781/10^15 < log16. (U,log16] OPEN. Altered-prime +/-1e-6 controls demonstrate sensitivity.'),
 ('M76 Arb', 'ARB_POINTWISE_RESEARCH_EVIDENCE:96 gridpoints certify A/B/margin positive;50 prior floating-unresolved points resolved. Nothing between gridpoints; altered-prime/scalar-correction controls obstruct naive universal inference.'),
 ('WP2', 'Independent cover verifier PASS1310 intervals at192 bits; finite transcript, not continuous K3.'),
 ('WP4 source-suite', 'UNRESOLVED:7/18 required boxes tested (6PASS then1UNRESOLVED); all_aperture_positivity_certified=false, certified_negative_stop=false.384bits,maxdepth40,maxnodes500,time600sec.'),
 ('WP4 dedicated', 'Separate exact job120881550296 PASS18/18 frozen even/odd boxes with384bits,maxdepth40,maxnodes1000,time1200sec. Same checker source bytes, larger budget/different Python runtime. No contradiction and no continuous K3 theorem.'),
 ('WP5/WP6', 'Altered-prime crossing is a non-zeta control. Unrestricted physical Q>=0 falsified at bounded true-source apertures: B=3/20 positive versus69/100 negative. Not first-contact, selected-ground or RH counterexample.'),
]
postgreen = {
 'what_became_formally_true': 'Historical Lean surfaces and exact cea7 narrow/subset gates replayed successfully; full100 receipt and canonical parent extension still fail. No new original theorem root is promoted by this later harvest.',
 'workflow_harvest': '22 completed runs/66 completed jobs;56 success,6 failure,4 skipped. Every disposition is keyed by run+job ID; skipped is not passed.',
 'what_changed': 'Execution coverage improved against the much older frozen audit baseline; preceding c6ce comparison is43/44 byte-identical logs and one tiny numerical residual. Final source suite now completes after preceding cancellation, adding22 recorded artifact members. Finite contact second-derivative enclosure improves on one replay, coverage unchanged.',
 'upstream_implications': 'Preserve normalization scalar correction and domain/aperture hypotheses. Source identities alone do not eliminate negative even eigenvalues; finite Gram/Schur/jet invariants need genuine physical selectors.',
 'downstream_implications': 'New finite positive sampled/certified regions can guide missing analytic inequalities; M51 has a real unfilled terminal sliver, M76 no inter-grid control, WP4 no continuous cover. Stage19 force-sampling can later provide an auditable jet bridge, but must not be assumed to cure these gaps.',
 'resurrected_routes': 'Environment-blocked historical checks are runnable; failed bridge diagnostics remain mathematically unresolved. Higher-budget frozen WP4 shows budget exhaustion need not be sign failure, while continuous K3 remains separate.',
 'RH_relevant_leads': 'LEAD: combine actual zero-jet sampling/independence with physical signed-measure separator constraints, rather than extrapolating all-B positivity or abstract no-crossing. Lead requires missing formal physical consumers.',
 'falsification_checks': 'Pair-D exact simultaneous-bad countermodel; sign-indefinite full dual geometry; M74 surviving countermodel; WP6 true-source ray sign change; altered-prime, scalar-correction, aperture and oddness controls all block overstrong inferences. Floating near-zero changes/eigenvector signs are not robust new restrictions.',
 'highest_leverage_next_moves': 'Finish actual force-sampling then actual confluent jet independence and finite-span physical signed-measure closure; native window rates. Re-run exact new-head CI after push. Complete cold100/parent extension/registry/canonical graph/independent review only when original roots meet full signatures.'
}
report = {
 'schema':'OPICA_PR294_LATER_ALL_WORKFLOW_HARVEST_V1', 'date':'2026-10-24',
 'scope':'Later completion harvest extending immutable HARVEST.json. All22 runs and66 jobs attached to audited cea7 head, including PR and push runs; latest attempts. No checkout edits.',
 'head':original['head'], 'tree':original['tree'], 'synthetic_merge':original['synthetic_merge'],
 'api_evidence':['LATER_API_SNAPSHOT.json','LATER_FINAL_API_SNAPSHOT.json'],
 'api_final_file_written_at': final['retrieved_at'],
 'retrieval_caveat':'final_file_written_at is serialization time for already-fetched final run/job responses; LATER_API_SNAPSHOT records14:50 query time. Final source artifact was created14:54:33UTC.',
 'counts':{'runs':22,'jobs':66,'run_conclusions':rc,'job_conclusions':jc,'pending':0},
 'source_authority':{'applies_to_commit':original['head'],'applies_to_tree':original['tree'],'synthetic_merge_same_tree':True,'applies_to_later_Stage19_commit_59ff4855':False,'new_head_CI_required_after_push':True},
 'full100_acceptance':False,'RH':'OPEN','Step4':'OPEN','independent_closing_inequalities':'OPEN',
 'preserved_initial_harvest':{'path':'HARVEST.json','sha256':digest(P/'HARVEST.json'),'markdown_sha256':digest(P/'HARVEST.md'),'historical_pending_jobs_now_resolved_here':True},
 'runs':[{'id':r['id'],'name':r['name'],'event':r['event'],'path':r['path'],'head_sha':r['head_sha'],'status':r['status'],'conclusion':r['conclusion'],'url':r['html_url'],'jobs':[j for j in jobs if j['run_id']==r['id']]} for r in runs.values()],
 'post268_all44':{'execution_counts':science44['execution_counts'],'frozen_baseline_comparison_counts':science44['comparison_counts'],'all_log_hashes_verified':True,'mathematical_change_from_CHANGEd_labels':False,'explanation':'32 CHANGED_REVIEW_LOG =30 ENVIRONMENT_BLOCKED+1 FAIL_OR_MISSING_INPUT+1 TIMEOUT becoming runnable.12 prior PASS remain execution-PASS. This comparison does not measure mathematical novelty.','preceding_c6ce_comparison':comparison['post268_totals'],'one_residual_difference':{'id':'check_post171_fb05_schur_barrier_scope','field':'production_smoke.budget_reconstruction_error','prior':6.203854594147708e-25,'current':1.4475660719677984e-24,'same_disposition':True},'individual_results':'later-science/POST268_ALL44_SCIENCE.json','complete_inspected_outputs':'later-science/ALL44_REVIEWED_OUTPUTS.json','diagonal_shift':'FINITE_NUMERICAL_DIAGNOSTIC_ONLY; finite_diagnostic_tolerance_passed=false, diagonal_index_independent=false, offdiagonal_vanishes=false; NOT_CERTIFIED; INFINITE_TAIL_UNCONTROLLED'},
 'source_scientific_dispositions':[{'family':a,'disposition':b} for a,b in source_dispositions],
 'source_artifact':{'id':12564610299,'path':'later-artifacts/12564610299.zip','sha256':'b68f7c022ce573dd88cf4a744598af3e8422d25484e0aa9feb6e711777da223c','digest_verified':True,'members_inspected':len(source),'individual_outputs':'later-science/FINAL_SOURCE_FALSIFIER_OUTPUTS.json','prior_job':120868137077,'prior_conclusion':'cancelled','common_members':19,'new_members':22,'raw_numeric_equality':False,'comparison':'later-science/PRECEDING_HEAD_COMPARISON.json','float_caveat':'Roundoff and eigenvector gauge changes affect raw probes. M49/M50 row106 changes skipped/evaluated status at roughly1e-17 gap; not evidence of a sign theorem.'},
 'contact_comparison':{'claim_cap':'EXECUTION_INTEGRITY_ONLY','coverage_dispositions_equal':True,'obligations_json_equal':True,'raw_intervals_equal':False,'finite_changed_enclosure':{'field':'selected_replay[1].right.attempts[0].even.fixed_second','prior_certified_positive':False,'current_certified_positive':True,'prior_lower_approx':-1.587793e-6,'current_lower_approx':7.902216e-8,'interpretation':'A finite enclosure improvement for selected near-contact replay, not inherited/exact contact authority.'},'eligible_inherited_contacts':0,'exact_contact_authority':False,'comparison':'later-science/PRECEDING_HEAD_COMPARISON.json'},
 'post_green_research_pass':postgreen,
 'classification_note':'Primary categories reflect actual function. Compound jobs may both replay and produce bounded research evidence. Aggregators and fast-integrity are regression gates; wrapper exit0 is execution evidence, not a positive mathematical verdict.',
 'disposition_invariant':'Exact run+job attribution only. No current job inherits a companion PR/push job pass by name. Historical comparisons never confer current formal authority.'
}
assert len([j for r in report['runs'] for j in r['jobs']])==66
assert digest(P/'later-artifacts/12564610299.zip')==report['source_artifact']['sha256']
save('LATER_HARVEST.json',report)
md = ['# PR #294 later workflow harvest — 2026-10-24','',
f"Audited commit `{original['head']}`, tree `{original['tree']}`. PR synthetic merge `{original['synthetic_merge']['commit']}` has the identical source tree. All **22 runs / 66 jobs** are now completed: **56 success, 6 failure, 4 skipped**; runs18success/4failure. This extends the initial bounded harvest without rewriting it.",'',
'This CI belongs to the old cea7 head. It does **not** validate later Stage19 source commit59ff4855 or subsequent changes; fresh exact-head CI is required after push. RH, Step4, independent closing inequalities and full100 aggregate acceptance remain OPEN.','',
'## Formal validity and release blockers','',
'The exact PR and push narrow jobs pass20 modules/25 consumer files/228 axiom closures, with unchanged checked source. Their subset jobs cover41 historical roots (1379 public declarations,16 constructors,7658 dependency nodes), leaving59 outside that subset. Those gates do not cover all90 roots with mixed historical/narrow evidence and are not a cold100 receipt. All existing successful formal surfaces retain their hypotheses.','',
'Six failed jobs are material: python-rhrc120881695067 and opica-contract120881550565 reject the absent full child reviewed type table (1346 static errors); rhkg120881695088 extracts14100 declarations/194 registered roots then rejects39 unclassified standalone modules at graph freshness; PR release120881552112 and push release120882596910 report FAIL_RELEASE_INCOMPLETE; opica-component-summary120882132546 fails its prerequisites.','',
'Four skipped jobs confer no pass: opica-formal120882133108; opica-dependency-delta120882133508; dispatch-only post287-full-k3120881607839; conditional WP4 alternative120887644596 (dedicated feasibility passed).','',
'## Mathematical dispositions','',
'All44 post268 checks execute successfully and full logs match their archived hashes. Against the frozen audit baseline12 retain PASS and32 carry CHANGED_REVIEW_LOG:30 formerly ENVIRONMENT_BLOCKED,1 FAIL_OR_MISSING_INPUT and1 TIMEOUT. These are improvements in execution coverage. Against the immediately preceding c6ce649d head,43/44 complete logs are byte-identical. The remaining change is a reconstruction residual6.203854594147708e-25 →1.4475660719677984e-24, with the same PASS and claim cap.','',
'The newly runnable diagonal-shift diagnostic explicitly reports finite tolerance=false, index-independent diagonal=false, vanishing offdiagonal=false, and NOT_CERTIFIED / INFINITE_TAIL_UNCONTROLLED. Its zero exit establishes execution. The CCM-Weil diagnostic likewise reports FINITE_DIAGNOSTIC_NOT_A_BRIDGE_PROOF and uncertified zero/Archimedean tails. Pair-D retains an exact simultaneous-bad countermodel; dual geometry is full-space independent and sign-indefinite; canonical realizability layers3–5 and discrepancy/source decomposition remain unresolved.','',
'The final source-falsifier job120881607061 succeeds as a research wrapper. Its41 inspected members include exact regressions, interval research certificates and numerical probes. The previous c6ce source job was cancelled:19 members are comparable and22 later members are newly available, so there is no claim that the entire previous run completed.','',
'The source-suite WP4 result is **UNRESOLVED,7/18**:6PASS then1UNRESOLVED, no certified negative stop, positivity=false. It used384bits/maxdepth40/maxnodes500/time600s. The dedicated job120881550296 is **PASS18/18** frozen boxes with384bits/maxdepth40/maxnodes1000/time1200s and a different Python runtime, using the same checker source. These distinct budgets are compatible. Neither is a continuous K3 positivity theorem.','',
'M51 certifies K2 even-bottom positivity only on [1/400,U], U=2772588722239781/10^15 < log16; (U,log16] remains OPEN. M76 Arb certifies96 gridpoints and resolves50 prior floating ambiguities, with no assertion between points. M71 certifies224 bounded sign cells; M45 certifies232 bounded odd-endpoint cases. These are preserved scoped research certificates, not new OPICA original-root authority.','',
'Unrestricted physical signed-ray Q≥0 remains falsified on bounded true-source apertures (B=3/20 positive,69/100 negative), without being a first-contact or selected-ground counterexample. M74 identities/rank-one tangency still coexist with a surviving negative even eigenvalue. Altered-prime/scalar-correction/aperture/oddness controls obstruct overstrong generalizations.','',
'Raw float outputs are not identical across executions; eigenvector sign choices, roundoff and M49/M50 row106 selection near a1e-17 parity gap must not be called mathematical advances. Contact calibration also changes raw enclosures: one selected near-contact even second-derivative lower bound changes about−1.587793e-6→+7.902216e-8 and becomes certified positive. Overall coverage/dispositions and obligation records are unchanged:11 Q-overlap rows;8 curvature/remainder/response rows each;18 seam controls;0 eligible inherited contacts and exact_contact_authority=false. This is a finite enclosure improvement.','',
'## Post-green implications','']
for k,v in postgreen.items(): md += [f"**{k.replace('_',' ').capitalize()}.** {v}",'']
md += ['## Exact workflow inventory','', 'F=formal validity, G=regression, R=research-producing. Every row is an exact job; detailed dispositions, steps, source pins, previous-job comparisons and log hashes are in LATER_HARVEST.json.','', '| Run / workflow | Job | Result | Class |','|---|---|---|---|']
for r in report['runs']:
    for j in r['jobs']:
        cl={'FORMAL VALIDITY GATE':'F','REGRESSION GATE':'G','RESEARCH-PRODUCING CHECK':'R'}[j['classification']]
        md.append(f"| [{r['id']}]({r['url']}) {r['name']} ({r['event']}) | [{j['id']}]({r['url']}/job/{j['id']}) {j['name']} | {j['conclusion']} | {cl} |")
md += ['', '## Evidence and reproducibility','',
'LATER_HARVEST.json contains all66 exact-job dispositions. LATER_API_SNAPSHOT.json is the14:50 API snapshot; LATER_FINAL_API_SNAPSHOT.json saves the final completion responses. The final file timestamp is serialization time, not an invented API query timestamp. Source artifact12564610299 was created14:54:33UTC; archive SHA256 b68f7c022ce573dd88cf4a744598af3e8422d25484e0aa9feb6e711777da223c was verified. Other later and baseline archives are digest-checked in their integrity records.','',
'later-science/ALL44_REVIEWED_OUTPUTS.json and FINAL_SOURCE_FALSIFIER_OUTPUTS.json retain inspected full outputs. PRECEDING_HEAD_COMPARISON.json retains all comparisons, including actual float/enclosure changes. LATER_FILE_MANIFEST.json seals the read-only evidence package. Original HARVEST.json/HARVEST.md remain unchanged. No checkout, workflow, frozen receipt, source, approval or claim was changed by this audit.','']
(P/'LATER_HARVEST.md').write_text('\n'.join(md),encoding='utf-8')
patterns = ['later-logs','later-science','later-artifacts','later-baseline-artifacts']
files = [P/x for x in ['LATER_HARVEST.json','LATER_HARVEST.md','LATER_API_SNAPSHOT.json','LATER_FINAL_API_SNAPSHOT.json','review_later_science.py','compare_later_baselines.py','seal_later_harvest.py']]
for root in patterns:
    files += [x for x in (P/root).rglob('*') if x.is_file() and '.private.' not in x.name]
save('LATER_FILE_MANIFEST.json',{'schema':'OPICA_LATER_HARVEST_FILE_MANIFEST_V1','head':original['head'],'tree':original['tree'],'files':[{'path':x.relative_to(P).as_posix(),'bytes':x.stat().st_size,'sha256':digest(x)} for x in sorted(set(files))]})
print(json.dumps({'counts':report['counts'],'files_manifested':len(set(files)),'harvest_sha256':digest(P/'LATER_HARVEST.json'),'markdown_sha256':digest(P/'LATER_HARVEST.md'),'manifest_sha256':digest(P/'LATER_FILE_MANIFEST.json')}))
