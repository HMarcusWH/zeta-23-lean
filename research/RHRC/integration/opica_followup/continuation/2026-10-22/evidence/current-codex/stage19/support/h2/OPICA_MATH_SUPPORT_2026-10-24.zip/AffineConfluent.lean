import CoordinateConfluent
import Mathlib.Algebra.BigOperators.Intervals

noncomputable section
set_option maxHeartbeats 800000
open Polynomial Finset
open scoped BigOperators

namespace OPICAConfluentAudit
variable {K : Type*} [CommRing K] {M : ℕ}

theorem affineNegPower (a : K) (n : ℕ) :
    (C a - X : K[X]) ^ n = (-1 : K) ^ n • (X - C a) ^ n := by
  have he : (C a - X : K[X]) = C (-1) * (X - C a) := by
    simp only [map_neg, map_one]
    ring
  rw [he, mul_pow, ← map_pow, Polynomial.C_mul']

theorem det_functionalMatrix_affine (L : Fin M → K[X] →ₗ[K] K) (a : K)
    [Nontrivial K] :
    (functionalMatrix L (fun i => (C a - X) ^ (i : ℕ))).det =
      (-1 : K) ^ (M * (M - 1) / 2) *
        (functionalMatrix L (fun i => X ^ (i : ℕ))).det := by
  have hmat : functionalMatrix L (fun i => (C a - X) ^ (i : ℕ)) =
      Matrix.of (fun i j : Fin M => (-1 : K) ^ (i : ℕ) *
        functionalMatrix L (fun i => (X - C a) ^ (i : ℕ)) i j) := by
    ext i j
    change L j ((C a - X) ^ (i : ℕ)) = _
    rw [affineNegPower, map_smul]
    rfl
  rw [hmat, Matrix.det_mul_column]
  have hpdeg (i : Fin M) : ((X - C a : K[X]) ^ (i : ℕ)).natDegree = (i : ℕ) := by
    rw [(Polynomial.monic_X_sub_C a).natDegree_pow, Polynomial.natDegree_X_sub_C, mul_one]
  rw [det_functionalMatrix_monic_basis L (fun i => (X - C a) ^ (i : ℕ)) hpdeg
    (fun i => (Polynomial.monic_X_sub_C a).pow _),
    Finset.prod_pow_eq_pow_sum,
    Fin.sum_univ_eq_sum_range (fun n : ℕ => n) M, Finset.sum_range_id]

theorem profilePolynomial_confluent_expanded_determinant [Nontrivial K]
    (node : Fin M → K) (hnode : ∀ i, node i ≠ 0) (a : K) :
    (functionalMatrix (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
      (fun i => X * (C a - X) ^ (i : ℕ))).det =
      (-1 : K) ^ (M * (M - 1) / 2) *
        (∏ i : Fin M, node i) *
          ∏ i : Fin M, ∏ j ∈ priorNonmatches node (node i) i, (node i - node j) := by
  let L : Fin M → K[X] →ₗ[K] K := fun j =>
    (hasseFunctional (node j) (repeatedJetOrder node j)).comp
      (LinearMap.mulLeft K (X : K[X]))
  have hsource : functionalMatrix L (fun i => (C a - X) ^ (i : ℕ)) =
      functionalMatrix (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
        (fun i => X * (C a - X) ^ (i : ℕ)) := rfl
  have hmonomial : functionalMatrix L (fun i => X ^ (i : ℕ)) =
      functionalMatrix (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
        (fun i => X ^ ((i : ℕ) + 1)) := by
    ext i j
    change hasseFunctional (node j) (repeatedJetOrder node j) (X * X ^ (i : ℕ)) = _
    rw [← pow_succ']
    rfl
  rw [← hsource, det_functionalMatrix_affine, hmonomial,
    coordinateHermite_determinant node hnode]
  rw [mul_assoc]

#print axioms profilePolynomial_confluent_expanded_determinant
end OPICAConfluentAudit
