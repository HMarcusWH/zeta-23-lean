import GroupedIndex

noncomputable section
set_option maxHeartbeats 800000
open Finset
namespace OPICAGroupedConfluent
open OPICAConfluentAudit

theorem prior_match_condition {K : Type*} {r : ℕ} (κ : Fin r → K)
    (hκ : Function.Injective κ) (m : Fin r → ℕ)
    (p q : (j : Fin r) × Fin (m j)) :
    (groupIndex m p < groupIndex m q ∧ κ p.1 = κ q.1) ↔
      (p.1 = q.1 ∧ (p.2 : ℕ) < (q.2 : ℕ)) := by
  constructor
  · rintro ⟨hidx, he⟩
    have hj := hκ he
    refine ⟨hj, ?_⟩
    change blockStart m p.1 + (p.2 : ℕ) < blockStart m q.1 + (q.2 : ℕ) at hidx
    have hb := congrArg (blockStart m) hj
    omega
  · rintro ⟨hj, hk⟩
    refine ⟨?_, congrArg κ hj⟩
    change blockStart m p.1 + (p.2 : ℕ) < blockStart m q.1 + (q.2 : ℕ)
    have hb := congrArg (blockStart m) hj
    omega

theorem grouped_repeatedJetOrder {K : Type*} {r : ℕ} [DecidableEq K]
    (κ : Fin r → K) (hκ : Function.Injective κ) (m : Fin r → ℕ)
    (q : (j : Fin r) × Fin (m j)) :
    repeatedJetOrder (groupedNode κ m) (groupIndex m q) = (q.2 : ℕ) := by
  classical
  rcases q with ⟨j, k⟩
  unfold repeatedJetOrder priorMatches
  rw [groupedNode_at]
  dsimp only [Sigma.fst, Sigma.snd]
  rw [Finset.filter_congr_decidable]
  have hs : ((Iio (groupIndex m ⟨j, k⟩)).filter (fun i => groupedNode κ m i = κ j)) =
      univ.filter (fun i => i < groupIndex m ⟨j, k⟩ ∧ groupedNode κ m i = κ j) := by
    ext i
    simp
  rw [hs, card_eq_sum_ones, sum_filter, ← (groupEquiv m).sum_comp]
  simp only [groupedNode, Equiv.symm_apply_apply]
  change (∑ p : (j : Fin r) × Fin (m j),
    if groupIndex m p < groupIndex m ⟨j, k⟩ ∧ κ p.1 = κ j then 1 else 0) = (k : ℕ)
  simp_rw [prior_match_condition κ hκ m]
  rw [Fintype.sum_sigma, Fintype.sum_eq_single j]
  · simp only [true_and, eq_self_iff_true]
    have hi : univ.filter (fun l : Fin (m j) => (l : ℕ) < (k : ℕ)) = Iio k := by
      ext l
      simp
    rw [← sum_filter, hi, ← card_eq_sum_ones, Fin.card_Iio]
  · intro l hl
    simp [hl]

theorem grouped_prior_gap {K : Type*} [CommRing K] {r : ℕ}
    (κ : Fin r → K) (hκ : Function.Injective κ) (m : Fin r → ℕ)
    (q : (j : Fin r) × Fin (m j)) :
    (priorNonmatches (groupedNode κ m) (groupedNode κ m (groupIndex m q))
        (groupIndex m q)).prod (fun i : Fin (∑ j, m j) =>
          groupedNode κ m (groupIndex m q) - groupedNode κ m i) =
      ∏ j ∈ Iio q.1, (κ q.1 - κ j) ^ m j := by
  classical
  rw [groupedNode_at]
  unfold priorNonmatches
  have hs : ((Iio (groupIndex m q)).filter (fun i => groupedNode κ m i ≠ κ q.1)) =
      univ.filter (fun i => i < groupIndex m q ∧ groupedNode κ m i ≠ κ q.1) := by
    ext i
    simp
  rw [hs, prod_filter, ← (groupEquiv m).prod_comp]
  simp only [groupedNode, Equiv.symm_apply_apply]
  change (∏ p : (j : Fin r) × Fin (m j),
    if groupIndex m p < groupIndex m q ∧ κ p.1 ≠ κ q.1 then κ q.1 - κ p.1 else 1) = _
  simp_rw [prior_nonmatch_condition κ hκ m]
  rw [Fintype.prod_sigma]
  have hi : univ.filter (fun j : Fin r => j < q.1) = Iio q.1 := by ext j; simp
  rw [← hi, prod_filter]
  apply Finset.prod_congr rfl
  intro j hj
  by_cases hjq : j < q.1
  · simp [hjq]
  · simp [hjq]

theorem grouped_gap_product {K : Type*} [CommRing K] {r : ℕ}
    (κ : Fin r → K) (hκ : Function.Injective κ) (m : Fin r → ℕ) :
    (∏ i : Fin (∑ j, m j),
      (priorNonmatches (groupedNode κ m) (groupedNode κ m i) i).prod
        (fun j : Fin (∑ l, m l) => groupedNode κ m i - groupedNode κ m j)) =
      ∏ j, ∏ i ∈ Iio j, (κ j - κ i) ^ (m i * m j) := by
  classical
  rw [← (groupEquiv m).prod_comp]
  trans ∏ p : (j : Fin r) × Fin (m j), ∏ i ∈ Iio p.1, (κ p.1 - κ i) ^ m i
  · apply Finset.prod_congr rfl
    intro p hp
    exact grouped_prior_gap κ hκ m p
  rw [Fintype.prod_sigma]
  apply Finset.prod_congr rfl
  intro j hj
  change (∏ _y : Fin (m j), ∏ i ∈ Iio j, (κ j - κ i) ^ m i) = _
  rw [Fin.prod_const, ← Finset.prod_pow]
  apply Finset.prod_congr rfl
  intro i hi
  rw [← pow_mul]

#print axioms grouped_repeatedJetOrder
#print axioms grouped_gap_product
end OPICAGroupedConfluent

