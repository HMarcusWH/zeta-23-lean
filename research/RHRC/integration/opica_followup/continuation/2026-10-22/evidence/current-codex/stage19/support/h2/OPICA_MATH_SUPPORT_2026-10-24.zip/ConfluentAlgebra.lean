import Mathlib.Algebra.Polynomial.Taylor
import Mathlib.LinearAlgebra.Matrix.Block

/-! Mathlib-only algebra for the full OPICA H2a determinant route.
This file is scratch support and confers no primary-root authority. -/

noncomputable section
open Polynomial Finset
open scoped BigOperators

namespace OPICAConfluentAudit

variable {K : Type*} [CommRing K] {M : ℕ}

def functionalMatrix (L : Fin M → K[X] →ₗ[K] K) (p : Fin M → K[X]) :
    Matrix (Fin M) (Fin M) K := fun i j => L j (p i)

theorem functionalMatrix_eq_coeff_mul (L : Fin M → K[X] →ₗ[K] K)
    (p : Fin M → K[X]) (hdeg : ∀ i, (p i).natDegree < M) :
    functionalMatrix L p =
      (Matrix.of (fun i j : Fin M => (p j).coeff i)).transpose *
        functionalMatrix L (fun i => X ^ (i : ℕ)) := by
  ext i j
  change L j (p i) = ∑ k : Fin M, (p i).coeff k * L j (X ^ (k : ℕ))
  conv_lhs => rw [(p i).as_sum_range_C_mul_X_pow' (hdeg i)]
  rw [map_sum]
  rw [← Fin.sum_univ_eq_sum_range]
  apply Finset.sum_congr rfl
  intro k hk
  rw [Polynomial.C_mul', map_smul]
  rfl

theorem det_functionalMatrix_monic_basis (L : Fin M → K[X] →ₗ[K] K)
    (p : Fin M → K[X]) (hdeg : ∀ i, (p i).natDegree = (i : ℕ))
    (hmonic : ∀ i, (p i).Monic) :
    (functionalMatrix L p).det =
      (functionalMatrix L (fun i => X ^ (i : ℕ))).det := by
  rw [functionalMatrix_eq_coeff_mul L p (fun i => by rw [hdeg]; exact i.isLt),
    Matrix.det_mul, Matrix.det_transpose,
    Matrix.det_matrixOfPolynomials p hdeg hmonic, one_mul]

def hasseFunctional (κ : K) (k : ℕ) : K[X] →ₗ[K] K :=
  (Polynomial.leval κ).comp (Polynomial.hasseDeriv k)

theorem hasseFunctional_eq_taylor_coeff (κ : K) (k : ℕ) (p : K[X]) :
    hasseFunctional κ k p = (Polynomial.taylor κ p).coeff k := by
  exact (Polynomial.taylor_coeff κ p k).symm

/-- Monic Newton polynomials in an arbitrary ordered node sequence. Repeated
nodes are intentional: their number before a column is its normalized jet order. -/
def newtonPolynomial (node : Fin M → K) (i : Fin M) : K[X] :=
  ∏ j ∈ Finset.Iio i, (X - C (node j))

theorem newtonPolynomial_monic (node : Fin M → K) (i : Fin M) :
    (newtonPolynomial node i).Monic := by
  apply Polynomial.monic_prod_of_monic
  intro j hj
  exact Polynomial.monic_X_sub_C _

theorem newtonPolynomial_natDegree [Nontrivial K] (node : Fin M → K) (i : Fin M) :
    (newtonPolynomial node i).natDegree = (i : ℕ) := by
  rw [newtonPolynomial, Polynomial.natDegree_prod_of_monic]
  · simp
  · intro j hj
    exact Polynomial.monic_X_sub_C _

#print axioms functionalMatrix_eq_coeff_mul
#print axioms det_functionalMatrix_monic_basis
#print axioms newtonPolynomial_monic
#print axioms newtonPolynomial_natDegree

end OPICAConfluentAudit
