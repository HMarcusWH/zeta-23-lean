"""Retain old consumers while adding complete explicit written signatures.
These are source-bound review proposals, not independent approval or new roots.
"""
from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
specs=[
 ('source_order_uniform_norms',REPO/'Zeta23/OPICAFollowup/UniformSourceBounds.lean',''),
 ('native_field_theta_envelope',REPO/'Zeta23/OPICAFollowup/UniformSourceBounds.lean',''),
 ('near_gap_mass_bound',REPO/'Zeta23/OPICAFollowup/NearGapLimits.lean','nu hnu hself ha ha1 hgap hoff hR hd _hdhalf'),
 ('near_gap_controlled_limit_zero',REPO/'Zeta23/OPICAFollowup/NearGapLimits.lean','nu C hC hself a ha ha1 hgap hoff hlim φ'),
 ('dilation_near_gap_family',REPO/'Zeta23/OPICAFollowup/NearGapLimits.lean','L hL hu'),
 ('dilation_normalized_limit_not_measure',REPO/'Zeta23/OPICAFollowup/NearGapLimits.lean',''),
 ('fixed_basis_negative_mass_budget',HERE.parent/'audit-finite-span/FiniteSpanSeparationFullCandidate.lean','basis valid independent'),
]
pieces=[];provenance=[]
for name,path,args in specs:
    text=path.read_text(encoding='utf-8');start=text.index('theorem '+name);end=text.index(':= by',start)
    expected='expected_'+name+'_full_signature'
    sig=text[start:end].replace('theorem '+name,'theorem '+expected,1)
    pieces.append(sig+':= by\n  exact '+name+(' '+args if args else '')+'\n')
    provenance.append({'root':'Zeta23.OPICAFollowup.'+name,'companion':'Zeta23.OPICAFollowup.Validation.'+expected,
        'source':str(path),'source_line':text[:start].count('\n')+1,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'status':'COMPLETE_WRITTEN_SIGNATURE_REVIEW_PROPOSAL_INDEPENDENT_REVIEW_OPEN'})
header='''import Zeta23.OPICAFollowup
noncomputable section
open Set MeasureTheory Filter Complex
open scoped ENNReal Topology FourierTransform SchwartzMap
open Zeta23 Zeta23.OPICA Zeta23.OPICAFollowup Zeta23.OPICAFollowup.FiniteSpan
namespace Zeta23.OPICAFollowup.Validation
/- Complete explicit source-signature companions retain old consumer APIs.
No reflection-generated theorem type or independent review seal is used. -/
'''
out=header+'\n'.join(pieces)+'\nend Zeta23.OPICAFollowup.Validation\n'
(HERE/'FullSignatureCompanions.lean').write_text(out,encoding='utf-8')
(HERE/'full-signature-companion-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
