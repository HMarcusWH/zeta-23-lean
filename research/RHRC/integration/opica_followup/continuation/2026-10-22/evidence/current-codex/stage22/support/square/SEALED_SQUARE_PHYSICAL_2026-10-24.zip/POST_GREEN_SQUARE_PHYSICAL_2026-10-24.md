# Actual square measure and correction barrier — 24 October 2026

Base code commit `139c1a0d88cc0fb2d8a0d8ea71e152b25b14c36e`, tree
`3e63b0c72fc04da7bab45388d6096e82e95c4acb`.
The exact original `SquareDefect.lean` source is SHA256
`da73276d089068c1711f3854a9520fbcbbbc877d77ccc33fe20cb9ceb83d64d1`.
It is preserved as the exact byte prefix of the assembled scratch candidate,
SHA256 `c65b7b8eb6894a89a12a85e36ea660c97ca8deeb47900392786b20ae81b4ee58`.
Every original import, root statement and proof remains intact. This lane
writes only scratch files and scratch compiler outputs. Final exact commands,
source/object pins, axiom results and control dispositions are in the receipt.

**What became formally true.** The square is now a genuine locally finite
real signed measure, represented by canonical mutually singular Jordan parts:
positive `‖A-h‖² dx`, negative `‖A‖² puncturedLattice`. The source plateau
implies an exact measure gap; the origin masses vanish; the negative part
vanishes off the integer lattice. Both Jordan measures are reflection
invariant for even h. Their variation has derived linear growth. Its actual
tempered-distribution pairing equals the literal pre-existing square pairing,
and its Fourier defect is exactly integration against the original real C₀
defect. The selfdual projection is a genuine tempered distribution with the
original global density identity and every positive local gap-filling clause.
No separate global Jordan carrier for the projected distribution is claimed.

**What the correction theorem covers.** For every actual locally finite
complex measure σ, the new physical theorem assumes temperate growth of its
true Euclidean complex total variation and zero variation off ℤ. The standard
Mathlib growth class means there exists some natural n for which
`(1+‖x‖)^(-n)` is integrable against that variation. No n is fixed and no
linear-growth restriction is imposed on σ. A global measure inequality
`variationControl ≤ totalVariation + totalVariation` derives the four coordinate
growth classes internally, giving the actual complex tempered embedding.
The original no-repair periodicity argument then applies directly to genuine
measure pairings; polynomial coefficient reconstruction is unnecessary for
this domain. Adding any selfdual tempered distribution preserves the
obstruction. A separate physical consumer instantiates the true zero profile
with A=1, an arbitrary valid finite actual zero-jet combination and arbitrary
such σ. Independence and positivity of the added jet combination are not
required because its proved Fourier selfduality suffices.

**Domain firewall and primary literature.** Baake–Strungaru distinguish
distribution-tempered measures from strongly tempered measures in Definition
2.1; they need not coincide generally (Theorem 2.7). For uniformly discrete
support, Theorem 4.4 and Corollary 4.5 establish their equivalence. Hence the
integer-lattice domain admits the needed classical bridge, but this lane has
not formalized the implication from a mere tempered distribution extension
on compact smooth tests to the total-variation growth class. That additional
Lean adapter remains OPEN. The current theorem must not silently be advertised
as a formal proof of that equivalence. See their published
[A note on tempered measures, Colloquium Mathematicum 172 (2023), 15–30](https://doi.org/10.4064/cm8796-7-2022),
and the [author manuscript, arXiv:2202.09175v2](https://arxiv.org/pdf/2202.09175),
Definition 2.1, Theorem 2.7, Theorem 4.4 and Corollary 4.5.

**Workflow harvest.** These receipts are scratch formal-validity and
falsification checks, not GitHub checks or an aggregate release receipt.
The earlier complete old-head harvest is separate: 22 runs/66 jobs with
56 success, 6 failure and 4 skipped, pinned to cea7b2f6. It gives no authority
to this candidate. The owner's exact production integration and new-head
workflow harvest remain required.

**What changed.** Earlier green root checks validated raw Schwartz-test
formulas and analytic identities. The missing physical adapter is now
explicit: measure status, canonical Jordan parts, growth and distribution
identification no longer rest on terminology. All four original square roots
remain verbatim. The no-repair supplement addresses arbitrary true-TV
temperate complex measures and the projection supplement transports the
existing functional theorem to the actual square distribution. Root counts
are unchanged; these are supporting integration declarations.

**Upstream implications.** The global coordinate-variation domination extends
the existing compact factor-two inequality and permits temperate embeddings
beyond the old linear-growth domain. The proof of no repair needs only that
lattice values determine order-zero pairings and a lattice-vanishing test
pairs to zero. Temperate growth supplies the legitimate embedding, while the
periodicity contradiction itself does not depend on a growth degree.

**Downstream implications.** The mixed repair route is blocked in the proved
measure domain: square plus any selfdual tempered distribution plus any
temperate lattice measure cannot become selfdual. The actual finite zero-jet
span is one source-specific instance. DERIVED from S3.2 at A=1: every actual
zero profile has defect at the origin at least one; its selfdual projection
has density at the origin at least one half. The newly proved selfdual-addition
algebra preserves the same defect before the lattice correction. This is
neither an off-critical-zero exclusion nor an RH implication: critical-line
zeros satisfy the same source hypotheses.

**Resurrected routes and creative clues.** LEAD: use the now explicit square
carrier and mixed barrier to classify corrections that genuinely remain:
nonlattice, nonselfdual corrections whose defect cancels the continuous C₀
defect while preserving the required source gap/sign. The finite linear
selfdual span cannot supply that cancellation. A generic formal theorem
turning discrete-support tempered extensions into total-variation growth
would compress several future physical adapters. A fixed translated bump and
Schwartz seminorm bound, or the smooth sign-separation route in the cited
paper, are concrete approaches.

**Falsification checks.** A zero h with A=1 has positive mass two in the
purported gap, so the plateau premise is essential. The atom at integer one
is retained exactly, so removing the origin did not accidentally erase the
comb. The zero h,A=0 case gives the actual zero measure. Negative controls
reject omission of the plateau, omission of actual lattice support and an
invented tempered embedding without the required genuine growth class.
These are exact controls; no experiment is promoted to theorem authority.
The literature also rules out casually identifying all signed/complex
distribution-tempered measures with total-variation temperate measures away
from the uniformly discrete setting.

**Highest-leverage next moves.** Replay the exact assembled source and full
physical consumers after owner integration. Resolve the distribution-only
temperateness bridge in Lean before any stronger formal all-domain coverage
claim; the cited classical theorem alone is not kernel authority. Then run
the full cold compiler, parent-extension, registry/dependency, canonical-graph
and independent-review obligations, together with complete new-head workflow
harvest. Investigate actual nonlattice correction obstructions rather than
retrying the now blocked sum of a square, selfdual finite span and lattice
repair. The Jordan, temperate-measure and periodicity mechanisms are classical;
the new work is their source-specific formal realization and composition.

RH, Step4 and aggregate release remain OPEN.
