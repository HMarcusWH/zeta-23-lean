"""Collect exact warm overlay evidence; do not certify contract/release approval."""
from pathlib import Path
import datetime, hashlib, json, re, subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'opica-followup-repo'
OVERLAY = HERE / 'overlay'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
roots = json.loads((REPO / 'research/RHRC/integration/opica_followup/PUBLIC_ROOTS.json').read_text())['roots']
companions = json.loads((HERE / 'full-signature-companion-provenance.json').read_text())
names = ['Zeta23.OPICAFollowup.Validation.' + r['expected_type_consumer'] for r in roots]
names += [r['companion'] for r in companions]
names += ['Zeta23.OPICAFollowup.Validation.' + s for s in [
    'expected_canonical_recovery', 'expected_filter_causal_actions',
    'expected_followup_native_output', 'expected_followup_native_output_each_phase']]
assert len(names) == 111 and len(set(names)) == 111
allowed = {'propext', 'Classical.choice', 'Quot.sound'}

def parse(log):
    data = log.read_text(encoding='utf-8')
    assert 'error:' not in data and 'sorryAx' not in data, log
    printed = {}
    for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]", data, re.S):
        axes = {a.strip() for a in m[2].split(',') if a.strip()}
        assert axes <= allowed, (log, m[1], axes)
        printed[m[1]] = sorted(axes)
    for m in re.finditer(r"'([^']+)' does not depend on any axioms", data):
        printed[m[1]] = []
    return printed

module_rows = []
module_axioms = {}
for module in ['NativeFilters', 'JointObservation', 'Consumers', 'OPICAFollowup', 'Validation']:
    rel = 'Zeta23/OPICAFollowup.lean' if module == 'OPICAFollowup' else 'Zeta23/OPICAFollowup/' + module + '.lean'
    path = OVERLAY / rel
    log = HERE / (module + 'Stage22Overlay.log')
    printed = parse(log)
    module_axioms.update(printed)
    module_rows.append({'module': rel[:-5].replace('/', '.'), 'source': str(path.relative_to(HERE)).replace('\\', '/'),
        'source_sha256': sha(path), 'log': log.name, 'log_sha256': sha(log),
        'observed_native_exit_code': 0,
        'argv': ['C:/Users/macka/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean.exe',
            '-DmaxHeartbeats=800000', '--root=' + str(OVERLAY), str(path), '-o', str(path.with_suffix('.olean'))]})
assert set(names) <= set(module_axioms), set(names) - set(module_axioms)
base = json.loads((HERE / 'stage22-overlay-provenance.json').read_text())
base['status'] = 'WARM_ASSEMBLED_SOURCE_COMPILER_CHECKS_PASS_UNACCEPTED'
for row in base['assembly']:
    assert sha(OVERLAY / row['path']) == row['assembled_sha256'], row
owner_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
owner_tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip()
assert owner_head == base['base_head'] and owner_tree == base['base_tree']
tracked = subprocess.check_output(['git', 'ls-files', 'Zeta23', 'lake-manifest.json', 'lakefile.lean', 'lean-toolchain'], cwd=REPO, text=True).splitlines()
source_manifest = {p: sha(REPO / p) for p in tracked if (REPO / p).is_file() and (p.endswith('.lean') or p in ['lake-manifest.json', 'lean-toolchain'])}
receipt = {'schema': 'OPICA_STAGE22_WARM_ASSEMBLED_PROPOSAL_V1',
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': base['status'], 'owner_head': owner_head, 'owner_tree': owner_tree,
    'owner_working_status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).splitlines(),
    'assembly_provenance': base,
    'compiler': 'Lean4.33.0-rc2 x86_64-w64-windows-gnu commit d8b18978322de05a8f3dba51ef03cf5461676c17',
    'isolation': 'Scratch source and object overlay first in explicit LEAN_PATH, followed by inherited project and pinned dependency objects; no owner file/cache writes. Not a cold source-built closure.',
    'modules': module_rows, 'owner_source_manifest_sha256': hashlib.sha256(json.dumps(source_manifest, sort_keys=True).encode()).hexdigest(),
    'owner_source_manifest': source_manifest,
    'required_expected_name_count': 100, 'full_signature_companion_count': 7, 'canonical_physical_consumer_count': 4,
    'explicit_expected_axiom_audits': {name: module_axioms[name] for name in names},
    'all_printed_positive_axiom_audits': module_axioms,
    'independent_full_clause_physical_domain_review': 'NOT_ESTABLISHED',
    'definition_origin_implementation_dependency_review': 'NOT_ESTABLISHED',
    'canonical_human_review_seal': 'UNSET', 'registry_acceptance': 'NOT_ESTABLISHED',
    'full100_cold_receipt': 'NOT_ESTABLISHED', 'owner_final_clean_replay': 'REQUIRED',
    'release_ready': False, 'full_release_accepted': False, 'RH': 'OPEN', 'Step4': 'OPEN'}
(HERE / 'stage22-overlay-provenance.json').write_text(json.dumps(base, indent=2) + '\n', encoding='utf-8')
(HERE / 'stage22-warm-assembled-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print('Five assembled modules PASS;111 explicit positive expected/companion audits standard-only; review and release remain unestablished.')
