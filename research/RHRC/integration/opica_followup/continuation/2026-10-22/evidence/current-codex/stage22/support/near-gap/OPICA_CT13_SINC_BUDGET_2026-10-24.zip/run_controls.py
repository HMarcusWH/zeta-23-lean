from pathlib import Path
import hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
rows=[]
for name in ['WrongFactorControl','WrongSlopeControl']:
    process=subprocess.run([sys.executable,'-B',str(HERE/'compile.py'),name],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=(HERE/(name+'.log')).read_text(encoding='utf-8')
    row=json.loads((HERE/(name+'.receipt.json')).read_text())
    row['expected_disposition']='COMPILER_REJECTION_OF_CHANGED_MATHEMATICAL_CONCLUSION'
    row['negative_error_recovery_axioms_are_not_authority']=True
    row['expected_disposition_observed']=process.returncode!=0 and row['exit_code']!=0 and 'Type mismatch' in log
    rows.append(row)
    if not row['expected_disposition_observed']:
        raise SystemExit(name+' unexpected disposition; inspect preserved source/log')
    print(name,'REJECTED_AS_EXPECTED',flush=True)
(HERE/'negative-controls.json').write_text(json.dumps({'schema':'OPICA_CT13_NEGATIVE_CONTROLS_V1',
 'status':'TWO_CHANGED_CONCLUSIONS_REJECTED','controls':rows,'primary_root_increment':0,
 'release_ready':False,'RH':'OPEN','Step4':'OPEN'},indent=2)+'\n',encoding='utf-8')
