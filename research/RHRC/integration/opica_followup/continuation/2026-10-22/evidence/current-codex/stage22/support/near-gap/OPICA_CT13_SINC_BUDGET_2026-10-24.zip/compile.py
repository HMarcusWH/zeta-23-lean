from pathlib import Path
import hashlib, json, os, subprocess, sys, time
sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'opica-followup-repo'
LEAN = Path('C:/Users/macka/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean.exe')
env = os.environ.copy()
env['LEAN_PATH'] = ';'.join(map(str, [HERE, REPO/'.lake/build/lib/lean', *sorted((REPO/'.lake/packages').glob('*/.lake/build/lib/lean'))]))
env['LEAN_NUM_THREADS'] = '1'
name = sys.argv[1]
source = HERE / (name + '.lean'); log = HERE / (name + '.log')
before = hashlib.sha256(source.read_bytes()).hexdigest()
argv = [str(LEAN), '-DmaxHeartbeats=800000', '--root='+str(HERE), str(source), '-o', str(HERE / (name + '.olean'))]
started = time.monotonic()
run = subprocess.run(argv, cwd=REPO, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1800)
log.write_bytes(run.stdout)
receipt = {'schema':'OPICA_CT13_SCRATCH_COMPILER_V1','name':name,'source_sha256':before,
 'source_unchanged':before==hashlib.sha256(source.read_bytes()).hexdigest(),'argv':argv,
 'exit_code':run.returncode,'seconds':time.monotonic()-started,'log_sha256':hashlib.sha256(run.stdout).hexdigest(),
 'owner_head':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),
 'owner_status':subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'],text=True).splitlines(),
 'isolation':'Outside-checkout source/object; inherited project and pinned dependency objects; warm only.',
 'primary_root_increment':0,'release_ready':False,'RH':'OPEN','Step4':'OPEN'}
(HERE/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(name,run.returncode,log)
print(run.stdout.decode('utf-8',errors='replace')[-10000:])
raise SystemExit(run.returncode)
