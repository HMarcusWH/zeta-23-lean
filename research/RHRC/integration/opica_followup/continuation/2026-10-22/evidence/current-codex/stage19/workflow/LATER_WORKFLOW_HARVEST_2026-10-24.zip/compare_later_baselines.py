import hashlib, json, re, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT/'later-baseline-artifacts'
api = json.loads((OLD/'API_RECORDS.json').read_text())
integrity = []
for row in api:
    p = OLD/(str(row['id'])+'.zip')
    actual = hashlib.sha256(p.read_bytes()).hexdigest()
    assert actual == row['digest'].removeprefix('sha256:'), row['id']
    integrity.append({'file': p.name, 'sha256': actual, 'matches': True})

def read_members(path):
    with zipfile.ZipFile(path) as z:
        return {n:z.read(n) for n in z.namelist() if not n.endswith('/')}

def parse(text):
    decoder = json.JSONDecoder()
    text = re.sub(r'^\d{4}-\d\d-\d\dT[\d:.]+Z ', '', text, flags=re.M)
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    out, end = [], -1
    for m in re.finditer(r'(?m)^\s*\{', text):
        if m.start() < end:
            continue
        try:
            value, length = decoder.raw_decode(text[m.start():].lstrip())
            if isinstance(value, dict):
                out.append(value)
                end = m.start()+length
        except json.JSONDecodeError:
            pass
    return out

def diffs(a,b,path=''):
    if type(a) is not type(b):
        return [{'field':path,'current':a,'prior':b}]
    if isinstance(a,dict):
        return [r for k in sorted(set(a)|set(b)) for r in diffs(a.get(k),b.get(k),path+'.'+str(k))]
    if isinstance(a,list):
        if len(a)!=len(b):
            return [{'field':path+'.length','current':len(a),'prior':len(b)}]
        return [r for i,(x,y) in enumerate(zip(a,b)) for r in diffs(x,y,path+'['+str(i)+']')]
    return [] if a==b else [{'field':path,'current':a,'prior':b}]

old_members = {}
for row in api:
    if row['name'].startswith('post268-extended-'):
        for name,raw in read_members(OLD/(str(row['id'])+'.zip')).items():
            if name.endswith('.log'):
                assert name not in old_members
                old_members[name] = raw

current = json.loads((ROOT/'later-science/POST268_ALL44_SCIENCE.json').read_text())
comparisons=[]
for row in current['results']:
    oldraw=old_members[row['log']]
    oldparsed=parse(oldraw.decode('utf-8',errors='replace'))
    newarchive=ROOT/'later-artifacts'/row['verified_archive']
    if not newarchive.exists(): newarchive=ROOT/row['verified_archive']
    newraw=read_members(newarchive)[row['log']]
    newparsed=parse(newraw.decode('utf-8',errors='replace'))
    comparisons.append({'id':row['id'],'prior_head':'c6ce649d200e1bbbcbf7702634b95681a55ae207',
        'current_head':current['head'],'prior_log_sha256':hashlib.sha256(oldraw).hexdigest(),
        'current_log_sha256':hashlib.sha256(newraw).hexdigest(),'full_log_bytes_equal':oldraw==newraw,
        'parsed_json_equal':oldparsed==newparsed,'json_outputs':len(newparsed),
        'json_differences':diffs(newparsed,oldparsed),
        'frozen_baseline_comparison_label':row['comparison'],
        'note':'Frozen-baseline execution label is distinct from this preceding-head source/result comparison.'})

source_old=read_members(OLD/'12561240210.zip')
source_new=read_members(ROOT/'later-artifacts/12564610299.zip')
source_cmp=[]
for name in sorted(set(source_old)&set(source_new)):
    if name.endswith('.json'):
        a,b=json.loads(source_new[name]),json.loads(source_old[name])
        dd=diffs(a,b)
        provenance=lambda p: bool(re.search(r'\.seconds$|\.runtime_seconds$|\.elapsed_seconds$|\.git\.|\.source_identity\.',p))
        source_cmp.append({'file':name,'json_equal':a==b,'differences':dd,
                           'differences_beyond_named_runtime_and_git_fields':[x for x in dd if not provenance(x['field'])]})
    elif name.endswith('.txt'):
        source_cmp.append({'file':name,'bytes_equal':source_new[name]==source_old[name]})

old_contact=read_members(OLD/'12560246077.zip')
new_contact=read_members(ROOT/'later-artifacts/12562537218.zip')
contact=[]
for base in ['POST282_CONTACT_CALCULUS.json','POST282_CONTACT_CALCULUS_RECEIPT.json','POST282_CONTACT_CALCULUS_OBLIGATIONS.json']:
    get=lambda d:next(v for k,v in d.items() if k==base or k.endswith('/'+base))
    a,b=json.loads(get(new_contact)),json.loads(get(old_contact))
    contact.append({'file':base,'json_equal':a==b,'differences':diffs(a,b)})

out={'schema':'OPICA_LATER_PRECEDING_HEAD_COMPARISON_V1','prior_head':'c6ce649d200e1bbbcbf7702634b95681a55ae207',
     'current_head':current['head'],'archive_integrity':integrity,'post268':comparisons,
     'post268_totals':{'full_logs_equal':sum(x['full_log_bytes_equal'] for x in comparisons),
                       'parsed_json_equal':sum(x['parsed_json_equal'] for x in comparisons),'total':44},
     'source_falsifier':{'prior_job_cancelled':True,'compared_shared_files':source_cmp,
                         'newly_available_artifact_members':sorted(set(source_new)-set(source_old))},
     'contact_calculus':contact,'RH':'OPEN','Step4':'OPEN'}
(ROOT/'later-science/PRECEDING_HEAD_COMPARISON.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'post268_totals':out['post268_totals'],
                  'post268_json_differences':[{'id':x['id'],'diffs':x['json_differences']} for x in comparisons if x['json_differences']],
                  'source_shared':len(source_cmp),'source_changed':[{ 'file':x['file'],'diff_count':len(x.get('differences',[])),
                    'non_runtime_diff_count':len(x.get('differences_beyond_named_runtime_and_git_fields',[])),
                    'difference_sample':x.get('differences_beyond_named_runtime_and_git_fields',[])[:3]} for x in source_cmp if not x.get('json_equal',x.get('bytes_equal'))],
                  'source_new':out['source_falsifier']['newly_available_artifact_members'],
                  'contact':[{'file':x['file'],'equal':x['json_equal'],'diffs':x['differences'][:5],'diff_count':len(x['differences'])} for x in contact]},indent=2))
