from pathlib import Path
import hashlib, json
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
old=REPO/'Zeta23/OPICAFollowup/NearGapLimits.lean'
target=HERE/'production-overlay/Zeta23/OPICAFollowup/NearGapLimits.lean'
target.parent.mkdir(parents=True,exist_ok=True)
prefix=old.read_bytes()
assert hashlib.sha256(prefix).hexdigest()=='300aba8c18e0079c7df0b02dd804ed3d2dc266dacd18930c7bab962cf7dd8b35','Owner source moved; do not append twice or transfer old evidence.'
fragments=[]
for filename in ['CT13.lean','CT13Limits.lean']:
    data=(HERE/filename).read_bytes()
    fragments.append(data.split(b'\n',1)[1])
append=b'\n'.join(fragments)
target.write_bytes(prefix+b'\n'+append)
(HERE/'NearGapCT13Append.lean.txt').write_bytes(append)
consumer=(HERE/'ExpectedCT1SincBudget.lean').read_text(encoding='utf-8').replace('import CT13Limits','import Zeta23.OPICAFollowup.NearGapLimits',1)
(HERE/'ExpectedCT1SincBudgetProduction.lean').write_text(consumer,encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={'schema':'OPICA_CT13_APPEND_ONLY_PROPOSAL_V1','status':'SUPPORTING_ONLY_ZERO_PRIMARY_INCREMENT',
 'repository_path':'Zeta23/OPICAFollowup/NearGapLimits.lean','base_source_sha256':sha(old),
 'candidate_source':'production-overlay/Zeta23/OPICAFollowup/NearGapLimits.lean','candidate_sha256':sha(target),
 'append_source':'NearGapCT13Append.lean.txt','append_sha256':sha(HERE/'NearGapCT13Append.lean.txt'),
 'exact_old_source_byte_prefix_preserved':target.read_bytes().startswith(prefix),
 'only_standalone_self_imports_stripped':True,'new_project_imports':[],'new_Mathlib_imports':[],
 'independent_consumer':'ExpectedCT1SincBudgetProduction.lean','independent_consumer_sha256':sha(HERE/'ExpectedCT1SincBudgetProduction.lean'),
 'primary_root_increment':0,'independent_full_acceptance':'NOT_ESTABLISHED','release_ready':False,'RH':'OPEN','Step4':'OPEN'}
(HERE/'production-append-proposal.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
