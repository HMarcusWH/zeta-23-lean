import NativeAsymptoticCosts
import NativeWindowUpperRate

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23.OPICA
namespace Zeta23.OPICAFollowup.Stage19Rate.Asymptotic

theorem actualInput_rational_ratio_log_rate_zero (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    (rho : zetaZeroConfig.carrier) (hright : 1/2 < (rho : ℂ).re)
    (xi : ℝ) (hxi : 0 ≤ xi) :
    Tendsto (fun n => Real.log (1+
      ‖nativeAuxiliaryStableVector (completionIndex xi (T.time n)) (d n)‖/
        ‖auxRationalFactor (completionIndex xi (T.time n)) ((rho : ℂ)-1/2)‖)/T.time n)
      atTop (𝓝 0) := by
  obtain ⟨Cp,Cs,hCp,hCs,hbound⟩ := actualInput_div_rational_bound rho hright
  have hk := (completionIndex_div_time_tendsto_zero xi hxi).comp T.cofinal
  have h1 : Tendsto (fun n => (1 : ℝ)/T.time n) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop T.cofinal
  have hlog2 : Tendsto (fun n => Real.log 2/T.time n) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop T.cofinal
  have horder := fullSourceOrderCost_div_time_tendsto_zero T d hd
  have hu : Tendsto (fun n => Real.log 2/T.time n+
      Cp*((completionIndex xi (T.time n) : ℝ)/T.time n+1/T.time n)+
      Cs*(((d n : ℝ)+1)*Real.log ((d n : ℝ)+2)/T.time n)) atTop (𝓝 0) := by
    simpa using (hlog2.add ((hk.add h1).const_mul Cp)).add (horder.const_mul Cs)
  apply squeeze_zero (fun n => div_nonneg (Real.log_nonneg (by
    have h : 0 ≤ ‖nativeAuxiliaryStableVector (completionIndex xi (T.time n)) (d n)‖/
        ‖auxRationalFactor (completionIndex xi (T.time n)) ((rho : ℂ)-1/2)‖ :=
      div_nonneg (norm_nonneg _) (norm_nonneg _)
    linarith)) (T.positive n).le) _ hu
  intro n
  let k := completionIndex xi (T.time n)
  let B := Cp*((k : ℝ)+1)+Cs*((d n : ℝ)+1)*Real.log ((d n : ℝ)+2)
  have hB : 0 ≤ B := by
    have hlog : 0 ≤ Real.log ((d n : ℝ)+2) :=
      Real.log_nonneg (by linarith [Nat.cast_nonneg (α := ℝ) (d n)])
    dsimp [B]
    positivity
  have hb : ‖nativeAuxiliaryStableVector k (d n)‖/‖auxRationalFactor k ((rho : ℂ)-1/2)‖ ≤
      Real.exp B := hbound k (d n) (completionIndex_one_le xi (T.time n))
  have he : 1 ≤ Real.exp B := Real.one_le_exp hB
  have hbig : 1+‖nativeAuxiliaryStableVector k (d n)‖/‖auxRationalFactor k ((rho : ℂ)-1/2)‖ ≤
      2*Real.exp B := by
    linarith
  have hpos : 0 < 1+‖nativeAuxiliaryStableVector k (d n)‖/‖auxRationalFactor k ((rho : ℂ)-1/2)‖ :=
    by positivity
  have hlog := Real.log_le_log hpos hbig
  rw [Real.log_mul (by norm_num) (Real.exp_ne_zero _),Real.log_exp] at hlog
  exact (div_le_div_of_nonneg_right hlog (T.positive n).le).trans_eq (by dsimp [B,k]; ring)

#print axioms actualInput_rational_ratio_log_rate_zero
end Zeta23.OPICAFollowup.Stage19Rate.Asymptotic
