import AccumulatingRightCellCoefficientBridge
import ActualMeasureCellAccumulation
import RightCellIndependence

/-! Actual zero-measure independence in cumulative occurrence order.
This is not the frozen grouped primary theorem: the canonical (j,k) indexing
and grouped determinant product remain separate proof obligations. -/

noncomputable section
set_option maxHeartbeats 800000
open Set MeasureTheory Filter Complex Polynomial Finset
open scoped Topology SchwartzMap FourierTransform
namespace OPICAActualMeasureCell
open Zeta23.OPICAFollowup OPICAConfluentAudit OPICARightCellTaylor

theorem expanded_actual_zero_measure_jet_independent {M : ℕ}
    (ρ : Fin M → ℂ) (c : Fin M → ℂ)
    (h0 : ∀ i, 0 < (ρ i).re) (h1 : ∀ i, (ρ i).re < 1)
    (hz : ∀ i, riemannZeta (ρ i) = 0)
    (hk : ∀ i, repeatedJetOrder (fun j => spectralKappa (ρ j)) i < zeroJetOrder (ρ i))
    (hzero : (∑ i, c i •
      (normalizedZeroMeasureJet (ρ i) (repeatedJetOrder (fun j => spectralKappa (ρ j)) i)).distributionOfLinearGrowth
        (normalizedZeroMeasureJet_hasLinearGrowth (h0 i) (h1 i) (zero_ne_half (hz i)) (hk i))) = 0) :
    c = 0 := by
  classical
  let node : Fin M → ℂ := fun i => spectralKappa (ρ i)
  have hnode (i : Fin M) : node i ≠ 0 := by
    obtain ⟨hρ0, hρ1⟩ := strip_ne (h0 i) (h1 i)
    exact mul_ne_zero hρ0 (sub_ne_zero.mpr (Ne.symm hρ1))
  have hAE := actual_jet_combination_first_cell_ae_zero c ρ (repeatedJetOrder node)
    h0 h1 (fun i => zero_ne_half (hz i)) hk hzero
  have hacc : ∀ ε : ℝ, 0 < ε → ∃ u : ℝ, 0 < u ∧ u < ε ∧
      ∑ i, c i * rightCellJet (node i) (repeatedJetOrder node i) u = 0 := by
    intro ε hε
    obtain ⟨u, hu0, huε, hu2, hvan⟩ :=
      first_cell_ae_zero_gives_accumulating_right_cell_zeros c node (repeatedJetOrder node) hAE hε
    exact ⟨u, hu0, huε, hvan⟩
  have hrows := accumulating_rightCell_combination_polynomial_rows_zero
    node (repeatedJetOrder node) c hacc
  let A : Matrix (Fin M) (Fin M) ℂ := functionalMatrix
    (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
    (fun i => X * (C (1 / 4 : ℂ) - X) ^ (i : ℕ))
  have hdet : A.det ≠ 0 := by
    rw [show A = _ from rfl, profilePolynomial_confluent_expanded_determinant node hnode]
    apply mul_ne_zero
    · exact mul_ne_zero (pow_ne_zero _ (by norm_num))
        (Finset.prod_ne_zero_iff.mpr (fun i _ => hnode i))
    · apply Finset.prod_ne_zero_iff.mpr
      intro i hi
      apply Finset.prod_ne_zero_iff.mpr
      intro j hj
      have hjne : node j ≠ node i := (Finset.mem_filter.mp hj).2
      exact sub_ne_zero.mpr (Ne.symm hjne)
  apply Matrix.eq_zero_of_mulVec_eq_zero hdet
  ext i
  change ∑ j, A i j * c j = 0
  have hrow (j : Fin M) : A i j = iteratedDeriv (repeatedJetOrder node j)
      (fun w : ℂ => w * (1 / 4 - w) ^ (i : ℕ)) (node j) /
        ((repeatedJetOrder node j).factorial : ℂ) := by
    exact actual_polynomial_row (node j) (repeatedJetOrder node j) (i : ℕ)
  simp_rw [hrow, mul_comm]
  exact hrows (i : ℕ)

#print axioms expanded_actual_zero_measure_jet_independent
end OPICAActualMeasureCell
