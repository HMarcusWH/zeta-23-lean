param([int]$StartIndex = 0)
$ErrorActionPreference = 'Stop'
$opicaAuditRepo = Join-Path $PSScriptRoot '../opica-followup-repo'
$opicaAuditLean = 'C:/Users/macka/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean.exe'
$opicaAuditPaths = @(Get-ChildItem "$opicaAuditRepo/.lake/packages" -Directory | ForEach-Object { Join-Path $_.FullName '.lake/build/lib/lean' })
$opicaAuditPaths += Join-Path $opicaAuditRepo '.lake/build/lib/lean'
$opicaAuditPaths += $PSScriptRoot
$env:LEAN_PATH = $opicaAuditPaths -join ';'
Push-Location $PSScriptRoot
try {
  $opicaAuditResults = @()
  if ($StartIndex -gt 0) {
    $opicaAuditPrevious = Get-Content confluent-algebra-receipt.json -Raw | ConvertFrom-Json
    $opicaAuditResults = @($opicaAuditPrevious.results | Select-Object -First $StartIndex)
    foreach ($opicaAuditPrior in $opicaAuditResults) {
      if (($opicaAuditPrior.expected_disposition -eq 'PASS') -and ($opicaAuditPrior.exit_code -ne 0)) { throw 'Cannot reuse a failed positive prefix gate' }
      if (($opicaAuditPrior.expected_disposition -eq 'REJECT') -and ($opicaAuditPrior.exit_code -eq 0)) { throw 'Cannot reuse an accepted negative control' }
      if ((Get-FileHash $opicaAuditPrior.source -Algorithm SHA256).Hash.ToLower() -ne $opicaAuditPrior.source_sha256) { throw 'Source changed in reused prefix' }
      if ((Get-FileHash $opicaAuditPrior.log -Algorithm SHA256).Hash.ToLower() -ne $opicaAuditPrior.log_sha256) { throw 'Compiler log changed in reused prefix' }
      if (-not $opicaAuditPrior.checked_repository_head) { $opicaAuditPrior | Add-Member checked_repository_head $opicaAuditPrevious.repository_head }
      if (-not $opicaAuditPrior.checked_repository_committed_tree) { $opicaAuditPrior | Add-Member checked_repository_committed_tree $opicaAuditPrevious.repository_committed_tree }
    }
  }
  $opicaAuditNames = @('ConfluentAlgebra', 'NewtonHermite', 'CoordinateConfluent', 'AffineConfluent', 'ExpectedConfluentAlgebra', 'NegativeConfluentSign', 'NegativeConfluentFactorial', 'HasseNormalizedDerivative', 'ActualFirstCell', 'ExpectedActualFirstCell', 'PhysicalBoundaryCountercontrol')
  foreach ($opicaAuditName in @($opicaAuditNames | Select-Object -Skip $StartIndex)) {
    $opicaAuditArgs = @('-o', "$opicaAuditName.olean", "$opicaAuditName.lean")
    $opicaAuditHeadBefore = (& git -C $opicaAuditRepo rev-parse HEAD)
    $opicaAuditTreeBefore = (& git -C $opicaAuditRepo rev-parse 'HEAD^{tree}')
    $opicaAuditSourceBefore = (Get-FileHash "$opicaAuditName.lean" -Algorithm SHA256).Hash.ToLower()
    & $opicaAuditLean @opicaAuditArgs *> "$opicaAuditName.log"
    $opicaAuditCode = $LASTEXITCODE
    if ((Get-FileHash "$opicaAuditName.lean" -Algorithm SHA256).Hash.ToLower() -ne $opicaAuditSourceBefore) { throw 'Source changed during compilation' }
    $opicaAuditExpected = $(if ($opicaAuditName.StartsWith('Negative')) { 'REJECT' } else { 'PASS' })
    $opicaAuditResults += [ordered]@{
      source = "$opicaAuditName.lean"
      source_sha256 = $opicaAuditSourceBefore
      checked_repository_head = $opicaAuditHeadBefore
      checked_repository_committed_tree = $opicaAuditTreeBefore
      compiler = $opicaAuditLean
      arguments = $opicaAuditArgs
      exit_code = $opicaAuditCode
      expected_disposition = $opicaAuditExpected
      log = "$opicaAuditName.log"
      log_sha256 = (Get-FileHash "$opicaAuditName.log" -Algorithm SHA256).Hash.ToLower()
    }
    Write-Output "$opicaAuditName exit=$opicaAuditCode expected=$opicaAuditExpected"
    if (($opicaAuditExpected -eq 'PASS') -and ($opicaAuditCode -ne 0)) { break }
  }
  [ordered]@{
    schema = 'OPICA_SCRATCH_CONFLUENT_ALGEBRA_V1'
    date_utc = [DateTime]::UtcNow.ToString('o')
    repository_head = (& git -C $opicaAuditRepo rev-parse HEAD)
    repository_committed_tree = (& git -C $opicaAuditRepo rev-parse 'HEAD^{tree}')
    compiler_version = (& $opicaAuditLean --version)
    project_import_source_hashes = @('Zeta23/OPICAFollowup/CoPoissonJets.lean', 'Zeta23/OPICAFollowup/ZeroProfiles.lean', 'lean-toolchain', 'lake-manifest.json') | ForEach-Object {
      [ordered]@{ path = $_; sha256 = (Get-FileHash (Join-Path $opicaAuditRepo $_) -Algorithm SHA256).Hash.ToLower() }
    }
    results = $opicaAuditResults
    primary_root_authority = 'NONE; physical first-cell and grouped-index bridges remain required'
  } | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 confluent-algebra-receipt.json
  Get-Content confluent-algebra-receipt.json
} finally {
  Pop-Location
}
