import ShCoefficientExtraction

noncomputable section
open Set Filter Complex
open scoped Topology

namespace OPICAShCoefficientExtraction

/-- Uniform higher-order bounds along arbitrarily small positive
parameters force a leading coefficient to vanish. -/
theorem eq_zero_of_accumulating_monomial_bound (c : ℂ) (d : ℕ) (C : ℝ)
    (h : ∀ ε : ℝ, 0 < ε → ∃ u : ℝ, 0 < u ∧ u < ε ∧
      ‖c * (u : ℂ) ^ d‖ ≤ C * u ^ (d + 2)) : c = 0 := by
  have hex : ∀ n : ℕ, ∃ u : ℝ, 0 < u ∧ u < 1 / ((n : ℝ) + 1) ∧
      ‖c * (u : ℂ) ^ d‖ ≤ C * u ^ (d + 2) := by
    intro n
    exact h _ (by positivity)
  choose u hu0 hus hub using hex
  have hut : Tendsto u atTop (𝓝 0) :=
    squeeze_zero (fun n => (hu0 n).le) (fun n => (hus n).le)
      tendsto_one_div_add_atTop_nhds_zero_nat
  have hb : ∀ n : ℕ, ‖c‖ ≤ C * (u n) ^ 2 := by
    intro n
    have hp : 0 < (u n) ^ d := pow_pos (hu0 n) d
    have hn := hub n
    rw [norm_mul, norm_pow, Complex.norm_real, Real.norm_eq_abs,
      abs_of_pos (hu0 n), pow_add] at hn
    apply (mul_le_mul_iff_of_pos_right hp).mp
    calc ‖c‖ * (u n) ^ d ≤ C * ((u n) ^ d * (u n) ^ 2) := hn
      _ = (C * (u n) ^ 2) * (u n) ^ d := by ring
  have hlim : Tendsto (fun n : ℕ => C * (u n) ^ 2) atTop (𝓝 0) := by
    simpa only [zero_pow two_ne_zero, mul_zero] using tendsto_const_nhds.mul (hut.pow 2)
  have hn : ‖c‖ ≤ 0 :=
    le_of_tendsto_of_tendsto tendsto_const_nhds hlim (Eventually.of_forall hb)
  exact norm_eq_zero.mp (le_antisymm hn (norm_nonneg c))

/-- Coefficient extraction needs only a set of valid parameters
accumulating at zero, provided each error constant is independent of the
chosen small parameter. -/
theorem odd_coefficients_eq_zero_of_accumulating_remainder_bound
    (c : ℕ → ℂ)
    (h : ∀ n : ℕ, ∃ C : ℝ, ∀ ε : ℝ, 0 < ε → ∃ u : ℝ, 0 < u ∧ u < ε ∧
      ‖∑ j ∈ Finset.range (n + 1), c j * (u : ℂ) ^ (2 * j + 1)‖ ≤
        C * u ^ (2 * n + 3)) : ∀ n : ℕ, c n = 0 := by
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    obtain ⟨C, hC⟩ := h n
    apply eq_zero_of_accumulating_monomial_bound (c n) (2 * n + 1) C
    intro ε hε
    obtain ⟨u, hu0, huε, hub⟩ := hC ε hε
    refine ⟨u, hu0, huε, ?_⟩
    have hs : (∑ j ∈ Finset.range (n + 1), c j * (u : ℂ) ^ (2 * j + 1)) =
        c n * (u : ℂ) ^ (2 * n + 1) := by
      apply Finset.sum_eq_single n
      · intro j hj hjn
        have hjlt : j < n := by have := Finset.mem_range.mp hj; omega
        rw [ih j hjlt, zero_mul]
      · simp
    rw [hs] at hub
    simpa [show 2 * n + 1 + 2 = 2 * n + 3 by omega] using hub

#print axioms eq_zero_of_accumulating_monomial_bound
#print axioms odd_coefficients_eq_zero_of_accumulating_remainder_bound

end OPICAShCoefficientExtraction
