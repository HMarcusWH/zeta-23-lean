from pathlib import Path
import json,re,hashlib,sys
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
BASE=REPO/'research/RHRC/integration/opica_followup'
manifest=json.loads((BASE/'BUILD_MANIFEST.json').read_text())
rows={m['module']:m for m in manifest['modules']}
overlay=HERE/'overlay'
reached=set();todo=list(rows['Zeta23.OPICAFollowup.Consumers']['direct_project_imports'])
while todo:
    mod=todo.pop()
    if mod in reached:continue
    reached.add(mod)
    path=mod.replace('.','/')+'.lean'
    source=overlay/path
    if not source.exists():source=REPO/path
    if source.exists():todo.extend(re.findall(r'(?m)^import\s+(Zeta23(?:\.[A-Za-z0-9_]+)*)',source.read_text(encoding='utf-8')))
consumers=overlay/'Zeta23/OPICAFollowup/Consumers.lean'
body=re.sub(r'(?m)^import\s+Zeta23[^\n]*\n','',consumers.read_text(encoding='utf-8'))
consumer_imports=list(rows['Zeta23.OPICAFollowup.Consumers']['direct_project_imports'])
if '--include-required-native-adapter-proposal' in sys.argv:
    consumer_imports.insert(0,'Zeta23.OPICA.NativeJetAdapter')
imports='\n'.join('import '+m for m in consumer_imports)+'\n'
consumers.write_text(imports+body,encoding='utf-8')
facade='import Zeta23.OPICAFollowup.Consumers\n\n/-! Frozen public sibling entrypoint. RH and Step4 remain OPEN. -/\n'
(overlay/'Zeta23/OPICAFollowup.lean').write_text(facade,encoding='utf-8')
(HERE/'OPICAFollowupFacadeProductionProposal.lean').write_text(facade,encoding='utf-8')
validation=overlay/'Zeta23/OPICAFollowup/Validation.lean'
v=re.sub(r'(?m)^import\s+Zeta23[^\n]*\n','',validation.read_text(encoding='utf-8'))
v='import Zeta23.OPICAFollowup\n'+v
validation.write_text(v,encoding='utf-8')
(HERE/'ValidationProductionProposal.lean').write_text(v,encoding='utf-8')
report={'schema':'OPICA_FROZEN_DIRECT_IMPORT_DAG_PROPOSAL_V1','status':'SOURCE_PREPARED_COMPILER_REPLAY_PENDING',
    'consumers_imports':consumer_imports,
    'extra_import_status':'REQUIRED_IMPLEMENTATION_REFINEMENT_PROPOSAL_NOT_INDEPENDENTLY_ACCEPTED' if len(consumer_imports)>13 else 'ORIGINAL_FROZEN_13_ONLY',
    'facade_imports':['Zeta23.OPICAFollowup.Consumers'],'validation_imports':['Zeta23.OPICAFollowup'],
    'NativeJetAdapter_reachable_in_frozen_13_import_closure':'Zeta23.OPICA.NativeJetAdapter' in reached,
    'source_closure_count':len(reached),'source_closure':sorted(reached),
    'source_sha256':{str(p.relative_to(HERE)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in [consumers,overlay/'Zeta23/OPICAFollowup.lean',validation]},
    'claim':'No direct dependency amendment is assumed. Compilation must decide whether old Consumers needs the unlisted NativeJetAdapter.',
    'RH':'OPEN','Step4':'OPEN'}
(HERE/'frozen-dag-proposal.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('NativeJetAdapter in frozen closure:',report['NativeJetAdapter_reachable_in_frozen_13_import_closure'])
