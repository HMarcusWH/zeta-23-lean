import ActualJetTaylor

noncomputable section
set_option maxHeartbeats 800000
open Set Filter Complex
open scoped Topology
namespace OPICARightCellTaylor

variable {ι : Type*} [Fintype ι]

def combinationTaylorConstant (node : ι → ℂ) (a : ι → ℂ) (n : ℕ) : ℝ :=
  ∑ i, ‖a i‖ * ((‖node i‖ + 2) ^ (n + 2) * expMajorant (‖node i‖ + 2))

theorem finite_combination_remainder (node : ι → ℂ) (order : ι → ℕ) (a : ι → ℂ)
    {u : ℝ} (hu : |u| ≤ 1) (n : ℕ) :
    ‖(∑ j ∈ Finset.range (n + 1),
        (∑ i, a i * oddJetCoefficient (node i) (order i) j) * (u : ℂ) ^ (2 * j + 1)) -
      ∑ i, a i * rightCellJet (node i) (order i) u‖ ≤
        combinationTaylorConstant node a n * |u| ^ (2 * n + 3) := by
  classical
  have heq : (∑ j ∈ Finset.range (n + 1),
      (∑ i, a i * oddJetCoefficient (node i) (order i) j) * (u : ℂ) ^ (2 * j + 1)) =
      ∑ i, a i * partialJet (node i) (order i) u n := by
    simp_rw [Finset.sum_mul]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i hi
    rw [partialJet_eq, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j hj
    ring
  rw [heq, ← Finset.sum_sub_distrib]
  have hres : (∑ i, (a i * partialJet (node i) (order i) u n -
      a i * rightCellJet (node i) (order i) u)) =
      ∑ i, a i * (partialJet (node i) (order i) u n - rightCellJet (node i) (order i) u) := by
    apply Finset.sum_congr rfl
    intro i hi
    ring
  rw [hres]
  calc
    ‖∑ i, a i * (partialJet (node i) (order i) u n - rightCellJet (node i) (order i) u)‖
      ≤ ∑ i, ‖a i * (partialJet (node i) (order i) u n - rightCellJet (node i) (order i) u)‖ :=
        norm_sum_le _ _
    _ ≤ ∑ i, ‖a i‖ * (((‖node i‖ + 2) ^ (n + 2) * expMajorant (‖node i‖ + 2)) *
        |u| ^ (2 * n + 3)) := by
      apply Finset.sum_le_sum
      intro i hi
      rw [norm_mul, norm_sub_rev]
      exact mul_le_mul_of_nonneg_left
        (normalized_jet_remainder (node i) (order i) hu n) (norm_nonneg _)
    _ = combinationTaylorConstant node a n * |u| ^ (2 * n + 3) := by
      unfold combinationTaylorConstant
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro i hi
      ring

#print axioms finite_combination_remainder
end OPICARightCellTaylor
