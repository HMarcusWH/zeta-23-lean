import Zeta23.OPICAFollowup.CoPoissonJets
import Zeta23.OPICA.SignedHeatSeparator
import Mathlib.MeasureTheory.Measure.WithDensity

noncomputable section
open Set MeasureTheory Filter
open scoped ENNReal
namespace Zeta23.OPICAFollowup.FixedBudgetSupport
open Zeta23.OPICA

def sincWeight : ℝ → ℝ≥0∞ := fun x => ENNReal.ofReal (sincSquared x)

theorem sincWeight_measurable : Measurable sincWeight :=
  ENNReal.measurable_ofReal.comp sincSquared_continuous.measurable

theorem sinc_weight_finite (μ : Measure ℝ) [IsLocallyFiniteMeasure μ]
    (growth : LinearMassGrowth μ) : IsFiniteMeasure (μ.withDensity sincWeight) := by
  apply isFiniteMeasure_withDensity
  have h := (sincSquared_integrable_of_linear_growth μ growth).hasFiniteIntegral
  simpa only [HasFiniteIntegral,Real.enorm_of_nonneg (sincSquared_nonneg _),sincWeight] using h.ne

def sincWeightedJordan (ν : LocallyFiniteSignedMeasure) (growth : ν.HasLinearGrowth) :
    JordanDecomposition ℝ where
  posPart := ν.positive.withDensity sincWeight
  negPart := ν.negative.withDensity sincWeight
  posPart_finite := sinc_weight_finite _ (ν.positive_hasLinearGrowth growth)
  negPart_finite := sinc_weight_finite _ (ν.negative_hasLinearGrowth growth)
  mutuallySingular := ((ν.mutuallySingular.withDensity).symm.withDensity).symm

def sincWeightedSigned (ν : LocallyFiniteSignedMeasure) (growth : ν.HasLinearGrowth) :
    SignedMeasure ℝ := (sincWeightedJordan ν growth).toSignedMeasure

theorem sincWeightedSigned_jordan (ν : LocallyFiniteSignedMeasure) (growth : ν.HasLinearGrowth) :
    (sincWeightedSigned ν growth).toJordanDecomposition=sincWeightedJordan ν growth :=
  JordanDecomposition.toJordanDecomposition_toSignedMeasure _

theorem sinc_weight_real_mass (μ : Measure ℝ) [IsLocallyFiniteMeasure μ]
    (growth : LinearMassGrowth μ) :
    (μ.withDensity sincWeight).real univ=∫ x, sincSquared x ∂μ := by
  rw [Measure.real,withDensity_apply _ MeasurableSet.univ,Measure.restrict_univ]
  exact (integral_eq_lintegral_of_nonneg_ae (Eventually.of_forall sincSquared_nonneg)
    sincSquared_continuous.aestronglyMeasurable).symm

theorem sinc_weight_real_apply (μ : Measure ℝ) (E : Set ℝ) (hE : MeasurableSet E) :
    (μ.withDensity sincWeight).real E=∫ x in E, sincSquared x ∂μ := by
  rw [Measure.real,withDensity_apply _ hE]
  exact (integral_eq_lintegral_of_nonneg_ae (Eventually.of_forall sincSquared_nonneg)
    sincSquared_continuous.aestronglyMeasurable).symm

theorem sincWeightedSigned_apply (ν : LocallyFiniteSignedMeasure) (growth : ν.HasLinearGrowth)
    (E : Set ℝ) (hE : MeasurableSet E) :
    sincWeightedSigned ν growth E=(∫ x in E, sincSquared x ∂ν.positive)-
      (∫ x in E, sincSquared x ∂ν.negative) := by
  letI := sinc_weight_finite ν.positive (ν.positive_hasLinearGrowth growth)
  letI := sinc_weight_finite ν.negative (ν.negative_hasLinearGrowth growth)
  change ((ν.positive.withDensity sincWeight).toSignedMeasure-
    (ν.negative.withDensity sincWeight).toSignedMeasure) E=_
  rw [_root_.sub_apply,Measure.toSignedMeasure_apply_measurable hE,
    Measure.toSignedMeasure_apply_measurable hE,sinc_weight_real_apply _ _ hE,
    sinc_weight_real_apply _ _ hE]

theorem sincWeightedSigned_add (μ ν : LocallyFiniteSignedMeasure)
    (hμ : μ.HasLinearGrowth) (hν : ν.HasLinearGrowth)
    (hadd : (localJordanAdd μ ν).HasLinearGrowth) :
    sincWeightedSigned (localJordanAdd μ ν) hadd=sincWeightedSigned μ hμ+sincWeightedSigned ν hν := by
  ext E hE
  rw [_root_.add_apply,sincWeightedSigned_apply _ _ _ hE,
    sincWeightedSigned_apply _ _ _ hE,sincWeightedSigned_apply _ _ _ hE]
  let f := E.indicator sincSquared
  have hmp := (sincSquared_integrable_of_linear_growth μ.positive (μ.positive_hasLinearGrowth hμ)).indicator hE
  have hmn := (sincSquared_integrable_of_linear_growth μ.negative (μ.negative_hasLinearGrowth hμ)).indicator hE
  have hnp := (sincSquared_integrable_of_linear_growth ν.positive (ν.positive_hasLinearGrowth hν)).indicator hE
  have hnn := (sincSquared_integrable_of_linear_growth ν.negative (ν.negative_hasLinearGrowth hν)).indicator hE
  have h := localJordanDifference_integral (μ.positive+ν.positive) (μ.negative+ν.negative)
    f (integrable_add_measure.mpr ⟨hmp,hnp⟩) (integrable_add_measure.mpr ⟨hmn,hnn⟩)
  rw [integral_add_measure hmp hnp,integral_add_measure hmn hnn] at h
  simp only [f,integral_indicator hE] at h
  change (∫ x in E,sincSquared x ∂(localJordanDifference _ _).positive)-
    (∫ x in E,sincSquared x ∂(localJordanDifference _ _).negative)=_
  rw [h]
  ring

theorem sincWeightedSigned_scale (a : ℝ) (μ : LocallyFiniteSignedMeasure)
    (hμ : μ.HasLinearGrowth) (hscale : (localJordanScale a μ).HasLinearGrowth) :
    sincWeightedSigned (localJordanScale a μ) hscale=a • sincWeightedSigned μ hμ := by
  ext E hE
  rw [VectorMeasure.smul_apply,sincWeightedSigned_apply _ _ _ hE,sincWeightedSigned_apply _ _ _ hE]
  let f := E.indicator sincSquared
  have hp := (sincSquared_integrable_of_linear_growth μ.positive (μ.positive_hasLinearGrowth hμ)).indicator hE
  have hn := (sincSquared_integrable_of_linear_growth μ.negative (μ.negative_hasLinearGrowth hμ)).indicator hE
  have hpp : Integrable f (Real.toNNReal a • μ.positive) :=
    hp.smul_measure (c := (Real.toNNReal a : ℝ≥0∞)) ENNReal.coe_ne_top
  have hpn : Integrable f (Real.toNNReal a • μ.negative) :=
    hn.smul_measure (c := (Real.toNNReal a : ℝ≥0∞)) ENNReal.coe_ne_top
  have hnp : Integrable f (Real.toNNReal (-a) • μ.positive) :=
    hp.smul_measure (c := (Real.toNNReal (-a) : ℝ≥0∞)) ENNReal.coe_ne_top
  have hnn : Integrable f (Real.toNNReal (-a) • μ.negative) :=
    hn.smul_measure (c := (Real.toNNReal (-a) : ℝ≥0∞)) ENNReal.coe_ne_top
  have h := localJordanDifference_integral _ _ f
    (integrable_add_measure.mpr ⟨hpp,hnn⟩) (integrable_add_measure.mpr ⟨hpn,hnp⟩)
  rw [integral_add_measure hpp hnn,integral_add_measure hpn hnp] at h
  simp only [f,integral_indicator hE,Measure.restrict_smul,
    integral_smul_nnreal_measure,NNReal.smul_def,smul_eq_mul] at h
  change (∫ x in E,sincSquared x ∂(localJordanDifference _ _).positive)-
    (∫ x in E,sincSquared x ∂(localJordanDifference _ _).negative)=_
  rw [h]
  have ha : (Real.toNNReal a : ℝ)-(Real.toNNReal (-a) : ℝ)=a := by
    rw [Real.coe_toNNReal',Real.coe_toNNReal']
    rcases le_total 0 a with ha|ha
    · simp [max_eq_left ha,max_eq_right (neg_nonpos.mpr ha)]
    · simp [max_eq_right ha,max_eq_left (neg_nonneg.mpr ha)]
  conv_rhs => rw [←ha]
  simp only [smul_eq_mul]
  ring

theorem sinc_pairing_zero_of_gap (ν : LocallyFiniteSignedMeasure) (growth : ν.HasLinearGrowth)
    (self : ν.FourierSelfdual growth) (gap : ν.HasUnitGap) :
    (∫ x, sincSquared x ∂ν.positive)=(∫ x, sincSquared x ∂ν.negative) := by
  have h := signed_sinc_triangle_pairing ν growth self
  rw [LocallyFiniteSignedMeasure.integral,LocallyFiniteSignedMeasure.integral,
    unitTriangle_integral_zero_of_gap _ gap.1,unitTriangle_integral_zero_of_gap _ gap.2,
    sub_self,sub_eq_zero] at h
  exact h

theorem weighted_variation_eq_twice_negative (ν : LocallyFiniteSignedMeasure)
    (growth : ν.HasLinearGrowth) (self : ν.FourierSelfdual growth) (gap : ν.HasUnitGap) :
    (sincWeightedSigned ν growth).totalVariation.real univ=
      2*(∫ x, sincSquared x ∂ν.negative) := by
  letI := sinc_weight_finite ν.positive (ν.positive_hasLinearGrowth growth)
  letI := sinc_weight_finite ν.negative (ν.negative_hasLinearGrowth growth)
  rw [SignedMeasure.totalVariation,sincWeightedSigned_jordan]
  change (ν.positive.withDensity sincWeight+ν.negative.withDensity sincWeight).real univ=_
  rw [measureReal_add_apply,
    sinc_weight_real_mass _ (ν.positive_hasLinearGrowth growth),
    sinc_weight_real_mass _ (ν.negative_hasLinearGrowth growth),
    sinc_pairing_zero_of_gap ν growth self gap]
  ring

theorem negative_weight_zero_iff_zero (ν : LocallyFiniteSignedMeasure)
    (growth : ν.HasLinearGrowth) (self : ν.FourierSelfdual growth) (gap : ν.HasUnitGap) :
    (∫ x, sincSquared x ∂ν.negative)=0 ↔ ν.positive=0 ∧ ν.negative=0 := by
  constructor
  · intro h
    exact signed_sharp_gap_separator ν growth self gap
      (lattice_support_of_sincSquared_integral_zero _ (ν.negative_hasLinearGrowth growth) h)
  · rintro ⟨_,hneg⟩
    simp [hneg]

theorem sincWeightedSigned_zero_iff_zero (ν : LocallyFiniteSignedMeasure)
    (growth : ν.HasLinearGrowth) (self : ν.FourierSelfdual growth) (gap : ν.HasUnitGap) :
    sincWeightedSigned ν growth=0 ↔ ν.positive=0 ∧ ν.negative=0 := by
  constructor
  · intro hz
    have h := weighted_variation_eq_twice_negative ν growth self gap
    rw [hz,SignedMeasure.totalVariation_zero] at h
    simp only [Measure.real,Measure.coe_zero,Pi.zero_apply,ENNReal.toReal_zero] at h
    exact (negative_weight_zero_iff_zero ν growth self gap).mp (by linarith)
  · rintro ⟨hp,hn⟩
    ext E hE
    rw [sincWeightedSigned_apply _ _ _ hE,hp,hn]
    simp

theorem negative_sinc_off_lattice_eq_global (μ : Measure ℝ)
    [IsLocallyFiniteMeasure μ] (growth : LinearMassGrowth μ) (origin : μ {0}=0) :
    (∫ x in integerLatticeᶜ,sincSquared x ∂μ)=∫ x,sincSquared x ∂μ := by
  have hLat : (μ.restrict integerLattice) integerLatticeᶜ=0 := by
    rw [Measure.restrict_apply integerLattice_measurable.compl]
    simp
  have hOrigin : (μ.restrict integerLattice) {0}=0 :=
    le_antisymm ((Measure.restrict_le_self {0}).trans (le_of_eq origin)) zero_le
  have hz := sincSquared_integral_zero_of_lattice_support
    (μ.restrict integerLattice) hLat hOrigin
  have h := integral_add_compl integerLattice_measurable
    (sincSquared_integrable_of_linear_growth μ growth)
  rw [hz,zero_add] at h
  exact h

#print axioms weighted_variation_eq_twice_negative
#print axioms negative_weight_zero_iff_zero
#print axioms sincWeightedSigned_add
#print axioms sincWeightedSigned_scale
#print axioms sincWeightedSigned_zero_iff_zero
#print axioms negative_sinc_off_lattice_eq_global
end Zeta23.OPICAFollowup.FixedBudgetSupport
