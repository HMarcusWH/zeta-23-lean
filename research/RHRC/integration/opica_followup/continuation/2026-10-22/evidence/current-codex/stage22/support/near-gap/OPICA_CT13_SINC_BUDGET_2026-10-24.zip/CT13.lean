import Zeta23.OPICAFollowup.NearGapLimits

noncomputable section
open Set MeasureTheory Filter
open scoped Topology ENNReal NNReal
namespace Zeta23.OPICAFollowup.CT13Support
open Zeta23.OPICA

lemma triangle_integrable (μ : Measure ℝ) [IsLocallyFiniteMeasure μ] :
    Integrable unitTriangle μ := by
  have hi : Integrable (fun x => (unitTriangle x : ℂ)) μ :=
    (Complex.continuous_ofReal.comp unitTriangle_continuous).integrable_of_hasCompactSupport
      unitTriangle_hasCompactSupport
  simpa using hi.re

lemma triangle_lattice_zero {t : ℝ} (ht : 1 / 2 ≤ Real.exp t)
    (n : ℤ) (hn : n ∉ ({-1, 0, 1} : Finset ℤ)) :
    unitTriangle (Real.exp t * (n : ℝ)) = 0 := by
  have hn' : n ≠ -1 ∧ n ≠ 0 ∧ n ≠ 1 := by simpa using hn
  have hnabs : (2 : ℤ) ≤ |n| := by
    by_cases h : 0 ≤ n
    · rw [abs_of_nonneg h]; omega
    · rw [abs_of_neg (lt_of_not_ge h)]; omega
  have hnreal : (2 : ℝ) ≤ |(n : ℝ)| := by exact_mod_cast hnabs
  apply unitTriangle_eq_zero_of_one_le_abs
  rw [abs_mul, abs_of_pos (Real.exp_pos t)]
  nlinarith

lemma triangle_comb_pairing {t : ℝ} (ht : 1 / 2 ≤ Real.exp t) :
    (∫ x, unitTriangle x ∂dilatedCombMeasure t) =
      Real.exp (t / 2) * (1 + 2 * max (1 - Real.exp t) 0) := by
  have hf : Integrable unitTriangle (scaledLatticeMeasure t) := triangle_integrable _
  rw [dilatedCombMeasure, integral_smul_measure,
    ENNReal.toReal_ofReal (Real.exp_pos _).le,
    scaledLatticeMeasure, integral_map (scaledLatticePoint_measurable t).aemeasurable
      unitTriangle_continuous.aestronglyMeasurable]
  have hc : Integrable (fun n : ℤ => unitTriangle (scaledLatticePoint t n)) Measure.count :=
    (integrable_map_measure unitTriangle_continuous.aestronglyMeasurable
      (scaledLatticePoint_measurable t).aemeasurable).mp hf
  rw [integral_countable hc]
  simp only [count_real_singleton, scaledLatticePoint, smul_eq_mul, one_mul]
  rw [tsum_eq_sum (s := ({-1, 0, 1} : Finset ℤ)) (triangle_lattice_zero ht)]
  simp [unitTriangle, abs_of_pos (Real.exp_pos t)]
  ring

lemma jordan_add_triangle (μ ν : LocallyFiniteSignedMeasure) :
    (localJordanAdd μ ν).integral unitTriangle =
      μ.integral unitTriangle + ν.integral unitTriangle := by
  unfold LocallyFiniteSignedMeasure.integral localJordanAdd
  rw [localJordanDifference_integral _ _ _ (triangle_integrable _) (triangle_integrable _),
    integral_add_measure (triangle_integrable _) (triangle_integrable _),
    integral_add_measure (triangle_integrable _) (triangle_integrable _)]
  ring

lemma negative_comb_triangle (c t : ℝ) (hc : 0 ≤ c) :
    (localJordanScale (-c) (dilatedCombJordan t)).integral unitTriangle =
      -c * (∫ x, unitTriangle x ∂dilatedCombMeasure t) := by
  have hp : (localJordanScale (-c) (dilatedCombJordan t)).positive = 0 := by
    simp [localJordanScale, dilatedCombJordan, localJordanDifference,
      Real.toNNReal_of_nonpos (neg_nonpos.mpr hc)]
  have hn : (localJordanScale (-c) (dilatedCombJordan t)).negative =
      (Real.toNNReal c : ℝ≥0∞) • dilatedCombMeasure t := by
    simp [localJordanScale, dilatedCombJordan, localJordanDifference,
      Real.toNNReal_of_nonpos (neg_nonpos.mpr hc)]
  rw [LocallyFiniteSignedMeasure.integral, hp, hn, integral_zero_measure,
    integral_smul_measure]
  simp [hc, smul_eq_mul]

/-- Exact original CT1.3 triangle mass on the actual canonical Jordan family. -/
theorem triangle_identity {L : ℝ} (hL : 0 < L) (hu : L < Real.log 2) :
    (nearGapCombFamily L).integral unitTriangle =
      2 * Real.exp (-L / 2) * (1 - Real.exp (-L)) := by
  have hp : (1 : ℝ) < Real.exp L := by simpa using Real.exp_lt_exp.mpr hL
  have hm := nearGapComb_radius_bounds hL hu
  have hhalf : (1 / 2 : ℝ) ≤ Real.exp L := by linarith
  have hc : 0 ≤ 2 * Real.cosh (L / 2) := by positivity
  unfold nearGapCombFamily
  rw [jordan_add_triangle, jordan_add_triangle, negative_comb_triangle _ _ hc]
  have hcomb (t : ℝ) : (dilatedCombJordan t).integral unitTriangle =
      ∫ x, unitTriangle x ∂dilatedCombMeasure t := by
    simp [LocallyFiniteSignedMeasure.integral, dilatedCombJordan, localJordanDifference]
  rw [hcomb, hcomb, triangle_comb_pairing hhalf, triangle_comb_pairing hm.1.le,
    triangle_comb_pairing (t := 0) (by norm_num)]
  rw [max_eq_right (by linarith : 1 - Real.exp L ≤ 0),
    max_eq_left (by linarith : 0 ≤ 1 - Real.exp (-L))]
  simp only [Real.exp_zero, zero_div, sub_self, max_self, mul_zero, add_zero, mul_one]
  have hc := nearGapComb_origin_coefficient_zero L
  have he : Real.exp (-L / 2) = Real.exp ((-L) / 2) := rfl
  nlinarith

/-- Sinc pairing is derived from actual growth and Fourier self-duality. -/
theorem sinc_identity {L : ℝ} (hL : 0 < L) (hu : L < Real.log 2) :
    (nearGapCombFamily L).integral sincSquared =
      2 * Real.exp (-L / 2) * (1 - Real.exp (-L)) := by
  rw [signed_sinc_triangle_pairing _ (nearGapCombFamily_growth L)
    (nearGapCombFamily_fourier_selfdual L), triangle_identity hL hu]

/-- The negative sinc mass is zero on the actual off-integer-nonnegative family. -/
theorem negative_sinc_mass_zero {L : ℝ} (hL : 0 < L) :
    (∫ x, sincSquared x ∂(nearGapCombFamily L).negative) = 0 :=
  nearGap_sinc_negative_zero _ (nearGapCombFamily_growth L) (Real.exp_pos (-L))
    (nearGapCombFamily_actual_gap hL.le) (nearGapCombFamily_offlattice_nonnegative L)

theorem positive_sinc_mass {L : ℝ} (hL : 0 < L) (hu : L < Real.log 2) :
    (∫ x, sincSquared x ∂(nearGapCombFamily L).positive) =
      2 * Real.exp (-L / 2) * (1 - Real.exp (-L)) := by
  have h := sinc_identity hL hu
  change (∫ x, sincSquared x ∂(nearGapCombFamily L).positive) -
    (∫ x, sincSquared x ∂(nearGapCombFamily L).negative) = _ at h
  rwa [negative_sinc_mass_zero hL, sub_zero] at h

end Zeta23.OPICAFollowup.CT13Support
#print axioms Zeta23.OPICAFollowup.CT13Support.triangle_identity
#print axioms Zeta23.OPICAFollowup.CT13Support.sinc_identity
#print axioms Zeta23.OPICAFollowup.CT13Support.positive_sinc_mass
