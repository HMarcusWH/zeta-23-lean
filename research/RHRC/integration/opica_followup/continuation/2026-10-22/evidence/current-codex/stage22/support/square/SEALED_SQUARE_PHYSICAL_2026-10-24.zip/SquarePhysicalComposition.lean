import SquarePhysicalNoRepair

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology FourierTransform SchwartzMap
namespace Zeta23.OPICAFollowup
open Zeta23.OPICA

/-- Adding an arbitrary selfdual tempered distribution cannot change the
square defect or make an arbitrary tempered lattice-measure repair possible. -/
theorem square_actual_no_selfdual_and_measure_repair {h : ℝ → ℂ} {A : ℂ}
    (hev : ∀ x,h (-x)=h x) (hcont : Continuous h) (hint : Integrable h)
    (hL2 : MemLp h 2) (hsd : 𝓕 h=h) (hvan : Tendsto h (cocompact ℝ) (𝓝 0))
    (hpl : ∀ x,|x|≤1 → h x=A) (hne : h≠0)
    (T : TemperedDistribution ℝ ℂ) (hT : 𝓕 T=T)
    (σ : LocallyFiniteComplexMeasure) [σ.totalVariation.HasTemperateGrowth]
    (hσ : σ.totalVariation (Set.range (fun n:ℤ=>(n:ℝ)))ᶜ=0) :
    𝓕 ((squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)+T+SquarePhysicalSupport.correctionDistribution σ) ≠
      (squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)+T+SquarePhysicalSupport.correctionDistribution σ := by
  intro hs
  apply square_actual_no_tempered_measure_repair hev hcont hint hL2 hsd hvan hpl hne σ hσ
  apply add_right_cancel (b:=T)
  simpa only [FourierTransform.fourier_add,hT,add_assoc,add_comm,add_left_comm] using hs

end Zeta23.OPICAFollowup
#print axioms Zeta23.OPICAFollowup.square_actual_no_selfdual_and_measure_repair
