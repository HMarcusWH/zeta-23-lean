import Zeta23.OPICAFollowup.AuxiliaryCompletions
import Mathlib.Analysis.SpecialFunctions.Log.Basic

noncomputable section
open Filter
open scoped Topology
namespace Zeta23.OPICAFollowup.Stage19Rate

/-- The paper's completion index, with a real continuous horizon. -/
def completionIndex (xi T : ℝ) : ℕ := max 1 (Nat.floor (xi*T/Real.log T))

theorem completionIndex_one_le (xi T : ℝ) : 1 ≤ completionIndex xi T := le_max_left _ _

theorem completionIndex_rounding_bound {xi T : ℝ} (hxi : 0 ≤ xi) (hT : 1 < T) :
    |(completionIndex xi T : ℝ)-xi*T/Real.log T| ≤ 1 := by
  have hTp : 0 < T := by linarith
  have hl : 0 < Real.log T := Real.log_pos hT
  have hx : 0 ≤ xi*T/Real.log T := div_nonneg (mul_nonneg hxi hTp.le) hl.le
  have hf := Nat.floor_le hx
  have hg := Nat.lt_floor_add_one (xi*T/Real.log T)
  rw [completionIndex, Nat.cast_max, Nat.cast_one]
  apply abs_le.mpr
  constructor
  · have hm := le_max_right (1 : ℝ) (Nat.floor (xi*T/Real.log T) : ℝ)
    linarith
  · apply sub_le_iff_le_add.mpr
    apply max_le
    · linarith
    · linarith

theorem completionIndex_scaled_error {xi T : ℝ} (hxi : 0 ≤ xi) (hT : 1 < T) :
    |(completionIndex xi T : ℝ)*Real.log T/T-xi| ≤ Real.log T/T := by
  have hTp : 0 < T := by linarith
  have hl : 0 < Real.log T := Real.log_pos hT
  have he : (completionIndex xi T : ℝ)*Real.log T/T-xi =
      ((completionIndex xi T : ℝ)-xi*T/Real.log T)*Real.log T/T := by
    field_simp [hTp.ne',hl.ne']
  rw [he,abs_div,abs_mul,abs_of_pos hTp,abs_of_pos hl]
  exact (div_le_div_of_nonneg_right
    (mul_le_mul_of_nonneg_right (completionIndex_rounding_bound hxi hT) hl.le)
    hTp.le).trans_eq (by ring)

/-- The damping parameter's logarithmic-window exponent has exactly the
paper's rate xi at continuous horizons, with the max/floor convention retained. -/
theorem completionIndex_log_scale_tendsto (xi : ℝ) (hxi : 0 ≤ xi) :
    Tendsto (fun T : ℝ => (completionIndex xi T : ℝ)*Real.log T/T) atTop (𝓝 xi) := by
  have hl : Tendsto (fun T : ℝ => Real.log T/T) atTop (𝓝 0) := by
    simpa using Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 (by norm_num)
  have he : Tendsto (fun T : ℝ => (completionIndex xi T : ℝ)*Real.log T/T-xi)
      atTop (𝓝 0) := by
    apply squeeze_zero_norm' _ hl
    filter_upwards [eventually_gt_atTop (1 : ℝ)] with T hT
    simpa only [Real.norm_eq_abs] using completionIndex_scaled_error hxi hT
  simpa only [sub_add_cancel,zero_add] using he.add_const xi

theorem actualCompletionAlpha_log_scale_tendsto (xi : ℝ) (hxi : 0 ≤ xi) :
    Tendsto (fun T : ℝ => auxCompletionAlpha (completionIndex xi T)*Real.log T/T)
      atTop (𝓝 xi) := by
  have hl : Tendsto (fun T : ℝ => Real.log T/T) atTop (𝓝 0) := by
    simpa using Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 (by norm_num)
  have h := (completionIndex_log_scale_tendsto xi hxi).add (hl.const_mul (1/2 : ℝ))
  convert h using 1
  · ext T
    dsimp [auxCompletionAlpha]
    ring
  · simp

theorem completionIndex_div_time_tendsto_zero (xi : ℝ) (hxi : 0 ≤ xi) :
    Tendsto (fun T : ℝ => (completionIndex xi T : ℝ)/T) atTop (𝓝 0) := by
  have h1 : Tendsto (fun T : ℝ => xi/Real.log T) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop Real.tendsto_log_atTop
  have h2 : Tendsto (fun T : ℝ => (1 : ℝ)/T) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop tendsto_id
  apply squeeze_zero' _ _ (by simpa using h1.add h2)
  · filter_upwards [eventually_gt_atTop (1 : ℝ)] with T hT
    exact div_nonneg (Nat.cast_nonneg _) (by linarith)
  · filter_upwards [eventually_gt_atTop (1 : ℝ)] with T hT
    have hTp : 0 < T := by linarith
    have hl : 0 < Real.log T := Real.log_pos hT
    have hb := (abs_le.mp (completionIndex_rounding_bound hxi hT)).2
    have hnum : (completionIndex xi T : ℝ) ≤ xi*T/Real.log T+1 := by linarith
    exact (div_le_div_of_nonneg_right hnum hTp.le).trans_eq (by field_simp)

/-- A5 only needs this upper asymptotic bound. It avoids introducing the
unnecessary exact log(k+1)/log T asymptotic as a separate dependency. -/
theorem completionCost_eventually_lt (xi Cp : ℝ) (hxi : 0 ≤ xi) {eps : ℝ}
    (heps : 0 < eps) :
    ∀ᶠ T : ℝ in atTop,
      ((completionIndex xi T : ℝ)*Real.log ((completionIndex xi T : ℝ)+1)+
        Cp*((completionIndex xi T : ℝ)+1))/T < xi+eps := by
  have hk := completionIndex_div_time_tendsto_zero xi hxi
  have hu : Tendsto (fun T : ℝ =>
      (completionIndex xi T : ℝ)*Real.log T/T+
        (Real.log 2+Cp)*((completionIndex xi T : ℝ)/T)+Cp/T) atTop (𝓝 xi) := by
    have hCp : Tendsto (fun T : ℝ => Cp/T) atTop (𝓝 0) :=
      tendsto_const_nhds.div_atTop tendsto_id
    simpa using ((completionIndex_log_scale_tendsto xi hxi).add (hk.const_mul (Real.log 2+Cp))).add hCp
  have hsmall : ∀ᶠ T : ℝ in atTop, (completionIndex xi T : ℝ)/T < 1 :=
    (tendsto_order.1 hk).2 1 (by norm_num)
  have hupper : ∀ᶠ T : ℝ in atTop,
      (completionIndex xi T : ℝ)*Real.log T/T+
        (Real.log 2+Cp)*((completionIndex xi T : ℝ)/T)+Cp/T < xi+eps :=
    (tendsto_order.1 hu).2 (xi+eps) (by linarith)
  filter_upwards [hsmall,hupper,eventually_gt_atTop (1 : ℝ)] with T hs hu hT
  have hTp : 0 < T := by linarith
  have hkT : (completionIndex xi T : ℝ) < T := by
    simpa only [one_mul] using (div_lt_iff₀ hTp).mp hs
  have hlog : Real.log ((completionIndex xi T : ℝ)+1) ≤ Real.log (2*T) :=
    Real.log_le_log (by positivity) (by linarith)
  rw [Real.log_mul (by norm_num) hTp.ne'] at hlog
  have hnum := mul_le_mul_of_nonneg_left hlog (Nat.cast_nonneg (completionIndex xi T))
  have hbound : ((completionIndex xi T : ℝ)*Real.log ((completionIndex xi T : ℝ)+1)+
      Cp*((completionIndex xi T : ℝ)+1))/T ≤
      (completionIndex xi T : ℝ)*Real.log T/T+
        (Real.log 2+Cp)*((completionIndex xi T : ℝ)/T)+Cp/T := by
    calc
      _ ≤ ((completionIndex xi T : ℝ)*(Real.log 2+Real.log T)+
          Cp*((completionIndex xi T : ℝ)+1))/T :=
        div_le_div_of_nonneg_right (by linarith [hnum]) hTp.le
      _ = _ := by ring
  exact hbound.trans_lt hu

#print axioms completionIndex_rounding_bound
#print axioms completionIndex_scaled_error
#print axioms completionIndex_log_scale_tendsto
#print axioms actualCompletionAlpha_log_scale_tendsto
#print axioms completionIndex_div_time_tendsto_zero
#print axioms completionCost_eventually_lt
end Zeta23.OPICAFollowup.Stage19Rate
