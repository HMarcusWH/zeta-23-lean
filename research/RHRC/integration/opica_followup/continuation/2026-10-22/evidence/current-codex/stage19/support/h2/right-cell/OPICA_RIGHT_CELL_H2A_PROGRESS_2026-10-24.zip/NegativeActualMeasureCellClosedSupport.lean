import ActualMeasureCell

noncomputable section
open Set
open scoped SchwartzMap

/-- Invalid expected-type control: closing the cell includes lattice
points, so the open-cell lattice removal theorem must not accept it. -/
example (φ : 𝓢(ℝ, ℂ))
    (hφ : Function.support (φ : ℝ → ℂ) ⊆ Icc 1 2) (n : ℤ) : φ n = 0 := by
  exact OPICAActualMeasureCell.integer_samples_zero φ hφ n
