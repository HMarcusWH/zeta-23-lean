import Zeta23.OPICAFollowup.NearGapLimits
open MeasureTheory Set
open Zeta23.OPICA Zeta23.OPICAFollowup
#check Continuous.integrable_of_hasCompactSupport
#check Integrable.re
#check integrable_ofReal
#check MeasureTheory.integrable_count_iff
#check MeasureTheory.integral_count
#check MeasureTheory.integral_countable
#check tsum_eq_sum
#check Finset.summable_iff_support_subset
#check Real.hasDerivAt_exp
#check Filter.Tendsto.div_atTop
#check HasDerivAt.tendsto_slope_zero_right
#check Real.rpow_def_of_pos
#check localJordanDifference_integral
#check LocallyFiniteSignedMeasure.integral
#check HasCompactSupport.comp_left
