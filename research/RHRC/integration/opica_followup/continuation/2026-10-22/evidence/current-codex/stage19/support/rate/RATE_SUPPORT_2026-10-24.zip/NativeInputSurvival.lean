import NativeInputRate

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23.OPICA
namespace Zeta23.OPICAFollowup.Stage19Rate.Asymptotic

theorem actual_completed_input_eventually_half_leading (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n) atTop (𝓝 0))
    (rho : zetaZeroConfig.carrier) (hright : 1/2 < (rho : ℂ).re)
    (xi : ℝ) (hxi : 0 ≤ xi) :
    ∀ᶠ n : ℕ in atTop,
      ‖nativeAuxiliaryStableVector (completionIndex xi (T.time n)) (d n)‖ ≤
        nativeMultiplicityTailConstant (d n) rho*
          ‖auxRationalFactor (completionIndex xi (T.time n)) ((rho : ℂ)-1/2)‖*
            Real.exp (((rho : ℂ)-1/2).re*T.time n)/2 := by
  let delta : ℝ := ((rho : ℂ)-1/2).re
  have hdelta : 0 < delta := by
    change 0 < ((rho : ℂ)-1/2).re
    simp only [Complex.sub_re]
    norm_num
    linarith
  have hQ := actualInput_rational_ratio_log_rate_zero T d hd rho hright xi hxi
  have hD := multiplicityTailConstant_log_div_time_tendsto_zero T d hd rho hright
  have hDiff := hQ.sub hD
  have hSmall : ∀ᶠ n : ℕ in atTop,
      (Real.log (1+‖nativeAuxiliaryStableVector (completionIndex xi (T.time n)) (d n)‖/
          ‖auxRationalFactor (completionIndex xi (T.time n)) ((rho : ℂ)-1/2)‖)-
        Real.log (nativeMultiplicityTailConstant (d n) rho))/T.time n < delta/2 := by
    have h := (tendsto_order.1 hDiff).2 (delta/2) (by linarith)
    simpa only [←sub_div,sub_zero] using h
  filter_upwards [hSmall,T.cofinal.eventually_ge_atTop (2*Real.log 2/delta)] with n hn hTime
  let k := completionIndex xi (T.time n)
  let D := nativeMultiplicityTailConstant (d n) rho
  let R := ‖auxRationalFactor k ((rho : ℂ)-1/2)‖
  let Q := ‖nativeAuxiliaryStableVector k (d n)‖/R
  have hDp : 0 < D := nativeMultiplicityTailConstant_pos (d n) rho hright
  have hRp : 0 < R := by
    apply norm_pos_iff.mpr
    apply auxRationalFactor_ne_zero
    · simpa only [delta] using hdelta
    · exact auxiliary_centered_zero_ne_half rho
  have hQp : 0 < 1+Q := by dsimp [Q]; positivity
  have hCost : Real.log (1+Q)-Real.log D < delta/2*T.time n :=
    (div_lt_iff₀ (T.positive n)).mp hn
  have hLog2 : Real.log 2 ≤ delta/2*T.time n := by
    have h := (div_le_iff₀ hdelta).mp hTime
    nlinarith
  have hLog : Real.log (1+Q) ≤ Real.log D+delta*T.time n-Real.log 2 := by linarith
  have he := (Real.log_le_iff_le_exp hQp).mp hLog
  rw [Real.exp_sub,Real.exp_add,Real.exp_log hDp,Real.exp_log (by norm_num : (0 : ℝ)<2)] at he
  have hRatio : Q ≤ D*Real.exp (delta*T.time n)/2 := by linarith
  have hFinal := (div_le_iff₀ hRp).mp hRatio
  exact hFinal.trans_eq (by dsimp [D,R,delta]; ring)

#print axioms actual_completed_input_eventually_half_leading
end Zeta23.OPICAFollowup.Stage19Rate.Asymptotic
