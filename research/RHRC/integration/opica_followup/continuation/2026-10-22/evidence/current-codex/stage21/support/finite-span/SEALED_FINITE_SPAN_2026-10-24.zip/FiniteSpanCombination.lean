import FiniteSpanCompact
import FiniteSpanCoefficients

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform

namespace Zeta23.OPICAFollowup.FiniteSpanScratch
open Zeta23.OPICA

lemma realBasisCombination_integral {n : ℕ} (basis : Fin n → List JetDatum)
    (h : ∀ i, ∀ j ∈ basis i, ValidJet j) (a : Fin n → ℝ) (φ : 𝓢(ℝ, ℂ)) :
    (actualZeroJetSum (realBasisCombinationData basis a)).integral φ =
      ∑ i, (a i : ℂ) * (actualZeroJetSum (basis i)).integral φ := by
  rw [actualZeroJetSum_integral _ (realBasisCombination_valid basis h a)]
  simp only [realBasisCombinationData, List.map_flatten, List.sum_flatten,
    List.map_ofFn, List.sum_ofFn, List.map_map, Function.comp_apply]
  apply Finset.sum_congr rfl
  intro i hi
  rw [actualZeroJetSum_integral _ (h i)]
  simp only [scaleJetData, List.map_map, Function.comp_def, mul_assoc]
  rw [List.sum_map_mul_left]

lemma zeroJetRealSpan_distribution_integral (data : List JetDatum)
    (h : ∀ j ∈ data, ValidJet j) (φ : 𝓢(ℝ, ℂ)) :
    (zeroJetRealSpan data).distributionOfLinearGrowth (zeroJetRealSpan_growth data h) φ =
      ((actualZeroJetSum data).integral φ +
        starRingEnd ℂ ((actualZeroJetSum data).integral (complexSchwartzConj φ))) / 2 := by
  change ((actualZeroJetSum data).rePart.distributionOfLinearGrowth
    ((actualZeroJetSum data).re_hasLinearGrowth (actualZeroJetSum_growth data h))) φ = _
  rw [←(actualZeroJetSum data).realify_distribution (actualZeroJetSum_growth data h) φ]
  rfl

lemma realBasisCombination_distribution {n : ℕ} (basis : Fin n → List JetDatum)
    (h : ∀ i, ∀ j ∈ basis i, ValidJet j) (a : Fin n → ℝ) :
    (zeroJetRealSpan (realBasisCombinationData basis a)).distributionOfLinearGrowth
        (zeroJetRealSpan_growth _ (realBasisCombination_valid basis h a)) =
      ∑ i, a i • (zeroJetRealSpan (basis i)).distributionOfLinearGrowth
        (zeroJetRealSpan_growth _ (h i)) := by
  ext φ
  rw [zeroJetRealSpan_distribution_integral _ (realBasisCombination_valid basis h a)]
  simp only [realBasisCombination_integral basis h a, map_sum, map_mul, Complex.conj_ofReal,
    sum_apply, smul_apply, Complex.real_smul]
  rw [←Finset.sum_add_distrib, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i hi
  rw [zeroJetRealSpan_distribution_integral _ (h i)]
  ring

/-- A fixed independent real basis can consist of arbitrary finite realified
actual-jet combinations. Independence is on the actual embedded measures. -/
theorem independent_real_span_basis_coefficients_zero {n : ℕ}
    (basis : Fin n → List JetDatum) (h : ∀ i, ∀ j ∈ basis i, ValidJet j)
    (hind : LinearIndependent ℝ (fun i => (zeroJetRealSpan (basis i)).distributionOfLinearGrowth
      (zeroJetRealSpan_growth _ (h i)))) (a : Fin n → ℝ)
    (hoff : (zeroJetRealSpan (realBasisCombinationData basis a)).OffLatticeNonnegative) : a = 0 := by
  have hz := finite_zero_span_positive_only_zero _ (realBasisCombination_valid basis h a) hoff
  have hdist : (zeroJetRealSpan (realBasisCombinationData basis a)).distributionOfLinearGrowth
      (zeroJetRealSpan_growth _ (realBasisCombination_valid basis h a)) = 0 := by
    ext φ
    rw [LocallyFiniteSignedMeasure.distributionOfLinearGrowth_apply, hz.1, hz.2]
    simp
  rw [realBasisCombination_distribution basis h a] at hdist
  funext i
  exact Fintype.linearIndependent_iff.mp hind a hdist i

#print axioms Zeta23.OPICAFollowup.FiniteSpanScratch.independent_real_span_basis_coefficients_zero
end Zeta23.OPICAFollowup.FiniteSpanScratch
