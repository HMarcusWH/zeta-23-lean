from pathlib import Path
import json,hashlib,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((HERE/'warm-overlay-receipt.json').read_text())
dest=HERE/'history/initial-all100-diagnostic'
dest.mkdir(parents=True,exist_ok=True)
original=subprocess.check_output(['git','show','9a8b2a4baee49f2056c7945b1544a7bc2893735b:Zeta23/OPICAFollowup/Consumers.lean'],cwd=REPO)
failed=(HERE/'Consumers.failed-frozen-13-imports.lean.txt').read_text(encoding='utf-8')
pos=failed.index('/-- Full physical composition:')
start=failed.rfind('noncomputable section',0,pos)
snippet=failed[start:]
reconstructed=b'import Zeta23.OPICAFollowup.FiniteSpanSeparation\n'+original+b'\n\n'+snippet.encode('utf-8')
alternative={
 'overlay/Zeta23/OPICAFollowup/Consumers.lean':reconstructed,
 'overlay/Zeta23/OPICAFollowup/Validation.lean':(HERE/'ValidationProposal.lean').read_bytes(),
 'overlay/Zeta23/OPICAFollowup.lean':(HERE/'OPICAFollowupFacadeProposal.lean').read_bytes(),
}
rows=[]
for relative,digest in receipt['source_sha256'].items():
    current=HERE/relative
    data=current.read_bytes()
    if sha(data)!=digest:data=alternative.get(relative,b'')
    assert sha(data)==digest,relative
    target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    rows.append({'path':relative,'sha256':digest})
(dest/'warm-overlay-receipt.json').write_bytes((HERE/'warm-overlay-receipt.json').read_bytes())
(dest/'source-snapshot.json').write_text(json.dumps({'status':'EXACT_HASH_MATCHING_HISTORICAL_SOURCE_SNAPSHOT','sources':rows},indent=2)+'\n',encoding='utf-8')
print('preserved historical exact source snapshots',len(rows))
