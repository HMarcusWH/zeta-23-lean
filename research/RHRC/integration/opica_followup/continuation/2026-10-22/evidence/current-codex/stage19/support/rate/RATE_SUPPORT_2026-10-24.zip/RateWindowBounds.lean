import Zeta23.OPICAFollowup.NativeWindowRate

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23.CCM
namespace Zeta23.OPICAFollowup.Stage19Rate

/-- The literal window energy has the sharp theta envelope, at every source
order and every real horizon whose window begins after zero. -/
theorem nativeWindowEnergy_upper (d : ℕ) {C T : ℝ} (hC : 0 ≤ C) (hT : 1 ≤ T)
    (hstart : 0 ≤ T-C*Real.log T) :
    nativeWindowEnergy d C T ≤ C*Real.log T*(nativeFieldOrderConstant d)^2*
      Real.exp (2*nativeZeroDisplacementSup*T) := by
  obtain ⟨A,hA,henv⟩ := native_field_theta_envelope
  have htheta : 0 ≤ nativeZeroDisplacementSup := native_zero_sup_bounds.1
  have hCT : 0 ≤ C*Real.log T := mul_nonneg hC (Real.log_nonneg hT)
  have hlen : T-C*Real.log T ≤ T := by linarith
  let B := (nativeFieldOrderConstant d)^2*Real.exp (2*nativeZeroDisplacementSup*T)
  have hi : nativeWindowEnergy d C T ≤ ∫ _t : ℝ in Icc (T-C*Real.log T) T, B := by
    apply setIntegral_mono_on (nativeWindowEnergy_integrable d C T)
      ((continuous_const : Continuous (fun _ : ℝ => B)).continuousOn.integrableOn_compact isCompact_Icc)
      measurableSet_Icc
    intro t ht
    have hp := (henv d).2.1 t (hstart.trans ht.1)
    have he := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left ht.2 htheta)
    have hK := (henv d).1
    have hbound := hp.trans (mul_le_mul_of_nonneg_left he hK.le)
    have hsquare := pow_le_pow_left₀ (abs_nonneg (primeFieldFamily d t)) hbound 2
    calc
      |primeFieldFamily d t|^2 ≤
        (nativeFieldOrderConstant d*Real.exp (nativeZeroDisplacementSup*T))^2 := hsquare
      _ = B := by dsimp [B]; rw [mul_pow, ← Real.exp_nat_mul]; congr 2 <;> ring
  calc
    nativeWindowEnergy d C T ≤ ∫ _t : ℝ in Icc (T-C*Real.log T) T, B := hi
    _ = _ := by
      rw [setIntegral_const, Real.volume_real_Icc_of_le hlen, smul_eq_mul]
      dsimp [B]
      ring

/-- Polynomially weaker than the paper's inverse-alpha prefactor, but with
the same required exponential separation. The actual early prime-field memory
is used; its envelope is discharged internally. -/
theorem native_oldMemory_upper (d : ℕ) {alpha C T : ℝ} (ha : 0 ≤ alpha)
    (hC : 0 ≤ C) (hT : 1 ≤ T) (hstart : 0 ≤ T-C*Real.log T) :
    (∫ s : ℝ in Icc 0 (T-C*Real.log T),
      Real.exp (-alpha*(T-s))*|primeFieldFamily d s|) ≤
      T*nativeFieldOrderConstant d*
        Real.exp (nativeZeroDisplacementSup*T-(alpha+nativeZeroDisplacementSup)*C*Real.log T) := by
  obtain ⟨A,hA,henv⟩ := native_field_theta_envelope
  have htheta : 0 ≤ nativeZeroDisplacementSup := native_zero_sup_bounds.1
  have hCT : 0 ≤ C*Real.log T := mul_nonneg hC (Real.log_nonneg hT)
  have hecont : Continuous (fun s : ℝ => Real.exp (-alpha*(T-s))) := by fun_prop
  have hcont : Continuous (fun s : ℝ =>
      Real.exp (-alpha*(T-s))*|primeFieldFamily d s|) :=
    hecont.mul (primeFieldFamily_contDiff d).continuous.abs
  let B := nativeFieldOrderConstant d*
    Real.exp (nativeZeroDisplacementSup*T-(alpha+nativeZeroDisplacementSup)*C*Real.log T)
  have hi : (∫ s : ℝ in Icc 0 (T-C*Real.log T),
      Real.exp (-alpha*(T-s))*|primeFieldFamily d s|) ≤
      ∫ _s : ℝ in Icc 0 (T-C*Real.log T), B := by
    apply setIntegral_mono_on (hcont.continuousOn.integrableOn_compact isCompact_Icc)
      ((continuous_const : Continuous (fun _ : ℝ => B)).continuousOn.integrableOn_compact isCompact_Icc)
      measurableSet_Icc
    intro s hs
    have hp := mul_le_mul_of_nonneg_left ((henv d).2.1 s hs.1) (Real.exp_nonneg (-alpha*(T-s)))
    have hex : -alpha*(T-s)+nativeZeroDisplacementSup*s ≤
        nativeZeroDisplacementSup*T-(alpha+nativeZeroDisplacementSup)*C*Real.log T := by
      nlinarith [mul_le_mul_of_nonneg_left hs.2 (add_nonneg ha htheta)]
    calc
      _ ≤ Real.exp (-alpha*(T-s))*(nativeFieldOrderConstant d*Real.exp (nativeZeroDisplacementSup*s)) := hp
      _ = nativeFieldOrderConstant d*Real.exp (-alpha*(T-s)+nativeZeroDisplacementSup*s) := by
        rw [Real.exp_add]; ring
      _ ≤ B := mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr hex) (henv d).1.le
  calc
    _ ≤ ∫ _s : ℝ in Icc 0 (T-C*Real.log T), B := hi
    _ = (T-C*Real.log T)*nativeFieldOrderConstant d*
        Real.exp (nativeZeroDisplacementSup*T-(alpha+nativeZeroDisplacementSup)*C*Real.log T) := by
      rw [setIntegral_const, Real.volume_real_Icc_of_le hstart, sub_zero, smul_eq_mul]
      dsimp [B]
      ring
    _ ≤ _ := by
      apply mul_le_mul_of_nonneg_right _ (Real.exp_nonneg _)
      apply mul_le_mul_of_nonneg_right _ (henv d).1.le
      linarith

#print axioms nativeWindowEnergy_upper
#print axioms native_oldMemory_upper
end Zeta23.OPICAFollowup.Stage19Rate
