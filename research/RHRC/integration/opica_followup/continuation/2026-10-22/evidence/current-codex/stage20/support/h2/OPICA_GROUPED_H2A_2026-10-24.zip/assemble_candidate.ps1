$opicaOld=(Resolve-Path '../audit-math').Path
$opicaNext=(Resolve-Path '../audit-math-next').Path
$opicaGroup=(Get-Location).Path
$opicaSourcePaths=@(
 (Join-Path $opicaOld 'ConfluentAlgebra.lean'),
 (Join-Path $opicaOld 'NewtonHermite.lean'),
 (Join-Path $opicaOld 'CoordinateConfluent.lean'),
 (Join-Path $opicaOld 'AffineConfluent.lean'),
 (Join-Path $opicaOld 'HasseNormalizedDerivative.lean'),
 (Join-Path $opicaOld 'ActualFirstCell.lean'),
 (Join-Path $opicaNext 'ShFiniteTaylor.lean'),
 (Join-Path $opicaNext 'ActualJetTaylor.lean'),
 (Join-Path $opicaNext 'ShAccumulatingCoefficientExtraction.lean'),
 (Join-Path $opicaNext 'ActualMeasureCell.lean'),
 (Join-Path $opicaNext 'ActualMeasureCellAE.lean'),
 (Join-Path $opicaNext 'ActualMeasureCellAccumulation.lean'),
 (Join-Path $opicaNext 'FiniteJetCombinationRemainder.lean'),
 (Join-Path $opicaNext 'AccumulatingRightCellCoefficientBridge.lean')
)
$opicaTailPaths=@((Join-Path $opicaNext 'ExpandedActualMeasureIndependence.lean'),(Join-Path $opicaGroup 'GroupedIndex.lean'),(Join-Path $opicaGroup 'GroupedProducts.lean'),(Join-Path $opicaGroup 'GroupedActualConfluent.lean'))
$opicaImports=@('import Zeta23.OPICAFollowup.CoPoissonJets')
$opicaBodies=@()
$opicaFragmentHashes=@()
foreach($opicaPath in ($opicaSourcePaths+$opicaTailPaths)){
 foreach($opicaLine in (Get-Content -LiteralPath $opicaPath)){
  if($opicaLine -match '^import Mathlib\.' -and $opicaImports -notcontains $opicaLine){$opicaImports+=$opicaLine}
 }
}
foreach($opicaPath in $opicaSourcePaths){
 $opicaHash=(Get-FileHash -LiteralPath $opicaPath -Algorithm SHA256).Hash.ToLowerInvariant()
 $opicaFragmentHashes += [ordered]@{source=$opicaPath;sha256=$opicaHash}
 $opicaBody=(Get-Content -LiteralPath $opicaPath | Where-Object {$_ -notmatch '^import ' -and $_ -notmatch '^#print axioms'}) -join "`n"
 $opicaLabel=Split-Path -Leaf $opicaPath
 $opicaBodies += "/- Verified source fragment: $opicaLabel ; sha256=$opicaHash -/`nsection`n$opicaBody`nend`nend"
}
$opicaRowPath=Join-Path $opicaNext 'RightCellIndependence.lean'
$opicaRowSource=Get-Content -Raw -LiteralPath $opicaRowPath
$opicaRowStart=$opicaRowSource.IndexOf('theorem actual_polynomial_row')
$opicaRowEnd=$opicaRowSource.IndexOf('/-- Independence',$opicaRowStart)
$opicaRowText=$opicaRowSource.Substring($opicaRowStart,$opicaRowEnd-$opicaRowStart)
$opicaFragmentHashes += [ordered]@{source="$opicaRowPath#actual_polynomial_row";sha256=(Get-FileHash -LiteralPath $opicaRowPath -Algorithm SHA256).Hash.ToLowerInvariant();hash_scope='whole enclosing sealed source file; one named theorem extracted'}
$opicaBodies += "section`nnoncomputable section`nnamespace OPICARightCellTaylor`nopen Polynomial OPICAConfluentAudit`n$opicaRowText`nend OPICARightCellTaylor`nend`nend"
foreach($opicaPath in $opicaTailPaths){
 $opicaHash=(Get-FileHash -LiteralPath $opicaPath -Algorithm SHA256).Hash.ToLowerInvariant()
 $opicaFragmentHashes += [ordered]@{source=$opicaPath;sha256=$opicaHash}
 $opicaBody=(Get-Content -LiteralPath $opicaPath | Where-Object {$_ -notmatch '^import ' -and $_ -notmatch '^#print axioms'}) -join "`n"
 $opicaLabel=Split-Path -Leaf $opicaPath
 $opicaBodies += "/- Source fragment: $opicaLabel ; sha256=$opicaHash -/`nsection`n$opicaBody`nend`nend"
}
$opicaHeader="/- Candidate ConfluentProfiles module. Original roots retain their complete grouped contracts.`nThe only direct project import is frozen CoPoissonJets. Compilation and physical expected consumers`nmust pass before any original-root authority is recorded. RH and Step 4 remain OPEN. -/"
$opicaFull=(($opicaImports -join "`n")+"`n`n$opicaHeader`nset_option maxHeartbeats 800000`n`n"+($opicaBodies -join "`n`n")+"`n`n#print axioms Zeta23.OPICAFollowup.profile_jet_confluent_determinant`n#print axioms Zeta23.OPICAFollowup.finite_zero_jet_independent`n")
Set-Content -LiteralPath ConfluentProfilesCandidate.lean -Value $opicaFull
$opicaFragmentHashes|ConvertTo-Json -Depth 4|Set-Content -LiteralPath ConfluentProfilesCandidate.fragments.json
Write-Output "candidate_lines=$((Get-Content ConfluentProfilesCandidate.lean).Count)"
$opicaImports | Where-Object {$_ -match 'Zeta23'}
