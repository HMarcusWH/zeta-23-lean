import ExpandedActualMeasureIndependence

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform
namespace OPICAIndependentExpandedActual
open Zeta23.OPICAFollowup

def independentOrder {M : ℕ} (ρ : Fin M → ℂ) (i : Fin M) : ℕ := by
  classical
  exact ((Finset.Iio i).filter (fun j => spectralKappa (ρ j) = spectralKappa (ρ i))).card

theorem independent_order_eq {M : ℕ} (ρ : Fin M → ℂ) (i : Fin M) :
    independentOrder ρ i =
      OPICAConfluentAudit.repeatedJetOrder (fun j => spectralKappa (ρ j)) i := by
  unfold independentOrder OPICAConfluentAudit.repeatedJetOrder OPICAConfluentAudit.priorMatches
  rw [Finset.filter_congr_decidable]

/-- The independent expected consumer asks for genuine linear independence of
the actual embedded measures, with the cumulative orders defined independently.
The canonical grouped primary signature remains a separate obligation. -/
theorem expected_actual_measure_linearIndependent {M : ℕ} (ρ : Fin M → ℂ)
    (h0 : ∀ i, 0 < (ρ i).re) (h1 : ∀ i, (ρ i).re < 1)
    (hz : ∀ i, riemannZeta (ρ i) = 0)
    (hk : ∀ i, independentOrder ρ i < zeroJetOrder (ρ i)) :
    LinearIndependent ℂ (fun i =>
      (normalizedZeroMeasureJet (ρ i) (independentOrder ρ i)).distributionOfLinearGrowth
        (normalizedZeroMeasureJet_hasLinearGrowth (h0 i) (h1 i) (zero_ne_half (hz i)) (hk i))) := by
  simp only [independent_order_eq] at hk ⊢
  apply Fintype.linearIndependent_iff.mpr
  intro c hc i
  exact congrFun
    (OPICAActualMeasureCell.expanded_actual_zero_measure_jet_independent ρ c h0 h1 hz hk hc) i

#print axioms expected_actual_measure_linearIndependent
end OPICAIndependentExpandedActual
