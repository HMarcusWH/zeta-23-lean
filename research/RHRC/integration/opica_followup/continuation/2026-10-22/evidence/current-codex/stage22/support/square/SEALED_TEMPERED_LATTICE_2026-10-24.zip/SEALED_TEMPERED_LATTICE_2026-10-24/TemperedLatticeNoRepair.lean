import SchwartzCompactApprox
import SquareDefectPhysicalFullCandidate

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology FourierTransform SchwartzMap ContDiff

namespace Zeta23.OPICAFollowup
open Zeta23.OPICA
namespace TemperedLatticeBridge

/-- The original distribution-tempered measure domain: agreement only on compact
smooth tests, without a variation-growth or global Schwartz-integrability premise. -/
def ExtendsCompactPairing (σ : LocallyFiniteComplexMeasure)
    (T : TemperedDistribution ℝ ℂ) : Prop :=
  ∀ φ : 𝓢(ℝ,ℂ), HasCompactSupport (φ : ℝ → ℂ) → T φ=σ.integral φ

/-- Compact smooth tests determine a tempered distribution. This statement
does not use a measure or a support/growth hypothesis. -/
theorem eq_of_compact_agreement (T U : TemperedDistribution ℝ ℂ)
    (hTU : ∀ φ : 𝓢(ℝ,ℂ), HasCompactSupport (φ : ℝ → ℂ) → T φ=U φ) : T=U := by
  ext φ
  have hT := (T.continuous.tendsto φ).comp (compactApprox_tendsto φ)
  have hU := (U.continuous.tendsto φ).comp (compactApprox_tendsto φ)
  exact tendsto_nhds_unique hT (hU.congr (fun N =>
    (hTU (compactApprox φ N) (compactApprox_hasCompactSupport φ N)).symm))

theorem extension_unique (σ : LocallyFiniteComplexMeasure) (T U : TemperedDistribution ℝ ℂ)
    (hT : ExtendsCompactPairing σ T) (hU : ExtendsCompactPairing σ U) : T=U := by
  exact eq_of_compact_agreement T U (fun φ hφ => (hT φ hφ).trans (hU φ hφ).symm)

theorem extension_annihilates_lattice_zero
    (σ : LocallyFiniteComplexMeasure) (T : TemperedDistribution ℝ ℂ)
    (hσ : σ.totalVariation (Set.range (fun n : ℤ => (n : ℝ)))ᶜ=0)
    (hT : ExtendsCompactPairing σ T)
    (φ : 𝓢(ℝ,ℂ)) (hφ : ∀ n : ℤ, φ n=0) : T φ=0 := by
  have hcontrol : σ.variationControl (Set.range (fun n : ℤ => (n : ℝ)))ᶜ=0 := by
    apply le_antisymm _ zero_le
    have hs := SquarePhysicalSupport.variationControl_le_two_totalVariation σ
      (Set.range (fun n : ℤ => (n : ℝ)))ᶜ
    simpa only [Measure.add_apply,hσ,add_zero] using hs
  let Φ : ℕ → 𝓢(ℝ,ℂ) := compactApprox φ
  have hc (N : ℕ) : HasCompactSupport (Φ N : ℝ → ℂ) :=
    compactApprox_hasCompactSupport φ N
  have hz (N : ℕ) : T (Φ N)=0 := by
    rw [hT _ (hc N)]
    have heq := SquarePhysicalSupport.complex_integral_congr_on_lattice σ hcontrol (Φ N) 0
      (fun n => by simpa only [Pi.zero_apply] using compactApprox_zero φ (hφ n) N)
    simpa only [LocallyFiniteComplexMeasure.integral, Pi.zero_apply, integral_zero,
      sub_self,mul_zero,add_zero] using heq
  have hlim : Tendsto (fun N => T (Φ N)) atTop (𝓝 (T φ)) :=
    (T.continuous.tendsto φ).comp
      (compactApprox_tendsto φ)
  have hlim0 : Tendsto (fun N => T (Φ N)) atTop (𝓝 0) :=
    tendsto_const_nhds.congr (fun N => (hz N).symm)
  exact tendsto_nhds_unique hlim hlim0

theorem extension_congr_on_lattice
    (σ : LocallyFiniteComplexMeasure) (T : TemperedDistribution ℝ ℂ)
    (hσ : σ.totalVariation (Set.range (fun n : ℤ => (n : ℝ)))ᶜ=0)
    (hT : ExtendsCompactPairing σ T)
    (φ ψ : 𝓢(ℝ,ℂ)) (hφψ : ∀ n : ℤ, φ n=ψ n) : T φ=T ψ := by
  have h := extension_annihilates_lattice_zero σ T hσ hT (φ-ψ)
    (fun n => by simp [hφψ n])
  simpa only [map_sub,sub_eq_zero] using h

end TemperedLatticeBridge

/-- Full distribution-tempered correction domain. An arbitrary actual locally
finite complex measure supported on the integer lattice and any tempered extension
of its compact-test pairing cannot repair the actual square measure. -/
theorem square_actual_no_distribution_tempered_measure_repair {h : ℝ → ℂ} {A : ℂ}
    (hev : ∀ x,h (-x)=h x) (hcont : Continuous h) (hint : Integrable h)
    (hL2 : MemLp h 2) (hsd : 𝓕 h=h) (hvan : Tendsto h (cocompact ℝ) (𝓝 0))
    (hpl : ∀ x,|x|≤1 → h x=A) (hne : h≠0)
    (σ : LocallyFiniteComplexMeasure) (T : TemperedDistribution ℝ ℂ)
    (hσ : σ.totalVariation (Set.range (fun n : ℤ => (n : ℝ)))ᶜ=0)
    (hT : TemperedLatticeBridge.ExtendsCompactPairing σ T) :
    𝓕 ((squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)+T) ≠
      (squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)+T := by
  intro hself
  have hd0 : squareDualityDefect h 0≠0 := by
    obtain ⟨heq,hpos,-⟩ := square_defect_origin_positive hev hcont hL2 hpl hne
    rw [heq]
    exact_mod_cast hpos.ne'
  apply SquarePhysicalSupport.no_lattice_supported_functional_repair
    hcont hint hL2 hsd hev hvan A hd0 (fun φ => T φ)
    (TemperedLatticeBridge.extension_annihilates_lattice_zero σ T hσ hT)
    (TemperedLatticeBridge.extension_congr_on_lattice σ T hσ hT)
  intro φ
  have hp := congrArg (fun S : TemperedDistribution ℝ ℂ => S φ) hself
  simpa only [TemperedDistribution.fourier_apply,map_add,ContinuousLinearMap.add_apply,
    squareGapJordan_pairing hcont hvan A] using hp

/-- The full correction-domain barrier survives addition of any selfdual
tempered distribution, including the actual finite zero-jet span. -/
theorem square_actual_no_selfdual_and_distribution_tempered_measure_repair
    {h : ℝ → ℂ} {A : ℂ}
    (hev : ∀ x,h (-x)=h x) (hcont : Continuous h) (hint : Integrable h)
    (hL2 : MemLp h 2) (hsd : 𝓕 h=h) (hvan : Tendsto h (cocompact ℝ) (𝓝 0))
    (hpl : ∀ x,|x|≤1 → h x=A) (hne : h≠0)
    (S : TemperedDistribution ℝ ℂ) (hS : 𝓕 S=S)
    (σ : LocallyFiniteComplexMeasure) (T : TemperedDistribution ℝ ℂ)
    (hσ : σ.totalVariation (Set.range (fun n : ℤ => (n : ℝ)))ᶜ=0)
    (hT : TemperedLatticeBridge.ExtendsCompactPairing σ T) :
    𝓕 ((squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)+S+T) ≠
      (squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)+S+T := by
  intro hs
  apply square_actual_no_distribution_tempered_measure_repair
    hev hcont hint hL2 hsd hvan hpl hne σ T hσ hT
  apply add_right_cancel (b := S)
  simpa only [FourierTransform.fourier_add,hS,add_assoc,add_comm,add_left_comm] using hs

#print axioms TemperedLatticeBridge.extension_annihilates_lattice_zero
#print axioms TemperedLatticeBridge.eq_of_compact_agreement
#print axioms TemperedLatticeBridge.extension_unique
#print axioms TemperedLatticeBridge.extension_congr_on_lattice
#print axioms square_actual_no_distribution_tempered_measure_repair
#print axioms square_actual_no_selfdual_and_distribution_tempered_measure_repair

end Zeta23.OPICAFollowup
