# Full distribution-tempered lattice correction domain — 24 October 2026

**PROVED in the native narrow source gates:** the actual square obstruction
extends to every actual locally finite complex measure supported on the
integer lattice that has a tempered-distribution extension of its compact
smooth test pairing. No true-total-variation temperate-growth premise or
global Schwartz integrability is assumed. An arbitrary additional selfdual
tempered distribution cannot remove this obstruction.

This is a supporting full-domain completion of the frozen SquareDefect
contract. It does not add a primary root, change the original 100 obligations,
register a claim, seal a production review or establish aggregate acceptance.
RH and Step4 remain OPEN.

## What became formally true

The exact correction domain consists of:

* `σ : LocallyFiniteComplexMeasure`, the existing faithful coordinate-Jordan
  representation of actual locally finite complex measures;
* `T : TemperedDistribution ℝ ℂ`;
* actual true-total-variation support
  `σ.totalVariation (range (fun n : ℤ => (n : ℝ)))ᶜ = 0`;
* compact compatibility
  `∀ φ : 𝓢(ℝ,ℂ), HasCompactSupport (φ : ℝ → ℂ) → T φ = σ.integral φ`.

For every such σ and T and the original even, continuous, selfdual, L1/L2,
vanishing-at-infinity, nonzero source h with plateau A on [-1,1],
`square_actual_no_distribution_tempered_measure_repair` proves
`𝓕 (Tτ + T) ≠ Tτ + T`, with `Tτ` the actual previously constructed square
Jordan measure's tempered distribution. The source and actual measure are
unchanged. The source assumptions are exactly those used by the existing
physical square theorem.

The proof supplies an explicit fixed compact smooth unit bump and its scales.
Multiplication by the Nth scale gives `compactApprox φ N`, compactly supported
and preserving every pointwise zero of φ. The derivative product estimate and
one extra decay power show that every Schwartz seminorm of the error is at
most `C / (N + 1)`, where C may depend on φ and the chosen seminorm but not N.
Thus approximation converges in the full Schwartz topology. Compact
compatibility and actual support make T vanish on compact lattice-zero
approximants; continuity makes T vanish on every lattice-zero Schwartz test.
Linearity then derives congruence of pairings when lattice values agree.
The previously GREEN generic periodicity/continuous-C0-defect argument now
applies with no growth or coefficient reconstruction.

`eq_of_compact_agreement` proves that compact smooth tests determine any two
tempered distributions; `extension_unique` applies this to any actual measure,
without a support or growth assumption. The full-domain mixed theorem permits
any additional S with `𝓕 S = S` and proves
`𝓕 (Tτ + S + T) ≠ Tτ + S + T`.

## Exact sources and native evidence

The checked checkout is commit `5ad2fc2df49ed551a8e3040a0dff65939aef015a`, tree
`bb9a2c03d02f34db68e59ee89bb80a1e24e31c7b`. The initial assigned baseline was
`139c1a0d88cc0fb2d8a0d8ea71e152b25b14c36e`; the owner advanced the checkout
while this scratch work was in progress. Each final receipt records its exact
checked source/object dependency hashes and source stability.

Native compiler: Lean `4.33.0-rc2`, Windows x86_64, commit
`d8b18978322de05a8f3dba51ef03cf5461676c17`.
Mathlib remains pinned to `51e6992efd06126df61a496bebf8f49482a4e129`;
`lake-manifest.json` SHA256
`1847b362e15efd927e75aa8b5442e491f998e4a3f730f9dcaca9841f2957c448`.
Each narrow compiler invocation uses `LEAN_NUM_THREADS=2` and writes only
inside this scratch directory. No source, dependency cache, pin, workflow,
registry, claim object, review seal or synced project file was edited here.

| Exact source | SHA256 |
| --- | --- |
| `SchwartzCompactApprox.lean` | `f2ceb97fa0d10b67bcf7036709e898087dfd04bf44808098ac0f4461a1600ad9` |
| `TemperedLatticeNoRepair.lean` | `bd0c74c720d1c7eb56f19d60b8845b887db8c2ba54bfec000f02c4007da11af5` |
| `ExpectedTemperedLatticeNoRepair.lean` | `9e9edd98bda335a4b3a04aa490a7816639ca7620f14757e53fba30f1c52d7cc8` |
| `TemperedLatticeAxiomAudit.lean` | `e973810f23cdbe19fe27d0aebfdf356251d778edf78074c1e261a1ed243d3d93` |

The bridge imports the exact previously GREEN physical square scratch module,
SHA256 `c65b7b8eb6894a89a12a85e36ea660c97ca8deeb47900392786b20ae81b4ee58`.
That physical module preserves the original Square source as an exact byte
prefix. Its underlying original source is SHA256
`da73276d089068c1711f3854a9520fbcbbbc877d77ccc33fe20cb9ceb83d64d1`.

## Workflow harvest

These are local narrow formal-validity and adversarial checks, not GitHub CI
jobs or full-release receipts. The owner's complete workflow harvest remains
a separate obligation.

| Gate | Actual disposition |
| --- | --- |
| `cutoff7` | Native exit 0; source unchanged; full Schwartz approximation and compact-support statements compiled; three displayed closures use only `propext`, `Classical.choice`, `Quot.sound`. |
| `bridge1` | Native exit 0; source unchanged; annihilation, lattice congruence, compact-test determination, extension uniqueness, full-domain no repair and mixed selfdual barrier compiled; all six displayed closures use only the same standard axioms. |
| `expected1` | Native exit 0; source unchanged; five independent full-type/specialization/uniqueness/mixed/falsification declarations compiled with standard-only closures. The original-domain consumer expands compact compatibility inline. |
| `negative1` | Expected compiler rejection: an arbitrary T cannot be constrained by support of an unrelated σ when compact compatibility is omitted. Exact error is a missing `ExtendsCompactPairing σ T` argument. |
| `final-axioms` | Native exit 0; source unchanged; all 17 fully qualified support/bridge/consumer/falsifier declarations print closures containing only `propext`, `Classical.choice`, `Quot.sound`. Log SHA256 `7f364c4d3c20987a9036f8945ba524ddfd01b3b9fb735614050a2ba95a0a6108`. |
| Initial/cutoff1–6 attempts | Failed local proof-engineering attempts. They established no theorem authority. Error-recovery `sorryAx` output from failed attempts is not part of the final GREEN closures or delivery seal. |

The independent expected-type source additionally proves the semantic
falsifier `∀ S, ∃ T, 𝓕 (S+T)=S+T`, by choosing T=-S. Hence the compatibility
hypothesis is mathematically necessary: without it even the actual square
can be canceled exactly by a free tempered distribution.

## What changed

Earlier no-repair code first used polynomially bounded lattice coefficients;
the actual physical supplement then quantified arbitrary genuine σ with
true-TV temperate growth. The present theorem covers the broader original
distribution-tempered interpretation and does not replace it with stronger
global integrability. The new proof derives exactly the lattice-zero and
equal-lattice-values facts needed by the existing periodicity theorem.

The implication from a compact-compatible lattice measure's tempered
extension to true-TV `HasTemperateGrowth` is still not separately formalized.
It is unnecessary for this full-domain no-repair proof. No such equivalence
is claimed as Lean authority. The classical distinction and lattice-support
equivalence are in Baake–Strungaru, *A note on tempered measures*, Definition
2.1, Theorem 2.7, Theorem 4.4 and Corollary 4.5:
<https://arxiv.org/html/2202.09175v2>. The direct density method here is
classical functional analysis, not a new general RH insight or a new claimed
literature result.

## Upstream implications

The reusable result is explicit compact approximation in the Schwartz
topology, preserving an arbitrary zero set. Compact-test determination and
uniqueness compress later physical adapters: after two genuine tempered
distributions are constructed, equality on compact smooth tests suffices for
their global equality. A separate tail-growth adapter need not be reproved
for this equality step. Construction and continuity of each distribution
remain necessary.

## Downstream implications

The actual square plus any selfdual tempered distribution plus any genuine
distribution-tempered lattice measure is blocked. DERIVED by the existing
selfdual finite zero-jet span theorem and the new general mixed barrier: that
actual span cannot repair the square even in the broader correction domain.
The named independent mixed consumer checks the general physical theorem;
this lane does not relabel a new finite-span source instantiation as another
primary root.

## Resurrected routes

The previously missing broad correction-domain route is now discharged
directly. Polynomial coefficient reconstruction and true-TV growth
equivalence can remain independent reusable research tasks; neither blocks
the original square correction contract. Compact-test identities elsewhere
can be reconsidered when both sides already have genuine tempered
constructions.

## New RH-relevant clues

LEAD: use compact approximation to formalize annihilation of the pointwise
vanishing ideal for general supported order-zero tempered measures. The
square barrier still leaves nonlattice and nonselfdual corrections as the
relevant correction space to investigate. These are structural restrictions
on a particular construction, not zero exclusions or an RH implication.

## Falsification checks

The proof uses the full Schwartz seminorm topology, not merely pointwise
convergence. The truncations preserve lattice zeros exactly, so no unproved
convergence of σ's noncompact integrals occurs. The derivative bound is
uniform in N and the decay estimate includes boundary points by the outside
case. The semantic cancellation falsifier shows why compact compatibility
cannot be omitted. The negative consumer rejects exactly that omission.
The existing physical square's plateau, nonzero source, actual lattice
support and order-zero status are retained.

## Highest-leverage next moves

Compile the exact production assembly and its independent expected consumer
after owner integration into the planned `SquareDefect.lean` path. Then run
the cold original-100 and parent-extension/registry/canonical/review gates
on the exact production head, harvest all its workflows and preserve every
OPEN closing claim. The native scratch bridge closes a mathematical domain
gap; it does not supply those aggregate release gates.

`assemble_production.py` produces a scratch standalone assembly by adding the
three Mathlib imports, preserving the exact c65b physical body, removing only
scratch imports from the supplementary bodies, and fully qualifying their
inline axiom audit names. The prepared assembly SHA256 is
`98c3688c4e293519aa79e3da6aaba02bcb2bca6d132ae18f16dbc4c58986ff48`;
`assembly-preparation.json` records that the physical body is unchanged.
Preparation alone is not a native receipt for the assembled source.
