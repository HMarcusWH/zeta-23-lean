"""Read-only source review and focused execution of the real unregistered loader."""
import ast
from pathlib import Path
import importlib.abc
import importlib.util
import json
import subprocess
import sys
import types
import unittest
from unittest.mock import patch
from prepare_review import HERE, REPO, sha, read_json, write_json

PROPOSAL=HERE.parent/'opica-stage23/parent-import-proposal-v2'
OUT=HERE/'parent-import-review';OUT.mkdir(exist_ok=True)
folder=REPO/'research/RHRC/integration/opica'
source=(PROPOSAL/'validate_contract.py').read_bytes()
test_source=(PROPOSAL/'test_contract.py').read_bytes()

def require(ok,message):
    if not ok:raise ValueError(message)

def execute():
    class ProposedLoader(importlib.abc.Loader):
        def create_module(self,spec):return None
        def exec_module(self,module):
            module.__file__=str(folder/'validate_contract.py')
            exec(compile(source,module.__file__,'exec'),module.__dict__)
    real_spec=importlib.util.spec_from_file_location
    def requested(name,path,*args,**kwargs):
        if name=='opica_contract':
            return importlib.util.spec_from_loader(name,ProposedLoader(),origin=str(folder/'validate_contract.py'))
        return real_spec(name,path,*args,**kwargs)
    module=types.ModuleType('nonauthor_exact_parent_import_test_source')
    module.__file__=str(folder/'tests/test_contract.py')
    with patch.object(importlib.util,'spec_from_file_location',side_effect=requested):
        exec(compile(test_source,module.__file__,'exec'),module.__dict__)
    require('opica_contract' not in sys.modules,'fixture accidentally registered parent validator')
    cls=module.DocumentationReviewTests
    suite=unittest.TestSuite(cls(name) for name in [
        'test_full_root_extension_still_rejects_absent_full_reviewed_types',
        'test_exact_provider_supports_unregistered_parent_module_import'])
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    print('PARENT_IMPORT_FIX_TEST_RESULT '+json.dumps({'tests_run':result.testsRun,
        'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
        'successful':result.wasSuccessful(),'parent_module_registered':False,'fixture_authority':'SYNTHETIC_ONLY'}))
    return 0 if result.wasSuccessful() else 1

def main():
    require(sha(source)=='67e1fd0202a3308220ab219c39dfab02ccbc376a0f8702b5f06c0b84e73d26d3','proposal parent changed')
    require(sha(test_source)=='5108cb7f0fb9ad7a4db29fc0927da20eb0e17339fdd8cf8ad98d4c1e7b1e688e','proposal tests changed')
    current=(folder/'validate_contract.py').read_bytes()
    def funcs(t):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(t).body if isinstance(n,ast.FunctionDef)}
    old,new=funcs(current),funcs(source)
    require(set(old)==set(new),'unexpected runtime function inventory change')
    require({n for n in old if old[n]!=new[n]}=={'_exact_source_extension_context'},'runtime delta exceeds actual helper namespace repair')
    descriptor=read_json(REPO/'research/RHRC/integration/opica_followup/PARENT_EXTENSION.json')
    require('research/RHRC/integration/opica/tests/test_contract.py' in descriptor['modified_exact_paths'],
            'parent test fixture path is outside original authority')
    runs=[]
    for mode in ['normal','optimized']:
        command=[sys.executable,'-B']+(['-O'] if mode=='optimized' else [])+[str(Path(__file__)),'--child']
        p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (OUT/(mode+'.log')).write_bytes(p.stdout)
        marker='PARENT_IMPORT_FIX_TEST_RESULT '
        row=json.loads(next(line[len(marker):] for line in p.stdout.decode().splitlines() if line.startswith(marker)))
        require(p.returncode==0 and row['tests_run']==2 and row['failures']==row['errors']==row['skips']==0,
                'actual unregistered loader/fail-closed fixture did not pass')
        runs.append({'mode':mode,'command':command,'exit_code':p.returncode,'result':row,'log_sha256':sha(p.stdout)})
    require((folder/'validate_contract.py').read_bytes()==current,'owner changed runtime source during focused source comparison')
    review={'schema':'OPICA_NONAUTHOR_PARENT_IMPORT_HELPER_NAMESPACE_REVIEW_V1',
        'status':'NARROW_RUNTIME_LOADER_AND_MISSING_TYPE_FIXTURE_REVIEWED',
        'parent_source_sha256':sha(source),'test_source_sha256':sha(test_source),'runs':runs,
        'actual_unregistered_module_loader_exercised':True,
        'runtime_review':'Only the actual V2 provider call changes from sys.modules[__name__] to a SimpleNamespace carrying the actual three required parent helpers. Their function globals and names remain real. No source/registry/type/policy predicate is replaced or skipped.',
        'fixture_review':'The old missing-types assertion and actual caller are retained. The negative fixture explicitly removes the current table and forces the legacy probe, so live reviewed metadata does not invalidate its absence premise. New positive checks actual helper identities in an intentionally unregistered validator module.',
        'full_installed_suite_and_genuine_acceptance':'SEPARATE_REQUIRED','owner_writes':False,
        'human_review':'NOT_ESTABLISHED','RH':'OPEN','Step4':'OPEN','full_release':'OPEN'}
    write_json(OUT/'REVIEW.json',review)
    print({'status':review['status'],'tests_per_mode':2,'parent_source_sha256':sha(source)})

if __name__=='__main__':raise SystemExit(execute()) if '--child' in sys.argv else main()
