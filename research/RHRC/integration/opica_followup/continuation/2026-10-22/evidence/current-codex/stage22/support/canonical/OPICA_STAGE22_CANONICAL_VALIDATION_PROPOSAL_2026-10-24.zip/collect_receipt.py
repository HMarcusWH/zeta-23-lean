from pathlib import Path
import json,re,hashlib,subprocess,datetime
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
BASE=REPO/'research/RHRC/integration/opica_followup'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
roots=json.loads((BASE/'PUBLIC_ROOTS.json').read_text())['roots']
log=(HERE/'ValidationAggregateOverlay.log').read_text(encoding='utf-8')
assert 'error:' not in log
assert 'sorryAx' not in log
printed={}
for match in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log,re.S):
    name=match[1];axes={a.strip() for a in match[2].split(',') if a.strip()}
    assert axes<={'propext','Classical.choice','Quot.sound'},(name,axes)
    printed[name]=sorted(axes)
for match in re.finditer(r"'([^']+)' does not depend on any axioms",log):printed[match[1]]=[]
expected=['Zeta23.OPICAFollowup.Validation.'+r['expected_type_consumer'] for r in roots]
assert len(expected)==100 and set(expected)<=set(printed),set(expected)-set(printed)
files=[HERE/'overlay/Zeta23/OPICAFollowup.lean',HERE/'ValidationProposal.lean',HERE/'OPICAFollowupFacadeProposal.lean',
    *[HERE/'overlay/Zeta23/OPICAFollowup'/f for f in ['ConfluentProfiles.lean','SquareDefect.lean','FiniteSpanSeparation.lean','Consumers.lean','Validation.lean']],
    HERE/'overlay/research/RHRC/integration/opica_followup/continuation/2026-10-22/consumers/ExpectedConfluentProfiles.lean']
logs=['ConfluentProfilesRelocated.log','SquareDefectRenamed.log','ExpectedConfluentProfilesRelocated.log','FiniteSpanSeparationAggregateOverlay.log','ConsumersAggregateOverlay.log','ValidationAggregateOverlay.log','FacadeAggregateOverlay.log']
result={'schema':'OPICA_WARM_OVERLAY_AGGREGATE_DIAGNOSTIC_V1','date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status':'WARM_ISOLATED_COMPILER_AND_100_EXPECTED_NAME_AXIOM_AUDIT_ONLY',
    'owner_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    'owner_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO,text=True).strip(),
    'owner_working_status':subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).splitlines(),
    'compiler':'C:/Users/macka/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean.exe',
    'compiler_version':'Lean4.33.0-rc2 x86_64-w64-windows-gnu commit d8b18978322de05a8f3dba51ef03cf5461676c17',
    'isolation':'Explicit LEAN_PATH with scratch overlay and copied project-object snapshot; no production object writes. This is not a cold source-built project check.',
    'command_pattern':'lean --root=<overlay> <source> -o <outside-checkout object>',
    'source_sha256':{str(p.relative_to(HERE)).replace('\\','/'):sha(p) for p in files},
    'compiler_logs':[{'path':f,'sha256':sha(HERE/f),'observed_native_exit_code':0} for f in logs],
    'all100_required_expected_names':{n:printed[n] for n in expected},
    'full_clause_and_physical_domain_review':'NOT_ESTABLISHED; see full-clause-review-input.json; source copies and type matches do not establish approval.',
    'original_root_semantic_acceptance':'NOT_PROMOTED_BY_THIS_RECEIPT',
    'full100_cold_receipt':'NOT_ESTABLISHED','independent_review_seal':'UNSET','registry_projection':'NOT_ACCEPTED',
    'release_ready':False,'RH':'OPEN','Step4':'OPEN',
    'replacement_warning':'Span and Consumer candidate source hashes must match; later public-root composition edits require fresh checks.'}
(HERE/'warm-overlay-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('Strictly audited100 required expected names; all printed standard axioms only.')
print('Source receipt',HERE/'warm-overlay-receipt.json')
