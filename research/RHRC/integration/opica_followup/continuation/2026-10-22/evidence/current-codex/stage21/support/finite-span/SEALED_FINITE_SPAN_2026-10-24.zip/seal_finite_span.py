"""Seal scratch evidence only. Never mutates the owner checkout or its cache."""
from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, zipfile

P = Path(__file__).resolve().parent
B = P.parent / 'audit-budget'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
labels = ['FinalNamespacePinnedModule', 'FinalPhysicalModule',
          'FinalAllExpectedAndFalsifiers', 'FinalNegativeContracts']
expected = {'FiniteSpanSeparationFullCandidate.lean':
            '8e69e7c90abb572cf45d71bd70c0446b6844372d4ae954aeb8274ea3e1f1e5ef',
            'ConsumersSpanFullCandidate.lean':
            'a5ec14ea0c5754ba762034420b58047f6134baa1e8b52fc405c9c06e3872cc6e'}
for name, digest in expected.items():
    assert sha(P / name) == digest

gates = []
axiom_total = 0
for label in labels:
    file = P / (label + '.receipt.json')
    row = json.loads(file.read_text(encoding='utf-8'))
    log = P / (label + '.log')
    assert sha(log) == row['log_sha256']
    assert row['source_unchanged'] and row['source_before'] == row['source_after']
    # The owner may proceed to production after these completed scratch gates.
    # Before/after equality above is the gate; later deltas are explicit provenance.
    changed_later = [{'path': path, 'checked_sha256': digest,
                      'seal_time_sha256': sha(Path(path)) if Path(path).is_file() else None}
                     for path, digest in row['source_before'].items()
                     if not Path(path).is_file() or sha(Path(path)) != digest]
    text = log.read_text(encoding='utf-8')
    axiom_lists = re.findall(r'depends on axioms:\s*\[([^]]*)\]', text, flags=re.S)
    for ax in axiom_lists:
        assert set(ax.replace(' ', '').replace('\n', '').split(',')) <= {
            'propext', 'Classical.choice', 'Quot.sound'}
    axiom_total += len(axiom_lists)
    errors = len(re.findall(r': error(?:\(|:)', text))
    if label == 'FinalNegativeContracts':
        assert row['exit_code'] == 1 and errors == 5
        assert 'Application type mismatch' in text or 'Type mismatch' in text
        assert 'Function.choose' in text and 'Function.choose_spec' in text
        disposition = 'PASS_EXPECTED_REJECTION: four contract-removal controls, five expected diagnostics'
    else:
        assert row['exit_code'] == 0 and errors == 0
        assert 'sorryAx' not in text
        disposition = 'PASS_EXACT_SCRATCH_COMPILATION_STANDARD_AXIOMS_ONLY'
    gates.append({'label': label, 'disposition': disposition,
                  'exit_code': row['exit_code'], 'seconds': row['seconds'],
                  'source_object_input_count': len(row['source_before']),
                  'head_begin': row['head_begin'], 'head_end': row['head'],
                  'tree_begin': row['tree_begin'], 'tree_end': row['tree'],
                  'source_object_pins_unchanged_during_gate': True,
                  'imported_file_changes_after_completed_gate': changed_later,
                  'receipt_sha256': sha(file), 'log_sha256': sha(log),
                  'axiom_print_count': len(axiom_lists), 'error_count': errors})
assert axiom_total == 13

for name in expected:
    source = (P/name).read_text(encoding='utf-8')
    uncommented = re.sub(r'/\-.*?\-/|--[^\n]*', '', source, flags=re.S)
    assert not re.search(r'\b(?:sorry|admit)\b', uncommented)
    assert not re.search(r'(?m)^\s*(?:private\s+)?(?:axiom|constant|opaque)\b', uncommented)

component = json.loads((P/'FINAL_CHECK_COMPONENTS.json').read_text(encoding='utf-8'))
assert all(sha(P/name) == digest for name, digest in component['sha256'].items())
receipt = {
    'schema': 'OPICA_ACTUAL_FINITE_SPAN_FINAL_SCRATCH_RECEIPT_V1',
    'date_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'code_commit': '9a8b2a4baee49f2056c7945b1544a7bc2893735b',
    'code_tree': '6aa53d22d50d2aa24046d73b128c64a1d262f7f3',
    'later_owner_record_commit': '36b677c26b01fafeac719413753092c5988c38d3',
    'later_owner_record_tree': '919a8f82f804c0389253412fb2b61330ac173dc7',
    'scope': 'Scratch formal evidence only; owner must integrate and replay exact production sources. No root-ledger, cold100, aggregate, RH or Step4 acceptance.',
    'source_sha256': expected,
    'temporal_import_provenance': 'Primary module gate consumed historical ConfluentProfiles source1773e3 and pinned cached object at9a8. Owner later installed namespace-compatible sourcea84c72; physical/final suites pinned that source walk and consumed existing cached objects. No claim that this lane compiled the relocated Confluent source; exact production replay is mandatory.',
    'gates': gates,
    'standard_axiom_prints_total': axiom_total,
    'public_roots': [
        'Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero',
        'Zeta23.OPICAFollowup.fixed_basis_negative_mass_budget',
        'Zeta23.OPICAFollowup.actual_zero_measure_span_consumer'],
    'full_expected_types': {
        'H2b_two_clauses': 'IndependentFullFiniteSpan.full_original_domain_and_independent_basis',
        'global_negative_sqrt_sum_squares_budget': 'IndependentActualFixedBudget.expected_full_actual_euclidean_budget',
        'actual_zero_profiles_jets_separator_and_coefficients': 'IndependentSpanPhysicalConsumer.expected_actual_zero_measure_span_consumer'},
    'physical_domains': [
        'Actual normalized zero-jet measures: zeta(rho)=0, 0<Re(rho)<1, k<zeroJetOrder(rho)',
        'Every finite complex combination canonically realified into genuine Jordan parts',
        'Growth, gap, Fourier selfduality and reflection derived internally',
        'Coefficient uniqueness and budget explicitly require independence of the selected actual real basis distributions',
        'Budget is global, off integer lattice, sinc squared, Euclidean norm, fixed basis only; dimension zero included'],
    'public_root_composition': {
        'physical_consumer': ['copoisson_zero_jets_measures', 'zero_profile_regular_selfdual',
                              'finite_zero_span_positive_only_zero.1', 'finite_zero_span_positive_only_zero.2'],
        'budget_injectivity': ['finite_zero_span_positive_only_zero.2'],
        'canonical_real_imag_generator_independence': 'NOT CLAIMED; explicit actual independent real basis retained'},
    'positive_falsification': [
        'Zero actual basis has no strictly positive coefficient budget',
        'Duplicate actual basis cannot be linearly independent',
        'Reflected rho and 1-rho give the same jet',
        'Dirac at integer2 has growth/gap and zero sinc-weighted image but nonzero positive part',
        'The same Dirac measure is formally not Fourier selfdual'],
    'negative_controls': [
        'Off-lattice nonnegativity removal rejected',
        'Actual multiplicity-bound removal rejected',
        'Real basis independence removal rejected for coefficient uniqueness',
        'Budget theorem API remains a function awaiting independence; missing premise rejected. Mathematical necessity separately established by zero-basis countermodel.'],
    'claim_firewall': {'RH': 'OPEN', 'Step4': 'OPEN', 'cold100': 'OPEN',
                       'aggregate_release': 'OPEN', 'new_original_root_promotion': False},
}
receipt_file = P/'FINITE_SPAN_FINAL_RECEIPT_2026-10-24.json'
receipt_file.write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')

historical_confluent = P/'historical/ConfluentProfiles_at9a8.lean'
historical_confluent.write_bytes(subprocess.check_output(
    ['git', 'show', '9a8b2a4baee49f2056c7945b1544a7bc2893735b:Zeta23/OPICAFollowup/ConfluentProfiles.lean'],
    cwd=P.parent/'opica-followup-repo'))
assert sha(historical_confluent) == '1773e3200a8b3e7284b276d97dcfc5481945e4139852fef8d92e3b64b7b0b0d0'

names = list(expected) + [
    'ExpectedFullFiniteSpanFinal.lean', 'ExpectedActualFixedBudgetFinal.lean',
    'ExpectedSpanPhysicalConsumerFinal.lean', 'WeightedControlsFinal.lean',
    'DuplicateBasisControlFinal.lean', 'NegativeFullFiniteSpanFinal.lean',
    'NegativeBudgetIndependenceFinal.lean', 'AllFinalFiniteSpanChecks.lean',
    'AllFinalNegativeControls.lean', 'FINAL_CHECK_COMPONENTS.json',
    'FiniteSpanScratch.lean', 'FiniteSpanCompact.lean', 'FiniteSpanCombination.lean',
    'FiniteSpanWeighted.lean', 'FiniteSpanSeparationCandidate.lean',
    'ConsumersSpanCandidate.lean', 'assemble_candidate.py', 'assemble_full_candidate.py',
    'prepare_final_checks.py', 'run_scratch.py', 'print_lean_path.py',
    'seal_finite_span.py', 'HANDOFF.md', 'POST_GREEN_FINITE_SPAN_2026-10-24.md',
    receipt_file.name, 'historical/FiniteSpanSeparationFullCandidate_4eba8ef.lean',
    'historical/public-root-dependency.diff', 'historical/ConfluentProfiles_at9a8.lean']
names += [label+ext for label in labels for ext in ('.log', '.receipt.json')]
out = P/'SEALED_FINITE_SPAN_2026-10-24'
assert not out.exists(), 'Never overwrite an existing sealed bundle'
out.mkdir()
for name in names:
    target = out/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(P/name, target)
for name in ['PositiveHomogeneousBudget.lean', 'TVSignedBudget.lean',
             'SincWeightedMeasures.lean', 'ActualFixedBudget.lean',
             'FIXED_BASIS_BUDGET_RECEIPT_2026-10-24.json',
             'POST_GREEN_FIXED_BASIS_BUDGET_2026-10-24.md']:
    target = out/'sealed-budget-components'/name
    target.parent.mkdir(exist_ok=True)
    shutil.copyfile(B/name, target)
reviews = P.parent/'audit-independent-review'
for file in reviews.glob('*'):
    if file.is_file() and ('FINITE_SPAN_ASSEMBLY_REVIEW_DELTA' in file.name or
                           'PHYSICAL_SPAN_CONSUMER_REVIEW' in file.name):
        target = out/'independent-read-reviews'/file.name
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(file, target)
manifest = {str(f.relative_to(out)).replace('\\', '/'): sha(f)
            for f in sorted(out.rglob('*')) if f.is_file()}
manifest_file = out/'FILE_MANIFEST_SHA256.json'
manifest_file.write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
archive = P/'SEALED_FINITE_SPAN_2026-10-24.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
    for f in sorted(out.rglob('*')):
        if f.is_file(): z.write(f, str(f.relative_to(out)).replace('\\', '/'))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, digest in manifest.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == digest
print(json.dumps({'receipt_sha256': sha(receipt_file), 'archive_sha256': sha(archive),
                  'manifest_sha256': sha(manifest_file), 'manifest_entries': len(manifest),
                  'archive_bytes': archive.stat().st_size, 'gates': gates}, indent=2))
