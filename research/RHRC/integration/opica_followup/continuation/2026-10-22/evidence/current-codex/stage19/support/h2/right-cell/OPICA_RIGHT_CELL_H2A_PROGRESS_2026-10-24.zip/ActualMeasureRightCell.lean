import ActualMeasureCellAccumulation

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform

namespace OPICAActualMeasureCell
open Zeta23.OPICAFollowup

/-- Complete actual-measure consumer: a zero relation of prescribed
physical jets supplies exact right-cell zeros accumulating at u=0. -/
theorem actual_measure_relation_gives_accumulating_right_cell_zeros
    {ι : Type*} [Fintype ι] (c : ι → ℂ) (ρ : ι → ℂ) (k : ι → ℕ)
    (h0 : ∀ i, 0 < (ρ i).re) (h1 : ∀ i, (ρ i).re < 1)
    (hh : ∀ i, ρ i ≠ 1 / 2) (hk : ∀ i, k i < zeroJetOrder (ρ i))
    (hzero : (∑ i, c i • (normalizedZeroMeasureJet (ρ i) (k i)).distributionOfLinearGrowth
      (normalizedZeroMeasureJet_hasLinearGrowth (h0 i) (h1 i) (hh i) (hk i))) = 0)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ u : ℝ, 0 < u ∧ u < ε ∧ u < Real.log 2 ∧
      (∑ i, c i * (iteratedDeriv (k i)
        (fun w : ℂ => w * shKernel (1 / 4 - w) u) (spectralKappa (ρ i)) /
          ((k i).factorial : ℂ))) = 0 :=
  first_cell_ae_zero_gives_accumulating_right_cell_zeros c
    (fun i => spectralKappa (ρ i)) k
    (actual_jet_combination_first_cell_ae_zero c ρ k h0 h1 hh hk hzero) hε

#print axioms actual_measure_relation_gives_accumulating_right_cell_zeros

end OPICAActualMeasureCell
