"""Isolated warm diagnostic; never an acceptance or independent review seal."""
from pathlib import Path
import datetime, hashlib, json, os, re, subprocess, time

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'opica-followup-repo'
OVERLAY = HERE / 'overlay'
LEAN = Path('C:/Users/macka/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean.exe')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
env = os.environ.copy()
env['LEAN_PATH'] = ';'.join(map(str, [OVERLAY, REPO / '.lake/build/lib/lean',
    *sorted((REPO / '.lake/packages').glob('*/.lake/build/lib/lean'))]))
env['LEAN_NUM_THREADS'] = '1'

source = (HERE / 'CompareFullExpectedTypesDefault.lean').read_text(encoding='utf-8')
companions = json.loads((HERE / 'full-signature-companion-provenance.json').read_text())
for row in companions:
    rootbase = row['root'].rsplit('.', 1)[1]
    pattern = r'(?m)^(opica_type_comparison ' + re.escape(row['root']) + r' against )\S+$'
    source, n = re.subn(pattern, lambda m: m[1] + row['companion'], source)
    assert n == 1, (rootbase, n)
type_source = HERE / 'CompareFullSignatureCoverage.lean'
type_source.write_text(source, encoding='utf-8')

expected_source = (HERE / 'ExpectedCanonicalInterfaces.lean').read_text(encoding='utf-8')
controls = [
    ('RecoveryWrongCost', 'q = ‖ell x‖ / ‖jointObservation P C x‖} ∧',
        'q = ‖ell x‖ / ‖jointObservation P C x‖} + 1 ∧'),
    ('EulerWrongMultiplier', 'finiteEulerMultiplier Q z * state.laplace z) ∧',
        '(finiteEulerMultiplier Q z + 1) * state.laplace z) ∧'),
    ('ResidualWrongPower', '(1 - riemannZeta (z + 1 / 2) * truncatedMoebiusRealMultiplier Y z)^r *',
        '(1 - riemannZeta (z + 1 / 2) * truncatedMoebiusRealMultiplier Y z)^(r + 1) *'),
]
jobs = [('full-source-signature-coverage', type_source, True)]
for name, before, after in controls:
    assert expected_source.count(before) == 1, name
    path = HERE / ('NegativeCanonical' + name + '.lean')
    path.write_text(expected_source.replace(before, after), encoding='utf-8')
    jobs.append(('negative-' + name, path, False))

receipt = {'schema': 'OPICA_STAGE22_WARM_TYPE_CONTROL_DIAGNOSTIC_V1',
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'RUNNING_UNACCEPTED', 'owner_head': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'compiler': str(LEAN), 'compiler_version': subprocess.check_output([str(LEAN), '--version'], text=True).strip(),
    'isolation': 'Explicit scratch overlay plus inherited project and pinned dependency objects; no owner cache writes. Warm diagnostic only.',
    'release_ready': False, 'independent_semantic_review': 'NOT_ESTABLISHED',
    'RH': 'OPEN', 'Step4': 'OPEN', 'commands': []}
receipt_path = HERE / 'stage22-type-control-receipt.json'
for label, path, positive in jobs:
    log = HERE / (path.stem + '.log')
    argv = [str(LEAN), '-DmaxHeartbeats=800000', '--root=' + str(HERE), str(path), '-o', str(path.with_suffix('.olean'))]
    started = time.monotonic()
    run = subprocess.run(argv, cwd=REPO, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1800)
    log.write_bytes(run.stdout)
    row = {'label': label, 'source': path.name, 'source_sha256': sha(path),
        'argv': argv, 'log': log.name, 'log_sha256': sha(log), 'exit_code': run.returncode,
        'seconds': time.monotonic() - started, 'expected_positive': positive}
    text = run.stdout.decode('utf-8', errors='replace')
    if positive:
        pairs = [line.split('\t') for line in text.splitlines() if line.startswith('OPICA_DIAGNOSTIC_TYPE_COMPARISON\t')]
        row['coverage'] = {'records': len(pairs), 'definitionally_equal': sum(p[-1] == 'DEFINITIONALLY_EQUAL' for p in pairs),
            'other': [p for p in pairs if p[-1] != 'DEFINITIONALLY_EQUAL']}
        ok = run.returncode == 0 and len(pairs) == 100 and not row['coverage']['other'] and 'sorryAx' not in text
    else:
        # Compiler rejection at the changed consumer is evidence, not its error-recovery axiom output.
        ok = run.returncode != 0 and 'error:' in text
    row['expected_disposition_observed'] = ok
    receipt['commands'].append(row)
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(label, 'PASS' if ok else 'UNEXPECTED', run.returncode, flush=True)
    if not ok:
        receipt['status'] = 'DIAGNOSTIC_DISCREPANCY'
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
        raise SystemExit(1)
receipt['status'] = 'WARM_COMPUTABLE_TYPE_COVERAGE_AND_MUTATION_CONTROLS_ONLY'
receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
