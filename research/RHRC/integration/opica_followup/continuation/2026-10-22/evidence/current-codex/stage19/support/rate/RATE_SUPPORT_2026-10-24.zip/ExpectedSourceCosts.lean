import RateSourceCosts

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23 Zeta23.OPICA Zeta23.CCM Zeta23.OPICAFollowup
namespace Stage19IndependentRate

theorem expected_source_both_log_signs (rho : zetaZeroConfig.carrier)
    (hright : 1/2 < (rho : ℂ).re) :
    ∃ Cp : ℝ, 0 < Cp ∧ ∀ d : ℕ,
      |Real.log ‖sourceFamilyLaplace d ((rho : ℂ)-1/2)‖| ≤ Cp*((d : ℝ)+1) :=
  Stage19Rate.sourceFactor_abs_log_bound rho hright

theorem expected_actual_source_sublinear (T : HorizonSchedule) (order : ℕ → ℕ)
    (slow : Tendsto (fun n => (order n : ℝ)*Real.log ((order n : ℝ)+2)/T.time n)
      atTop (𝓝 0)) (rho : zetaZeroConfig.carrier) (hright : 1/2 < (rho : ℂ).re) :
    Tendsto (fun n => Real.log ‖sourceFamilyLaplace (order n) ((rho : ℂ)-1/2)‖/T.time n)
      atTop (𝓝 0) :=
  Stage19Rate.sourceFactor_log_div_time_tendsto_zero T order slow rho hright

theorem expected_actual_field_cost_sublinear (T : HorizonSchedule) (order : ℕ → ℕ)
    (slow : Tendsto (fun n => (order n : ℝ)*Real.log ((order n : ℝ)+2)/T.time n)
      atTop (𝓝 0)) :
    Tendsto (fun n => Real.log (1+nativeFieldOrderConstant (order n))/T.time n)
      atTop (𝓝 0) :=
  Stage19Rate.fieldEnvelope_log_div_time_tendsto_zero T order slow

/-- The correction at d=0 is essential even though it vanishes after division
by a cofinal horizon. This is a negative control on the tempting pointwise bound. -/
theorem dropping_zero_order_correction_is_false :
    ¬ (∀ d : ℕ, ((d : ℝ)+1)*Real.log ((d : ℝ)+2) ≤
      2*((d : ℝ)*Real.log ((d : ℝ)+2))) := by
  intro h
  have hz := h 0
  norm_num at hz
  exact (not_le_of_gt (Real.log_pos (by norm_num : (1 : ℝ)<2))) hz

/-- The literal source vanishes at the excluded elementary points, so a lower
coefficient cost cannot silently be claimed on every complex parameter. -/
theorem actual_elementary_parameter_control (d : ℕ) :
    sourceFamilyLaplace d (1/2) = 0 ∧ sourceFamilyLaplace d (-1/2) = 0 :=
  sourceFamilyLaplace_elementary_zeros d

#print axioms expected_source_both_log_signs
#print axioms expected_actual_source_sublinear
#print axioms expected_actual_field_cost_sublinear
#print axioms dropping_zero_order_correction_is_false
#print axioms actual_elementary_parameter_control
end Stage19IndependentRate
