from pathlib import Path
import hashlib, json, re, subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
BASE=REPO/'research/RHRC/integration/opica_followup'
OVERLAY=HERE/'overlay'
manifest=json.loads((BASE/'BUILD_MANIFEST.json').read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()

def uncomment(text):
    out=[]; i=0; depth=0; quoted=False
    while i<len(text):
        if depth:
            if text[i:i+2]=='/-': depth+=1; out.extend('  ');i+=2
            elif text[i:i+2]=='-/':depth-=1;out.extend('  ');i+=2
            else:out.append('\n' if text[i]=='\n' else ' ');i+=1
        elif not quoted and text[i:i+2]=='/-':depth=1;out.extend('  ');i+=2
        elif not quoted and text[i:i+2]=='--':
            j=text.find('\n',i);j=len(text) if j<0 else j
            out.extend(' '*(j-i));i=j
        elif text[i]=='"':quoted=not quoted;out.append(' ');i+=1
        elif quoted and text[i]=='\\':out.extend('  ');i+=2
        else:out.append(' ' if quoted and text[i]!='\n' else text[i]);i+=1
    return ''.join(out)

declarations=[]
for row in manifest['modules']:
    path=REPO/row['path']
    if not path.exists():continue
    stack=[]; namespace=[]
    clean=uncomment(path.read_text(encoding='utf-8'))
    for n,line in enumerate(clean.splitlines(),1):
        m=re.match(r'^\s*namespace\s+([A-Za-z0-9_.]+)',line)
        if m:
            stack.append(('namespace',list(namespace)))
            namespace+=m[1].split('.')
            continue
        if re.match(r'^\s*(?:noncomputable\s+)?section\b',line):stack.append(('section',None));continue
        if re.match(r'^\s*end\b',line):
            if stack:
                kind,old=stack.pop()
                if kind=='namespace':namespace=old
            continue
        m=re.match(r'^\s*((?:(?:private|protected|noncomputable|unsafe)\s+)*)(theorem|lemma|def|abbrev|structure|inductive|class|opaque|axiom|instance)\s+([A-Za-z_][A-Za-z0-9_\'.]*)',line)
        if m and 'private' not in m[1].split():
            name='.'.join(namespace+[m[3]])
            declarations.append({'full_name':name,'kind':m[2],'path':row['path'],'line':n})
by_name={}
for d in declarations:by_name.setdefault(d['full_name'],[]).append(d)
collisions={k:v for k,v in by_name.items() if len(v)>1}
foreign=[d for d in declarations if not d['full_name'].startswith('Zeta23.OPICAFollowup.') and d['path']!='Zeta23/RHRC/OpicaFollowupBindings.lean']
changes=[]
relocations={}
for rel in ['Zeta23/OPICAFollowup/ConfluentProfiles.lean','research/RHRC/integration/opica_followup/continuation/2026-10-22/consumers/ExpectedConfluentProfiles.lean','Zeta23/OPICAFollowup/SquareDefect.lean']:
    original=(REPO/rel).read_bytes();text=original.decode('utf-8')
    if rel.endswith('ConfluentProfiles.lean'):
        helpers=['OPICAConfluentAudit','OPICAActualFirstCellAudit','OPICARightCellTaylor','OPICAShCoefficientExtraction','OPICAActualMeasureCell','OPICAGroupedConfluent']
        for ns in helpers:
            new='Zeta23.OPICAFollowup.'+ns
            text=re.sub(r'(?<![\w.])'+re.escape(ns)+r'\b',new,text)
            relocations[ns]=new
    if rel.endswith('SquareDefect.lean'):
        text=re.sub(r'\bintegrable_mul_schwartz\b','square_integrable_mul_schwartz',text)
        relocations['Zeta23.OPICAFollowup.integrable_mul_schwartz (SquareDefect only)']='Zeta23.OPICAFollowup.square_integrable_mul_schwartz'
    target=OVERLAY/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(text.encode('utf-8'))
    changes.append({'path':rel,'original_sha256':sha(original),'proposal_sha256':sha(target.read_bytes()),'proposal':str(target)})
report={'schema':'OPICA_UNACCEPTED_HELPER_API_COMPATIBILITY_V1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    'status':'SOURCE_AUDIT_AND_PROPOSAL_NOT_COMPILER_VALIDATED','static_scanner_limit':'Top-level named declarations only; native aggregate compiler is authoritative.',
    'duplicate_public_source_names':collisions,'foreign_public_source_names':foreign,
    'proposed_helper_names':relocations,'source_changes':changes,
    'primary_roots':'No original root fullname is renamed. Helper qualification changes reflected implementation names/types until separately reviewed; mathematical formulas, hypotheses and physical constructions are preserved.',
    'full_acceptance':'OPEN','independent_review':'NOT_ESTABLISHED','RH':'OPEN','Step4':'OPEN'}
(HERE/'helper-api-audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print('public collisions:',json.dumps(collisions,indent=2));print('foreign public names',len(foreign));print('written outside checkout:',len(changes))
