import Mathlib.Algebra.Polynomial.HasseDeriv
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.Analysis.Calculus.IteratedDeriv.Defs

noncomputable section
open Polynomial
namespace OPICAConfluentAudit

variable {K : Type*} [NontriviallyNormedField K]

theorem iteratedDeriv_polynomial_eval (p : K[X]) (n : ℕ) :
    iteratedDeriv n (fun z => p.eval z) =
      (fun z => (Polynomial.derivative^[n] p).eval z) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [iteratedDeriv_succ, ih]
    funext z
    rw [Polynomial.deriv, Function.iterate_succ_apply']

theorem hasse_eq_normalized_iteratedDeriv [CharZero K] (p : K[X]) (n : ℕ) (z : K) :
    (Polynomial.hasseDeriv n p).eval z =
      iteratedDeriv n (fun w => p.eval w) z / (n.factorial : K) := by
  have hf := congrFun (Polynomial.factorial_smul_hasseDeriv n) p
  have he := congrArg (fun q : K[X] => q.eval z) hf
  change (Polynomial.evalRingHom z) (n.factorial • Polynomial.hasseDeriv n p) =
    (Polynomial.derivative^[n] p).eval z at he
  rw [map_nsmul, nsmul_eq_mul] at he
  have he' : (n.factorial : K) * (Polynomial.hasseDeriv n p).eval z =
      iteratedDeriv n (fun w => p.eval w) z := by
    rw [iteratedDeriv_polynomial_eval]
    exact he
  apply (eq_div_iff (by exact_mod_cast Nat.factorial_ne_zero n : (n.factorial : K) ≠ 0)).mpr
  simpa only [mul_comm] using he'

#print axioms iteratedDeriv_polynomial_eval
#print axioms hasse_eq_normalized_iteratedDeriv
end OPICAConfluentAudit
