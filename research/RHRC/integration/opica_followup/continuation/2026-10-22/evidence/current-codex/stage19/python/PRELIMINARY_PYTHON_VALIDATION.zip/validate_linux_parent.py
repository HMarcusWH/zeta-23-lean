import datetime, hashlib, json, os, platform, subprocess, sys, tempfile
from pathlib import Path

repo = Path('/mnt/c/Users/macka/.codex/.chatgpt-projects/g-p-6a353c7268b08191b685956e466d73e4/work/opica-followup-repo')
out = repo.parent / 'opica-stage19/python/linux-parent'
out.mkdir(parents=True, exist_ok=True)
os.environ['TMPDIR'] = tempfile.mkdtemp(prefix='opica-stage19-parent-', dir='/tmp')
tempfile.tempdir = os.environ['TMPDIR']
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
def source_state():
    def git(*args):
        p = subprocess.run(['git', '-C', str(repo), *args], capture_output=True, text=True)
        return {'exit_code': p.returncode, 'stdout': p.stdout.strip(), 'stderr': p.stderr.strip()}
    paths = ['research/RHRC/integration/opica/tests/test_contract.py', 'research/RHRC/integration/opica/validate_contract.py', 'research/RHRC/integration/opica_followup/validate_contract.py']
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1'), 'files': {p: hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}}
summary = {'scope': 'Unmodified 82-test focused parent contract suite on Linux, true /tmp fixtures; no Lean compilation', 'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(), 'tmpdir': os.environ['TMPDIR'], 'source_before': source_state(), 'commands': []}
for label, flags in [('normal', []), ('optimized', ['-O'])]:
    cmd = [sys.executable, '-B', *flags, '-m', 'unittest', 'discover', '-s', 'research/RHRC/integration/opica/tests', '-p', 'test_contract.py']
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(cmd, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600)
    log = out / f'parent-contract-{label}.log'
    log.write_bytes(p.stdout)
    row = {'label': label, 'command': cmd, 'cwd': str(repo), 'started_at': start, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': p.returncode, 'log': str(log), 'log_sha256': hashlib.sha256(p.stdout).hexdigest()}
    summary['commands'].append(row)
    print(json.dumps(row), flush=True)
summary['source_after'] = source_state()
summary['status'] = 'PASS_FOCUSED_PARENT_TESTS_ONLY' if all(x['exit_code']==0 for x in summary['commands']) else 'FAIL'
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(summary['status'], flush=True)
