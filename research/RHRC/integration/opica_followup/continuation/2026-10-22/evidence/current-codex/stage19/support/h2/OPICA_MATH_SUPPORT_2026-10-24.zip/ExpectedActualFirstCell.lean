import ActualFirstCell

noncomputable section
open Complex
open Zeta23.OPICAFollowup
namespace OPICAFirstCellIndependent

theorem audit_actual_jet_definition (κ : ℂ) (k : ℕ) (y : ℝ) :
    zeroJetDensity κ k y =
      iteratedDeriv k (fun w => zeroFamilyDensity w y) κ / (k.factorial : ℂ) := rfl

theorem expected_actual_first_cell_jet (κ : ℂ) (k : ℕ) {u : ℝ}
    (hu0 : 0 ≤ u) (hu2 : u < Real.log 2) :
    (Real.exp (u / 2) : ℂ) * zeroJetDensity κ k (Real.exp u) =
      iteratedDeriv k (fun w : ℂ => w * shKernel (1 / 4 - w) u) κ /
        (k.factorial : ℂ) :=
  OPICAActualFirstCellAudit.actual_normalized_jet_first_log_cell κ k hu0 hu2

theorem expected_first_endpoint (κ : ℂ) (k : ℕ) : zeroJetDensity κ k 1 = 0 := by
  have h := expected_actual_first_cell_jet κ k (u := 0) (by norm_num)
    (Real.log_pos (by norm_num))
  simpa [shKernel] using h

theorem expected_global_left_gap (κ : ℂ) {u : ℝ} (hu : u < 0) :
    (Real.exp (u / 2) : ℂ) * zeroFamilyDensity κ (Real.exp u) = 0 := by
  have hexp : |Real.exp u| < 1 := by
    rw [abs_of_pos (Real.exp_pos u)]
    calc
      Real.exp u < Real.exp 0 := Real.exp_lt_exp.mpr hu
      _ = 1 := Real.exp_zero
  rw [zeroFamilyDensity_small κ hexp, mul_zero]

theorem expected_quarter_right_cell {u : ℝ} (hu0 : 0 ≤ u) (hu2 : u < Real.log 2) :
    (Real.exp (u / 2) : ℂ) * zeroFamilyDensity (1 / 4) (Real.exp u) = (u : ℂ) / 4 := by
  rw [OPICAActualFirstCellAudit.actual_family_first_log_cell (1 / 4) hu0 hu2,
    sub_self, shKernel_zero]
  ring

#print axioms audit_actual_jet_definition
#print axioms expected_actual_first_cell_jet
#print axioms expected_first_endpoint
#print axioms expected_global_left_gap
#print axioms expected_quarter_right_cell
end OPICAFirstCellIndependent
