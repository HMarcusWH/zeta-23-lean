import Mathlib.Algebra.Field.Basic
import Mathlib.Data.Fin.Basic

/-!
Independent supporting lemma for OPICA H2a, outside production sources.
Multiplication by the local coordinate κ on normalized Taylor jets has the
recurrence κ a_k + a_(k-1), with no factorial on the predecessor term.
This is one of the algebraic invertibility steps in H2a; it does not establish
the confluent determinant or independence of the actual zero measures.
-/

namespace OPICAAudit

variable {K : Type*} [Field K]

def normalizedJetMul (κ : K) (a : ℕ → K) (k : ℕ) : K :=
  κ * a k + if k = 0 then 0 else a (k - 1)

theorem normalizedJetMul_zero_iff {m : ℕ} {κ : K} (hκ : κ ≠ 0) (a : ℕ → K) :
    (∀ k < m, normalizedJetMul κ a k = 0) ↔ ∀ k < m, a k = 0 := by
  constructor
  · intro h k hk
    induction k with
    | zero =>
      have h0 := h 0 hk
      simpa [normalizedJetMul, hκ] using h0
    | succ k ih =>
      have hp : a k = 0 := ih (Nat.lt_of_succ_lt hk)
      have hs := h (k + 1) hk
      simp only [normalizedJetMul, Nat.add_eq_zero_iff, Nat.one_ne_zero, and_false,
        if_false, Nat.add_sub_cancel, hp, add_zero] at hs
      exact (mul_eq_zero.mp hs).resolve_left hκ
  · intro h k hk
    rw [normalizedJetMul, h k hk, mul_zero, zero_add]
    split
    · rfl
    · rename_i hk0
      exact h (k - 1) (Nat.lt_of_le_of_lt (Nat.sub_le k 1) hk)

theorem normalizedJetMul_injective_on_truncation {m : ℕ} {κ : K} (hκ : κ ≠ 0)
    (a b : ℕ → K) (h : ∀ k < m, normalizedJetMul κ a k = normalizedJetMul κ b k) :
    ∀ k < m, a k = b k := by
  have hz : ∀ k < m, normalizedJetMul κ (fun i => a i - b i) k = 0 := by
    intro k hk
    have he := h k hk
    unfold normalizedJetMul at he ⊢
    by_cases hk0 : k = 0
    · subst k
      have hab : a 0 = b 0 := by simpa [hκ] using he
      simp [hab]
    · simp only [if_neg hk0, mul_sub] at he ⊢
      calc
        κ * a k - κ * b k + (a (k - 1) - b (k - 1)) =
            (κ * a k + a (k - 1)) - (κ * b k + b (k - 1)) :=
          sub_add_sub_comm _ _ _ _
        _ = 0 := sub_eq_zero.mpr he
  intro k hk
  exact sub_eq_zero.mp ((normalizedJetMul_zero_iff hκ _).mp hz k hk)

#print axioms normalizedJetMul_zero_iff
#print axioms normalizedJetMul_injective_on_truncation

end OPICAAudit
