# OPICA PR 294 workflow audit — 2026-10-24

Bounded read-only live audit of branch head cea7b2f62ea847c18958cc7385151c8c2b09520d.
Workflow API data, fetched workflow sources, decoded job logs, and parsed scientific outputs are retained here.
This is an audit record, not a compiler receipt or external approval.
