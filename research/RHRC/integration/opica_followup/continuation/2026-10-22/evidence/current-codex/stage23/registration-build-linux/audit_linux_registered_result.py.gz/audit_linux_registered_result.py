"""Reparse actual global compilation and all registered axiom closures.

Diagnostic source-bound registration evidence only, never cold/release evidence.
"""
from pathlib import Path
import argparse, hashlib, json, re

W = Path(__file__).resolve().parents[1]
R = W/'opica-followup-repo'
S = W/'opica-stage23/registration-build-linux'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok, text):
    if not ok: raise ValueError(text)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output', type=Path, required=True);args=ap.parse_args()
    require(not args.output.exists() and not args.output.resolve().is_relative_to(R.resolve()), 'fresh external output required')
    result=json.loads((S/'RESULT.json').read_bytes())
    require(result['status']=='PASS_LINUX_REGISTERED_AUDIT_COMPILATION' and result['exit_code']==0 and
        result['all_math_sources_unchanged'] and result['source_sha256_before']==result['source_sha256_after'],
        'actual full registration compilation did not pass on unchanged sources')
    require(sha(S/'build.log')==result['log_sha256'], 'actual compiler log differs')
    sources=result['source_sha256_after']
    for path,digest in sources.items(): require(sha(R/path)==digest, 'current mathematics differs: '+path)
    registered=json.loads((R/'research/RHRC/REGISTERED_THEOREM_BINDINGS.json').read_bytes())['bindings']
    roots=json.loads((R/'research/RHRC/integration/opica_followup/PUBLIC_ROOTS.json').read_bytes())['roots']
    text=(S/'build.log').read_text(encoding='utf-8')
    parsed={}
    for name,body in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",text):
        axioms=sorted(set(x.strip() for x in body.split(',') if x.strip()))
        require(set(axioms)<={'propext','Classical.choice','Quot.sound'}, 'nonstandard transitive axiom: '+name)
        if name in parsed:require(parsed[name]==axioms, 'inconsistent axiom exports: '+name)
        parsed[name]=axioms
    for name in re.findall(r"'([^']+)' does not depend on any axioms",text):
        if name in parsed:require(parsed[name]==[], 'inconsistent empty axiom export: '+name)
        parsed[name]=[]
    names=sorted(set(row['theorem'] for row in registered));root_names={row['full_name'] for row in roots}
    require(len(registered)==294 and len(roots)==100 and root_names<=set(names), 'reviewed full registration inventory differs')
    require(all(name in parsed for name in names), 'missing registered compiler axiom output: '+repr([n for n in names if n not in parsed]))
    output={'status':'PASS_SOURCE_EQUAL_LINUX_GLOBAL_REGISTRATION_AND_STANDARD_AXIOMS_ONLY',
        'actual_compiler_result_sha256':sha(S/'RESULT.json'),'actual_compiler_log_sha256':sha(S/'build.log'),
        'registered_binding_rows':len(registered),'unique_registered_theorems':len(names),'original_followup_roots':len(roots),
        'all_current_mathematical_sources_match_compiled_snapshot':True,
        'registered_axiom_closures':{n:parsed[n] for n in names},
        'source_scope':'Actual unchanged whole Lean source census; metadata/HEAD precede final integration',
        'cold_isolation_claimed':False,'full_release_accepted':False,'RH':'OPEN','Step4':'OPEN'}
    args.output.write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({k:v for k,v in output.items() if k!='registered_axiom_closures'}))
if __name__=='__main__':main()
