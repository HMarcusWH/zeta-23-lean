import ShFiniteTaylor

/-! Uniform finite Taylor remainders for the actual normalized parameter jets.
The real variable is restricted to the explicit analytic right-cell continuation.
No derivative of the global physical density at the lattice boundary is used. -/

noncomputable section
set_option maxHeartbeats 800000
open Set Filter Complex
open scoped Topology
namespace OPICARightCellTaylor
open Zeta23.OPICAFollowup

def firstPartial (κ : ℂ) (u : ℝ) (n : ℕ) : ℂ :=
  ∑ j ∈ Finset.range (n + 1),
    (κ * (1 / 4 - κ) ^ j) * (u : ℂ) ^ (2 * j + 1) /
      ((2 * j + 1).factorial : ℂ)

theorem firstPartial_eq (κ : ℂ) (u : ℝ) (n : ℕ) :
    firstPartial κ u n = κ * shPartial (1 / 4 - κ) u n := by
  unfold firstPartial shPartial
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem differentiable_firstPartial (u : ℝ) (n : ℕ) :
    Differentiable ℂ (fun κ => firstPartial κ u n) := by
  unfold firstPartial
  exact Differentiable.fun_sum (fun j _ =>
    ((differentiable_id.mul (((differentiable_const (1 / 4 : ℂ)).sub
      differentiable_id).pow j)).mul_const _).div_const _)

theorem differentiable_firstKernel (u : ℝ) :
    Differentiable ℂ (fun κ : ℂ => κ * shKernel (1 / 4 - κ) u) :=
  differentiable_id.mul ((differentiable_shKernel u).comp
    ((differentiable_const _).sub differentiable_id))

theorem firstKernel_sub_partial_norm (κ₀ : ℂ) {w : ℂ}
    (hw : ‖w‖ ≤ ‖κ₀‖ + 1) {u : ℝ} (hu : |u| ≤ 1) (n : ℕ) :
    ‖w * shKernel (1 / 4 - w) u - firstPartial w u n‖ ≤
      (‖κ₀‖ + 2) ^ (n + 2) * expMajorant (‖κ₀‖ + 2) * |u| ^ (2 * n + 3) := by
  let B : ℝ := ‖κ₀‖ + 2
  have hB : 0 ≤ B := by dsimp [B]; positivity
  have hwB : ‖w‖ ≤ B := by dsimp [B]; linarith
  have hxB : ‖(1 / 4 : ℂ) - w‖ ≤ B := by
    calc
      ‖(1 / 4 : ℂ) - w‖ ≤ ‖(1 / 4 : ℂ)‖ + ‖w‖ := norm_sub_le _ _
      _ ≤ B := by norm_num; dsimp [B]; linarith
  rw [firstPartial_eq, ← mul_sub, norm_mul]
  calc
    ‖w‖ * ‖shKernel (1 / 4 - w) u - shPartial (1 / 4 - w) u n‖
      ≤ B * (B ^ (n + 1) * |u| ^ (2 * n + 3) * expMajorant B) := by
        exact mul_le_mul hwB (shKernel_sub_partial_norm hB hxB hu n)
          (norm_nonneg _) hB
    _ = _ := by dsimp [B]; rw [show n + 2 = (n + 1) + 1 by omega, pow_succ]; ring

def rightCellJet (κ : ℂ) (k : ℕ) (u : ℝ) : ℂ :=
  iteratedDeriv k (fun w : ℂ => w * shKernel (1 / 4 - w) u) κ /
    (k.factorial : ℂ)

def partialJet (κ : ℂ) (k : ℕ) (u : ℝ) (n : ℕ) : ℂ :=
  iteratedDeriv k (fun w : ℂ => firstPartial w u n) κ / (k.factorial : ℂ)

theorem normalized_jet_remainder (κ : ℂ) (k : ℕ) {u : ℝ} (hu : |u| ≤ 1) (n : ℕ) :
    ‖rightCellJet κ k u - partialJet κ k u n‖ ≤
      (‖κ‖ + 2) ^ (n + 2) * expMajorant (‖κ‖ + 2) * |u| ^ (2 * n + 3) := by
  have hd := (differentiable_firstKernel u).sub (differentiable_firstPartial u n)
  have hb := norm_iteratedDeriv_le_of_entire hd k κ
    (fun w hw => firstKernel_sub_partial_norm κ hw hu n)
  have he : iteratedDeriv k (fun w : ℂ => w * shKernel (1 / 4 - w) u -
      firstPartial w u n) κ =
      iteratedDeriv k (fun w : ℂ => w * shKernel (1 / 4 - w) u) κ -
      iteratedDeriv k (fun w : ℂ => firstPartial w u n) κ := by
    exact iteratedDeriv_fun_sub (differentiable_firstKernel u).contDiff.contDiffAt
      (differentiable_firstPartial u n).contDiff.contDiffAt
  change ‖iteratedDeriv k (fun w : ℂ => w * shKernel (1 / 4 - w) u -
    firstPartial w u n) κ‖ ≤ _ at hb
  rw [he] at hb
  unfold rightCellJet partialJet
  rw [← sub_div, norm_div, Complex.norm_natCast]
  apply (div_le_iff₀ (by positivity : (0 : ℝ) < k.factorial)).mpr
  simpa [mul_comm, mul_left_comm, mul_assoc] using hb

def oddJetCoefficient (κ : ℂ) (k j : ℕ) : ℂ :=
  iteratedDeriv k (fun w : ℂ => w * (1 / 4 - w) ^ j) κ /
    (k.factorial : ℂ) / ((2 * j + 1).factorial : ℂ)

theorem partialJet_eq (κ : ℂ) (k : ℕ) (u : ℝ) (n : ℕ) :
    partialJet κ k u n =
      ∑ j ∈ Finset.range (n + 1), oddJetCoefficient κ k j * (u : ℂ) ^ (2 * j + 1) := by
  unfold partialJet firstPartial
  rw [iteratedDeriv_fun_sum]
  · rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro j hj
    rw [iteratedDeriv_div_const, iteratedDeriv_mul_const_field]
    unfold oddJetCoefficient
    ring
  · intro j hj
    exact (((differentiable_id.mul (((differentiable_const (1 / 4 : ℂ)).sub
      differentiable_id).pow j)).mul_const _).div_const _).contDiff.contDiffAt

#print axioms normalized_jet_remainder
#print axioms partialJet_eq
end OPICARightCellTaylor
