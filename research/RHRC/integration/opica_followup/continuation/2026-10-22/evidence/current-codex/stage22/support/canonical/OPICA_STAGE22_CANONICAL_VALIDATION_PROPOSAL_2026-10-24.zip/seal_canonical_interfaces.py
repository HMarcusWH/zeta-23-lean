from pathlib import Path
import json,hashlib,re,datetime,subprocess,zipfile
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['CanonicalRecoveryProposal','CanonicalFilterActionsProposal','FollowupNativeOutputProposal']
rows=[]
for name in names:
    source=HERE/(name+'.lean');log=HERE/(name+'.log');text=log.read_text(encoding='utf-8')
    assert 'error:' not in text and 'sorryAx' not in text
    requested=re.findall(r'(?m)^#print axioms\s+(\S+)',source.read_text(encoding='utf-8'))
    printed={}
    for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",text,re.S):
        axes={a.strip() for a in m[2].split(',') if a.strip()}
        assert axes<={'propext','Classical.choice','Quot.sound'}
        printed[m[1]]=sorted(axes)
    assert set(requested)<=set(printed),(name,set(requested)-set(printed))
    rows.append({'source':source.name,'sha256':sha(source),'log':log.name,'log_sha256':sha(log),
        'observed_native_exit_code':0,'requested_axiom_audits':{n:printed[n] for n in requested}})
receipt={'schema':'OPICA_CANONICAL_INTERFACE_PROPOSALS_V1','status':'SEALED_NATIVE_COMPILED_PROPOSALS_INDEPENDENT_REVIEW_OPEN',
    'date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'observed_owner_head_at_seal':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    'observed_owner_tree_at_seal':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO,text=True).strip(),
    'owner_status_at_seal':subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).splitlines(),
    'compiler':'Lean4.33.0-rc2 x86_64-w64-windows-gnu commit d8b18978322de05a8f3dba51ef03cf5461676c17',
    'command':'lean -DmaxHeartbeats=800000 --root=<external scratch> <source> -o <external scratch object>',
    'cache_limit':'Warm existing project/package imports. Import object hashes were not captured before every run; no cold source-bound receipt is claimed. Owner module builds and full replay remain mandatory.',
    'canonical_required_definitions':{'NativeFilters':['finiteEulerFilter','inverseFiniteEulerFilter','rationalCausalFilter','truncatedInverseResidual'],
        'JointObservation':['optimalRecoveryCost','orthogonalRecovery'],'Consumers':['FollowupNativeOutput']},
    'construction':'Actual local causal actions with real residual cutoff; direct quotient-to-range factor and orthogonal projection; transparent original generated Step123 output with actual physical/cofinal companions.',
    'files':rows,'native_axiom_audit_count':sum(len(r['requested_axiom_audits']) for r in rows),
    'installation':'Strip each self-import only and append its complete body to the indicated actual source module. Preserve every old declaration and original root contract. Freshly compile the exact assembled bytes.',
    'primary_roots_added':0,'independent_review':'NOT_ESTABLISHED','full_review_seal':'UNSET','release_ready':False,'RH':'OPEN','Step4':'OPEN'}
(HERE/'canonical-interfaces-sealed-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
paths=[HERE/'canonical-interfaces-sealed-receipt.json',HERE/'seal_canonical_interfaces.py']
for name in names:paths.extend([HERE/(name+'.lean'),HERE/(name+'.log')])
paths.extend(sorted(HERE.glob('Canonical*failed*.log')))
paths.extend(sorted(HERE.glob('Canonical*failed*.lean.txt')))
archive=HERE/'OPICA_CANONICAL_INTERFACES_2026-10-24.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,p.name)
print('sealed',archive,'sha256',sha(archive),'audits',receipt['native_axiom_audit_count'])
