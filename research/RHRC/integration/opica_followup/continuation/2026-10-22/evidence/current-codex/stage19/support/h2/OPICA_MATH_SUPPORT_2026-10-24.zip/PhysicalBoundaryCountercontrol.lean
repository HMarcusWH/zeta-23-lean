import ExpectedActualFirstCell
import Mathlib.Analysis.Calculus.Deriv.Abs

noncomputable section
open Set Filter Complex
open scoped Topology
namespace OPICAFirstCellIndependent
open Zeta23.OPICAFollowup

def physicalQuarterCellReal (u : ℝ) : ℝ :=
  ((Real.exp (u / 2) : ℂ) * zeroFamilyDensity (1 / 4) (Real.exp u)).re

/-- An actual-density countercontrol: the analytic right-cell continuation
cannot be replaced by the global physical density in a two-sided derivative. -/
theorem physicalQuarterCell_not_differentiable :
    ¬ DifferentiableAt ℝ physicalQuarterCellReal 0 := by
  intro hdiff
  have hlog : (0 : ℝ) < Real.log 2 := Real.log_pos (by norm_num)
  have hnear : (fun u : ℝ => 8 * physicalQuarterCellReal u - u) =ᶠ[𝓝 0]
      (abs : ℝ → ℝ) := by
    filter_upwards [isOpen_Iio.mem_nhds hlog] with u hu
    by_cases hu0 : 0 ≤ u
    · have hp : physicalQuarterCellReal u = u / 4 := by
        unfold physicalQuarterCellReal
        rw [expected_quarter_right_cell hu0 hu]
        norm_num [Complex.div_re]
      rw [hp, abs_of_nonneg hu0]
      ring
    · have hn : physicalQuarterCellReal u = 0 := by
        unfold physicalQuarterCellReal
        rw [expected_global_left_gap (1 / 4) (lt_of_not_ge hu0), Complex.zero_re]
      rw [hn, abs_of_neg (lt_of_not_ge hu0)]
      ring
  have haux : DifferentiableAt ℝ (fun u : ℝ => 8 * physicalQuarterCellReal u - u) 0 :=
    (hdiff.const_mul (8 : ℝ)).sub differentiableAt_id
  exact not_differentiableAt_abs_zero (haux.congr_of_eventuallyEq hnear.symm)

#print axioms physicalQuarterCell_not_differentiable
end OPICAFirstCellIndependent
