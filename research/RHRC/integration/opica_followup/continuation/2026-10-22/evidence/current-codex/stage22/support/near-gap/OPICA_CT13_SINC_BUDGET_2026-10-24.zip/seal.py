from pathlib import Path
import datetime,hashlib,json,re,subprocess,zipfile
HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'opica-followup-repo'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
positive=[];axes={}
for name in ['CT13','CT13Limits','ExpectedCT1SincBudget']:
    receipt=json.loads((HERE/(name+'.receipt.json')).read_text())
    assert receipt['exit_code']==0 and receipt['source_unchanged']
    assert sha(HERE/(name+'.lean'))==receipt['source_sha256']
    assert sha(HERE/(name+'.log'))==receipt['log_sha256']
    log=(HERE/(name+'.log')).read_text(encoding='utf-8')
    assert 'error:' not in log and 'sorryAx' not in log
    for m in re.finditer(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log,re.S):
        actual={a.strip() for a in m[2].split(',') if a.strip()}
        assert actual<={'propext','Classical.choice','Quot.sound'}
        axes[m[1]]=sorted(actual)
    positive.append(receipt)
assert len(axes)==11
negative=json.loads((HERE/'negative-controls.json').read_text())
assert negative['status']=='TWO_CHANGED_CONCLUSIONS_REJECTED'
for row in negative['controls']:
    assert row['expected_disposition_observed'] and row['exit_code']!=0
proposal=json.loads((HERE/'production-append-proposal.json').read_text())
assert sha(HERE/proposal['candidate_source'])==proposal['candidate_sha256']
assert sha(HERE/proposal['independent_consumer'])==proposal['independent_consumer_sha256']
imports=['Zeta23/OPICAFollowup/NearGapLimits.lean','Zeta23/OPICAFollowup/DilatedComb.lean',
 'Zeta23/OPICAFollowup/ComplexLocalMeasures.lean','Zeta23/OPICA/SignedHeatSeparator.lean','Zeta23/OPICA/SincTriangle.lean']
compiler='C:/Users/macka/.elan/toolchains/leanprover--lean4---v4.33.0-rc2/bin/lean.exe'
result={'schema':'OPICA_CT13_SUPPORT_SEALED_V1','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'WARM_SUPPORTING_PHYSICAL_IDENTITY_LIMITS_AND_CONTROLS_VERIFIED_ZERO_PRIMARY_INCREMENT',
 'compiler_version':subprocess.check_output([compiler,'--version'],text=True).strip(),
 'compiler_sha256':sha(Path(compiler)),
 'owner_head':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),
 'owner_tree':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD^{tree}'],text=True).strip(),
 'owner_working_status':subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'],text=True).splitlines(),
 'imported_project_source_hashes_at_seal':{p:sha(REPO/p) for p in imports},
 'positive_compiler_receipts':positive,'allowed_axiom_audits':axes,'negative_controls':negative,
 'production_append_proposal':proposal,
 'production_assembled_module_compiled_by_this_lane':False,
 'owner_actual_source_clean_replay':'REQUIRED','original_primary_root_increment':0,
 'frozen_paper_priority':'CT1.3_ALREADY_IN_ORIGINAL_PAPER_NO_NEW_DISCOVERY_CLAIM',
 'full_release_accepted':False,'release_ready':False,'RH':'OPEN','Step4':'OPEN'}
(HERE/'sealed-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
paths=[p for p in HERE.iterdir() if p.is_file() and p.suffix in {'.lean','.txt','.log','.json','.py','.md'}]
paths.append(HERE/proposal['candidate_source'])
manifest=[{'path':p.relative_to(HERE).as_posix(),'sha256':sha(p)} for p in paths]
(HERE/'sealed-files.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');paths.append(HERE/'sealed-files.json')
archive=HERE/'OPICA_CT13_SINC_BUDGET_2026-10-24.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in paths:z.write(p,p.relative_to(HERE).as_posix())
print(archive.name,sha(archive),len(paths),'files;11stdaxiompositiveaudits;2rejectedcontrols;0primary')
