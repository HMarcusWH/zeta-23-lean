from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent
duplicate=(P/'DuplicateBasisControl.lean').read_text(encoding='utf-8')
duplicate=duplicate.replace('import FiniteSpanCombination','import FiniteSpanSeparationFullCandidate').replace('FiniteSpanScratch','FiniteSpan')
duplicate=re.sub(r'(?<![.\w])zeroJetRealSpan\b','Zeta23.OPICAFollowup.FiniteSpan.zeroJetRealSpan',duplicate)
duplicate=duplicate.replace('theorem repeated_actual_basis_is_not_independent','namespace IndependentFiniteSpanFalsification\n\ntheorem repeated_actual_basis_is_not_independent')
duplicate=duplicate.replace('#print axioms repeated_actual_basis_is_not_independent','#print axioms IndependentFiniteSpanFalsification.repeated_actual_basis_is_not_independent').replace('#print axioms reflected_zero_is_the_same_jet','#print axioms IndependentFiniteSpanFalsification.reflected_zero_is_the_same_jet')
duplicate+='\nend IndependentFiniteSpanFalsification\n'
(P/'DuplicateBasisControlFinal.lean').write_text(duplicate,encoding='utf-8')
def inline(name):
    return '\n'.join(x for x in (P/name).read_text(encoding='utf-8').splitlines()
        if not x.startswith('import ')).strip()+'\n'
positive=['ExpectedFullFiniteSpanFinal.lean','ExpectedActualFixedBudgetFinal.lean',
          'ExpectedSpanPhysicalConsumerFinal.lean','WeightedControlsFinal.lean','DuplicateBasisControlFinal.lean']
negative=['NegativeFullFiniteSpanFinal.lean','NegativeBudgetIndependenceFinal.lean']
(P/'AllFinalFiniteSpanChecks.lean').write_text('import ConsumersSpanFullCandidate\n\n'+'\n'.join(inline(x) for x in positive),encoding='utf-8')
(P/'AllFinalNegativeControls.lean').write_text('import FiniteSpanSeparationFullCandidate\n\n'+'\n'.join(inline(x) for x in negative),encoding='utf-8')
manifest={'schema':'OPICA_FINITE_SPAN_COMBINED_CONSUMER_COMPONENTS_V1',
          'purpose':'Independent consumer source contains literal separately authored full expected-type and falsification components; only import lines removed. One compiler startup per positive/negative suite.',
          'positive':positive,'negative':negative,
          'sha256':{x:hashlib.sha256((P/x).read_bytes()).hexdigest() for x in positive+negative+['AllFinalFiniteSpanChecks.lean','AllFinalNegativeControls.lean']}}
(P/'FINAL_CHECK_COMPONENTS.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest['sha256']))
