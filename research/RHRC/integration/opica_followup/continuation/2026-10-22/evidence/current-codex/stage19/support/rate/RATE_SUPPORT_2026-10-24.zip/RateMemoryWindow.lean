import RateWindowBounds

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
namespace Zeta23.OPICAFollowup.Stage19Rate

theorem tailMemory_split (d : ℕ) (alpha C T : ℝ) (hC : 0 ≤ C) (hT : 1 ≤ T)
    (hstart : 0 ≤ T-C*Real.log T) :
    tailMemory alpha d T =
      (∫ s : ℝ in Icc 0 (T-C*Real.log T), Real.exp (-alpha*(T-s))*|primeFieldFamily d s|)+
      (∫ s : ℝ in Icc (T-C*Real.log T) T, Real.exp (-alpha*(T-s))*|primeFieldFamily d s|) := by
  let f : ℝ → ℝ := fun s => Real.exp (-alpha*(T-s))*|primeFieldFamily d s|
  have he : Continuous (fun s : ℝ => Real.exp (-alpha*(T-s))) := by fun_prop
  have hf : Continuous f := he.mul (primeFieldFamily_contDiff d).continuous.abs
  have hLT : T-C*Real.log T ≤ T := sub_le_self _ (mul_nonneg hC (Real.log_nonneg hT))
  have h0T : 0 ≤ T := by linarith
  have h := intervalIntegral.integral_add_adjacent_intervals (μ := volume)
    (hf.intervalIntegrable 0 (T-C*Real.log T)) (hf.intervalIntegrable (T-C*Real.log T) T)
  rw [intervalIntegral.integral_of_le hstart, intervalIntegral.integral_of_le hLT,
    intervalIntegral.integral_of_le h0T] at h
  simpa only [tailMemory, integral_Icc_eq_integral_Ioc, f] using h.symm

/-- A direct Cauchy–Schwarz bridge from actual terminal memory to the literal
energy. Its logarithmic-window prefactor is sufficient for a rate theorem. -/
theorem native_terminalMemory_sq_le_windowEnergy (d : ℕ) {alpha C T : ℝ}
    (ha : 0 ≤ alpha) (hC : 0 ≤ C) (hT : 1 ≤ T) :
    (∫ s : ℝ in Icc (T-C*Real.log T) T,
      Real.exp (-alpha*(T-s))*|primeFieldFamily d s|)^2 ≤
      C*Real.log T*nativeWindowEnergy d C T := by
  let I := Icc (T-C*Real.log T) T
  let mu : Measure ℝ := volume.restrict I
  have hlen : 0 ≤ C*Real.log T := mul_nonneg hC (Real.log_nonneg hT)
  have hLT : T-C*Real.log T ≤ T := by linarith
  have hFcont : Continuous (fun s : ℝ => |primeFieldFamily d s|) :=
    (primeFieldFamily_contDiff d).continuous.abs
  have hFmeas : AEStronglyMeasurable (fun s : ℝ => |primeFieldFamily d s|) mu :=
    hFcont.aestronglyMeasurable
  have hF2 : Integrable (fun s : ℝ => |primeFieldFamily d s|^2) mu :=
    nativeWindowEnergy_integrable d C T
  have h1meas : AEStronglyMeasurable (fun _s : ℝ => (1 : ℝ)) mu :=
    stronglyMeasurable_const.aestronglyMeasurable
  have h12 : Integrable (fun _s : ℝ => (1 : ℝ)^2) mu :=
    (continuous_const : Continuous (fun _s : ℝ => (1 : ℝ)^2)).continuousOn.integrableOn_compact isCompact_Icc
  have hHolder := integral_mul_le_Lp_mul_Lq_of_nonneg Real.HolderConjugate.two_two
    (Eventually.of_forall (fun _s : ℝ => zero_le_one))
    (Eventually.of_forall (fun s : ℝ => abs_nonneg (primeFieldFamily d s)))
    (by simpa using (memLp_two_iff_integrable_sq h1meas).mpr h12)
    (by simpa using (memLp_two_iff_integrable_sq hFmeas).mpr hF2)
  have hCS : (∫ s : ℝ in I, |primeFieldFamily d s|) ≤
      Real.sqrt (C*Real.log T)*Real.sqrt (nativeWindowEnergy d C T) := by
    simpa only [one_mul,Real.rpow_two,Real.sqrt_eq_rpow,one_pow,
      mu,I,nativeWindowEnergy,setIntegral_const,Real.volume_real_Icc_of_le hLT,
      smul_eq_mul,mul_one,sub_sub_cancel] using hHolder
  have hecont : Continuous (fun s : ℝ => Real.exp (-alpha*(T-s))) := by fun_prop
  have hweightcont : Continuous (fun s : ℝ => Real.exp (-alpha*(T-s))*|primeFieldFamily d s|) :=
    hecont.mul hFcont
  have hdrop : (∫ s : ℝ in I, Real.exp (-alpha*(T-s))*|primeFieldFamily d s|) ≤
      ∫ s : ℝ in I, |primeFieldFamily d s| := by
    apply setIntegral_mono_on
      (hweightcont.continuousOn.integrableOn_compact isCompact_Icc)
      (hFcont.continuousOn.integrableOn_compact isCompact_Icc) measurableSet_Icc
    intro s hs
    have hExp : Real.exp (-alpha*(T-s)) ≤ 1 :=
      Real.exp_le_one_iff.mpr (mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr ha) (sub_nonneg.mpr hs.2))
    simpa only [one_mul] using mul_le_mul_of_nonneg_right hExp (abs_nonneg (primeFieldFamily d s))
  have hmem : 0 ≤ ∫ s : ℝ in I, Real.exp (-alpha*(T-s))*|primeFieldFamily d s| :=
    integral_nonneg fun _ => mul_nonneg (Real.exp_nonneg _) (abs_nonneg _)
  calc
    _ ≤ (Real.sqrt (C*Real.log T)*Real.sqrt (nativeWindowEnergy d C T))^2 :=
      pow_le_pow_left₀ hmem (hdrop.trans hCS) 2
    _ = _ := by rw [mul_pow,Real.sq_sqrt hlen,Real.sq_sqrt (nativeWindowEnergy_nonneg d C T)]

/-- A source-specific finite-horizon obstruction from an actual right zero,
with its full multiplicity. Every coefficient, subtraction and old-memory
cost is discharged from the existing native constructions. -/
theorem native_window_energy_multiplicity_barrier (k d : ℕ) (hk : 1 ≤ k)
    (rho : Zeta23.zetaZeroConfig.carrier) (hright : 1/2 < (rho : ℂ).re)
    {C T : ℝ} (hC : 0 ≤ C) (hT : 1 ≤ T) (hstart : 0 ≤ T-C*Real.log T) :
    let alpha := auxCompletionAlpha k
    let lower := Real.sqrt (2*alpha)/auxCompletionBound k*
      max (nativeMultiplicityTailConstant d rho*‖auxRationalFactor k ((rho : ℂ)-1/2)‖*
        Real.exp (((rho : ℂ)-1/2).re*T)-‖nativeAuxiliaryStableVector k d‖) 0
    let old := T*nativeFieldOrderConstant d*
      Real.exp (nativeZeroDisplacementSup*T-(alpha+nativeZeroDisplacementSup)*C*Real.log T)
    (max (lower-old) 0)^2 ≤ C*Real.log T*nativeWindowEnergy d C T := by
  dsimp only
  have ha : 0 ≤ auxCompletionAlpha k := by dsimp [auxCompletionAlpha]; positivity
  have hLower := native_terminal_memory_lower k d hk rho hright T
  have hOld := native_oldMemory_upper d ha hC hT hstart
  have hSplit := tailMemory_split d (auxCompletionAlpha k) C T hC hT hstart
  have hWin0 : 0 ≤ ∫ s : ℝ in Icc (T-C*Real.log T) T,
      Real.exp (-auxCompletionAlpha k*(T-s))*|primeFieldFamily d s| :=
    integral_nonneg fun _ => mul_nonneg (Real.exp_nonneg _) (abs_nonneg _)
  have hBarrier : max
      (Real.sqrt (2*auxCompletionAlpha k)/auxCompletionBound k*
        max (nativeMultiplicityTailConstant d rho*‖auxRationalFactor k ((rho : ℂ)-1/2)‖*
          Real.exp (((rho : ℂ)-1/2).re*T)-‖nativeAuxiliaryStableVector k d‖) 0-
        T*nativeFieldOrderConstant d*
          Real.exp (nativeZeroDisplacementSup*T-(auxCompletionAlpha k+nativeZeroDisplacementSup)*C*Real.log T)) 0 ≤
      ∫ s : ℝ in Icc (T-C*Real.log T) T,
        Real.exp (-auxCompletionAlpha k*(T-s))*|primeFieldFamily d s| := by
    apply max_le _ hWin0
    linarith
  exact (pow_le_pow_left₀ (le_max_right _ _) hBarrier 2).trans
    (native_terminalMemory_sq_le_windowEnergy d ha hC hT)

#print axioms tailMemory_split
#print axioms native_terminalMemory_sq_le_windowEnergy
#print axioms native_window_energy_multiplicity_barrier
end Zeta23.OPICAFollowup.Stage19Rate
