import NewtonHermite

noncomputable section
open Polynomial Finset
open scoped BigOperators

namespace OPICAConfluentAudit
variable {K : Type*} [CommRing K] {M : ℕ}

theorem priorMatches_cons_zero (node : Fin M → K) {κ : K} (hκ : κ ≠ 0) (i : Fin M) :
    priorMatches (Fin.cons 0 node) κ i.succ =
      (priorMatches node κ i).map (Fin.succEmb M) := by
  classical
  ext j
  refine Fin.cases ?_ (fun j => ?_) j
  · simp [priorMatches, hκ, Ne.symm hκ]
  · simp [priorMatches]

theorem priorNonmatches_cons_zero (node : Fin M → K) {κ : K} (hκ : κ ≠ 0) (i : Fin M) :
    priorNonmatches (Fin.cons 0 node) κ i.succ =
      insert 0 ((priorNonmatches node κ i).map (Fin.succEmb M)) := by
  classical
  ext j
  refine Fin.cases ?_ (fun j => ?_) j
  · simp [priorNonmatches, hκ, Ne.symm hκ]
  · simp [priorNonmatches]

theorem repeatedJetOrder_cons_zero (node : Fin M → K) (hnode : ∀ i, node i ≠ 0) (i : Fin M) :
    repeatedJetOrder (Fin.cons 0 node) i.succ = repeatedJetOrder node i := by
  unfold repeatedJetOrder
  rw [Fin.cons_succ, priorMatches_cons_zero node (hnode i), Finset.card_map]

theorem coordinateHermite_determinant [Nontrivial K] (node : Fin M → K)
    (hnode : ∀ i, node i ≠ 0) :
    (functionalMatrix (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
      (fun i => X ^ ((i : ℕ) + 1))).det =
      (∏ i : Fin M, node i) *
        ∏ i : Fin M, ∏ j ∈ priorNonmatches node (node i) i, (node i - node j) := by
  classical
  let extnode : Fin (M + 1) → K := Fin.cons 0 node
  let A : Matrix (Fin (M + 1)) (Fin (M + 1)) K :=
    functionalMatrix (fun j => hasseFunctional (extnode j) (repeatedJetOrder extnode j))
      (fun i => X ^ (i : ℕ))
  have horder : repeatedJetOrder extnode 0 = 0 := by simp [extnode, repeatedJetOrder, priorMatches]
  have hA00 : A 0 0 = 1 := by simp [A, functionalMatrix, horder, hasseFunctional, extnode]
  have hAcol (i : Fin M) : A i.succ 0 = 0 := by
    simp [A, functionalMatrix, horder, hasseFunctional, extnode]
  have hminor : A.submatrix Fin.succ Fin.succ =
      functionalMatrix (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
        (fun i => X ^ ((i : ℕ) + 1)) := by
    ext i j
    change hasseFunctional (extnode j.succ) (repeatedJetOrder extnode j.succ)
      (X ^ (i.succ : ℕ)) = _
    rw [show extnode j.succ = node j from Fin.cons_succ _ _ _,
      show repeatedJetOrder extnode j.succ = repeatedJetOrder node j from
        repeatedJetOrder_cons_zero node hnode j]
    rfl
  have hexpand : A.det =
      (functionalMatrix (fun j => hasseFunctional (node j) (repeatedJetOrder node j))
        (fun i => X ^ ((i : ℕ) + 1))).det := by
    rw [Matrix.det_succ_column_zero, Fin.sum_univ_succ]
    simp only [Fin.val_zero, pow_zero, hA00, one_mul, Fin.succAbove_zero, hminor,
      hAcol, mul_zero, zero_mul, Finset.sum_const_zero, add_zero]
  rw [← hexpand]
  change (functionalMatrix (fun j => hasseFunctional (extnode j) (repeatedJetOrder extnode j))
    (fun i => X ^ (i : ℕ))).det = _
  rw [normalizedHermite_determinant, Fin.prod_univ_succ]
  have hzero : (∏ j ∈ priorNonmatches extnode (extnode 0) 0,
      (extnode 0 - extnode j)) = 1 := by
    have hempty : Finset.Iio (0 : Fin (M + 1)) = ∅ := by
      apply Finset.eq_empty_iff_forall_notMem.mpr
      intro j hj
      have hj' : j < (0 : Fin (M + 1)) := Finset.mem_Iio.mp hj
      exact Nat.not_lt_zero j.val hj'
    simp [priorNonmatches, hempty]
  rw [hzero, one_mul]
  have hterm (i : Fin M) :
      (∏ j ∈ priorNonmatches extnode (extnode i.succ) i.succ,
        (extnode i.succ - extnode j)) =
      node i * ∏ j ∈ priorNonmatches node (node i) i, (node i - node j) := by
    rw [show extnode i.succ = node i from Fin.cons_succ _ _ _,
      show priorNonmatches extnode (node i) i.succ =
        insert 0 ((priorNonmatches node (node i) i).map (Fin.succEmb M)) from
          priorNonmatches_cons_zero node (hnode i) i,
      Finset.prod_insert (by simp)]
    simp [extnode, Finset.prod_map]
  simp_rw [hterm]
  exact Finset.prod_mul_distrib

#print axioms coordinateHermite_determinant
end OPICAConfluentAudit
