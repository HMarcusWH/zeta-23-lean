import ShCoefficientExtraction

noncomputable section

/-- Deliberately invalid expected-type consumer: dropping the two extra
orders must be rejected by the compiler. -/
example (c : ℂ) (C ε : ℝ) (hε : 0 < ε)
    (h : ∀ u : ℝ, 0 < u → u < ε → ‖c * (u : ℂ) ^ 3‖ ≤ C * u ^ 3) : c = 0 := by
  exact OPICAShCoefficientExtraction.eq_zero_of_small_pos_monomial_bound c 3 hε C h
