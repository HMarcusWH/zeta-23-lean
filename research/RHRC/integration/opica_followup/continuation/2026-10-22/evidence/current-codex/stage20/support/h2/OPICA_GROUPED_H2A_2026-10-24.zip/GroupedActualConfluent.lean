import GroupedProducts
import ExpandedActualMeasureIndependence

/-! Candidate exact grouped H2a contracts. These declarations are scratch only
until their complete compiler/independent expected-type gates pass. -/

noncomputable section
set_option maxHeartbeats 800000
open Set MeasureTheory Filter Complex Polynomial Finset
open scoped Topology SchwartzMap FourierTransform
namespace Zeta23.OPICAFollowup
open OPICAGroupedConfluent OPICAConfluentAudit OPICARightCellTaylor

def distinctSpectralNodes {r : ℕ} (ρ : Fin r → ℂ) : Prop :=
  Function.Injective (fun j => spectralKappa (ρ j))

/-- The exact normalized polynomial rows obtained from the actual right-cell
Taylor coefficients after clearing the nonzero odd factorials. Columns are
ordered (j,0),...,(j,m_j-1) via the explicit increasing block equivalence. -/
def profileJetMatrix {r : ℕ} (κ : Fin r → ℂ) (m : Fin r → ℕ) :
    Matrix (Fin (∑ j, m j)) (Fin (∑ j, m j)) ℂ := fun n i =>
  iteratedDeriv (((groupEquiv m).symm i).2 : ℕ)
    (fun w : ℂ => w * (1 / 4 - w) ^ (n : ℕ))
    (κ ((groupEquiv m).symm i).1) /
      ((((groupEquiv m).symm i).2 : ℕ).factorial : ℂ)

theorem profile_jet_confluent_determinant {r : ℕ} (κ : Fin r → ℂ)
    (hκ : Function.Injective κ) (hκ0 : ∀ j, κ j ≠ 0) (m : Fin r → ℕ) :
    (profileJetMatrix κ m).det =
      (-1 : ℂ) ^ ((∑ j, m j) * ((∑ j, m j) - 1) / 2) *
        (∏ j, κ j ^ m j) * ∏ j, ∏ i ∈ Iio j, (κ j - κ i) ^ (m i * m j) := by
  classical
  have ho (i : Fin (∑ j, m j)) :
      repeatedJetOrder (groupedNode κ m) i = (((groupEquiv m).symm i).2 : ℕ) := by
    have h := grouped_repeatedJetOrder κ hκ m ((groupEquiv m).symm i)
    have hi : groupIndex m ((groupEquiv m).symm i) = i := (groupEquiv m).apply_symm_apply i
    simpa only [hi] using h
  have hmatrix : profileJetMatrix κ m = functionalMatrix
      (fun j => hasseFunctional (groupedNode κ m j) (repeatedJetOrder (groupedNode κ m) j))
      (fun i => X * (C (1 / 4 : ℂ) - X) ^ (i : ℕ)) := by
    ext i j
    change _ = (Polynomial.hasseDeriv (repeatedJetOrder (groupedNode κ m) j)
      (X * (C (1 / 4 : ℂ) - X) ^ (i : ℕ))).eval (groupedNode κ m j)
    rw [actual_polynomial_row, ho]
    rfl
  rw [hmatrix, profilePolynomial_confluent_expanded_determinant
    (groupedNode κ m) (fun i => hκ0 _), grouped_node_product, grouped_gap_product κ hκ m]

theorem finite_zero_jet_independent {r : ℕ} (ρ : Fin r → ℂ)
    (hz : ∀ j, riemannZeta (ρ j) = 0)
    (h0 : ∀ j, 0 < (ρ j).re) (h1 : ∀ j, (ρ j).re < 1)
    (hdist : distinctSpectralNodes ρ) :
    LinearIndependent ℂ (fun p : (j : Fin r) × Fin (zeroJetOrder (ρ j)) =>
      (normalizedZeroMeasureJet (ρ p.1) (p.2 : ℕ)).distributionOfLinearGrowth
        (normalizedZeroMeasureJet_hasLinearGrowth (h0 p.1) (h1 p.1)
          (zero_ne_half (hz p.1)) p.2.isLt)) := by
  classical
  let m : Fin r → ℕ := fun j => zeroJetOrder (ρ j)
  let κ : Fin r → ℂ := fun j => spectralKappa (ρ j)
  let e := groupEquiv m
  let ρe : Fin (∑ j, m j) → ℂ := fun i => ρ (e.symm i).1
  have ho (i : Fin (∑ j, m j)) :
      repeatedJetOrder (fun j => spectralKappa (ρe j)) i = ((e.symm i).2 : ℕ) := by
    change repeatedJetOrder (groupedNode κ m) i = _
    have h := grouped_repeatedJetOrder κ hdist m (e.symm i)
    have hi : groupIndex m (e.symm i) = i := e.apply_symm_apply i
    simpa only [hi] using h
  have hke (i : Fin (∑ j, m j)) :
      repeatedJetOrder (fun j => spectralKappa (ρe j)) i < zeroJetOrder (ρe i) := by
    rw [ho]
    exact (e.symm i).2.isLt
  have hLI : LinearIndependent ℂ (fun i : Fin (∑ j, m j) =>
      (normalizedZeroMeasureJet (ρe i)
        (repeatedJetOrder (fun j => spectralKappa (ρe j)) i)).distributionOfLinearGrowth
          (normalizedZeroMeasureJet_hasLinearGrowth (h0 (e.symm i).1) (h1 (e.symm i).1)
            (zero_ne_half (hz (e.symm i).1)) (hke i))) := by
    apply Fintype.linearIndependent_iff.mpr
    intro c hc i
    exact congrFun (OPICAActualMeasureCell.expanded_actual_zero_measure_jet_independent
      ρe c (fun i => h0 (e.symm i).1) (fun i => h1 (e.symm i).1)
      (fun i => hz (e.symm i).1) hke hc) i
  have hcomp := hLI.comp e e.injective
  have hkcol (p : (j : Fin r) × Fin (m j)) :
      ((e.symm (e p)).2 : ℕ) = (p.2 : ℕ) :=
    congrArg (fun q : (j : Fin r) × Fin (m j) => (q.2 : ℕ)) (e.symm_apply_apply p)
  simpa [Function.comp_def, ρe, ho, hkcol] using hcomp

#print axioms profile_jet_confluent_determinant
#print axioms finite_zero_jet_independent
end Zeta23.OPICAFollowup
