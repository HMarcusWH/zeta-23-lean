# Actual finite-span restriction and fixed-basis budget

The final production candidate is `FiniteSpanSeparationFullCandidate.lean`,
SHA256 `8e69e7c90abb572cf45d71bd70c0446b6844372d4ae954aeb8274ea3e1f1e5ef`.
The standalone consumer SHA256 is
`a5ec14ea0c5754ba762034420b58047f6134baa1e8b52fc405c9c06e3872cc6e`.
Its project imports are exactly `ConfluentProfiles` and `SignedHeatSeparator`;
the remaining imports are pinned Mathlib. All production declarations are
under `Zeta23.OPICAFollowup`. In particular the generic compactness and total
variation helpers were relocated on the assembled copy to
`Zeta23.OPICAFollowup.FixedBasisSupport` for strict release compatibility.
The sealed component sources in `work/audit-budget` were preserved unchanged.

The public roots are:

- `Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero`: both the Jordan
  zero conclusion for every actual finite realified jet combination and
  coordinate zero on any independent actual real basis.
- `Zeta23.OPICAFollowup.fixed_basis_negative_mass_budget`: a strictly positive
  constant for each fixed independent actual real basis, the Euclidean
  coefficient norm, and the actual global sinc-squared negative mass off the
  integer lattice. The zero-dimensional case is included.
- `Zeta23.OPICAFollowup.actual_zero_measure_span_consumer`: supplied separately
  in `ConsumersSpanFullCandidate.lean`, including actual zero-profile
  regularity, true normalized jets, internally established separator
  hypotheses and both finite-span conclusions.

`zeroJetRealSpan` is publicly exposed at `Zeta23.OPICAFollowup.zeroJetRealSpan`.
It is an abbreviation of the actual canonical Jordan real part of a finite
sum of normalized zero-jet measures. Complex coefficients in the finite sum
cover arbitrary real/imaginary real combinations; this is not an abstract
measure packet. Every actual source datum contains its coefficient, zero and
jet index. Its explicit validity requires zeta zero, the full open strip and
the actual multiplicity bound. Growth, unit gap, Fourier selfduality and
reflection are proved from the existing true jet results.

The basis clause explicitly retains independence of the actual real basis
distributions. No canonical Re/Im generator independence is claimed; repeated,
reflected or conjugate-dependent generators must not be treated as independent.
This is the original fixed-independent-real-basis contract, not an extra
positivity or nonvanishing packet.

## Integration

1. Install the entire full candidate as the previously missing planned file
   `Zeta23/OPICAFollowup/FiniteSpanSeparation.lean`. Keep its two project imports
   and all original root types intact.
2. Add its production import to the existing `Consumers.lean`, then append the
   new consumer theorem in that file's `Zeta23.OPICAFollowup` namespace, using
   `open Zeta23.OPICA FiniteSpan`. Preserve every existing consumer theorem;
   do not replace the file with the standalone scratch consumer.
3. In `ExpectedFullFiniteSpanFinal.lean` and
   `ExpectedActualFixedBudgetFinal.lean`, replace only the import
   `FiniteSpanSeparationFullCandidate` by
   `Zeta23.OPICAFollowup.FiniteSpanSeparation`.
4. In `ExpectedSpanPhysicalConsumerFinal.lean`, replace only the import
   `ConsumersSpanFullCandidate` by `Zeta23.OPICAFollowup.Consumers`.
5. Repeat the exact source-pinned production build and independent gates;
   scratch receipts never promote the ledger, supply a cold100 receipt or
   confer aggregate release acceptance.

The direct public root axiom commands are:

```lean
#print axioms Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero
#print axioms Zeta23.OPICAFollowup.fixed_basis_negative_mass_budget
#print axioms Zeta23.OPICAFollowup.actual_zero_measure_span_consumer
```

The three fully qualified independent consumer declarations are:

- `IndependentFullFiniteSpan.full_original_domain_and_independent_basis`
- `IndependentActualFixedBudget.expected_full_actual_euclidean_budget`
- `IndependentSpanPhysicalConsumer.expected_actual_zero_measure_span_consumer`

Every requested axiom print in the final independent consumers is fully
qualified. `AllFinalFiniteSpanChecks.lean` contains the literal bodies of the
three independent expected-type files and additional exact falsification
controls, with only their imports removed. `FINAL_CHECK_COMPONENTS.json`
records the component hashes. `AllFinalNegativeControls.lean` collects three
contract-removal controls and the independent-basis argument control.

The physical consumer genuinely uses the public H1 zero-jet root, the public
zero-profile regularity root and both public finite-span root clauses. Budget
injectivity uses the public coefficient-zero root. The historical 4eba8ef
reviewed source and literal public-root proof dependency diff are preserved
in `historical/`; no authority is silently transferred between versions.

The positive falsifiers include a zero actual basis with no positive budget,
duplicate-basis dependence, the exact reflected-zero jet identity, and a
nonzero lattice Dirac measure with growth/gap and zero weighted image that
is proved not Fourier selfdual. These distinguish actual source restrictions
from invalid generic strengthenings.

`FinalNamespacePinnedModule.receipt.json` pins all recursively imported project
sources and consumed objects before and after compilation. Final consumer
receipts use the same recursive pinning. Commands emit scratch outputs only.
Compiler pins, repository source, shared caches, frozen research evidence,
CI logic and validators were not modified by this lane.

RH, Step4, cold100 acceptance, aggregate release and independent closing
inequalities remain OPEN unless separately established by the owner gates.

Temporal import provenance: the primary module used ConfluentProfiles source
1773e320 at code9a8. Owner subsequently installed its namespace-compatible
sourcea84c72 before the downstream scratch checks; their recursive source walk
and the actually consumed cached objects are recorded separately. This lane
does not claim to have compiled that relocated dependency. The original
Confluent source is preserved in historical/ConfluentProfiles_at9a8.lean.
Exact production builds on all owner-installed sources remain required.
