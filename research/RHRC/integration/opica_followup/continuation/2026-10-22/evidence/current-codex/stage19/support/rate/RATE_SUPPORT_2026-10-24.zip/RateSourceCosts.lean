import Zeta23.OPICAFollowup.UniformSourceBounds
import Zeta23.OPICA.EnergyRate

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23.OPICA
open Zeta23.CCM
open Zeta23.ExceptionalZero
namespace Zeta23.OPICAFollowup.Stage19Rate

/-- Both signs of the literal source transform logarithm have linear order
cost at every actual right zero. No source coefficient estimate is a premise. -/
theorem sourceFactor_abs_log_bound (rho : zetaZeroConfig.carrier)
    (hright : 1/2 < (rho : ℂ).re) :
    ∃ Cp : ℝ, 0 < Cp ∧ ∀ d : ℕ,
      |Real.log ‖sourceFamilyLaplace d ((rho : ℂ)-1/2)‖| ≤ Cp*((d : ℝ)+1) := by
  let p : ℂ := (rho : ℂ)-1/2
  let A : ℝ := |Real.log ‖p^2-1/4‖|
  let B : ℝ := |Real.log ‖nativeOriginalSourceLaplace p‖|
  have hp : p^2-1/4 ≠ 0 := right_zero_source_factor_ne_zero rho hright
  have hJ : nativeOriginalSourceLaplace p ≠ 0 :=
    nativeOriginalSourceLaplace_ne_zero_at_off_line_zero rho (ne_of_gt hright)
  refine ⟨A+B+1, by dsimp [A,B]; positivity, fun d => ?_⟩
  rw [sourceFamilyLaplace_factor, norm_mul, norm_pow,
    Real.log_mul (pow_ne_zero d (norm_ne_zero_iff.mpr hp)) (norm_ne_zero_iff.mpr hJ),
    Real.log_pow]
  have htri := abs_add_le ((d : ℝ)*Real.log ‖p^2-1/4‖)
    (Real.log ‖nativeOriginalSourceLaplace p‖)
  simp only [abs_mul, abs_of_nonneg (Nat.cast_nonneg (α := ℝ) d)] at htri
  change |(d : ℝ)*Real.log ‖p^2-1/4‖+Real.log ‖nativeOriginalSourceLaplace p‖| ≤ _
  apply htri.trans
  change (d : ℝ)*A+B ≤ (A+B+1)*((d : ℝ)+1)
  nlinarith [abs_nonneg (Real.log ‖p^2-1/4‖),
    abs_nonneg (Real.log ‖nativeOriginalSourceLaplace p‖), Nat.cast_nonneg (α := ℝ) d]

/-- The zero order costs log 2. It cannot be discarded by silently replacing
the MS1 hypothesis d log(d+2) by (d+1) log(d+2). -/
theorem sourceOrderCost_le_twice (d : ℕ) :
    ((d : ℝ)+1)*Real.log ((d : ℝ)+2) ≤
      2*((d : ℝ)*Real.log ((d : ℝ)+2))+Real.log 2 := by
  by_cases hd : d=0
  · subst d; norm_num
  · have hd1 : (1 : ℝ) ≤ d := by exact_mod_cast Nat.one_le_iff_ne_zero.mpr hd
    have hlog : 0 ≤ Real.log ((d : ℝ)+2) := Real.log_nonneg (by linarith)
    nlinarith [Real.log_nonneg (by norm_num : (1 : ℝ) ≤ 2)]

theorem sourceOrder_div_time_tendsto_zero (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n)
      atTop (𝓝 0)) :
    Tendsto (fun n => (d n : ℝ)/T.time n) atTop (𝓝 0) := by
  have hlog2 : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hu := hd.const_mul (Real.log 2)⁻¹
  apply squeeze_zero (fun n => div_nonneg (Nat.cast_nonneg _) (T.positive n).le) _
    (by simpa using hu)
  intro n
  have hlog := Real.log_le_log (by norm_num : (0 : ℝ)<2)
    (by linarith [Nat.cast_nonneg (α := ℝ) (d n)] : (2 : ℝ) ≤ (d n : ℝ)+2)
  have h := mul_le_mul_of_nonneg_left hlog (Nat.cast_nonneg (d n))
  have hnum : (d n : ℝ) ≤ (Real.log 2)⁻¹*((d n : ℝ)*Real.log ((d n : ℝ)+2)) := by
    calc
      (d n : ℝ) = (Real.log 2)⁻¹*((d n : ℝ)*Real.log 2) := by field_simp
      _ ≤ _ := mul_le_mul_of_nonneg_left h (inv_nonneg.mpr hlog2.le)
  exact (div_le_div_of_nonneg_right hnum (T.positive n).le).trans_eq (by ring)

theorem fullSourceOrderCost_div_time_tendsto_zero (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n)
      atTop (𝓝 0)) :
    Tendsto (fun n => ((d n : ℝ)+1)*Real.log ((d n : ℝ)+2)/T.time n)
      atTop (𝓝 0) := by
  have hc : Tendsto (fun n => Real.log 2/T.time n) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop T.cofinal
  have hu := (hd.const_mul 2).add hc
  apply squeeze_zero (fun n => div_nonneg (mul_nonneg (by positivity)
    (Real.log_nonneg (by linarith [Nat.cast_nonneg (α := ℝ) (d n)]))) (T.positive n).le) _
    (by simpa [add_div] using hu)
  intro n
  exact (div_le_div_of_nonneg_right (sourceOrderCost_le_twice (d n)) (T.positive n).le).trans_eq (by ring)

/-- Both upper and lower literal transform costs are sublinear under precisely
the original MS1 order condition, including d=0 and bounded order schedules. -/
theorem sourceFactor_log_div_time_tendsto_zero (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n)
      atTop (𝓝 0)) (rho : zetaZeroConfig.carrier)
    (hright : 1/2 < (rho : ℂ).re) :
    Tendsto (fun n => Real.log ‖sourceFamilyLaplace (d n) ((rho : ℂ)-1/2)‖/T.time n)
      atTop (𝓝 0) := by
  obtain ⟨Cp,hCp,hcost⟩ := sourceFactor_abs_log_bound rho hright
  have hc : Tendsto (fun n => (1 : ℝ)/T.time n) atTop (𝓝 0) :=
    tendsto_const_nhds.div_atTop T.cofinal
  have hu := ((sourceOrder_div_time_tendsto_zero T d hd).add hc).const_mul Cp
  apply squeeze_zero_norm _ (by simpa [add_div] using hu)
  intro n
  rw [Real.norm_eq_abs, abs_div, abs_of_pos (T.positive n)]
  exact (div_le_div_of_nonneg_right (hcost (d n)) (T.positive n).le).trans_eq (by ring)

/-- The actual field envelope's order constant has zero rate under MS1.
This prices the already proved actual envelope; it assumes no window rate. -/
theorem fieldEnvelope_log_div_time_tendsto_zero (T : HorizonSchedule) (d : ℕ → ℕ)
    (hd : Tendsto (fun n => (d n : ℝ)*Real.log ((d n : ℝ)+2)/T.time n)
      atTop (𝓝 0)) :
    Tendsto (fun n => Real.log (1+nativeFieldOrderConstant (d n))/T.time n)
      atTop (𝓝 0) := by
  obtain ⟨C,hC,hbound⟩ := native_field_theta_envelope
  have hu := (fullSourceOrderCost_div_time_tendsto_zero T d hd).const_mul C
  apply squeeze_zero (fun n => div_nonneg
    (Real.log_nonneg (by linarith [(hbound (d n)).1])) (T.positive n).le) _
    (by simpa using hu)
  intro n
  exact (div_le_div_of_nonneg_right (hbound (d n)).2.2 (T.positive n).le).trans_eq (by ring)

#print axioms sourceFactor_abs_log_bound
#print axioms sourceOrderCost_le_twice
#print axioms sourceOrder_div_time_tendsto_zero
#print axioms fullSourceOrderCost_div_time_tendsto_zero
#print axioms sourceFactor_log_div_time_tendsto_zero
#print axioms fieldEnvelope_log_div_time_tendsto_zero
end Zeta23.OPICAFollowup.Stage19Rate
