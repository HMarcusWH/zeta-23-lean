import ActualJetControls

/-! Deliberate negative control: the κ second derivative requires 1/2!.
This file is expected to fail and is not a theorem source. -/
example : OPICARightCellTaylor.oddJetCoefficient (1 / 4) 2 1 = (-1 / 3 : ℂ) := by
  exact OPICARightCellTaylor.second_parameter_jet_cubic_coefficient
