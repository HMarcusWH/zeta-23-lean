import Zeta23.OPICAFollowup.CoPoissonJets

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform

namespace OPICAActualMeasureCell
open Zeta23.OPICAFollowup

/-- No integer lies in the open first cell; every lattice sample of a test
supported in that cell therefore vanishes. -/
theorem integer_samples_zero (φ : 𝓢(ℝ, ℂ))
    (hφ : Function.support (φ : ℝ → ℂ) ⊆ Ioo 1 2) (n : ℤ) : φ n = 0 := by
  by_contra hn
  have hcell := hφ hn
  have hlow : (1 : ℤ) < n := by exact_mod_cast hcell.1
  have hhigh : n < (2 : ℤ) := by exact_mod_cast hcell.2
  omega

/-- On the open first cell the actual normalized measure jet pairs with
its density alone: the actual punctured-lattice term vanishes. -/
theorem actual_jet_first_cell_pairing {ρ : ℂ} (h0 : 0 < ρ.re) (h1 : ρ.re < 1)
    (hh : ρ ≠ 1 / 2) (k : ℕ) (φ : 𝓢(ℝ, ℂ))
    (hφ : Function.support (φ : ℝ → ℂ) ⊆ Ioo 1 2) :
    (normalizedZeroMeasureJet ρ k).integral φ =
      ∫ x, zeroJetDensity (spectralKappa ρ) k x * φ x := by
  rw [normalizedZeroMeasureJet_integral h0 h1 hh]
  simp [integer_samples_zero φ hφ]

/-- A zero combination of the faithful embedded actual measure jets has
zero density pairing against every Schwartz test supported in (1,2).
Linear growth is established from the prescribed physical jet orders. -/
theorem actual_jet_combination_first_cell_integral_zero {ι : Type*} [Fintype ι]
    (c : ι → ℂ) (ρ : ι → ℂ) (k : ι → ℕ)
    (h0 : ∀ i, 0 < (ρ i).re) (h1 : ∀ i, (ρ i).re < 1)
    (hh : ∀ i, ρ i ≠ 1 / 2) (hk : ∀ i, k i < zeroJetOrder (ρ i))
    (hzero : (∑ i, c i • (normalizedZeroMeasureJet (ρ i) (k i)).distributionOfLinearGrowth
      (normalizedZeroMeasureJet_hasLinearGrowth (h0 i) (h1 i) (hh i) (hk i))) = 0)
    (φ : 𝓢(ℝ, ℂ)) (hφ : Function.support (φ : ℝ → ℂ) ⊆ Ioo 1 2) :
    (∫ x, (∑ i, c i * zeroJetDensity (spectralKappa (ρ i)) (k i) x) * φ x) = 0 := by
  have hp : (∑ i, c i * (normalizedZeroMeasureJet (ρ i) (k i)).integral φ) = 0 := by
    have he := congrArg (fun T : TemperedDistribution ℝ ℂ => T φ) hzero
    simpa only [ContinuousLinearMap.sum_apply, ContinuousLinearMap.smul_apply,
      ContinuousLinearMap.zero_apply, smul_eq_mul,
      LocallyFiniteComplexMeasure.distributionOfLinearGrowth_apply] using he
  simp_rw [actual_jet_first_cell_pairing (h0 _) (h1 _) (hh _) _ φ hφ] at hp
  calc
    (∫ x, (∑ i, c i * zeroJetDensity (spectralKappa (ρ i)) (k i) x) * φ x) =
        ∑ i, c i * ∫ x, zeroJetDensity (spectralKappa (ρ i)) (k i) x * φ x := by
      simp_rw [Finset.sum_mul, mul_assoc]
      rw [integral_finset_sum]
      · simp_rw [integral_const_mul]
      · intro i _
        exact (integrable_zeroJetDensity_mul _ _ φ).const_mul (c i)
    _ = 0 := hp

#print axioms integer_samples_zero
#print axioms actual_jet_first_cell_pairing
#print axioms actual_jet_combination_first_cell_integral_zero

end OPICAActualMeasureCell
