import Zeta23.OPICAFollowup.CoPoissonJets

/-! Actual physical first-cell bridge for H2a. This identifies the existing
zeroJetDensity with the κ-jets of the entire first-cell kernel. The odd-u
Taylor coefficient extraction and measure-independence bridge remain separate. -/

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology
namespace OPICAActualFirstCellAudit
open Zeta23.OPICAFollowup

theorem actual_family_first_cell (κ : ℂ) {y : ℝ} (hy1 : 1 ≤ y) (hy2 : y < 2) :
    zeroFamilyDensity κ y =
      κ * (Real.exp (-Real.log y / 2) : ℂ) * shKernel (1 / 4 - κ) (Real.log y) := by
  have hy0 : 0 ≤ y := by linarith
  have hfloor : ⌊|y|⌋₊ = 1 := by
    apply (Nat.floor_eq_iff (abs_nonneg y)).mpr
    rw [abs_of_nonneg hy0]
    norm_num
    exact ⟨hy1, hy2⟩
  rw [zeroFamilyDensity, hfloor, abs_of_nonneg hy0]
  simp only [Finset.Icc_self, Finset.sum_singleton, Nat.cast_one, div_one]
  ring

theorem actual_family_first_log_cell (κ : ℂ) {u : ℝ} (hu0 : 0 ≤ u)
    (hu2 : u < Real.log 2) :
    (Real.exp (u / 2) : ℂ) * zeroFamilyDensity κ (Real.exp u) =
      κ * shKernel (1 / 4 - κ) u := by
  have hy1 : 1 ≤ Real.exp u := Real.one_le_exp hu0
  have hy2 : Real.exp u < 2 := by
    calc
      Real.exp u < Real.exp (Real.log 2) := Real.exp_lt_exp.mpr hu2
      _ = 2 := Real.exp_log (by norm_num)
  rw [actual_family_first_cell κ hy1 hy2, Real.log_exp]
  have he : (Real.exp (u / 2) : ℂ) * (Real.exp (-u / 2) : ℂ) = 1 := by
    have hr : Real.exp (u / 2) * Real.exp (-u / 2) = 1 := by
      rw [← Real.exp_add, show u / 2 + -u / 2 = 0 by ring, Real.exp_zero]
    exact_mod_cast hr
  calc
    _ = κ * ((Real.exp (u / 2) : ℂ) * (Real.exp (-u / 2) : ℂ)) *
        shKernel (1 / 4 - κ) u := by ring
    _ = _ := by rw [he]; ring

theorem actual_normalized_jet_first_log_cell (κ : ℂ) (k : ℕ) {u : ℝ} (hu0 : 0 ≤ u)
    (hu2 : u < Real.log 2) :
    (Real.exp (u / 2) : ℂ) * zeroJetDensity κ k (Real.exp u) =
      iteratedDeriv k (fun w : ℂ => w * shKernel (1 / 4 - w) u) κ /
        (k.factorial : ℂ) := by
  have heq : (fun w : ℂ => (Real.exp (u / 2) : ℂ) * zeroFamilyDensity w (Real.exp u)) =
      (fun w : ℂ => w * shKernel (1 / 4 - w) u) :=
    funext (fun w => actual_family_first_log_cell w hu0 hu2)
  have hk := congrArg (fun f : ℂ → ℂ => iteratedDeriv k f κ) heq
  rw [iteratedDeriv_const_mul_field] at hk
  rw [zeroJetDensity, ← mul_div_assoc, hk]

#print axioms actual_family_first_cell
#print axioms actual_family_first_log_cell
#print axioms actual_normalized_jet_first_log_cell
end OPICAActualFirstCellAudit
