import FiniteSpanCombination
import SincWeightedMeasures

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap FourierTransform ENNReal NNReal

namespace Zeta23.OPICAFollowup.FiniteSpanScratch
open Zeta23.OPICA FixedBudgetSupport

lemma signed_zero_growth : zeroJordan.HasLinearGrowth := by
  refine ⟨0, le_rfl, fun R hR => ?_⟩
  simp [zeroJordan, LocallyFiniteSignedMeasure.totalVariation, Measure.real]

lemma signed_as_complex_growth (μ : LocallyFiniteSignedMeasure) (h : μ.HasLinearGrowth) :
    (⟨μ, zeroJordan⟩ : LocallyFiniteComplexMeasure).HasLinearGrowth := by
  simpa only [LocallyFiniteComplexMeasure.HasLinearGrowth,
    LocallyFiniteComplexMeasure.variationControl, zeroJordan,
    LocallyFiniteSignedMeasure.HasLinearGrowth,
    LocallyFiniteSignedMeasure.totalVariation, add_zero] using h

lemma signed_add_growth (μ ν : LocallyFiniteSignedMeasure)
    (hμ : μ.HasLinearGrowth) (hν : ν.HasLinearGrowth) : (localJordanAdd μ ν).HasLinearGrowth := by
  exact LocallyFiniteComplexMeasure.re_hasLinearGrowth
    ((⟨μ, zeroJordan⟩ : LocallyFiniteComplexMeasure).add ⟨ν,zeroJordan⟩)
    (LocallyFiniteComplexMeasure.hasLinearGrowth_add _ _
      (signed_as_complex_growth μ hμ) (signed_as_complex_growth ν hν))

lemma signed_scale_growth (a : ℝ) (μ : LocallyFiniteSignedMeasure)
    (hμ : μ.HasLinearGrowth) : (localJordanScale a μ).HasLinearGrowth := by
  obtain ⟨A,hA,hAb⟩ := hμ
  refine ⟨|a| * A,mul_nonneg (abs_nonneg _) hA,fun R hR => ?_⟩
  have hle := localJordanScale_totalVariation_le a μ (Icc (-R) R)
  rw [Measure.smul_apply,smul_eq_mul] at hle
  have hfin : ENNReal.ofReal |a| * μ.totalVariation (Icc (-R) R)≠∞ :=
    ENNReal.mul_ne_top ENNReal.ofReal_ne_top isCompact_Icc.measure_lt_top.ne
  have hh := ENNReal.toReal_mono hfin hle
  rw [ENNReal.toReal_mul,ENNReal.toReal_ofReal (abs_nonneg _)] at hh
  have ha := hAb R hR
  change (μ.totalVariation (Icc (-R) R)).toReal≤_ at ha
  change ((localJordanScale a μ).totalVariation (Icc (-R) R)).toReal≤_
  calc
    _ ≤ |a| * (μ.totalVariation (Icc (-R) R)).toReal := hh
    _ ≤ |a| * (A * (1+R)) := mul_le_mul_of_nonneg_left ha (abs_nonneg a)
    _ = _ := by ring

/-- Generic finite Jordan algebra with growth already proved for each input.
The actual basis below supplies these proofs from the actual zero jets. -/
abbrev GrowingSignedDatum := ℝ × {μ : LocallyFiniteSignedMeasure // μ.HasLinearGrowth}

def signedListSum : List GrowingSignedDatum → LocallyFiniteSignedMeasure
  | [] => zeroJordan
  | j :: rest => localJordanAdd (localJordanScale j.1 j.2.1) (signedListSum rest)

lemma signedListSum_growth (data : List GrowingSignedDatum) : (signedListSum data).HasLinearGrowth := by
  induction data with
  | nil => exact signed_zero_growth
  | cons j rest ih => exact signed_add_growth _ _ (signed_scale_growth _ _ j.2.2) ih

lemma zeroJordan_compactRestriction (K : Set ℝ) (hK : IsCompact K) :
    localSignedCompactRestriction zeroJordan K hK = 0 := by
  ext E hE
  simp [zeroJordan, localSignedCompactRestriction]

lemma signedListSum_compactRestriction (data : List GrowingSignedDatum)
    (K : Set ℝ) (hK : IsCompact K) :
    localSignedCompactRestriction (signedListSum data) K hK =
      (data.map (fun j => j.1 • localSignedCompactRestriction j.2.1 K hK)).sum := by
  induction data with
  | nil => simp [signedListSum, zeroJordan_compactRestriction]
  | cons j rest ih =>
    rw [signedListSum, localJordanAdd_compactRestriction, localJordanScale_compactRestriction, ih]
    rfl

lemma zeroJordan_weighted : sincWeightedSigned zeroJordan signed_zero_growth = 0 := by
  ext E hE
  rw [sincWeightedSigned_apply _ _ _ hE]
  simp [zeroJordan]

lemma signedListSum_weighted (data : List GrowingSignedDatum) :
    sincWeightedSigned (signedListSum data) (signedListSum_growth data) =
      (data.map (fun j => j.1 • sincWeightedSigned j.2.1 j.2.2)).sum := by
  induction data with
  | nil => simp [signedListSum, zeroJordan_weighted]
  | cons j rest ih =>
    change sincWeightedSigned (localJordanAdd (localJordanScale j.1 j.2.1) (signedListSum rest))
      (signed_add_growth _ _ (signed_scale_growth _ _ j.2.2) (signedListSum_growth rest)) = _
    rw [sincWeightedSigned_add _ _ (signed_scale_growth _ _ j.2.2)
      (signedListSum_growth rest), sincWeightedSigned_scale, ih]
    rfl

lemma signed_eq_of_compactRestrictions (μ ν : LocallyFiniteSignedMeasure)
    (h : ∀ K : Set ℝ, ∀ hK : IsCompact K,
      localSignedCompactRestriction μ K hK = localSignedCompactRestriction ν K hK) : μ = ν := by
  have hpK (K : Set ℝ) (hK : IsCompact K) : μ.positive.restrict K = ν.positive.restrict K := by
    have hp := congrArg (fun s : SignedMeasure ℝ => s.toJordanDecomposition.posPart) (h K hK)
    simpa only [localSignedCompactRestriction_jordan, localSignedCompactJordan] using hp
  have hnK (K : Set ℝ) (hK : IsCompact K) : μ.negative.restrict K = ν.negative.restrict K := by
    have hn := congrArg (fun s : SignedMeasure ℝ => s.toJordanDecomposition.negPart) (h K hK)
    simpa only [localSignedCompactRestriction_jordan, localSignedCompactJordan] using hn
  have hp : μ.positive = ν.positive :=
    Measure.ext_of_iUnion_eq_univ localMeasureInterval_cover (fun n => hpK _ isCompact_Icc)
  have hn : μ.negative = ν.negative :=
    Measure.ext_of_iUnion_eq_univ localMeasureInterval_cover (fun n => hnK _ isCompact_Icc)
  cases μ
  cases ν
  cases hp
  cases hn
  rfl

def basisSignedData {n : ℕ} (basis : Fin n → List JetDatum)
    (h : ∀ i, ∀ j ∈ basis i, ValidJet j) (a : Fin n → ℝ) : List GrowingSignedDatum :=
  List.ofFn (fun i => (a i, ⟨zeroJetRealSpan (basis i), zeroJetRealSpan_growth _ (h i)⟩))

lemma realBasisCombination_eq_signedListSum {n : ℕ} (basis : Fin n → List JetDatum)
    (h : ∀ i, ∀ j ∈ basis i, ValidJet j) (a : Fin n → ℝ) :
    zeroJetRealSpan (realBasisCombinationData basis a) = signedListSum (basisSignedData basis h a) := by
  apply signed_eq_of_compactRestrictions
  intro K hK
  rw [realBasisCombination_compactRestriction, signedListSum_compactRestriction]
  simp only [basisSignedData, List.map_ofFn, List.sum_ofFn, Function.comp_apply]

lemma sincWeightedSigned_congr (μ ν : LocallyFiniteSignedMeasure)
    (hμ : μ.HasLinearGrowth) (hν : ν.HasLinearGrowth) (heq : μ = ν) :
    sincWeightedSigned μ hμ = sincWeightedSigned ν hν := by
  cases heq
  rfl

theorem realBasisCombination_weightedSigned {n : ℕ} (basis : Fin n → List JetDatum)
    (h : ∀ i, ∀ j ∈ basis i, ValidJet j) (a : Fin n → ℝ) :
    sincWeightedSigned (zeroJetRealSpan (realBasisCombinationData basis a))
        (zeroJetRealSpan_growth _ (realBasisCombination_valid basis h a)) =
      ∑ i, a i • sincWeightedSigned (zeroJetRealSpan (basis i)) (zeroJetRealSpan_growth _ (h i)) := by
  have heq := realBasisCombination_eq_signedListSum basis h a
  have hw := sincWeightedSigned_congr _ _
    (zeroJetRealSpan_growth _ (realBasisCombination_valid basis h a))
    (signedListSum_growth (basisSignedData basis h a)) heq
  rw [hw, signedListSum_weighted]
  simp only [basisSignedData, List.map_ofFn, List.sum_ofFn, Function.comp_apply]

#print axioms Zeta23.OPICAFollowup.FiniteSpanScratch.realBasisCombination_weightedSigned
end Zeta23.OPICAFollowup.FiniteSpanScratch
