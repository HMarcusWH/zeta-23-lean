# Stage22 square physical integration

Install the sealed source only after the owner's current clean replay and
record finish. This lane did not edit the checkout, shared cache, validators,
parent sources or historical evidence.

The full candidate is `SquareDefectPhysicalFullCandidate.lean`, SHA256
`c65b7b8eb6894a89a12a85e36ea660c97ca8deeb47900392786b20ae81b4ee58`.
Its first bytes are the exact original `SquareDefect.lean`, SHA256
`da73276d089068c1711f3854a9520fbcbbbc877d77ccc33fe20cb9ceb83d64d1`.
The assembled file preserves all original four roots, types, proofs and
imports verbatim, then adds supporting physical adapters. All declarations
remain inside `Zeta23.OPICAFollowup`; no project import is added to Square.
`assemble_square_physical.py` records the assembly recipe and component hashes.

1. Verify the current production Square source equals the recorded original
   prefix, then install the full candidate at the existing planned
   `Zeta23/OPICAFollowup/SquareDefect.lean` path. The trailing axiom prints are
   included in the checked bytes; any removal changes source SHA and requires
   exact production replay.
2. `SquareSpanCompositionFinal.lean` supplies the optional but verified
   source-specific composition for the existing `Consumers.lean`: append
   `actualZeroSquareDistribution` and `actual_square_zero_jet_lattice_barrier`
   inside `Zeta23.OPICAFollowup`. Keep all prior consumer declarations and the
   authorized original imports. The existing Square and FiniteSpan imports
   provide everything needed; do not copy the standalone import header.
3. In `ExpectedSquarePhysicalFinal.lean` and
   `NegativeSquarePhysicalFinal.lean`, replace only the scratch full-candidate
   import by `Zeta23.OPICAFollowup.SquareDefect`.
4. In `ExpectedSquareSpanCompositionFinal.lean`, replace only its standalone
   consumer import by `Zeta23.OPICAFollowup.Consumers`.
5. Repeat exact production compilation, full independent types, allowed
   axioms, meaningful negative controls and source-pinned receipts. These are
   supporting physical checks, not additional original theorem roots.

The full physical expected declarations are:

- `Zeta23.OPICAFollowup.SquarePhysicalExpected.full_actual_square_measure`
- `Zeta23.OPICAFollowup.SquarePhysicalExpected.all_actual_tempered_corrections`
- `Zeta23.OPICAFollowup.SquarePhysicalExpected.full_actual_projection`
- `Zeta23.OPICAFollowup.SquareSpanExpected.full_actual_square_jet_lattice_composition`

The broad physical no-repair theorem is
`Zeta23.OPICAFollowup.square_actual_no_tempered_measure_repair`. Its exact
domain is a genuine locally finite complex measure σ with
`σ.totalVariation.HasTemperateGrowth` and `σ.totalVariation (ℤᶜ)=0`.
The variation is the actual Euclidean complex variation, not relabelled
coordinate variation. The four coordinate temperate embeddings are derived
from the proved global factor-two bound. No linear-growth assumption or
fixed polynomial degree is imposed on σ.

Do not upgrade this signature silently to a correction represented only by
an arbitrary tempered distribution extending local order-zero compact-test
pairings. The discrete-support equivalence is a classical published theorem,
but its Lean bridge is a separate OPEN obligation being pursued in
`work/audit-tempered-lattice`. The post-green report cites the exact primary
literature and distinguishes mathematical equivalence from kernel authority.

The projection is a genuine tempered distribution of the actual square
carrier, with the exact global density identity and all positive local
gap-filling clauses. A separate global Jordan carrier for the projected
distribution is not claimed by this bundle.

The source-specific mixed barrier uses the actual zero profile with plateau
one, an arbitrary actual finite multiplicity-bounded zero-jet combination,
and the arbitrary true-TV-temperate lattice measure. The jet combination
needs no independence premise: its source-specific Fourier selfduality is
enough. This does not exclude an off-critical zero or arbitrary nonlinear
nonlattice corrections. RH, Step4 and aggregate acceptance remain OPEN.
