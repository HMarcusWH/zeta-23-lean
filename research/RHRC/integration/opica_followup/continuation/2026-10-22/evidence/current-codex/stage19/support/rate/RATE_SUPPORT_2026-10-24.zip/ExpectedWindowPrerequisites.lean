import RateMemoryWindow
import RateCompletionIndex

noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Zeta23 Zeta23.OPICAFollowup
namespace Stage19IndependentWindow

theorem expected_actual_energy_upper (d : ℕ) {C T : ℝ} (C_nonneg : 0 ≤ C)
    (T_at_least_one : 1 ≤ T) (start_nonneg : 0 ≤ T-C*Real.log T) :
    (∫ t : ℝ in Icc (T-C*Real.log T) T, |primeFieldFamily d t|^2) ≤
      C*Real.log T*(nativeFieldOrderConstant d)^2*Real.exp (2*nativeZeroDisplacementSup*T) :=
  Stage19Rate.nativeWindowEnergy_upper d C_nonneg T_at_least_one start_nonneg

theorem expected_actual_memory_split (d : ℕ) (alpha C T : ℝ) (C_nonneg : 0 ≤ C)
    (T_at_least_one : 1 ≤ T) (start_nonneg : 0 ≤ T-C*Real.log T) :
    (∫ s : ℝ in Icc 0 T, Real.exp (-alpha*(T-s))*|primeFieldFamily d s|) =
      (∫ s : ℝ in Icc 0 (T-C*Real.log T), Real.exp (-alpha*(T-s))*|primeFieldFamily d s|)+
      (∫ s : ℝ in Icc (T-C*Real.log T) T, Real.exp (-alpha*(T-s))*|primeFieldFamily d s|) :=
  Stage19Rate.tailMemory_split d alpha C T C_nonneg T_at_least_one start_nonneg

theorem expected_physical_terminal_cauchy_schwarz (d : ℕ) {alpha C T : ℝ}
    (alpha_nonneg : 0 ≤ alpha) (C_nonneg : 0 ≤ C) (T_at_least_one : 1 ≤ T) :
    (∫ s : ℝ in Icc (T-C*Real.log T) T, Real.exp (-alpha*(T-s))*|primeFieldFamily d s|)^2 ≤
      C*Real.log T*(∫ t : ℝ in Icc (T-C*Real.log T) T, |primeFieldFamily d t|^2) :=
  Stage19Rate.native_terminalMemory_sq_le_windowEnergy d alpha_nonneg C_nonneg T_at_least_one

theorem expected_actual_multiplicity_energy_barrier (k d : ℕ) (k_at_least_one : 1 ≤ k)
    (rho : zetaZeroConfig.carrier) (right_zero : 1/2 < (rho : ℂ).re)
    {C T : ℝ} (C_nonneg : 0 ≤ C) (T_at_least_one : 1 ≤ T)
    (start_nonneg : 0 ≤ T-C*Real.log T) :
    (max (Real.sqrt (2*auxCompletionAlpha k)/auxCompletionBound k*
      max (nativeMultiplicityTailConstant d rho*‖auxRationalFactor k ((rho : ℂ)-1/2)‖*
        Real.exp (((rho : ℂ)-1/2).re*T)-‖nativeAuxiliaryStableVector k d‖) 0-
        T*nativeFieldOrderConstant d*
          Real.exp (nativeZeroDisplacementSup*T-(auxCompletionAlpha k+nativeZeroDisplacementSup)*C*Real.log T)) 0)^2 ≤
      C*Real.log T*(∫ t : ℝ in Icc (T-C*Real.log T) T, |primeFieldFamily d t|^2) :=
  Stage19Rate.native_window_energy_multiplicity_barrier k d k_at_least_one rho right_zero
    C_nonneg T_at_least_one start_nonneg

theorem expected_continuous_completion_exponent (xi : ℝ) (xi_nonneg : 0 ≤ xi) :
    Tendsto (fun T : ℝ => auxCompletionAlpha (max 1 (Nat.floor (xi*T/Real.log T)))*Real.log T/T)
      atTop (𝓝 xi) :=
  Stage19Rate.actualCompletionAlpha_log_scale_tendsto xi xi_nonneg

theorem expected_completion_normalization_cost (xi Cp : ℝ) (xi_nonneg : 0 ≤ xi)
    {epsilon : ℝ} (epsilon_pos : 0 < epsilon) :
    ∀ᶠ T : ℝ in atTop,
      (((max 1 (Nat.floor (xi*T/Real.log T)) : ℕ) : ℝ)*
        Real.log (((max 1 (Nat.floor (xi*T/Real.log T)) : ℕ) : ℝ)+1)+
        Cp*(((max 1 (Nat.floor (xi*T/Real.log T)) : ℕ) : ℝ)+1))/T < xi+epsilon :=
  Stage19Rate.completionCost_eventually_lt xi Cp xi_nonneg epsilon_pos

/-- Damping with the opposite sign invalidates dropping the memory weight. -/
theorem negative_damping_control : ¬ Real.exp (-(-1 : ℝ)*(1-0)) ≤ 1 := by
  norm_num only [neg_neg,sub_zero,one_mul]
  exact not_le_of_gt (Real.one_lt_exp_iff.mpr (by norm_num))

/-- The positive part cannot establish a positive lower barrier while the old
memory cost dominates. This falsifies an omitted-subtraction interpretation. -/
theorem dominated_barrier_is_zero (lower old : ℝ) (dominated : lower ≤ old) :
    max (lower-old) 0 = 0 := max_eq_right (sub_nonpos.mpr dominated)

#print axioms expected_actual_energy_upper
#print axioms expected_actual_memory_split
#print axioms expected_physical_terminal_cauchy_schwarz
#print axioms expected_actual_multiplicity_energy_barrier
#print axioms expected_continuous_completion_exponent
#print axioms expected_completion_normalization_cost
#print axioms negative_damping_control
#print axioms dominated_barrier_is_zero
end Stage19IndependentWindow
