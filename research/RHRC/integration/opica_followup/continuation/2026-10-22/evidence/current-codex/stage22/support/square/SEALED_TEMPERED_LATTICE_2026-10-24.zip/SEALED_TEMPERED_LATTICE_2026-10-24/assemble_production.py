"""Assemble a scratch production-shaped Square module without touching the checkout.

The fixed physical Square source body is kept byte-for-byte. Extra Mathlib imports
are inserted before it, then the two supplementary bodies are appended after
removing scratch imports. The owner must compile this exact assembled source and
its final independent consumers before production promotion.
"""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
base=P.parent/'audit-square-physical'/'SquareDefectPhysicalFullCandidate.lean'
expected={
    base:'c65b7b8eb6894a89a12a85e36ea660c97ca8deeb47900392786b20ae81b4ee58',
    P/'SchwartzCompactApprox.lean':'f2ceb97fa0d10b67bcf7036709e898087dfd04bf44808098ac0f4461a1600ad9',
    P/'TemperedLatticeNoRepair.lean':'bd0c74c720d1c7eb56f19d60b8845b887db8c2ba54bfec000f02c4007da11af5',
}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in expected.items():
    assert sha(p)==h,(str(p),sha(p),h)
extras=b'import Mathlib.Analysis.Distribution.SchwartzSpace.Deriv\nimport Mathlib.Analysis.Calculus.BumpFunction.Basic\nimport Mathlib.Tactic\n'
body=extras+base.read_bytes()
assert body[len(extras):]==base.read_bytes()
for filename,ns in [('SchwartzCompactApprox.lean','Zeta23.OPICAFollowup.TemperedLatticeBridge.'),('TemperedLatticeNoRepair.lean','Zeta23.OPICAFollowup.')]:
    lines=[]
    for line in (P/filename).read_text(encoding='utf-8').splitlines():
        if line.startswith('import '): continue
        if line.startswith('#print axioms '):
            name=line.removeprefix('#print axioms ')
            line='#print axioms '+ns+name
        lines.append(line)
    body+=('\n\n'+'\n'.join(lines)+'\n').encode('utf-8')
target=P/'SquareDefectFullDomainAssembled.lean'
target.write_bytes(body)
consumer=(P/'ExpectedTemperedLatticeNoRepair.lean').read_text(encoding='utf-8')
consumer=consumer.replace('import TemperedLatticeNoRepair','import SquareDefectFullDomainAssembled',1)
consumer='\n'.join(('#print axioms Zeta23.OPICAFollowup.'+line.removeprefix('#print axioms ')
    if line.startswith('#print axioms ') else line) for line in consumer.splitlines())+'\n'
(P/'ExpectedSquareDefectFullDomainAssembled.lean').write_text(consumer,encoding='utf-8')
(P/'ExpectedSquareDefectFullDomainProduction.lean').write_text(consumer.replace(
    'import SquareDefectFullDomainAssembled','import Zeta23.OPICAFollowup.SquareDefect',1),encoding='utf-8')
row={'scope':'Prepared assembly only; native owner replay required. No source/pin/registry changes.',
     'input_hashes':{str(p):h for p,h in expected.items()},
     'output':str(target),'output_sha256':sha(target),
     'physical_body_unchanged':body[len(extras):len(extras)+base.stat().st_size]==base.read_bytes()}
(P/'assembly-preparation.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row,indent=2))
