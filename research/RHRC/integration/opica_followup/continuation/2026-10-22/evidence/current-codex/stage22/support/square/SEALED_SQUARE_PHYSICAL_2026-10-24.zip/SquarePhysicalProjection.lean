import SquarePhysicalCandidate

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology FourierTransform SchwartzMap
namespace Zeta23.OPICAFollowup
open Zeta23.OPICA

/-- The self-dual projection of the actual tempered distribution of the
canonical square Jordan measure; it is not merely a raw test functional. -/
def squareProjectedDistribution {h : ℝ → ℂ} (hcont : Continuous h)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) (A : ℂ) : TemperedDistribution ℝ ℂ :=
  (1/2:ℂ) • ((squareGapJordan h A hcont).distributionOfLinearGrowth
    (squareGapJordan_growth hcont hvan A)+
      𝓕 ((squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)))

theorem squareProjectedDistribution_functional {h : ℝ → ℂ} (hcont : Continuous h)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) (A : ℂ) (φ : 𝓢(ℝ,ℂ)) :
    squareProjectedDistribution hcont hvan A φ=
      Zeta23.OPICA.involutionSelfdualProjection fourierFunctional (squareGapMeasure h A) φ := by
  simp only [squareProjectedDistribution,ContinuousLinearMap.smul_apply,ContinuousLinearMap.add_apply,
    smul_eq_mul,TemperedDistribution.fourier_apply,squareGapJordan_pairing hcont hvan A,
    involutionSelfdualProjection,Pi.smul_apply,Pi.add_apply,fourierFunctional,
    LinearMap.coe_mk,AddHom.coe_mk]
  ring

/-- The existing S3.3 projection theorem transported to the actual square
measure distribution: Fourier selfduality and strictly positive local density
on a nonempty interval inside the old exact measure gap. -/
theorem square_actual_projection_fills_gap {h : ℝ → ℂ} {A : ℂ}
    (hev : ∀ x,h (-x)=h x) (hcont : Continuous h) (hint : Integrable h)
    (hL2 : MemLp h 2) (hsd : 𝓕 h=h) (hvan : Tendsto h (cocompact ℝ) (𝓝 0))
    (hpl : ∀ x,|x|≤1 → h x=A) (hne : h≠0) :
    𝓕 (squareProjectedDistribution hcont hvan A)=squareProjectedDistribution hcont hvan A ∧
    (∀ φ:𝓢(ℝ,ℂ),squareProjectedDistribution hcont hvan A φ=
      (squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A) φ+
          (1/2)*∫ x,squareDualityDefect h x*φ x) ∧
    ∃ ε:ℝ,0<ε ∧ ε<1 ∧
      (∀ x∈Ioo (-ε) ε,0<(squareDualityDefect h x).re ∧ (squareDualityDefect h x).im=0) ∧
      ∀ φ:𝓢(ℝ,ℂ),tsupport φ⊆Ioo (-ε) ε →
        squareProjectedDistribution hcont hvan A φ=∫ x,(squareDualityDefect h x/2)*φ x := by
  have hp := square_selfdual_projection_fills_gap hev hcont hint hL2 hsd hpl hne
  refine ⟨?_,?_,?_⟩
  · ext φ
    rw [TemperedDistribution.fourier_apply,squareProjectedDistribution_functional,
      squareProjectedDistribution_functional]
    exact congrFun hp.1 φ
  · intro φ
    rw [squareProjectedDistribution_functional,squareGapJordan_pairing hcont hvan A]
    exact hp.2.1 φ
  · obtain ⟨ε,hε,hε1,hpos,hpair⟩ := hp.2.2
    exact ⟨ε,hε,hε1,hpos,fun φ hφ =>
      (squareProjectedDistribution_functional hcont hvan A φ).trans (hpair φ hφ)⟩

end Zeta23.OPICAFollowup
#print axioms Zeta23.OPICAFollowup.square_actual_projection_fills_gap
