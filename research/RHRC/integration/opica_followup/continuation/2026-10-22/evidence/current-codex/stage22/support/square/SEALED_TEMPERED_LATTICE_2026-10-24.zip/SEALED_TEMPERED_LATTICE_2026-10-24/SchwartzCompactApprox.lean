import Mathlib.Analysis.Distribution.SchwartzSpace.Deriv
import Mathlib.Analysis.Calculus.BumpFunction.Basic
import Mathlib.Tactic

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology SchwartzMap ContDiff

namespace Zeta23.OPICAFollowup.TemperedLatticeBridge

def unitBump : ContDiffBump (0 : ℝ) := ⟨1,2,by norm_num,by norm_num⟩

def unitBumpSchwartz : 𝓢(ℝ,ℝ) :=
  unitBump.hasCompactSupport.toSchwartzMap unitBump.contDiff

def scaledBump (N : ℕ) (x : ℝ) : ℝ :=
  unitBumpSchwartz (((N : ℝ)+1)⁻¹*x)

theorem scaledBump_smooth (N : ℕ) : ContDiff ℝ ∞ (scaledBump N) :=
  (unitBumpSchwartz.smooth ⊤).comp (contDiff_const.mul contDiff_id)

theorem scaledBump_compact (N : ℕ) : HasCompactSupport (scaledBump N) := by
  exact unitBump.hasCompactSupport.comp_homeomorph
    (Homeomorph.mulLeft₀ (((N : ℝ)+1)⁻¹) (inv_ne_zero (by positivity)))

theorem scaledBump_eq_one (N : ℕ) (x : ℝ) (hx : ‖x‖ < (N : ℝ)+1) :
    scaledBump N x=1 := by
  apply unitBump.one_of_mem_closedBall
  simp only [Metric.mem_closedBall, dist_zero_right, unitBump]
  rw [norm_mul, Real.norm_of_nonneg (by positivity)]
  exact (inv_mul_le_one₀ (by positivity)).mpr hx.le

theorem scaledBump_derivative_bound (n : ℕ) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ N x,
      ‖iteratedFDeriv ℝ n (fun y => scaledBump N y - 1) x‖ ≤ B := by
  refine ⟨(SchwartzMap.seminorm ℝ 0 n) unitBumpSchwartz+1, by positivity, ?_⟩
  intro N x
  let L : ℝ →L[ℝ] ℝ := ((N : ℝ)+1)⁻¹ • ContinuousLinearMap.id ℝ ℝ
  have heq : scaledBump N = unitBumpSchwartz ∘ L := rfl
  have hL : ‖L‖ ≤ 1 := by
    simp only [L, norm_smul, ContinuousLinearMap.norm_id, mul_one]
    rw [Real.norm_of_nonneg (by positivity)]
    exact inv_le_one_of_one_le₀ (by have := Nat.cast_nonneg (α := ℝ) N; linarith)
  have hD : ‖iteratedFDeriv ℝ n (scaledBump N) x‖ ≤
      (SchwartzMap.seminorm ℝ 0 n) unitBumpSchwartz := by
    rw [heq, L.iteratedFDeriv_comp_right (unitBumpSchwartz.smooth n) x le_rfl]
    apply le_trans (ContinuousMultilinearMap.norm_compContinuousLinearMap_le _ _)
    calc
      ‖iteratedFDeriv ℝ n unitBumpSchwartz (L x)‖ * ∏ _i : Fin n, ‖L‖ ≤
          ‖iteratedFDeriv ℝ n unitBumpSchwartz (L x)‖ * 1 := by
            gcongr
            exact Finset.prod_le_one (by intros; positivity) (by intros; exact hL)
      _ ≤ (SchwartzMap.seminorm ℝ 0 n) unitBumpSchwartz := by
        simpa using SchwartzMap.norm_iteratedFDeriv_le_seminorm ℝ unitBumpSchwartz n (L x)
  have hc : ‖iteratedFDeriv ℝ n (fun _ : ℝ => (1 : ℝ)) x‖ ≤ 1 := by
    cases n with
    | zero => simp [norm_iteratedFDeriv_zero]
    | succ n => simp [iteratedFDeriv_succ_const]
  change ‖iteratedFDeriv ℝ n (scaledBump N - fun _ => (1 : ℝ)) x‖ ≤ _
  rw [iteratedFDeriv_sub ((scaledBump_smooth N).of_le
      (by exact_mod_cast (le_top : (n : ℕ∞) ≤ ⊤))) contDiff_const,
    Pi.sub_apply]
  exact (norm_sub_le _ _).trans (add_le_add hD hc)

/-- Multiplying by cutoffs with uniformly bounded derivatives converges in every
Schwartz seminorm when the region on which the cutoff equals one tends to infinity.
This is an analytic approximation lemma, independent of measures or distributions. -/
theorem cutoff_tendsto
    (b : ℕ → ℝ → ℝ)
    (hbs : ∀ N, ContDiff ℝ ∞ (b N))
    (hbc : ∀ N, HasCompactSupport (b N))
    (hb1 : ∀ (N : ℕ) (x : ℝ), ‖x‖ < (N : ℝ) + 1 → b N x = 1)
    (hbder : ∀ n, ∃ B : ℝ, 0 ≤ B ∧ ∀ N x,
      ‖iteratedFDeriv ℝ n (fun y => b N y - 1) x‖ ≤ B)
    (φ : 𝓢(ℝ, ℂ)) :
    Tendsto (fun N => SchwartzMap.smulLeftCLM ℂ (b N) φ)
      atTop (𝓝 φ) := by
  rw [(schwartz_withSeminorms ℝ ℝ ℂ).tendsto_nhds]
  rintro ⟨k,n⟩ ε hε
  let B : ℕ → ℝ := fun i => Classical.choose (hbder i)
  have hB (i : ℕ) := Classical.choose_spec (hbder i)
  let C : ℝ := ∑ i ∈ Finset.range (n + 1),
    (n.choose i : ℝ) * B i * (SchwartzMap.seminorm ℝ (k+1) (n-i)) φ
  have hC : 0 ≤ C := by
    apply Finset.sum_nonneg
    intro i hi
    exact mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (hB i).1) (apply_nonneg _ _)
  have hbound (N : ℕ) :
      (SchwartzMap.seminorm ℝ k n)
        (SchwartzMap.smulLeftCLM ℂ (b N) φ - φ) ≤
          C / ((N : ℝ) + 1) := by
    apply SchwartzMap.seminorm_le_bound ℝ k n _ (div_nonneg hC (by positivity))
    intro x
    have hgrowth : Function.HasTemperateGrowth (b N) :=
      ((hbc N).toSchwartzMap (hbs N)).hasTemperateGrowth
    have heq :
        (⇑(SchwartzMap.smulLeftCLM ℂ (b N) φ - φ) : ℝ → ℂ) =
          (fun y => (b N y - 1) • φ y) := by
      funext y
      simp only [sub_apply, SchwartzMap.smulLeftCLM_apply_apply hgrowth,
        sub_smul, one_smul]
    rw [heq]
    change ‖x‖ ^ k * ‖iteratedFDeriv ℝ n (fun y => (b N y - 1) • φ y) x‖ ≤ _
    by_cases hx : ‖x‖ < (N : ℝ) + 1
    · have hevent : (fun y => (b N y - 1) • φ y) =ᶠ[𝓝 x] 0 := by
        filter_upwards [IsOpen.mem_nhds (isOpen_lt continuous_norm continuous_const) hx] with y hy
        simp [hb1 N y hy]
      rw [(hevent.iteratedFDeriv ℝ n).self_of_nhds]
      simp only [iteratedFDeriv_zero, Pi.zero_apply, norm_zero, mul_zero]
      exact div_nonneg hC (by positivity)
    · have hxpos : 0 < ‖x‖ := lt_of_lt_of_le (by positivity : 0 < (N : ℝ) + 1) (le_of_not_gt hx)
      have hproduct := norm_iteratedFDeriv_smul_le
        (f := fun y => b N y - 1) (g := (φ : ℝ → ℂ))
        ((hbs N).sub contDiff_const) (φ.smooth ⊤) x (n := n)
          (by exact_mod_cast (le_top : (n : ℕ∞) ≤ ⊤))
      apply le_trans (mul_le_mul_of_nonneg_left hproduct (by positivity))
      rw [Finset.mul_sum, Finset.sum_div]
      apply Finset.sum_le_sum
      intro i hi
      calc
        ‖x‖ ^ k * ((n.choose i : ℝ) * ‖iteratedFDeriv ℝ i (fun y => b N y - 1) x‖ *
            ‖iteratedFDeriv ℝ (n-i) φ x‖) =
          ((n.choose i : ℝ) * ‖iteratedFDeriv ℝ i (fun y => b N y - 1) x‖) *
            (‖x‖ ^ (k+1) * ‖iteratedFDeriv ℝ (n-i) φ x‖) / ‖x‖ := by
              rw [pow_succ]; field_simp
        _ ≤ ((n.choose i : ℝ) * B i) *
            (SchwartzMap.seminorm ℝ (k+1) (n-i)) φ / ((N : ℝ)+1) := by
          apply div_le_div₀
            (mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (hB i).1) (apply_nonneg _ _))
            _ (by positivity) (le_of_not_gt hx)
          apply mul_le_mul
            (mul_le_mul_of_nonneg_left ((hB i).2 N x) (Nat.cast_nonneg _))
            (SchwartzMap.le_seminorm ℝ (k+1) (n-i) φ x)
          · positivity
          · exact mul_nonneg (Nat.cast_nonneg _) (hB i).1
  have hlim : Tendsto (fun N : ℕ => C / ((N : ℝ) + 1)) atTop (𝓝 0) := by
    exact tendsto_const_nhds.div_atTop (tendsto_atTop_add_const_right _ _ tendsto_natCast_atTop_atTop)
  filter_upwards [(tendsto_order.1 hlim).2 ε hε] with N hN
  exact lt_of_le_of_lt (hbound N) hN

/-- Explicit compact approximation preserving every pointwise zero of the input. -/
def compactApprox (φ : 𝓢(ℝ,ℂ)) (N : ℕ) : 𝓢(ℝ,ℂ) :=
  SchwartzMap.smulLeftCLM ℂ (scaledBump N) φ

theorem compactApprox_apply (φ : 𝓢(ℝ,ℂ)) (N : ℕ) (x : ℝ) :
    compactApprox φ N x=scaledBump N x • φ x := by
  exact SchwartzMap.smulLeftCLM_apply_apply
    ((scaledBump_compact N).toSchwartzMap (scaledBump_smooth N)).hasTemperateGrowth φ x

theorem compactApprox_hasCompactSupport (φ : 𝓢(ℝ,ℂ)) (N : ℕ) :
    HasCompactSupport (compactApprox φ N : ℝ → ℂ) := by
  have heq : (compactApprox φ N : ℝ → ℂ)=fun x=>scaledBump N x • φ x :=
    funext (compactApprox_apply φ N)
  rw [heq]
  exact (scaledBump_compact N).smul_right

theorem compactApprox_tendsto (φ : 𝓢(ℝ,ℂ)) :
    Tendsto (compactApprox φ) atTop (𝓝 φ) :=
  cutoff_tendsto scaledBump scaledBump_smooth scaledBump_compact
    scaledBump_eq_one scaledBump_derivative_bound φ

theorem compactApprox_zero (φ : 𝓢(ℝ,ℂ)) {x : ℝ} (hx : φ x=0) (N : ℕ) :
    compactApprox φ N x=0 := by
  simp only [compactApprox_apply,hx,smul_zero]

#print axioms cutoff_tendsto
#print axioms compactApprox_tendsto
#print axioms compactApprox_hasCompactSupport

end Zeta23.OPICAFollowup.TemperedLatticeBridge
