# CT1.3 physical sinc identity and normalization cost — 2026-10-24

SUPPORTING FORMALIZATION; zero original-primary-root increment. RH and Step4 remain OPEN. The exact formula already appears in the frozen project paper at lines1094–1102. This is a source-specific Lean adapter and a domain check, not a discovery or priority claim.

For the actual canonical Jordan family `nearGapCombFamily L = D_L + D_(-L) - 2cosh(L/2)D_0`, with `0<L<log2` and `r=expL`, native Lean proves:

\[
\nu_L(s)=\nu_L(\Delta)=2e^{-L/2}(1-e^{-L})
=\frac{2(r-1)}{r^{3/2}}.
\]

The actual negative Jordan sinc integral is zero; the positive Jordan sinc integral equals the displayed mass. The proof derives the triangle integral from the genuine dilated counting measures. When `exp(t)≥1/2`, all terms outside the finite set `{-1,0,1}` vanish. The exact original cosh origin identity cancels the origin terms. Canonical Jordan-addition/difference integral algebra is justified by actual compact-support integrability. Existing growth and Fourier self-duality then derive the sinc/triangle equality. No desired transform, positivity or pairing conclusion is assumed.

For the actual positive Jordan measure the following limits are proved:

\[
\frac{\int s\,d\nu_L^+}{L}\to2,
\qquad
\frac{\int s\,d\nu_L^+}{L^2}\to+\infty
\quad(L\downarrow0).
\]

The last expression is explicitly the positive weighted mass divided by `L²`. No separate new theorem identifying the Jordan parts of `localJordanScale (L²)⁻¹ ν_L` is claimed here. Its familiar positive-scalar interpretation is DERIVED, not an extra compiled statement in this bundle.

The literal independent consumer was written from the frozen formula before its first elaboration. Its five statements retain the original real power `r^(3/2)`, both actual Jordan masses, both limits and the physical domain boundary. It additionally proves that this actual family fails `HasUnitGap`: its positive atom at `exp(-L)∈(-1,1)` has mass `exp(-L/2)>0`. Thus the family is outside the exact-unit-gap domain used by the finite zero-jet span and its fixed-basis negative-mass budget. It is not a counterexample to that theorem.

The conservative Post-Green implication is a quantified obstruction to changing test topology. The normalized family has the existing order-two Schwartz limit, yet its rescaled positive sinc mass diverges. Sinc squared is not a Schwartz test, and the current Schwartz convergence theorem gives no continuity for this weighted pairing. Extending its limit to that test without a separate tail/domain theorem is invalid. The same example defeats a uniform extension of exact-gap fixed-basis restrictions to arbitrary near-gap families.

A further DERIVED consequence is `positive sinc mass = 2√a(1-a)` for the actual gap `a=exp(-L)`. Its ratio to the gap deficit tends2. The linear loss scale in the near-gap budget is therefore realized by this canonical family; a uniform quadratic replacement would fail. This algebraic restatement has not been added as a separate formal declaration here.

Every current positive source compiled under the pinned Lean4.33.0-rc2 compiler with only `propext`, `Classical.choice`, and `Quot.sound`. The independent factor-two and slope-zero mutation controls were rejected by the real compiler at the changed mathematical conclusions. Their error-recovery `sorryAx` output is rejected evidence and is never counted as validity. Failed draft logs/sources are preserved.

The proposed production payload is append-only: `NearGapCT13Append.lean.txt` is appended after the exact old `NearGapLimits.lean` bytes. It strips only the two standalone self-import lines and introduces no new project or Mathlib import. All helpers stay under `Zeta23.OPICAFollowup.CT13Support`; every original root/proof remains an exact byte prefix. The import-only production independent consumer is `ExpectedCT1SincBudgetProduction.lean`.

These checks use scratch objects and inherited project/dependency objects. They are warm isolated checks; no owner source/cache was written. The assembled production module/import-only consumer has not been compiled by this lane, so the owner must compile the actual installed bytes and replay the positive/negative consumer evidence at the final clean pin. This bundle grants no full-release approval, registry authority, independent human seal or RH authority.
