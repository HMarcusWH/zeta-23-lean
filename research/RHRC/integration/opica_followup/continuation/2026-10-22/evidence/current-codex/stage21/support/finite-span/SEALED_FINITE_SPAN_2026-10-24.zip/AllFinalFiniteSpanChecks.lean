import ConsumersSpanFullCandidate

noncomputable section
open Set MeasureTheory Complex
open Zeta23.OPICA Zeta23.OPICAFollowup Zeta23.OPICAFollowup.FiniteSpan

namespace IndependentFullFiniteSpan
theorem full_original_domain_and_independent_basis :
    (∀ data : List (ℂ × ℂ × ℕ),
      ∀ h : ∀ j ∈ data, riemannZeta j.2.1 = 0 ∧ 0 < j.2.1.re ∧ j.2.1.re < 1 ∧
        j.2.2 < zeroJetOrder j.2.1,
      (Zeta23.OPICAFollowup.zeroJetRealSpan data).negative integerLatticeᶜ = 0 →
        (Zeta23.OPICAFollowup.zeroJetRealSpan data).positive = 0 ∧
          (Zeta23.OPICAFollowup.zeroJetRealSpan data).negative = 0) ∧
    (∀ n : ℕ, ∀ basis : Fin n → List (ℂ × ℂ × ℕ),
      ∀ h : ∀ i, ∀ j ∈ basis i, riemannZeta j.2.1 = 0 ∧ 0 < j.2.1.re ∧ j.2.1.re < 1 ∧
        j.2.2 < zeroJetOrder j.2.1,
      LinearIndependent ℝ (fun i =>
        (Zeta23.OPICAFollowup.zeroJetRealSpan (basis i)).distributionOfLinearGrowth
          (zeroJetRealSpan_growth _ (h i))) →
      ∀ a : Fin n → ℝ,
      (Zeta23.OPICAFollowup.zeroJetRealSpan (realBasisCombinationData basis a)).negative
        integerLatticeᶜ = 0 → a = 0) :=
  Zeta23.OPICAFollowup.finite_zero_span_positive_only_zero

#print axioms IndependentFullFiniteSpan.full_original_domain_and_independent_basis
end IndependentFullFiniteSpan

noncomputable section
open Set MeasureTheory
open scoped Topology
open Zeta23 Zeta23.OPICA Zeta23.OPICAFollowup
open Zeta23.OPICAFollowup.FiniteSpan
namespace IndependentActualFixedBudget

/-- Independent inline consumer expands the coefficient construction to
literal actual normalized zero-jet data and the norm to sqrt(sum squares). -/
theorem expected_full_actual_euclidean_budget {n : ℕ}
    (basis : Fin n → List (ℂ × ℂ × ℕ))
    (valid : ∀ i, ∀ j ∈ basis i, riemannZeta j.2.1=0 ∧
      0<j.2.1.re ∧ j.2.1.re<1 ∧ j.2.2<zeroJetOrder j.2.1)
    (independent : LinearIndependent ℝ (fun i =>
      (actualZeroJetSum (basis i)).rePart.distributionOfLinearGrowth
        (zeroJetRealSpan_growth (basis i) (valid i)))) :
    ∃ c_basis : ℝ, 0<c_basis ∧ ∀ a : Fin n → ℝ,
      c_basis*Real.sqrt (∑ i,‖a i‖^2) ≤
        ∫ x in (Set.range (fun m : ℤ => (m : ℝ)))ᶜ,sincSquared x
          ∂(actualZeroJetSum ((List.ofFn (fun i =>
            (basis i).map (fun j => ((a i : ℂ)*j.1,j.2.1,j.2.2)))).flatten)).rePart.negative := by
  obtain ⟨c,hc,hbound⟩ := fixed_basis_negative_mass_budget basis valid independent
  refine ⟨c,hc,fun a => ?_⟩
  simpa only [EuclideanSpace.norm_eq,realBasisCombinationData,scaleJetData,Zeta23.OPICAFollowup.zeroJetRealSpan,
    Zeta23.OPICAFollowup.FiniteSpan.zeroJetRealSpan,integerLattice] using hbound (WithLp.toLp 2 a)

theorem no_positive_budget_without_independence :
    ¬ ∃ c : ℝ, 0<c ∧ ∀ a : EuclideanSpace ℝ (Fin 1),
      c*‖a‖ ≤ ∫ x in integerLatticeᶜ,sincSquared x
        ∂(Zeta23.OPICAFollowup.FiniteSpan.zeroJetRealSpan (realBasisCombinationData (fun _ : Fin 1 => []) (fun i => a i))).negative := by
  rintro ⟨c,hc,hbound⟩
  have h := hbound (EuclideanSpace.single (0 : Fin 1) (1 : ℝ))
  simp [realBasisCombinationData,scaleJetData,Zeta23.OPICAFollowup.FiniteSpan.zeroJetRealSpan,actualZeroJetSum,
    zeroComplex,zeroJordan] at h
  linarith

#print axioms IndependentActualFixedBudget.expected_full_actual_euclidean_budget
#print axioms IndependentActualFixedBudget.no_positive_budget_without_independence
end IndependentActualFixedBudget

noncomputable section
open Set MeasureTheory Complex
open scoped SchwartzMap FourierTransform
open Zeta23.OPICA Zeta23.OPICAFollowup Zeta23.OPICAFollowup.FiniteSpan

namespace IndependentSpanPhysicalConsumer
theorem expected_actual_zero_measure_span_consumer (data : List (ℂ × ℂ × ℕ))
    (h : ∀ j ∈ data, riemannZeta j.2.1 = 0 ∧ 0 < j.2.1.re ∧ j.2.1.re < 1 ∧
      j.2.2 < zeroJetOrder j.2.1) :
    (∀ j ∈ data, Continuous (zeroProfile j.2.1) ∧ Integrable (zeroProfile j.2.1) ∧
      MemLp (zeroProfile j.2.1) 2 ∧ 𝓕 (zeroProfile j.2.1) = zeroProfile j.2.1 ∧
      (j.2.2 = 0 → normalizedZeroMeasureJet j.2.1 j.2.2 = zeroMeasure j.2.1)) ∧
    (∃ hg : (Zeta23.OPICAFollowup.zeroJetRealSpan data).HasLinearGrowth,
      (Zeta23.OPICAFollowup.zeroJetRealSpan data).FourierSelfdual hg ∧
      (Zeta23.OPICAFollowup.zeroJetRealSpan data).HasUnitGap ∧
      ((Zeta23.OPICAFollowup.zeroJetRealSpan data).negative integerLatticeᶜ = 0 →
        (Zeta23.OPICAFollowup.zeroJetRealSpan data).positive = 0 ∧
          (Zeta23.OPICAFollowup.zeroJetRealSpan data).negative = 0)) ∧
    (∀ n : ℕ, ∀ basis : Fin n → List (ℂ × ℂ × ℕ),
      ∀ hb : ∀ i, ∀ j ∈ basis i, riemannZeta j.2.1 = 0 ∧ 0 < j.2.1.re ∧ j.2.1.re < 1 ∧
        j.2.2 < zeroJetOrder j.2.1,
      LinearIndependent ℝ (fun i =>
        (Zeta23.OPICAFollowup.zeroJetRealSpan (basis i)).distributionOfLinearGrowth
          (zeroJetRealSpan_growth _ (hb i))) →
      ∀ a : Fin n → ℝ,
      (Zeta23.OPICAFollowup.zeroJetRealSpan (realBasisCombinationData basis a)).negative
        integerLatticeᶜ = 0 → a = 0) :=
  Zeta23.OPICAFollowup.actual_zero_measure_span_consumer data h

#print axioms IndependentSpanPhysicalConsumer.expected_actual_zero_measure_span_consumer
end IndependentSpanPhysicalConsumer

noncomputable section
open Set MeasureTheory
open scoped ENNReal
namespace IndependentWeightedBudgetControls
open Zeta23.OPICA Zeta23.OPICAFollowup.FixedBudgetSupport

/-- An auxiliary measure control, not an actual zero measure. It satisfies
growth and gap while the sinc weight loses its lattice atom. Selfduality is
therefore essential to the faithful actual-span argument. -/
def diracTwo : LocallyFiniteSignedMeasure where
  positive := Measure.dirac 2
  negative := 0
  positive_locallyFinite := inferInstance
  negative_locallyFinite := inferInstance
  mutuallySingular := Measure.MutuallySingular.zero_right

theorem diracTwo_growth : diracTwo.HasLinearGrowth := by
  refine ⟨1,by norm_num,fun R hR => ?_⟩
  have h : (Measure.dirac (2 : ℝ)).real (Icc (-R) R) ≤
      (Measure.dirac (2 : ℝ)).real univ :=
    measureReal_mono (subset_univ _) (by finiteness)
  simp only [diracTwo,LocallyFiniteSignedMeasure.totalVariation,add_zero]
  simpa using h.trans (by simp; linarith)

theorem diracTwo_gap : diracTwo.HasUnitGap := by
  constructor <;> norm_num [diracTwo,Measure.dirac_apply']

theorem diracTwo_nonzero_positive : diracTwo.positive ≠ 0 := by
  intro h
  have := congrArg (fun μ : Measure ℝ => μ univ) h
  norm_num [diracTwo] at this

theorem diracTwo_weighted_zero : sincWeightedSigned diracTwo diracTwo_growth=0 := by
  ext E hE
  rw [sincWeightedSigned_apply _ _ _ hE]
  have hs : sincSquared (2 : ℝ)=0 := sincSquared_int_zero (by norm_num : (2 : ℤ) ≠ 0)
  simp only [diracTwo,integral_zero_measure,sub_zero,VectorMeasure.zero_apply]
  rw [←integral_indicator hE,integral_dirac]
  simp [Set.indicator_apply,hs]

theorem diracTwo_not_selfdual : ¬ diracTwo.FourierSelfdual diracTwo_growth := by
  intro h
  exact diracTwo_nonzero_positive
    ((sincWeightedSigned_zero_iff_zero diracTwo diracTwo_growth h diracTwo_gap).mp
      diracTwo_weighted_zero).1

#print axioms IndependentWeightedBudgetControls.diracTwo_weighted_zero
#print axioms IndependentWeightedBudgetControls.diracTwo_not_selfdual
end IndependentWeightedBudgetControls

open Set MeasureTheory Complex
open scoped SchwartzMap FourierTransform
open Zeta23.OPICA Zeta23.OPICAFollowup Zeta23.OPICAFollowup.FiniteSpan

namespace IndependentFiniteSpanFalsification

theorem repeated_actual_basis_is_not_independent (data : List JetDatum)
    (h : ∀ j ∈ data, ValidJet j) :
    ¬ LinearIndependent ℝ (fun _ : Fin 2 => (Zeta23.OPICAFollowup.FiniteSpan.zeroJetRealSpan data).distributionOfLinearGrowth
      (zeroJetRealSpan_growth data h)) := by
  intro hind
  have h01 : (0 : Fin 2) = 1 := hind.injective rfl
  norm_num at h01

theorem reflected_zero_is_the_same_jet (ρ : ℂ) (k : ℕ) :
    normalizedZeroMeasureJet (1-ρ) k = normalizedZeroMeasureJet ρ k :=
  normalizedZeroMeasureJet_one_sub ρ k

#print axioms IndependentFiniteSpanFalsification.repeated_actual_basis_is_not_independent
#print axioms IndependentFiniteSpanFalsification.reflected_zero_is_the_same_jet

end IndependentFiniteSpanFalsification
