import AffineConfluent

-- EXPECTED REJECTION: dropping the global (−1)^(M(M−1)/2) sign at M=2.
example : (Matrix.of ![![(2 : ℚ), 3], ![-7 / 2, -33 / 4]]).det = 6 := by
  norm_num [Matrix.det_fin_two]
