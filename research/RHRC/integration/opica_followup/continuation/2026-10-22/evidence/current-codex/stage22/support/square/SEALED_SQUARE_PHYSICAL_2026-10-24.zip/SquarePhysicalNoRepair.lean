import SquarePhysicalCandidate

noncomputable section
open Set MeasureTheory Filter Complex
open scoped Topology FourierTransform SchwartzMap ContDiff
namespace Zeta23.OPICAFollowup
open Zeta23.OPICA
namespace SquarePhysicalSupport

/-- The periodicity argument depends only on genuine order-zero lattice support:
values at lattice points determine a test functional. No growth degree is fixed. -/
theorem no_lattice_supported_functional_repair {h : ℝ → ℂ}
    (hcont : Continuous h) (hint : Integrable h) (hL2 : MemLp h 2)
    (hsd : 𝓕 h=h) (hev : ∀ x,h (-x)=h x)
    (hvan : Tendsto h (cocompact ℝ) (𝓝 0)) (A : ℂ)
    (hd0 : squareDualityDefect h 0 ≠ 0) (S : 𝓢(ℝ,ℂ) → ℂ)
    (hSzero : ∀ χ : 𝓢(ℝ,ℂ), (∀ n:ℤ,χ n=0) → S χ=0)
    (hScongr : ∀ χ ψ : 𝓢(ℝ,ℂ), (∀ n:ℤ,χ n=ψ n) → S χ=S ψ) :
    ¬ (∀ φ : 𝓢(ℝ,ℂ), squareGapMeasure h A (𝓕 φ)+S (𝓕 φ)=
      squareGapMeasure h A φ+S φ) := by
  intro hc
  set d := squareDualityDefect h with hddef
  have hdc : Continuous d := continuous_squareDualityDefect hcont hint hL2 hsd hev
  have hdt : Tendsto d (cocompact ℝ) (𝓝 0) := tendsto_squareDualityDefect hint hsd hev hvan
  -- d is bounded
  obtain ⟨M, hM⟩ : ∃ M, ∀ x, ‖d x‖ ≤ M := by
    obtain ⟨K, hK, hKc⟩ : ∃ K : Set ℝ, IsCompact K ∧ ∀ x ∉ K, ‖d x‖ < 1 := by
      have := hdt (Metric.ball_mem_nhds 0 one_pos)
      rw [Filter.mem_map, Filter.mem_cocompact] at this
      obtain ⟨K, hK, hKs⟩ := this
      exact ⟨K, hK, fun x hx => by simpa using hKs hx⟩
    obtain ⟨B, hB⟩ := hK.exists_bound_of_continuousOn hdc.continuousOn
    exact ⟨max B 1, fun x => by
      by_cases hx : x ∈ K
      · exact (hB x hx).trans (le_max_left _ _)
      · exact (hKc x hx).le.trans (le_max_right _ _)⟩
  have key : ∀ φ : 𝓢(ℝ, ℂ), S (𝓕 φ) = S φ - ∫ x, d x * φ x := by
    intro φ
    have h1 := hc φ
    have h2 := squareGapMeasure_fourier_defect hint hL2 hsd hev A φ
    linear_combination h1 - h2
  set U : Set ℝ := (Set.range (fun n : ℤ => (n : ℝ)))ᶜ with hU
  have hUo : IsOpen U := by
    rw [hU, isOpen_compl_iff]
    exact (Int.isClosedEmbedding_coe_real.isClosed_range)
  set D : ℝ → ℂ := fun x => d (x + 1) - d x with hD
  have hDc : Continuous D := (hdc.comp (continuous_id.add continuous_const)).sub hdc
  have hint0 : ∀ φ : ℝ → ℂ, Continuous φ → HasCompactSupport φ → Integrable (fun x => d x * φ x) := by
    intro φ hφ hcs
    exact (hφ.integrable_of_hasCompactSupport hcs).bdd_mul hdc.aestronglyMeasurable
      (Eventually.of_forall hM)
  have hDzero : ∀ g : ℝ → ℝ, ContDiff ℝ ∞ g → HasCompactSupport g → tsupport g ⊆ U →
      ∫ x, g x • D x = 0 := by
    intro g hg hgc hgU
    set φ : ℝ → ℂ := fun x => (g x : ℂ) with hφ
    have hφs : ContDiff ℝ ∞ φ := Complex.ofRealCLM.contDiff.comp hg
    have hφc : HasCompactSupport φ := hgc.comp_left Complex.ofReal_zero
    set ψ : ℝ → ℂ := fun x => φ (x - 1) with hψ
    have hψs : ContDiff ℝ ∞ ψ := hφs.comp (contDiff_id.sub contDiff_const)
    have hψc : HasCompactSupport ψ := hφc.comp_homeomorph (Homeomorph.subRight (1 : ℝ))
    have hφZ : ∀ n : ℤ, φ n = 0 := fun n => by
      have : (n : ℝ) ∉ tsupport g := fun hn => hgU hn ⟨n, rfl⟩
      simp [φ, image_eq_zero_of_notMem_tsupport this]
    have hψZ : ∀ n : ℤ, ψ n = 0 := fun n => by
      simp only [ψ, show (n : ℝ) - 1 = ((n - 1 : ℤ) : ℝ) by push_cast; ring, hφZ]
    set Φ : 𝓢(ℝ, ℂ) := hφc.toSchwartzMap hφs
    set Ψ : 𝓢(ℝ, ℂ) := hψc.toSchwartzMap hψs
    have hkΦ := key Φ
    have hkΨ := key Ψ
    have hl0 : ∀ χ : 𝓢(ℝ, ℂ), (∀ n : ℤ, χ n = 0) → S χ = 0 := hSzero
    rw [hl0 Φ hφZ] at hkΦ
    rw [hl0 Ψ hψZ] at hkΨ
    have hsame : S (𝓕 Ψ) = S (𝓕 Φ) := by
      apply hScongr
      intro n
      simp only [SchwartzMap.fourier_coe]
      exact fourier_shift_int φ n
    have hI : (∫ x, d x * ψ x) = ∫ x, d (x + 1) * φ x := by
      rw [← integral_add_right_eq_self (fun x => d x * ψ x) (1 : ℝ)]
      simp only [ψ, add_sub_cancel_right]
    have heq : (∫ x, d (x + 1) * φ x) = ∫ x, d x * φ x := by
      have e1 : S (𝓕 Ψ) = -∫ x, d x * Ψ x := by rw [hkΨ]; ring
      have e2 : S (𝓕 Φ) = -∫ x, d x * Φ x := by rw [hkΦ]; ring
      have : (∫ x, d x * Ψ x) = ∫ x, d x * Φ x := by rw [← neg_inj, ← e1, ← e2, hsame]
      rw [← hI]; exact this
    have hi1 : Integrable (fun x => d (x + 1) * φ x) :=
      (hφs.continuous.integrable_of_hasCompactSupport hφc).bdd_mul
        (hdc.comp (continuous_id.add continuous_const)).aestronglyMeasurable
        (Eventually.of_forall fun x => hM _)
    have hi2 := hint0 φ hφs.continuous hφc
    calc ∫ x, g x • D x = ∫ x, d (x + 1) * φ x - d x * φ x := by
          refine integral_congr_ae (Eventually.of_forall fun x => ?_)
          simp only [hD, φ, Complex.real_smul]; ring
      _ = 0 := by rw [integral_sub hi1 hi2, heq, sub_self]
  have hae := hUo.ae_eq_zero_of_integral_contDiff_smul_eq_zero (μ := volume)
    (hDc.locallyIntegrable.locallyIntegrableOn U) hDzero
  have hnull : (volume : Measure ℝ) (Set.range (fun n : ℤ => (n : ℝ))) = 0 :=
    (Set.countable_range _).measure_zero _
  have hae' : D =ᵐ[volume] 0 := by
    filter_upwards [hae, measure_eq_zero_iff_ae_notMem.mp hnull] with x hx hxU
    exact hx hxU
  have hDall : ∀ x, D x = 0 := fun x => congrFun ((hDc.ae_eq_iff_eq volume continuous_const).mp hae') x
  have hper : ∀ n : ℕ, d n = d 0 := by
    intro n
    induction n with
    | zero => simp
    | succ n ih =>
      have := hDall n
      simp only [hD, sub_eq_zero] at this
      push_cast; rw [this, ih]
  have hlim : Tendsto (fun n : ℕ => d n) atTop (𝓝 0) :=
    hdt.comp (tendsto_natCast_atTop_atTop.mono_right atTop_le_cocompact)
  have : d 0 = 0 := by
    have hconst : Tendsto (fun n : ℕ => d n) atTop (𝓝 (d 0)) :=
      tendsto_const_nhds.congr fun n => (hper n).symm
    exact tendsto_nhds_unique hconst hlim
  exact hd0 this

theorem measure_integral_congr_on_lattice (μ : Measure ℝ)
    (hμ : μ (Set.range (fun n:ℤ => (n:ℝ)))ᶜ=0) (f g : ℝ → ℂ)
    (heq : ∀ n:ℤ,f n=g n) : (∫ x,f x ∂μ)=(∫ x,g x ∂μ) := by
  apply integral_congr_ae
  filter_upwards [measure_eq_zero_iff_ae_notMem.mp hμ] with x hx
  have hm : x∈Set.range (fun n:ℤ => (n:ℝ)) := by simpa using hx
  obtain ⟨n,rfl⟩ := hm
  exact heq n

theorem complex_integral_congr_on_lattice (σ : LocallyFiniteComplexMeasure)
    (hσ : σ.variationControl (Set.range (fun n:ℤ => (n:ℝ)))ᶜ=0)
    (f g : ℝ → ℂ) (heq : ∀ n:ℤ,f n=g n) : σ.integral f=σ.integral g := by
  have hz : (σ.rePart.positive (Set.range (fun n:ℤ => (n:ℝ)))ᶜ+
      σ.rePart.negative (Set.range (fun n:ℤ => (n:ℝ)))ᶜ)+
      (σ.imPart.positive (Set.range (fun n:ℤ => (n:ℝ)))ᶜ+
      σ.imPart.negative (Set.range (fun n:ℤ => (n:ℝ)))ᶜ)=0 := by
    simpa only [LocallyFiniteComplexMeasure.variationControl,
      LocallyFiniteSignedMeasure.totalVariation,Measure.add_apply] using hσ
  obtain ⟨hr,hi⟩ := add_eq_zero.mp hz
  obtain ⟨hrp,hrn⟩ := add_eq_zero.mp hr
  obtain ⟨hip,hin⟩ := add_eq_zero.mp hi
  unfold LocallyFiniteComplexMeasure.integral
  rw [measure_integral_congr_on_lattice _ hrp f g heq,
    measure_integral_congr_on_lattice _ hrn f g heq,
    measure_integral_congr_on_lattice _ hip f g heq,
    measure_integral_congr_on_lattice _ hin f g heq]

theorem variationControl_le_two_totalVariation (σ : LocallyFiniteComplexMeasure) :
    σ.variationControl ≤ σ.totalVariation+σ.totalVariation := by
  have hm : Monotone localMeasureInterval := by
    intro i j hij
    have hijr : (i:ℝ)≤(j:ℝ) := by exact_mod_cast hij
    exact Icc_subset_Icc (neg_le_neg hijr) hijr
  apply Measure.le_iff.mpr
  intro E hE
  have heq : σ.variationControl E=⨆ n:ℕ,σ.variationControl.restrict (localMeasureInterval n) E := by
    rw [←Measure.restrict_iUnion_apply_eq_iSup hm.directed_le hE,
      localMeasureInterval_cover,Measure.restrict_univ]
  rw [heq]
  apply iSup_le
  intro n
  exact (σ.variationControl_restrict_le_two (localMeasureInterval n) isCompact_Icc E).trans
    ((add_le_add Measure.restrict_le_self Measure.restrict_le_self) E)

theorem component_temperate (σ : LocallyFiniteComplexMeasure)
    [σ.totalVariation.HasTemperateGrowth] (μ : Measure ℝ) (hμ : μ≤σ.variationControl) :
    μ.HasTemperateGrowth := by
  obtain ⟨n,hi⟩ := Measure.HasTemperateGrowth.exists_integrable (μ:=σ.totalVariation)
  exact ⟨n,(integrable_add_measure.mpr ⟨hi,hi⟩).mono_measure
    (hμ.trans (variationControl_le_two_totalVariation σ))⟩

theorem coordinate_domination (σ : LocallyFiniteComplexMeasure) :
    σ.rePart.positive≤σ.variationControl ∧ σ.rePart.negative≤σ.variationControl ∧
      σ.imPart.positive≤σ.variationControl ∧ σ.imPart.negative≤σ.variationControl := by
  have hr : σ.rePart.totalVariation≤σ.variationControl := by
    intro E
    exact le_add_of_nonneg_right zero_le
  have hi : σ.imPart.totalVariation≤σ.variationControl := by
    intro E
    exact le_add_of_nonneg_left zero_le
  have hp (μ:LocallyFiniteSignedMeasure) : μ.positive≤μ.totalVariation := by
    intro E
    exact le_add_of_nonneg_right zero_le
  have hn (μ:LocallyFiniteSignedMeasure) : μ.negative≤μ.totalVariation := by
    intro E
    exact le_add_of_nonneg_left zero_le
  exact ⟨(hp _).trans hr,(hn _).trans hr,(hp _).trans hi,(hn _).trans hi⟩

/-- A genuine tempered embedding from temperate growth of the true Euclidean
complex total variation. Coordinate-growth instances are derived internally;
no growth order or linear-growth restriction is imposed. -/
def correctionDistribution (σ : LocallyFiniteComplexMeasure)
    [σ.totalVariation.HasTemperateGrowth] : TemperedDistribution ℝ ℂ := by
  letI := component_temperate σ σ.rePart.positive (coordinate_domination σ).1
  letI := component_temperate σ σ.rePart.negative (coordinate_domination σ).2.1
  letI := component_temperate σ σ.imPart.positive (coordinate_domination σ).2.2.1
  letI := component_temperate σ σ.imPart.negative (coordinate_domination σ).2.2.2
  exact σ.rePart.toTemperedDistribution+I • σ.imPart.toTemperedDistribution

theorem correctionDistribution_apply (σ : LocallyFiniteComplexMeasure)
    [σ.totalVariation.HasTemperateGrowth]
    (φ : 𝓢(ℝ,ℂ)) : correctionDistribution σ φ=σ.integral φ := rfl

end SquarePhysicalSupport

/-- No genuine lattice-supported tempered order-zero complex measure can repair
the square's Fourier defect. No polynomial degree is fixed and no linear-growth
replacement of the correction domain is used. -/
theorem square_actual_no_tempered_measure_repair {h : ℝ → ℂ} {A : ℂ}
    (hev : ∀ x,h (-x)=h x) (hcont : Continuous h) (hint : Integrable h)
    (hL2 : MemLp h 2) (hsd : 𝓕 h=h) (hvan : Tendsto h (cocompact ℝ) (𝓝 0))
    (hpl : ∀ x,|x|≤1 → h x=A) (hne : h≠0)
    (σ : LocallyFiniteComplexMeasure)
    [σ.totalVariation.HasTemperateGrowth]
    (hσ : σ.totalVariation (Set.range (fun n:ℤ => (n:ℝ)))ᶜ=0) :
    𝓕 ((squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)+SquarePhysicalSupport.correctionDistribution σ) ≠
      (squareGapJordan h A hcont).distributionOfLinearGrowth
        (squareGapJordan_growth hcont hvan A)+SquarePhysicalSupport.correctionDistribution σ := by
  intro hself
  have hcontrol : σ.variationControl (Set.range (fun n:ℤ => (n:ℝ)))ᶜ=0 := by
    apply le_antisymm _ zero_le
    have hs := SquarePhysicalSupport.variationControl_le_two_totalVariation σ
      (Set.range (fun n:ℤ => (n:ℝ)))ᶜ
    simpa only [Measure.add_apply,hσ,add_zero] using hs
  have hd0 : squareDualityDefect h 0≠0 := by
    obtain ⟨heq,hpos,-⟩ := square_defect_origin_positive hev hcont hL2 hpl hne
    rw [heq]
    exact_mod_cast hpos.ne'
  apply SquarePhysicalSupport.no_lattice_supported_functional_repair
    hcont hint hL2 hsd hev hvan A hd0 (fun φ => σ.integral φ) ?_ ?_ ?_
  · intro χ hχ
    have heq := SquarePhysicalSupport.complex_integral_congr_on_lattice σ hcontrol χ 0 hχ
    simpa only [LocallyFiniteComplexMeasure.integral,Pi.zero_apply,integral_zero,
      sub_self,mul_zero,add_zero] using heq
  · intro χ ψ hχψ
    exact SquarePhysicalSupport.complex_integral_congr_on_lattice σ hcontrol χ ψ hχψ
  · intro φ
    have hp := congrArg (fun T:TemperedDistribution ℝ ℂ => T φ) hself
    simpa only [TemperedDistribution.fourier_apply,map_add,ContinuousLinearMap.add_apply,
      squareGapJordan_pairing hcont hvan A,
      SquarePhysicalSupport.correctionDistribution_apply] using hp

end Zeta23.OPICAFollowup
#print axioms Zeta23.OPICAFollowup.square_actual_no_tempered_measure_repair
