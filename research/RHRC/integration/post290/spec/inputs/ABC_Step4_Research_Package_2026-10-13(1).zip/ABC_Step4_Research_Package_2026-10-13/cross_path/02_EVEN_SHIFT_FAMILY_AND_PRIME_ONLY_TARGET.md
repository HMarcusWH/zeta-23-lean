# Joint campaign: the complete even-shift family and the prime-only closing target

13 October 2026. **NEW PAPER / DERIVED.** This note uses the original native causal logarithmic derivative and the contact-source/domain premises recorded in the Path C notes. It establishes exact reductions and a limitation of a specific averaging attempt. It does not prove the remaining upper estimate or Step 4.

## 1. Every positive even shift removes the infinite gamma tail

Keep the native transform

\[
J(p)=\frac{\zeta'}{\zeta}(p+1/2)
+\frac1{p-1/2}+\frac1{p+1/2}
+\frac12\psi(p/2+1/4)-\frac12\log\pi.
\]

For an integer \(m\ge1\), set \(k_{2m}=(1-e^{-2mt})W_+\). Iterating the exact digamma recurrence gives

\[
\begin{aligned}
J(p)-J(p+2m)={}&\frac{\zeta'}{\zeta}(p+1/2)
-\frac{\zeta'}{\zeta}(p+2m+1/2)+\frac1{p-1/2}\\
&-\frac1{p+2m-1/2}-\frac1{p+2m+1/2}
-\sum_{j=1}^{m-1}\frac1{p+1/2+2j}.
\end{aligned}
\tag{1}
\]

The empty sum at \(m=1\) is zero. Start in \(\Re p>1/2\), where the Dirichlet series converge absolutely, and use uniqueness of proper causal distributions. The exact inverse transform is

\[
\begin{aligned}
k_{2m}(dt)={}&\left[e^{t/2}-e^{-(2m-1/2)t}-e^{-(2m+1/2)t}
-\sum_{j=1}^{m-1}e^{-(1/2+2j)t}\right]dt\\
&-\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}(1-n^{-2m})\delta_{\log n}(dt).
\end{aligned}
\tag{2}
\]

There is no discarded diagonal term. The multiplier vanishes at zero, and the full gamma recurrence, including the finite end terms, is incorporated in (1)–(2). The \(m=1\) identity is the Path B/C result independently checked in this campaign.

## 2. The unchanged contact source gives one centered prime-power expression

Let \(f\) be an actual supported contact vector on \([-a,a]\), and put

\[
D_f(p)=\int_{-a}^a f(u)e^{-pu}\,du,
\qquad x=a+s,\quad s>0.
\]

For the shifted compact source \(f_+(t)=f(t-a)\), define
\(z_{2m,f}(s)=(k_{2m}*f_+)(2a+s)\).
The prime-power centered output is

\[
\mathcal C_f^{\Lambda}(s)=e^{x/2}D_f(1/2)
-\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}f(x-\log n).
\tag{3}
\]

Equation (2) gives, with all source factors retained,

\[
\begin{aligned}
z_{2m,f}-\mathcal C_f^{\Lambda}={}&
-e^{-(2m-1/2)x}D_f(-(2m-1/2))
-e^{-(2m+1/2)x}D_f(-(2m+1/2))\\
&-\sum_{j=1}^{m-1}e^{-(1/2+2j)x}D_f(-(1/2+2j))\\
&+\sum_{n\ge2}\Lambda(n)n^{-1/2-2m}f(x-\log n).
\end{aligned}
\tag{4}
\]

Every term on the right is in unweighted \(L^2(0,\infty)\). For the discrete term, its measure has finite total variation because

\[
\sum_{n\ge2}\Lambda(n)n^{-1/2-2m}
\le\sum_{n\ge2}(\log n)n^{-5/2}<\infty.
\]

Young's inequality on the whole line, followed by restriction to \(x>a\), applies to the original compact \(L^2\) source. It requires no pointwise evaluation bound or extra derivative of \(f\). Thus all positive even shifts have the same centered prime-power forcing modulo a proved \(L^2\) remainder.

## 3. Prime powers of exponent at least two are a controlled remainder at every positive damping

Define the prime-only expression

\[
\boxed{\mathcal C_f^{\mathrm{prime}}(s)=
e^{(a+s)/2}D_f(1/2)
-\sum_{p\text{ prime}}\frac{\log p}{\sqrt p}
f(a+s-\log p).}
\tag{5}
\]

The difference between (3) and (5) is the actual sum over \(p^k\), \(k\ge2\). For every \(\epsilon>0\), the damped measure has finite variation:

\[
\begin{aligned}
\sum_p\sum_{k\ge2}(\log p)p^{-k(1/2+\epsilon)}
&=\sum_p\frac{(\log p)p^{-1-2\epsilon}}{1-p^{-1/2-\epsilon}}\\
&\le\frac1{1-2^{-1/2-\epsilon}}
\sum_{n\ge2}\frac{\log n}{n^{1+2\epsilon}}<\infty.
\end{aligned}
\tag{6}
\]

To check the weight explicitly, for any measure \(\mu\),

\[
e^{-\epsilon x}(\mu*f)(x)
=[(e^{-\epsilon\cdot}\mu)*(e^{-\epsilon\cdot}f)](x).
\]

The source on the right remains compact and \(L^2\), even though its support includes negative times. Weighted Young's inequality and \(x=a+s\) prove

\[
\boxed{e^{-\epsilon s}
(\mathcal C_f^{\Lambda}-\mathcal C_f^{\mathrm{prime}})(s)
\in L^2(0,\infty)\quad\text{for every }\epsilon>0.}
\tag{7}
\]

No unweighted \(L^1\) bound is claimed for this prime-power measure. The square-prime part would involve \(\sum_p(\log p)/p\). The positive damping is essential to the stated absolute estimate.

This removes the complete prime-power field in a norm that is actually proved. It does not delete individual cross terms in a square. For any two fields \(u,v\) on a finite interval,
\(|\|u\|_2-\|v\|_2|\le\|u-v\|_2\); applying this to the exact decomposition preserves the full quadratic accounting.

## 4. Exact sufficient closing contract on the original source

For the canonical original source \(f_0\), Path C proves

\[
z_{2,f_0}-j_2=(I-\mathsf B_2)v,
\qquad\|\mathsf B_2\|\le e^{-2a}<1,
\qquad j_2\in L^2.
\tag{8}
\]

The bound and identity hold on every causal prefix, and after every positive damping. Combining (4), (7), and (8) gives

\[
\boxed{
e^{-\epsilon\cdot}v\in L^2
\quad\Longleftrightarrow\quad
e^{-\epsilon\cdot}\mathcal C_{f_0}^{\mathrm{prime}}\in L^2
\quad(\epsilon>0).
}
\tag{9}
\]

This is an actual same-source equivalence, with a proved stable causal inverse and explicit controlled remainders. It does not claim that the right side of (9) holds.

The weaker quiet-subsequence contract also transfers. If a field belongs to every positively damped \(L^2\) space, then its cumulative energy has upper logarithmic exponent zero: for each \(\eta>0\),

\[
\int_0^T|r(s)|^2ds\le e^{2\eta T}\|e^{-\eta\cdot}r\|_2^2,
\]

and then let \(\eta\downarrow0\). The finite-prefix norm comparison in (8), the triangle inequality, and this estimate show that \(v\) and (5) have the same quiet-subsequence property, with \(1+\) inside the logarithm. A bound

\[
\liminf_{T\to\infty}\frac1T
\log\left(1+\int_0^T|\mathcal C_{f_0}^{\mathrm{prime}}(s)|^2ds\right)=0
\tag{10}
\]

would therefore contradict the inherited positive exterior growth at a hypothetical contact. Formula (10) is a sharply stated **open closing lemma**; it is not a derived upper bound.

## 5. A finite-shift averaging attempt and its exact outcome

A natural combination is to use several gamma-clean shifts and choose coefficients to improve the forcing. For any fixed finite set of integers \(m_j\ge1\) and complex coefficients \(\alpha_j\), (4) proves

\[
\sum_j\alpha_j z_{2m_j,f}
=\left(\sum_j\alpha_j\right)\mathcal C_f^{\Lambda}+r,
\qquad r\in L^2.
\tag{11}
\]

If the coefficient sum is nonzero, this is the same unknown centered discrepancy up to scaling and a proved stable remainder. If the sum is zero, the combination is stable, but it removes every native right-zero residue simultaneously: \(J(p+2m_j)\) is holomorphic on \(\Re p>0\), so the residue of \(J(p)-J(p+2m_j)\) at a native right zero is the same multiplicity for every \(j\).

Thus this finite scalar averaging mechanism cannot both remove the uncontrolled forcing by the established identities and retain a pole-sensitive contradiction. This conclusion is limited to the stated finite, constant-coefficient combinations. It is not a claim about all vector filters, horizon-dependent transforms, or possible native arithmetic estimates.

## 6. What the joint attempt still lacks

Path A now removes a growing exact arithmetic sector while preserving the fixed Gevrey detector. Path C gives a strict source-derived contraction. Path B gives a fixed invertible shifted native sensor. Equations (5)–(10) isolate their remaining analytic task: a global signed cancellation estimate for the original-source prime discrepancy.

Local PSD supplies exact inequalities involving primes through the contact aperture. The native discrepancy in (5) uses primes through an increasing horizon. The separate contact-commutator note proves that a particular local sign argument does not bridge this gap, and Path B's native first-prime computation independently falsifies coefficientwise positivity of the filtered defect. No native norm absorption or global prime estimate is proved by the reductions here.

## Sources and validation

- Supplied C05 native causal transform and original contact-source/domain construction.
- New Path B note, §§1–5, and new Path C contraction note, §§1–5.
- NIST DLMF, 5.5.2, the digamma recurrence: https://dlmf.nist.gov/5.5.E2 (checked 13 October 2026).
- The recurrence iteration, weighted prime-power measure bound, exact norm transfers, and finite-shift averaging result are proved in this note. Finite symbolic controls check signs and finite endpoints; they do not replace the analytic proofs or establish the open estimate (10).
