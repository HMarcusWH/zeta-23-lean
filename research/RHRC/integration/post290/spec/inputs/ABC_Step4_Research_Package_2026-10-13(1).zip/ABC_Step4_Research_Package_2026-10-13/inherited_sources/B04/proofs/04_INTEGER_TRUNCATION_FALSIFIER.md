# B04.4 — Exact integer-lattice counterexample to automatic finite-source graph convergence

**Status:** PAPER elementary construction, independently checked symbolically. This is a deliberately *changed source/coefficient problem*, not a counterexample to RH and not the unchanged B detector. It falsifies one tempting generic functional-analysis inference used during B04.

## Claim being tested

False proposed principle:

> If a signed inverse has square-summable weighted coefficients, and its full causal output is rapidly decaying, then its natural finite integer-source truncations converge in global weighted L².

The following exact native integer-lattice construction refutes that inference while preserving the integer and Möbius convolution algebra.

## Construction

Choose a real, nonzero `phi ∈C_c^infty(R)` with support in a compact interval and

\[
K_\phi(1/2)=\int e^{-u/2}\phi(u)du\ne0.
\]

For example any nonnegative smooth bump works. Unlike the original B detector, `phi` is **not pole neutral**; this changed hypothesis is essential and is recorded explicitly.

Let

\[
N=\sum_{n\ge1}\frac{\delta_{\log n}}{\sqrt n},\qquad
M_\mu=\sum_{m\ge1}\frac{\mu(m)}{\sqrt m}\delta_{\log m}.
\]

The full lower-supported convolution identity `M_mu*N=delta_0` is exact. Thus

\[
\boxed{(M_\mu*N)*\phi=\phi,}
\]

which is smooth, compactly supported and decreasing faster than any exponential at positive infinity.

For every damping `epsilon>0`, the weighted Möbius coefficient vector belongs to `ell²`:

\[
\sum_{m\ge1}|\mu(m)|^2m^{-1-2\epsilon}
\le\sum_{m\ge1}m^{-1-2\epsilon}<\infty.
\]

Now truncate **only** the signed integer source:

\[
M_{\mu,X}=\sum_{m\le X}\frac{\mu(m)}{\sqrt m}\delta_{\log m},\qquad
F_X=M_{\mu,X}*N*\phi.
\]

## Global tail of every noncancelled truncation

For the ordinary integer lattice, a Riemann-sum argument gives

\[
(N*\phi)(t)=e^{t/2}K_\phi(1/2)+o(e^{t/2})
\qquad(t\to\infty).
\]

Indeed, on the compact support interval of `phi`, the summand is a smooth test sampled on integers near `e^t`; after `x=e^{t-u}` substitution the continuum integral is exactly `e^{t/2}K_phi(1/2)`, and the Riemann-sum error is lower order.

For each *fixed* finite cutoff X, insertion into the finite convolution gives

\[
\boxed{
F_X(t)=e^{t/2}K_\phi(1/2)
\sum_{m\le X}\frac{\mu(m)}m
+o_X(e^{t/2}).
}
\]

For every X with `S_X=Σ_{m≤X}mu(m)/m≠0` and every `0<epsilon<1/2`, the weighted output `e^{-epsilon t}F_X` is not in `L²(0,infty)`. Such X occur infinitely often: otherwise the step increments `S_n-S_{n-1}=mu(n)/n` would eventually all vanish, contradicted by infinitely many squarefree integers (in particular primes).

Yet the **full** signed output equals compact `phi` and belongs to every weighted space.

The finite truncations do agree with the full output on any fixed time interval after X grows sufficiently, by causal support and `M_mu*N=delta_0`. Therefore the apparent contradiction is entirely in the escaping global tail.

## Scope and consequence

This falsifier preserves exact native integer-divisor convolution and weighted square-summability of the Möbius coefficient vector. It **changes the source** from the original `U=(tN)*h` to `N*phi`, and drops the original pole-neutral double-zero `K(±1/2)=K'(±1/2)=0` requirement. It cannot be used to say that the original B output violates any norm law.

It does prove that *rapid full output + weighted ell² coefficients + local exact truncation* cannot by themselves yield a global graph-core theorem for integer-source synthesis. Any positive proof for the actual source needs more than this generic information: specifically the original double pole neutrality and a quantitative signed cancellation bound on the actual global error.

The same phenomenon explains why a formal finite-Euler or finite-integer approximation can be locally exact and still fail the closure test of B03.
