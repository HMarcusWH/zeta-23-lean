# Path B: a shifted native sensor and the exact gamma-free defect

**Date:** 2026-10-13. **Status:** new paper derivations, conditional only on the explicitly imported contact-source foundation below. These are not Lean declarations. The accompanying exact controls check finite algebra; they do not establish a global output estimate or Step 4.

## 1. What has been obtained

One fixed, explicitly native filter detects every right-half-plane zeta-zero residue, including every finite multiplicity. For any shift \(h>1/2\), this filter is a bounded causal isomorphism
\[
L^2_\epsilon(\mathbb R_+)\longleftrightarrow H^1_{\epsilon,0}(\mathbb R_+),
\qquad \epsilon\ge0,
\]
with an absolutely convergent Möbius-measure inverse and bounds uniform in the observation horizon. Derivatives fall on the filter, so this result works with the low regularity of the nullity-one contact source.

For the special shift \(h=2\), the complete gamma tail and its regularization cancel exactly. The remaining uncancelled forcing is an explicit centered Chebyshev measure, together with one decaying exponential. The same original contact source is retained, and all finite-history terms are retained.

The remaining arithmetic kernel does not acquire a favorable sign. Its convolution with the positive native sensor changes sign before the first prime and jumps negative at that prime. This gives a direct native control against a positivity shortcut. The new construction supplies neither the required subpower upper bound nor the required actual-input membership.

## 2. Imported source contract

All convolutions are causal, on zero extensions to \(\mathbb R\). Write
\[
\mathcal L u(p)=\int_0^\infty e^{-pt}u(t)\,dt
\]
when the integral converges, and use its distributional extension when appropriate. The actual half-distribution \(W_+\), including the inherited half-diagonal convention, has transform
\[
J(p)=\frac{\xi'}{\xi}\left(p+\frac12\right)
=\frac{\zeta'}{\zeta}\left(p+\frac12\right)+j(p),
\qquad \Re p>\frac12,
\]
\[
j(p)=\frac1{p-\frac12}+\frac1{p+\frac12}
 +\frac12\psi\left(\frac p2+\frac14\right)-\frac12\log\pi .
\tag{2.1}
\]
For \(t>0\),
\[
W_+(t)=e^{t/2}+e^{-t/2}
-\frac{e^{-t/2}}{1-e^{-2t}}-\Pi,\qquad
\Pi=\sum_{n\ge2}\Lambda(n)n^{-1/2}\delta_{\log n}.
\tag{2.2}
\]
Equation (2.2) by itself does not specify the distribution at zero; equation (2.1) and the source convention do.

The integer-completed native kernel is
\[
a(t)=3e^{-t}\sum_{n\le e^t}\sqrt n
 -2e^{-t/2}\lfloor e^t\rfloor,\qquad t\ge0,
\tag{2.3}
\]
\[
0<a(t)\le\frac32e^{-t/2},\qquad
A(p)=c_0(p)\zeta\left(p+\frac12\right),\qquad
c_0(p)=\frac{p-\frac12}{(p+\frac12)(p+1)}.
\tag{2.4}
\]
The apparent singularity at \(p=1/2\) cancels. The completed kernel
\[
q=a*W_+,\qquad Q=A J=A'+C A
\tag{2.5}
\]
is the actual causal convolution. The source proves
\[
e^{\tau t}a,\ e^{\tau t}q\in L^1\cap L^2,\qquad 0\le\tau<\frac12.
\tag{2.6}
\]
The gamma multiplier has logarithmic growth, controlled by the positive fractional Sobolev regularity available in that proof. [S1–S3]

For the contact interface, assume the full paper contact foundation: \(H_a=P_{[-a,a]}WP_{[-a,a]}\) is positive semidefinite with nonzero finite-dimensional kernel \(E\), and \(f=f_0\) is its canonical real parity source. Its Fourier transform \(G\) has only real simple zeros; hence
\[
D_f(p)=G(-ip)\ne0\quad(\Re p>0).
\tag{2.7}
\]
For every \(0<s<1/2\), the zero extension of \(f\) belongs to \(H^s\). No assumption \(f\in H^1\) is made.

Let \(c\) be the actual compact companion from the maximal-domain contact identity. Put \(L=2a\), \(f_+=T_a f\), and \(c_+=T_a c\). The actual original right exterior \(v\), with its causal zero extension, satisfies
\[
W_+*f_+=-c_++T_Lv,\qquad v\in L^2_{\mathrm{loc}}(\mathbb R_+).
\tag{2.8}
\]
The maximal-domain result excludes an additional endpoint distribution. On the initial convergence half-plane,
\[
V(p)=e^{ap}\left[D_f(p)J(p)+D_c(p)\right].
\tag{2.9}
\]
The source constructs the stable actual input
\[
a*v=y,\qquad
y(s)=\left[q*f_++a*c_+\right](s+L),
\qquad e^{\tau s}y\in L^2\quad(0\le\tau<1/2).
\tag{2.10}
\]
The complete bracket vanishes before \(L\); it is not legitimate to discard the separate initial pieces before proving their cancellation. These are imported paper hypotheses and results, not newly established formal authority. [S2, S3]

## 3. The fixed shifted sensor

For \(h>1/2\), define
\[
r_h(t)=e^{-ht}a(t),\qquad
R_h(p)=A(p+h)
=c_0(p+h)\zeta\left(p+h+\frac12\right).
\tag{3.1}
\]

### Proposition 3.1: zero-free sensor with a finite-measure derivative

For every \(h>1/2\):

1. \(R_h(p)\ne0\) throughout \(\Re p\ge0\).
2. \(r_h\in L^1\cap L^2\).
3. The distributional derivative of the causal zero extension, \(Dr_h\), is a finite signed measure, including its atom at zero.

**Proof.** The zeta argument has real part greater than one, so its absolutely convergent Euler product is nonzero. The rational factor has its zero and poles strictly to the left of the closed right half-plane. No zero-free theorem in the critical strip is used.

The bound in (2.4) gives
\[
\|e^{-\epsilon t}r_h\|_1
\le \frac{3}{2(h+\frac12+\epsilon)}.
\tag{3.2}
\]
On an open interval between successive \(\log n\),
\[
r_h'(t)=
-3(h+1)e^{-(h+1)t}\sum_{j\le n}\sqrt j
 +(2h+1)n e^{-(h+\frac12)t}.
\]
Since \(n\le e^t\) and \(\sum_{j\le n}\sqrt j\le n^{3/2}\),
\[
|r_h'(t)|\le(5h+4)e^{-(h-\frac12)t}.
\tag{3.3}
\]
At \(\log n\), including the initial jump at \(n=1\), the jump is
\[
r_h(\log n+)-r_h(\log n-)=n^{-(h+\frac12)}.
\tag{3.4}
\]
Consequently,
\[
\|e^{-\epsilon t}Dr_h\|_{\mathrm{TV}}
\le \zeta\left(h+\frac12+\epsilon\right)
 +\frac{5h+4}{h-\frac12+\epsilon}.
\tag{3.5}
\]
This proves the claim. The requirement \(h>1/2\) is sharp for this finite-variation construction: its atomic variation already diverges at \(h=1/2\). No optimality assertion is made about all possible inverses at that endpoint. \(\square\)

### Proposition 3.2: explicit causal graph isomorphism

Define
\[
\|u\|_\epsilon=\|e^{-\epsilon t}u(t)\|_{L^2(\mathbb R_+)},
\]
\[
H^1_{\epsilon,0}
=\{w:w(0)=0,\ \|w\|_\epsilon+\|w'\|_\epsilon<\infty\}.
\]
The derivative is the weak derivative on the half-line. The zero trace makes its causal distributional derivative free of an extra delta atom.

Set \(s=h+1/2>1\), and let
\[
M_s=\sum_{n\ge1}\mu(n)n^{-s}\delta_{\log n}.
\]
Then
\[
\|e^{-\epsilon t}M_s\|_{\mathrm{TV}}
=\sum_{n\ge1}|\mu(n)|n^{-(s+\epsilon)}
=\frac{\zeta(s+\epsilon)}{\zeta(2s+2\epsilon)}.
\tag{3.6}
\]
Convolution by \(r_h\) is a bounded bijection \(L^2_\epsilon\to H^1_{\epsilon,0}\), with inverse
\[
\boxed{
v=M_s*
\left[w'+(h+2)w
 +\frac32 e^{-(h-\frac12)t}\mathbf1_+*w\right].
}
\tag{3.7}
\]

**Proof.** If \(v\in L^2_\epsilon\), then \(w=r_h*v\) satisfies
\[
\|w\|_\epsilon\le a_{h,\epsilon}\|v\|_\epsilon,\qquad
\|w'\|_\epsilon\le b_{h,\epsilon}\|v\|_\epsilon,
\tag{3.8}
\]
where \(a_{h,\epsilon}\) is the right side of (3.2) and \(b_{h,\epsilon}\) is the right side of (3.5). Here \(w'=(Dr_h)*v\); the derivative is on the kernel. The causal \(H^1\) extension has zero trace.

The inverse is the exact rational identity
\[
\frac1{R_h(p)}
=\frac{p+h+2+\frac{3/2}{p+h-\frac12}}
       {\zeta(p+h+\frac12)}.
\tag{3.9}
\]
Indeed, division of \((p+h+\frac12)(p+h+1)\) by \(p+h-\frac12\) gives the displayed numerator. The absolutely convergent Euler product identifies the reciprocal zeta factor with \(M_s\). For \(w\in H^1_{\epsilon,0}\), every term in (3.7) belongs to \(L^2_\epsilon\), and
\[
\|v\|_\epsilon\le
Z(s+\epsilon)
\left[
\|w'\|_\epsilon+
\left(h+2+\frac{3}{2(h-\frac12+\epsilon)}\right)\|w\|_\epsilon
\right],
\tag{3.10}
\]
where \(Z(u)=\zeta(u)/\zeta(2u)\).
Laplace transforms on a right half-plane prove that (3.7) and convolution by \(r_h\) are mutual inverses. Equivalently, their causal distributional kernels compose to \(\delta_0\). \(\square\)

For example,
\[
h=1:\quad
v=M_{3/2}*
\left[w'+3w+\frac32e^{-t/2}\mathbf1_+*w\right],
\]
\[
h=2:\quad
v=M_{5/2}*
\left[w'+4w+\frac32e^{-3t/2}\mathbf1_+*w\right].
\tag{3.11}
\]
The raw reciprocal \(1/R_h\) has order \(p\). Thus the theorem is an \(H^1_0\)-to-\(L^2\) inverse theorem, not a claim of a bounded \(L^2\)-to-\(L^2\) inverse.

### Uniform finite-horizon version

For every \(v\in L^2_{\mathrm{loc}}\), \(w=r_h*v\) belongs to \(H^1_{\mathrm{loc}}\) with \(w(0)=0\), and (3.7) holds locally. For every \(T>0\), all bounds (3.8) and (3.10) hold with norms restricted to \([0,T]\), with exactly the same constants.

To justify this without inserting an endpoint atom at \(T\), first extend or truncate the input \(v\), apply the causal identity, and restrict to \([0,T]\). Alternatively apply Young's inequality directly to the explicit causal inverse on that interval. The quantity \(w'\) is the derivative of the actual output on the interval; it is not the distributional derivative of a discontinuously truncated \(w\). This distinction removes an otherwise spurious boundary term.

### Genuine convergence of the shifted Möbius truncations

For an integer cutoff \(X\ge1\), put \(M_{s,X}=\sum_{n\le X}\mu(n)n^{-s}\delta_{\log n}\). Then
\[
\|e^{-\epsilon t}(M_s-M_{s,X})\|_{\mathrm{TV}}
\le\frac{X^{1-s-\epsilon}}{s+\epsilon-1}.
\tag{3.12}
\]
Hence the explicit inverses with \(M_s\) replaced by \(M_{s,X}\) converge in operator norm from \(H^1_{\epsilon,0}\) to \(L^2_\epsilon\). This is a global convergence theorem on its stated domain. It does not establish that the unknown actual output belongs to that domain.

## 4. The sensor keeps every native residue

Suppose a native nontrivial zero \(\rho\) satisfies \(\Re\rho>1/2\), has multiplicity \(m\ge1\), and set \(\lambda=\rho-1/2\). The contact source identity (2.9) gives
\[
\operatorname*{Res}_{p=\lambda}V(p)
=m e^{a\lambda}D_f(\lambda)\ne0.
\tag{4.1}
\]
For the actual sensor output \(w_h=r_h*v\),
\[
\boxed{
\operatorname*{Res}_{p=\lambda}\mathcal Lw_h(p)
=m e^{a\lambda}R_h(\lambda)D_f(\lambda)\ne0.
}
\tag{4.2}
\]
One chosen \(h>1/2\) works simultaneously for all such zeros and all finite multiplicities. The shifted sensor does not need to be adapted to \(m\).

There is also an exact stable-input realization:
\[
a*w_h=r_h*y=:z_h.
\tag{4.3}
\]
At the zero of order \(m\) of \(A\), the complete lower input jet vanishes, and
\[
Z_h^{(m-1)}(\lambda)
=R_h(\lambda)c_0(\lambda)e^{a\lambda}
 D_f(\lambda)\zeta^{(m)}(\rho)\ne0.
\tag{4.4}
\]
There is no additional multiplicity or factorial factor in (4.4).

The B04 sharp Laguerre argument applies to (4.3) with the same source and the stable input \(z_h\). For \(0\le\epsilon<\Re\lambda\), \(\delta=\Re\lambda-\epsilon\), and
\[
e_T=e^{-\epsilon t}z_h-
\mathsf A_\epsilon(\mathbf1_{[0,T]}e^{-\epsilon t}w_h),
\]
causality gives support after \(T\), while the complete zero jet gives
\[
\|e_T\|_2\ge
\frac{|Z_h^{(m-1)}(\lambda)|(2\delta)^{m-1/2}}{(m-1)!}
e^{\delta T}.
\tag{4.5}
\]
Consequently the plain \(L^2_\epsilon\) prefix energy of \(w_h\), as well as its graph energy, has an exponential lower bound for every sufficiently large \(T\). A subpower upper bound along a cofinal sequence would already contradict (4.5). The \(H^1\) norm is needed for the strong inverse theorem, not for this residue contradiction. [S4]

## 5. Shift two cancels the complete gamma tail

The digamma recurrence gives
\[
\frac12\psi\left(\frac p2+\frac14\right)
-\frac12\psi\left(\frac p2+\frac54\right)
=-\frac1{p+\frac12}.
\]
Substitution in (2.1) yields
\[
J(p)-J(p+2)=
\frac{\zeta'}{\zeta}\left(p+\frac12\right)
-\frac{\zeta'}{\zeta}\left(p+\frac52\right)
+\frac1{p-\frac12}-\frac1{p+\frac32}-\frac1{p+\frac52}.
\tag{5.1}
\]
Therefore, as an identity of the actual causal distributions,
\[
\boxed{
\Delta_2:=(1-e^{-2t})W_+
=\left(e^{t/2}-e^{-3t/2}-e^{-5t/2}\right)\mathbf1_+\,dt
-\sum_{n\ge2}\Lambda(n)n^{-1/2}(1-n^{-2})\delta_{\log n}.
}
\tag{5.2}
\]
The vanishing factor removes the regularized singularity and the diagonal term at zero. This is a complete identity, not a finite gamma cutoff. At a finite cutoff \(N\), the telescoping gamma difference retains the endpoint
\[
-\frac1{p+\frac12}+\frac1{p+2N+\frac12}.
\tag{5.3}
\]
Only the full limit removes the second term.

Let \(\psi_{\rm Ch}(x)=\sum_{n\le x}\Lambda(n)\) and \(E(t)=\psi_{\rm Ch}(e^t)-e^t\). An equivalent Stieltjes form is
\[
\boxed{
\Delta_2=-(1-e^{-2t})e^{-t/2}\,dE(t)-e^{-5t/2}\,dt.
}
\tag{5.4}
\]
The Stieltjes differential is on \((0,\infty)\); either convention for the zero-extension endpoint of \(E\) gives the same result because its coefficient vanishes at zero.

Equation (5.4) isolates the exact centered arithmetic discrepancy. The measure \(\Delta_2\) is locally finite, but its total variation on the whole half-line is not finite. It has not become a bounded convolution operator on global \(L^2\).

## 6. The original-source identity and its complete history

Put \(q_2=e^{-2t}q\). Since exponential tilting commutes with causal convolution,
\[
q_2=r_2*(e^{-2t}W_+),\qquad
r_2*W_+=q_2+r_2*\Delta_2.
\tag{6.1}
\]
Convolving (2.8) by \(r_2\) gives the exact native identity
\[
\boxed{
T_L w_2=q_2*f_++r_2*c_++r_2*\Delta_2*f_+.
}
\tag{6.2}
\]
This uses the original \(f\) and the actual \(c\); a tilted source has not been declared a contact vector.

Write \(S_Lu(s)=u(s+L)\) for restriction followed by advance, and set
\[
\ell_2=S_L(q_2*f_++r_2*c_+),\qquad
u_2=S_L(r_2*\Delta_2*f_+).
\tag{6.3}
\]
Then \(w_2=\ell_2+u_2\). From (2.6), \(\ell_2\) is independently in every \(L^2_\epsilon\), and even has a positive exponential margin.

There is also enough source regularity for an independent \(H^1_{\epsilon}\) bound on \(\ell_2\). On a safe shifted vertical line, \(J(p+2)\) has at most logarithmic growth: the prime logarithmic derivative is absolutely convergent there and the gamma multiplier has the logarithmic estimate already used in [S2]. Thus
\[
W_{+,2}*f_+\in L^2_\epsilon,\qquad W_{+,2}=e^{-2t}W_+,
\]
using any fixed positive \(H^s\) regularity of the compact source. Since
\[
q_2*f_+=r_2*(W_{+,2}*f_+),
\]
Proposition 3.2 gives its \(H^1_\epsilon\) bound. The term \(r_2*c_+\) is handled by the same proposition with \(c_+\in L^2\). Advancing preserves \(H^1_\epsilon\) on the half-line, although the advanced known term need not have zero trace by itself. This argument does not require \(f'\in L^2\).

The unknown contribution is exactly \(u_2\). The three terms in (6.2) cancel before \(L\) only as a complete sum. For example,
\[
\mathcal L u_2(p)=e^{Lp}
\left[
R_2(p)(J(p)-J(p+2))e^{-ap}D_f(p)
-\int_0^Le^{-pt}(r_2*\Delta_2*f_+)(t)\,dt
\right].
\tag{6.4}
\]
The finite integral is an entire function. It must be retained in the identity even though it cannot remove a right-half-plane pole. In particular, \(u_2\) has the same nonzero residue (4.2) as \(w_2\).

## 7. The precise arithmetic commutator after integer completion

Let \(N_h=e^{-ht}\sum_{n\ge1}n^{-1/2}\delta_{\log n}\) and \(\Pi_h=e^{-ht}\Pi\). The exact native identity is \(N_h*\Pi_h=tN_h\). It does not simplify the difference \(\Pi-\Pi_h\) to that same expression.

At \(\log n\),
\[
\boxed{
[N_h*(\Pi-\Pi_h)]_{\log n}
=n^{-(h+\frac12)}
\sum_{d\mid n}\Lambda(d)(d^h-1).
}
\tag{7.1}
\]
Indeed, the term with \(n=md\) contributes
\[
m^{-(h+\frac12)}\Lambda(d)d^{-1/2}(1-d^{-h})
=n^{-(h+\frac12)}\Lambda(d)(d^h-1).
\]
For \(h=2\),
\[
C_2(n)=\sum_{d\mid n}\Lambda(d)(d^2-1)
=\sum_{p^k\Vert n}\log p\sum_{j=1}^k(p^{2j}-1).
\tag{7.2}
\]
These coefficients are positive, but their convolution with the remaining filters and the sign-changing contact source is not a positive quadratic form. They do not collapse to \(\log n\).

Moreover, \(\Pi_2\) is a finite positive measure because
\[
\sum_{n\ge2}\Lambda(n)n^{-5/2}
\le\sum_{n\ge2}(\log n)n^{-5/2}<\infty.
\tag{7.3}
\]
Consequently \(\Pi_2*f_+\) is independently in \(L^2\). The change from prime weight \(1\) to \(1-n^{-2}\) subtracts a stable term. It leaves all positive-half-plane residues and every positive-damping \(L^2\) membership target unchanged. Exact gamma cancellation is useful source cleanup; (7.3) does not prove a new cancellation exponent.

## 8. A direct native sign falsifier before the first prime

The kernel \(\kappa_2=r_2*\Delta_2\) is the new arithmetic kernel in (6.2). On \(0<t<\log2\), neither integer nor prime delayed terms have entered, so
\[
r_2(t)=3e^{-3t}-2e^{-5t/2},\qquad
\Delta_2(t)=e^{t/2}-e^{-3t/2}-e^{-5t/2}.
\]
Direct convolution gives
\[
\boxed{
\kappa_2(t)=\frac4{21}e^{t/2}
+\frac{50}{7}e^{-3t}
+\left(2t-\frac{22}{3}\right)e^{-5t/2}.
}
\tag{8.1}
\]
In particular \(\kappa_2(0+)=0\) and \(\kappa_2'(0+)=-1\), so the kernel is negative immediately after zero. But
\[
84\sqrt2\,\kappa_2(\log2-)
=75\sqrt2+42\log2-122>11>0.
\tag{8.2}
\]
Here \(\sqrt2>7/5\), and
\[
\log2=2\int_0^{1/3}\frac{du}{1-u^2}>\frac23.
\]
The prime-\(2\) atom creates a jump
\[
\kappa_2(\log2+)-\kappa_2(\log2-)
=-\frac{3\log2}{4\sqrt2},
\]
so
\[
84\sqrt2\,\kappa_2(\log2+)
=75\sqrt2-21\log2-122<-\frac{19}{2}<0,
\tag{8.3}
\]
using \(\sqrt2<3/2\).

Thus the exact native kernel is negative, then positive, then negative at the first prime. This refutes a coefficientwise positive-kernel argument for the new combination without appealing to a model perturbation or hypothetical zeros. Pointwise sign change alone does not settle operator accretivity; no stronger claim is made here.

## 9. A derivative-channel attempt and its actual cancellation

There is a useful exact algebraic hierarchy, but it has not produced the needed controlled output. Set
\[
\mathcal E(p)=\frac{\xi(p+\frac12)}{A(p)}
=\frac12(p+\tfrac12)^2(p+1)
 \pi^{-(p+\frac12)/2}\Gamma\left(\frac p2+\frac14\right),
\qquad C=\mathcal E'/\mathcal E .
\]
On the right half-plane \(\mathcal E\) is nonzero, and
\[
(\partial_p+C)^k A
=\mathcal E^{-1}\xi^{(k)}(p+\tfrac12).
\tag{9.1}
\]
For example,
\[
(\partial_p+C)^2A
=A''+2CA'+(C'+C^2)A
=A(J^2+J').
\tag{9.2}
\]
The finite controls verify the algebra through order six. They do not certify a simultaneous analytic domain for all iterated outputs.

Already at the first step, differentiating the known stable input yields
\[
(\partial_p+C)(A V)=Q V+A V'.
\tag{9.3}
\]
At a simple right zero, the residues of the two terms on the right cancel exactly: if \(A=a_0(p-\lambda)+\cdots\) and \(V=r/(p-\lambda)+\cdots\), then \(QV\) contributes \(a_0r/(p-\lambda)\), while \(AV'\) contributes \(-a_0r/(p-\lambda)\). Stability of the left side does not bound either summand. The fixed shifted sensor avoids this multiplicity-dependent algebra, but its output bound still requires the arithmetic estimate in the next section.

## 10. Exact remaining closing target

The graph inverse is now completely controlled. The unresolved quantity can be chosen as the explicit original-source forcing
\[
u_2(s)=
\left[
r_2*
\left(
-(1-e^{-2t})e^{-t/2}\,d[\psi_{\rm Ch}(e^t)-e^t]
-e^{-5t/2}\,dt
\right)*f_+
\right](s+L).
\tag{10.1}
\]
For instance, the following independent estimate would suffice:

For every \(\epsilon>0\) and \(\eta>0\), on the original contact source there are a constant \(C_{\epsilon,\eta}\) and a cofinal sequence \(T_j\to\infty\) such that
\[
\int_0^{T_j}e^{-2\epsilon s}|u_2(s)|^2\,ds
\le C_{\epsilon,\eta}e^{\eta T_j}.
\tag{10.2}
\]
Indeed the known term \(\ell_2\) is globally stable; an off-line zero with \(\Re\lambda>\epsilon\) would force the opposite lower bound \(c e^{2(\Re\lambda-\epsilon)T}\) on every sufficiently large horizon. Choosing \(\eta<2(\Re\lambda-\epsilon)\) gives a contradiction. Native symmetry handles the other half of the strip.

An independent \(L^2_\epsilon\) membership proof for (10.1) is already sufficient for the residue contradiction: it makes \(w_2=\ell_2+u_2\) an \(L^2_\epsilon\) function, whose Laplace transform cannot have the pole in (4.2). This conclusion does not invoke an \(L^2\)-to-\(L^2\) inverse.

To recover the original exterior by the graph inverse (3.7), one must instead establish \(H^1_\epsilon\) membership of \(u_2\). The independently controlled \(\ell_2\) then gives \(w_2\in H^1_\epsilon\), and the actual convolution has the required zero trace. Only with that graph-domain premise does (3.7) return \(v\in L^2_\epsilon\).

Ordinary PNT cancellation of the mean measure is not (10.2). It controls the full centered discrepancy only at the inherited square-root scale in the multiplicative variable; that scale allows a positive exponent below \(1/2\) in the time variable. The exact positive divisor coefficients (7.2), the stable tail (7.3), and the pre-prime formula (8.1) supply no further signed cofactor estimate. The lossless contact identity also retains its future boundary flux; no favorable sign has been proved for that flux.

Thus the attempted new route reaches a concrete uncancelled native discrepancy with a complete inverse and complete source history. It has not proved (10.2), and it has not closed Step 4.

## 11. Controls and scope

The companion files are:

- [exact_controls.py](exact_controls.py)
- [exact_controls.json](exact_controls.json)

The standard-library script passes nine exact finite algebra checks and five mutation falsifiers. It covers the shifted rational inverses; the full and finite-cutoff gamma identities; the native first-prime sign calculation; the Möbius and weighted-divisor coefficients through \(n=2000\); the covariant hierarchy through order six; the multiplicity factors; and the difference between prefix exactness and global exactness of a finite Möbius inverse. Its JSON explicitly excludes analytic-domain, global-output, and RH authority.

## Source map

- **[S1]** B04 [02_HARDY_RANGE_AND_ZERO_TEST.md](sandbox:/workspace/scratch/9907ae3f52f3/review/drive/PRO_B_Round4_Proofs_Evidence_and_A_C_Exports_2026-10-13/proofs/02_HARDY_RANGE_AND_ZERO_TEST.md), and [03_NATIVE_PRIME_CUTOFF_AND_BOUNDARY.md](sandbox:/workspace/scratch/9907ae3f52f3/review/drive/PRO_B_Round4_Proofs_Evidence_and_A_C_Exports_2026-10-13/proofs/03_NATIVE_PRIME_CUTOFF_AND_BOUNDARY.md): native integer completion, exact prefix residual, and the PNT exponent gap.
- **[S2]** C05 [01_COMPLETED_NATIVE_FORWARD_KERNEL_AND_ORIGINAL_EXTERIOR.md](sandbox:/workspace/scratch/9907ae3f52f3/review/drive/PRO_C_C05_Round4_Proofs_Review_and_Exports_2026-10-12/b_residue_range/01_COMPLETED_NATIVE_FORWARD_KERNEL_AND_ORIGINAL_EXTERIOR.md), and [04_STABLE_KERNELS_AND_ACTUAL_BOUNDARY_FLUX.md](sandbox:/workspace/scratch/9907ae3f52f3/review/drive/PRO_C_C05_Round4_Proofs_Review_and_Exports_2026-10-12/b_residue_range/04_STABLE_KERNELS_AND_ACTUAL_BOUNDARY_FLUX.md): the actual causal completed kernel, its fractional Sobolev and gamma estimates, and the complete future boundary flux.
- **[S3]** C05 [03_COMPLETE_NATIVE_CHAIN_AND_ONE_OPEN_COUPLING.md](sandbox:/workspace/scratch/9907ae3f52f3/review/drive/PRO_C_C05_Round4_Proofs_Review_and_Exports_2026-10-12/root/03_COMPLETE_NATIVE_CHAIN_AND_ONE_OPEN_COUPLING.md): the exact full-contact source, companion, advance, residue, and upper-rate statements.
- **[S4]** B04 [01_SHARP_DUAL_LEAKAGE.md](sandbox:/workspace/scratch/9907ae3f52f3/review/drive/PRO_B_Round4_Proofs_Evidence_and_A_C_Exports_2026-10-13/proofs/01_SHARP_DUAL_LEAKAGE.md): the multiplicity-complete Laguerre lower bound used in Section 4.
- **[S5]** B04 [06_STOPPING_POINT_AND_LEMMA.md](sandbox:/workspace/scratch/9907ae3f52f3/review/drive/PRO_B_Round4_Proofs_Evidence_and_A_C_Exports_2026-10-13/proofs/06_STOPPING_POINT_AND_LEMMA.md), and C05 [02_LOCAL_OBSERVATION_SYZYGY_CLASSIFICATION.md](sandbox:/workspace/scratch/9907ae3f52f3/review/drive/PRO_C_C05_Round4_Proofs_Review_and_Exports_2026-10-12/b_residue_range/02_LOCAL_OBSERVATION_SYZYGY_CLASSIFICATION.md): the earlier finite-channel limitation and exact missing upper estimate. The shifted construction above is a new native analytic attempt beyond that local channel class.
