# A03 arithmetic: exact stopping point, rejected inference, and exports

**Status: PAPER / DERIVED results; OPEN RH closure.** These notes contain
no new Lean declaration, no source edit to `zeta-23-lean`, and no changed
49-requirement or WP0–WP7 disposition. D2 remains Full K3.

## 1. What was actually attempted

The target was the full signed fluctuation of the original detector,
including the entire future-boundary norm. Two native mechanisms were
carried through before testing their closing step:

1. Center the finite prime prefix by the exact integer continuum before
   estimating its covariance. This cancels the full leading square and
   all mixed linear discrepancy terms exactly, through the actual
   boundary. It yields a squared effective-PNT error bound.
2. Use the exact native integer drive quantitatively, with its recovered
   non-dyadic Gevrey2 source, to remove every inverse index below
   `x/(B(log x)^2)`. The remaining sum has only `O((log x)^2)` cofactors,
   with actual Möbius signs, exact integer divisibility, and a precise
   inner cutoff retained.

Neither mechanism was assumed to be an independent norm theorem. Their
prospective closing steps were tested explicitly.

The subsequent native divisor audit in Note05 adds a precise structural
result: after this localization, every retained prime-power product
coefficient is zero, while opposite genuine composite signs occur in
every sufficiently late active window of the same detector. This locates
the remaining signal in signed composite correlations and rejects a
coefficientwise sign argument using the new short cofactor range.

## 2. Why the signed upper bound was not obtained

The first mechanism proves

\[
 \mathcal R_\epsilon(T)
 \le C_{\epsilon,h}
       (1+e^{(1-2\epsilon)T}T^{2B_0}e^{-2c_0\sqrt T}),
\]

from an actual established theta estimate with constants `B0,c0`. Its
exponential rate still exceeds the conditional dual-leakage rate of any
fixed native zero in the open strip. The exact source moments do not
improve that rate by themselves. Note02 constructs a specific positive,
prime-power-consistent tail, with an arbitrary exact native prefix, for
which the full completed signed fluctuation actually grows like

\[
 \frac{\eta^2c^4P_r(i/2)^4}{16(1-2\epsilon)}
 T^{-2}e^{(1-2\epsilon)T-2c\sqrt T}.
\]

That model has its own exact positive Euler/divisor law but loses the
literal native coefficients and original input. It decisively shows why
centering, the double source moment, generic divisor compatibility, and
a PNT-scale profile are insufficient.

The second mechanism proves, for a sufficiently large fixed `B`,

\[
 F(t)=\sum_{2\le m<B e^d t^2}\frac{\log m}{\sqrt m}
 \sum_{\substack{n>e^t/(Bt^2)\\nm\le e^{t+d}}}
 \frac{\mu(n)}{\sqrt n}h(t-\log m-\log n)+r_B(t),
 \qquad |r_B(t)|\le C_Be^{-c_Bt}.
 \tag{2.1}
\]

All prime powers are already included in (2.1), by the exact signed
divisor identity. The cofactor count is genuinely shorter, but the long
variable still contains native Möbius correlations on exponentially
large integer ranges. No independent bound for their complete signed
combination was proved. Treating the small number of cofactors as a
reason to remove the sharp inner threshold is false even in the finite
native coefficient checks.

The exact mode calculation is particularly restrictive. At a hypothetical
zero of multiplicity `m`, the principal part of the inverse times the
actual drive cancels higher-order terms but leaves precisely
`-m K(lambda) exp(lambda t)`. The log-squared cutoff retains that
coefficient up to a controlled decreasing error. Thus the new localization
does not manufacture source cancellation at a native off-line zero.

This is the specific failed closing step: the short-cofactor expression
has been derived, but rapid native lattice forcing does not eliminate a
coherent inverse mode. The missing input must bound the actual signed
long-Möbius correlation, rather than replace it by magnitudes or a generic
inverse norm.

## 3. The inherited magnitude countermodel survives the new localization

The proof of the discarded-small-divisor bound uses only
`|mu(n)|<=1`. In fact it holds uniformly for **any** coefficient sequence
`b(n)` with `|b(n)|<=1`, against this same actual native `U`.

Apply it to `b(n)=mu(n)^2`. B02's independently read actual-input control
gives

\[
 (M_{\mu^2}*U)(t)
 =\frac{P_r(i/2)^2}{\zeta(2)}e^{t/2}+O(1).
 \tag{3.1}
\]

Since the discarded part is still decreasing, the **same** exponentially
growing signal lies wholly in the corresponding short-cofactor sum in
(2.1), with `mu^2` replacing `mu`. It retains the exact input, each
coefficient magnitude, squarefree support, source regularity, and new
log-squared range. Its failure is exactly the native sign identity
`mu*1=delta1`.

The original asymptotic (3.1) is inherited, not counted as a new theorem.
The new result is its exact preservation under this campaign's proposed
arithmetic localization. It falsifies a closing estimate based only on
those retained features. The same uniform small-divisor estimate applies
to every finite Euler inverse's bounded coefficients; this does not
turn an integer-size truncation into a truncation by largest prime factor.
The two truncations have different tails.

## 4. Mandatory falsifier dispositions for these specific attempts

| Control | What this campaign's actual argument does with it |
|---|---|
| A02 native finite-Euler excess and divergent finite inverse norms | No uniform finite-Euler norm or positive majorant is used. The new cutoff is on integer size, and cannot be substituted for the old prime-factor cutoff. |
| B03 same-input positive-kernel perturbation | The source-specific forward range remains unsolved; positivity of the forward kernel is not used to bound (2.1). The altered kernel loses the exact native integer convolution identity. |
| Actual-input `mu^2` magnitude control | Survives the new log-squared localization exactly, as in Section3; hence coefficient magnitude estimates do not close the shortened sum. |
| Native negative work | No universal accretivity, small gain, or positive-real estimate is inferred. The new argument supplies no source-specific work sign either. |
| Q14 and signed K4/K5 residues | They supply no favorable sign on the complete arithmetic fluctuation or the long-divisor sum; no finite spectral sign was transported here. |
| Terminal K2 | This campaign's fixed detector is distinct from the dilating K2 source. No predecessor capacity or descent beyond the zero-dimensional predecessor is invoked. |
| C's locally identical prime tails and positive-theta quartet | Local contact geometry does not bound the exact distant signed sum. The slow-tail model can preserve any prescribed local prime prefix but changes the native global divisor/source law. The quartet keeps arithmetic and changes the smooth completion; it is not combined with the tail into a fictitious fully native model. |

The controls do not jointly retain every native feature. None is a
counterexample to RH, and none rules out a new law on the exact `mu`
and exact completion. Their purpose is to reject the particular proposed
upper-bound mechanisms before treating them as closure.

## 5. Cross-path exports

**To B.** The unchanged actual input has the quantitative estimate
`|U(t)|<=C exp(-kappa exp(t/2))`. It supports a much shorter exact
arithmetic realization of the possible dual leakage. The new small-divisor
remainder is independently in every desired weighted space, so the
source-specific range obstruction transfers to the remaining short-cofactor
sum without changing B's input or time origin. The multiplicity audit gives
the exact surviving coefficient `-mK(lambda)` with no extra factorial.

**To C.** These source estimates apply to B's original `c_j=r/[j(j+1)]`
detector only. They do not automatically apply to the dyadic compact
contact probe or upgrade a finite-regularity null generator to Gevrey2.
The slow-tail control can be placed beyond any chosen local support
threshold; its full fluctuation still grows after complete boundary
cancellation. The contact branch's separate proof specifies exactly
which local contact/defect data survive such a tail.

**To the integrator.** The strongest new arithmetic reduction in this
branch is (2.1), together with its independent remainder bound and hard
inverse-mode test. The upper bound remains OPEN. The exact continuum
polarization supplies a legitimate squared-PNT estimate and the slow-tail
model identifies why that estimate cannot be promoted by source geometry
alone. There is no new RH-equivalent proposition being relabeled as a
proved independent bound.

## 6. Validation and internal review record

`verify_arithmetic_round3.py` was run successfully with SymPy 1.14.0.
`ARITHMETIC_ROUND3_EXACT_CHECKS.json` records 57 exact symbolic/rational
checks. They cover the source's factor2 in `K''(1/2)`, the constructed
smooth profile's second/third derivatives, fourteen finite Gevrey
polynomial bounds, toy projection/mixed-term identities, the native
finite hyperbola cutoff identity, generalized Euler coefficient
compatibility and its loss of squarefree support, and multiplicities
one through seven in the inverse-mode residue. The new native checks
also cover 711 prime powers through 5000, a family of negative long-prime
coefficients, and neighboring products with exact opposite signs in
less than one detector width. No actual detector values or source-dependent
cutoff constants are inferred from those finite samples.

The vectors used in the projection tests are explicitly toy vectors;
they are not asserted to be the actual detector or a native contact.
The checks certify no infinite asymptotic, no universal Gevrey estimate,
no native norm bound, and no Lean theorem. The first attempted run found
SymPy absent; a temporary local dependency installation then enabled the
successful exact run. The dependency directory is outside these deliverable
proof files.

The arithmetic branch independently reviewed the contact branch's finite
central-jet plus unit-pole construction. The analytic-germ continuation,
normally convergent prime-power remainder, distant-prime correction
matrix and Chebyshev/Rolle nonsingularity were checked. A minor row-sign
clarification was sent back; no substantive gap was found in the stated
finite-germ scope. This is internal review, not independent external
validation or formal proof.

The arithmetic branch independently reviewed the dual-leakage branch's
optimal shifted-Laguerre jet estimate, exact forward norm, derivative
factorial, future-tail domain and complete signed-prime transfer. The
bound was found valid. A minor clarification distinguishes optimality
for one complete complex jet from the extra constraints of native
realness/conjugate jets; the author incorporated that scope.

No meaningful green Lean result occurred, so no formal Post-Green
promotion applies. The mathematical post-result pass above includes
normalization, upstream/source checks, downstream transports, creative
composition and the matched falsifiers. RH remains OPEN.
