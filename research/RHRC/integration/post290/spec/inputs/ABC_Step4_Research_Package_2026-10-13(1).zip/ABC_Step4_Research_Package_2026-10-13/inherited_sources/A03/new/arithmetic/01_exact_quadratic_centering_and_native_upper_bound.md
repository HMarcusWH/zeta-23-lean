# A03 arithmetic: exact quadratic centering of the full horizon budget

**Status: PAPER / DERIVED.** No Lean formalization or repository mutation.
This note uses A02's unchanged fixed source and genuine prime coefficients.
It proves a finite-horizon cancellation stronger than cancellation of the
leading asymptotic constants, then carries a classical unconditional prime
number theorem error through the complete signed fluctuation. The resulting
upper bound remains exponentially too weak to close RH.

## 1. The attempted closing theorem, before the calculation

Let `r=1/4096`, `d=2r`, `h=k_r*k_r`, and

\[
 K(p)=\int h(u)e^{-pu}du=(p^2-1/4)^2P_r(ip)^2.
\]

The source is real, even, smooth, supported in `[-d,d]`, and unchanged from
A02/B03. In particular `K(1/2)=K'(1/2)=0`. Let

\[
 F_1(t)=\sum_p\frac{\log p}{\sqrt p}h(t-\log p),
 \qquad F=F_1+F_{\ge2}=M_\mu*U.
\]

A02 proves independently that `e^{-epsilon t}F_{>=2}` is square integrable
for every positive epsilon. For `0<epsilon<1/2`, set `beta=1-2epsilon` and
`X=exp(T+d)`. The exact A02 signed fluctuation is

\[
 \mathcal R_\epsilon(T)
 =[P_{+,\epsilon}(X)-C_{+,\epsilon}X^\beta]
 -[P_{-,\epsilon}(X)-C_{-,\epsilon}X^\beta]
 -[\mathcal B_\epsilon(T)-C_{\partial,\epsilon}X^\beta].
 \tag{1.1}
\]

The attempted closing claim is a uniform upper bound on (1.1), for this
same actual source and every positive damping. B03 and the proposed dual
composition make this RH-strength; that implication is not a premise
proving the estimate. This attempt tests whether subtracting the exact
integer/prime continuum *before* estimating the signed Gram provides a
new quantitative saving beyond A02's leading PNT cancellation.

## 2. The continuum prefix is exactly an escaping boundary pulse

Let

\[
 G_X(t)=e^{-\epsilon t}\sum_{p\le X}\frac{\log p}{\sqrt p}
                 h(t-\log p),
\]

and subtract the continuum over **all** `0<x<=X`, not just `1<=x<=X`:

\[
 C_X(t)=e^{-\epsilon t}\int_0^Xx^{-1/2}h(t-\log x)dx.
 \tag{2.1}
\]

Each integral is ordinary and finite at every time, since the source is
compact. Write

\[
 J(u)=\int_u^d e^{-s/2}h(s)ds\quad(-d\le u\le d),
\]

and extend `J` by zero outside `[-d,d]`. The extension at the left endpoint
is valid because `K(1/2)=0`. Direct substitution gives, for every real `t`,

\[
 \boxed{C_X(t)=e^{\beta t/2}J(t-\log X).}\tag{2.2}
\]

In particular `C_X` is supported in `[T,T+2d]`, and

\[
 \boxed{\|C_X\|_2^2=C_{\partial,\epsilon}X^\beta,
 \quad C_{\partial,\epsilon}
 =\int_{-d}^d e^{\beta u}J(u)^2du.}\tag{2.3}
\]

Equation (2.3) is exact, not a PNT asymptotic. Integrating from `1` instead
of `0` introduces a separate compact initial pulse. Omitting that pulse
while claiming the same exact identity would be an endpoint error.

## 3. The entire linear discrepancy cancels with the future boundary

Put `Q_X=G_X-C_X`, and let `P_T` be restriction to `[0,T]`, extended by
zero. Both `G_X` and `Q_X` have bounded support in the nonnegative half-line
when `T>=0`. Since `P_TC_X=0`,

\[
 \boxed{
 \|G_X\|_2^2-\|1_{(T,\infty)}G_X\|_2^2
 =\|Q_X\|_2^2-\|1_{(T,\infty)}Q_X\|_2^2.
 }\tag{3.1}
\]

To see exactly what cancels, the expansion of the first full norm is

\[
 \|Q_X\|^2+2\Re\langle Q_X,C_X\rangle+\|C_X\|^2.
\]

The future-boundary norm contains precisely the same last two terms,
because `C_X` is supported in that future interval. Thus both the complete
continuum square and the complete **mixed linear** prime-discrepancy term
cancel identically. No bound or relative error for either mixed term is
needed. Dropping the future boundary destroys this cancellation.

The remaining quantity is exactly quadratic in the centered measure
`dtheta(x)-dx`. In particular, with the bounded A02 diagonal

\[
 D_\epsilon(X)=\|e^{-\epsilon\cdot}h\|_2^2
           \sum_{p\le X}(\log p)^2p^{-1-2\epsilon},
\]

the A02 relation `C_+-C_-=C_partial` gives

\[
 \boxed{\mathcal R_\epsilon(T)+D_\epsilon(X)
 =\|Q_X\|_2^2-\|1_{(T,\infty)}Q_X\|_2^2
 =\int_0^T e^{-2\epsilon t}|F_1(t)|^2dt.}\tag{3.2}
\]

The final equality is inherited. The new useful refinement is the exact
finite-prefix centered realization preceding it: there is no surviving
first-order PNT error in the full signed budget after its true future
boundary is retained.

### A late slab retains both exterior boundaries

For `S<T`, take `Y=exp(S-d)` and subtract the continuum on `Y<x<=X`.
Its synthesis is `C_X-C_Y`, supported in
`[S-2d,S] union [T,T+2d]`. On the slab `[S,T]` it vanishes exactly.
The corresponding finite prime interval contains precisely the primes
that can affect the slab. Expansion of its squared norm, subtracting
**both** exterior pieces, cancels the continuum and mixed terms exactly
as in (3.1). This version does not silently replace a finite horizon by a
full-line norm and does not require compactness as the horizon increases.

## 4. Exact integration by parts; no differentiation of a PNT error

Let `Delta(x)=theta(x)-x`, with `theta(x)=0` for `0<x<2`. For every time,
Stieltjes integration on the compact active interval gives

\[
 \boxed{F_1(t)=e^{-t/2}\int_{-d}^d
 \Delta(e^{t-u})e^{u/2}[h'(u)+h(u)/2]du.}\tag{4.1}
\]

The full continuum integral vanishes by `K(1/2)=0`; the source and all
its derivatives vanish at the shell endpoints, so there is no omitted
Stieltjes boundary term. The derivative falls on the known smooth
weight, **not** on `Delta` or on an asymptotic upper envelope for it.

For the normalized cumulative error

\[
 r(t)=e^{-t}\Delta(e^t),\qquad
 \nu_h(u)=e^{-u/2}[h'(u)+h(u)/2],
\]

this becomes

\[
 F_1(t)=e^{t/2}(\nu_h*r)(t),\qquad
 \int e^{-zu}\nu_h(u)du=(z+1)K(z+1/2).
 \tag{4.2}
\]

Thus the zeroth and first moments of `nu_h` vanish. This does **not**
authorize Taylor-expanding the actual step-like native `r`, nor does an
upper bound on `r` bound its derivatives. Note02 below tests the genuine
effect of these moments on a separately constructed smooth error profile.

## 5. An unconditional upper bound on the complete native signed fluctuation

Suppose an established PNT estimate has the form

\[
 |\theta(x)-x|\le C_0x(\log x)^B
                  e^{-c_0\sqrt{\log x}}\quad(x\ge x_0),
 \tag{5.1}
\]

where `C0,c0>0` and `B>=0` are fixed. This premise is an unconditional
theorem: for example Johnston--Yang, *Some explicit estimates for the
error term in the prime number theorem*, arXiv:2204.01980v2,
Corollary1.2/Table1 gives such values (including `B=1.515`, `c0=0.8274`).
The present argument does not claim those values are the best available.

For bounded `|u|<=d`,

\[
 (t-u)^B e^{-c_0\sqrt{t-u}}
 =O(t^B e^{-c_0\sqrt t})
\]

uniformly for large `t`. Equation (4.1) proves

\[
 \boxed{|F_1(t)|\le C_h e^{t/2}t^B e^{-c_0\sqrt t}.}\tag{5.2}
\]

Since the complete quantity (3.2) is a square, integration gives, for
every fixed `0<epsilon<1/2`,

\[
 \boxed{-D_\epsilon^*\le\mathcal R_\epsilon(T)
 \le C_{\epsilon,h}\bigl(1+e^{(1-2\epsilon)T}
                 T^{2B}e^{-2c_0\sqrt T}\bigr).}\tag{5.3}
\]

Here `D_epsilon^*=lim_X D_epsilon(X)<infinity`. The elementary endpoint
integration bound follows because the logarithmic derivative of
`e^{beta t}t^{2B}e^{-2c0 sqrt(t)}` tends to the positive number `beta`.
For `epsilon>=1/2` the same integrand is integrable at infinity, so the
corresponding complete norm is already unconditionally finite.

This squared-error estimate improves the inherited unspecified
`o(exp(beta T))`, but does not provide a subexponential upper bound when
`0<epsilon<1/2`. If a fixed hypothetical zero has real part `b<1`, the
dual lower exponent is `2(b-1/2-epsilon)`, strictly smaller than
`beta=1-2epsilon` by `2(1-b)>0`. The factor `exp(-2c0 sqrt(T))` cannot
bridge that positive linear exponent gap.

## 6. Precise stopping point of this closing attempt

The exact normalization and future-boundary polarization have been carried
out, and yield a genuinely second-order prime-counting-error bound. They
do not yield cancellation *inside* the remaining squared centered field.
The native arithmetic step still needed concerns its signed, source-specific
mean square at the exponentially finer scale. No absolute gcd estimate,
positive finite-Euler majorant, generic Schur capacity, or unweighted
critical-line norm is substituted for it.

The next note proves that source moments, a finite exact native prefix,
positive prime-power-consistent coefficients, and PNT-scale information
still permit an exponentially growing **complete** signed fluctuation.
That is a hard falsification of closing (5.3) by those inputs alone; it
does not falsify a theorem requiring the unmodified `mu` and `Lambda`.

## Source and novelty record

Inherited: A02's real fixed source, power-channel bound, complete Gram
identity, boundary constants, and centered-distribution adapter; B03's
native causal input and range obstruction; ordinary effective PNT.
New in this note, within the available campaign record: the exact
finite-prefix continuum polarization with both mixed terms canceled by
the retained boundary, its late-slab version, and the explicit squared
effective-PNT remainder estimate. No claim of historical novelty in
analytic number theory is made. RH remains OPEN.

Primary external source read: https://arxiv.org/html/2204.01980v2,
Theorem1.1, Corollary1.2, Table1 (retrieved this campaign).
