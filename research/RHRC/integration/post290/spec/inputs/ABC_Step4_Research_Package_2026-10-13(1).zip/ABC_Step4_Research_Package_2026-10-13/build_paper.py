#!/usr/bin/env python3
"""Assemble the paper from reviewed source notes.

Requires Pandoc, XeLaTeX, and standard TeX packages: amsmath, adjustbox,
fancyhdr, xurl, fvextra, longtable, booktabs, geometry, fontspec.
The Python code uses the standard library. No network calls.
"""
from pathlib import Path
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
BUILD.mkdir(exist_ok=True)
FILES = [
    "PAPER_OVERVIEW.md",
    "path_c/02_SOURCE_TILT_CONTRACTION_AND_GAMMA_FREE_FORCING.md",
    "path_b/01_SHIFTED_NATIVE_SENSOR_AND_GAMMA_FREE_DEFECT.md",
    "path_c/01_FULL_KERNEL_DEFECT_AND_MINIMAX_EXPONENT.md",
    "path_a/01_LOG_SQUARED_GCD_WEDGE.md",
    "path_a/02_ROUGH_CORE_AND_SQUAREFREE_SIGN_BUDGETS.md",
    "path_a/03_SMOOTH_SECTOR_BOUND.md",
    "path_a/04_PRIME_POWER_PRESERVING_ADAPTIVE_SIEVE.md",
    "path_a/05_JOINT_SOURCE_BRIDGE_AND_CLOSING_ATTEMPT.md",
    "cross_path/01_gamma_free_contact_commutator.md",
    "cross_path/02_EVEN_SHIFT_FAMILY_AND_PRIME_ONLY_TARGET.md",
    "path_b/02_CROSS_REVIEW_AND_EXACT_CONTRACTION_ITERATION.md",
    "path_c/03_CROSS_PATH_INTERFACE_REVIEW.md",
    "ROOT_REVIEW.md",
]
TITLE_OVERRIDES = {
    FILES[1]: "Path C: source contraction and exact forcing",
    FILES[2]: "Path B: shifted native sensor and inverse",
    FILES[3]: "Path C: full-kernel defect and minimax growth",
    FILES[4]: "Path A: the logarithm-squared covariance region",
    FILES[5]: "Path A: exact cancellation and rough-core signs",
    FILES[6]: "Path A: the controlled small-rough-core sector",
    FILES[7]: "Path A: the adaptive arithmetic mask",
    FILES[8]: "The exact A+B+C source bridge",
    FILES[9]: "Gamma-free supported contact inequalities",
    FILES[10]: "Even shifts and the prime-only target",
    FILES[11]: "Review: causal contraction iteration",
    FILES[12]: "Review: source interfaces and absorption",
    FILES[13]: "Final mathematical review",
}

def prepare_note(name):
    s = (ROOT / name).read_text()
    bad = [ord(c) for c in s if ord(c) < 32 and c not in "\n\t\r"]
    if bad:
        raise ValueError(f"Nonprinting controls in {name}: {bad}")
    if name in TITLE_OVERRIDES:
        s = re.sub(r"^# .*$", "# " + TITLE_OVERRIDES[name], s, count=1,
                   flags=re.M)
    # The PDF is a portable reading copy. Exact original link text and paths
    # remain in the underlying notes and the selected-source manifest.
    def local_link(m):
        label = m.group(1)
        target = m.group(2)
        if target.startswith(("sandbox:", "../", "./")) or target.endswith(".md"):
            return label
        return m.group(0)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", local_link, s)
    # Long literal paths use TeX's breakable path command in the reading copy.
    tick = chr(96)
    s = re.sub(tick + r"([^" + tick + r"\n]+)" + tick,
               lambda m: (r"\path{" + m.group(1) + "}"
                          if len(m.group(1)) >= 35 or
                          m.group(1).endswith((".md", ".py", ".json"))
                          else m.group(0)), s)
    s = re.sub(r"(?<![A-Za-z0-9_./{-])([A-Za-z0-9_./-]+\.(?:md|py|json))"
               r"(?![A-Za-z0-9_./-])",
               lambda m: r"\path{" + m.group(1) + "}", s)
    s = s.replace("\u2014", " - ").replace("\u2013", "-").replace("\u2011", "-")
    return s

metadata = r"""---
title: "Paths A, B and C: Step 4"
subtitle: "New paper results and the exact remaining closing lemma"
author: "Joint paper research campaign"
date: "13 October 2026"
documentclass: report
fontsize: 11pt
geometry:
  - a4paper
  - margin=24mm
  - headheight=14pt
colorlinks: true
linkcolor: MidnightBlue
urlcolor: MidnightBlue
toc: true
toc-depth: 1
numbersections: false
linestretch: 1.06
---

"""
header = r"""
\usepackage{adjustbox}
\usepackage{xurl}
\usepackage{fancyhdr}
\usepackage{fvextra}
\RecustomVerbatimEnvironment{verbatim}{Verbatim}{breaklines=true,fontsize=\small}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small Paths A, B and C -- Step 4}
\fancyhead[R]{\small Paper research / OPEN}
\fancyfoot[C]{\thepage}
\renewcommand{\headrulewidth}{0.3pt}
\setlength{\emergencystretch}{3em}
\Urlmuskip=0mu plus 2mu
\setcounter{tocdepth}{0}
\setlength{\parskip}{0.42em}
\widowpenalty=10000
\clubpenalty=10000
\displaywidowpenalty=10000
\raggedbottom
"""
(BUILD / "paper_header.tex").write_text(header)
assembled = metadata + "\n\n".join(prepare_note(f) for f in FILES)
(BUILD / "assembled_paper.md").write_text(assembled)
tex_path = BUILD / "ABC_Step4_Paper_2026-10-13.tex"
cmd = [
    "pandoc", str(BUILD / "assembled_paper.md"),
    "--from=markdown+tex_math_single_backslash+raw_tex",
    "--to=latex", "--standalone", "--top-level-division=chapter",
    "--no-highlight", "--include-in-header=" + str(BUILD / "paper_header.tex"),
    "--output=" + str(tex_path),
]
subprocess.run(cmd, check=True, cwd=ROOT)
tex = tex_path.read_text()
# Preserve each local equation tag, while shrinking only displays which would
# exceed the available line width. This avoids clipped long exact identities.
display_count = 0
def fit_display(m):
    global display_count
    display_count += 1
    body = m.group(1)
    tags = re.findall(r"\\tag\{([^{}]*)\}", body)
    if len(tags) > 1:
        raise ValueError("Multiple tags in one display")
    body = re.sub(r"\\tag\{[^{}]*\}", "", body)
    body = body.replace(r"\begin{split}", r"\begin{aligned}")
    body = body.replace(r"\end{split}", r"\end{aligned}")
    body = "\n".join(line for line in body.splitlines() if line.strip())
    tag = (r"\tag{" + tags[0] + "}") if tags else ""
    reserve = "42pt" if tags else "0pt"
    return (
        r"\begin{equation*}" + "\n" + (tag + "\n" if tag else "")
        + r"\begin{adjustbox}{max width=\dimexpr\linewidth-" + reserve
        + r"\relax}" + "\n" + r"$\displaystyle " + body + "$\n"
        + r"\end{adjustbox}" + "\n" + r"\end{equation*}"
    )
tex = re.sub(r"\\\[(.*?)\\\]", fit_display, tex, flags=re.S)
tex_path.write_text(tex)
for run in range(3):
    result = subprocess.run(
        ["xelatex", "-interaction=nonstopmode", "-halt-on-error",
         "-output-directory=" + str(BUILD), str(tex_path)],
        cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    (BUILD / f"xelatex_run_{run+1}.txt").write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-8000:])
        raise SystemExit(result.returncode)
pdf_path = ROOT / "ABC_Step4_Paper_2026-10-13.pdf"
shutil.copyfile(BUILD / (tex_path.stem + ".pdf"), pdf_path)
print(json.dumps({
    "pdf": str(pdf_path),
    "chapters": len(FILES),
    "display_equations": display_count,
    "bytes": pdf_path.stat().st_size
}))
