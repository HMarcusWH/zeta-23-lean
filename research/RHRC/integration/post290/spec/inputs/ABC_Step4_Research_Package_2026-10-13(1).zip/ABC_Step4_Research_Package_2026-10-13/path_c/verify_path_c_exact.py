#!/usr/bin/env python3
"""Finite exact-algebra controls for the Path C paper deductions.

These checks do not prove contact existence, sampling, Hardy factorization,
an infinite product theorem, an analytic norm estimate, or RH.
"""
from fractions import Fraction as F
from math import comb, factorial
from pathlib import Path
import json


def zeros(n):
    return [[F(0) for _ in range(n)] for _ in range(n)]


def identity(n):
    a = zeros(n)
    for j in range(n):
        a[j][j] = F(1)
    return a


def add(a, b):
    return [[x + y for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def scale(c, a):
    return [[c * x for x in row] for row in a]


def matmul(a, b):
    n = len(a)
    return [[sum(a[j][k] * b[k][l] for k in range(n))
             for l in range(n)] for j in range(n)]


def shifted_source_matrices():
    cases = 0
    for r in range(1, 10):
        n = zeros(r)
        for j in range(1, r):
            n[j][j-1] = F(j)
        for h in (F(1, 5), F(1), F(2), F(7, 3)):
            c = [[F(comb(j, k)) * (-h) ** (j-k) if k <= j else F(0)
                  for k in range(r)] for j in range(r)]
            exp_n = zeros(r)
            power = identity(r)
            for k in range(r):
                exp_n = add(exp_n, scale((-h)**k / factorial(k), power))
                power = matmul(power, n)
            assert c == exp_n
            for p in (F(2, 3), F(5, 2), F(11, 7)):
                for j in range(r):
                    assert sum(c[j][k] * (p+h)**k for k in range(r)) == p**j
            cases += 1
        for a in (F(1, 10), F(1), F(7, 2)):
            w = [(a/2)**j / factorial(j) for j in range(r)]
            for j in range(1, r):
                assert F(j) * w[j] / w[j-1] == a/2
            cases += 1
    return cases


def source_factor_contraction():
    cases = 0
    for x in (F(0), F(1, 10), F(1), F(7, 3)):
        for y in (F(-4), F(-1, 2), F(0), F(9, 2)):
            for h in (F(1, 7), F(1), F(2)):
                for gamma in (F(1, 3), F(2), F(13, 5)):
                    plus_old = x*x + (y-gamma)**2
                    plus_new = (x+h)**2 + (y-gamma)**2
                    minus_old = x*x + (y+gamma)**2
                    minus_new = (x+h)**2 + (y+gamma)**2
                    assert plus_new - plus_old == h*(2*x+h) > 0
                    assert minus_new - minus_old == h*(2*x+h) > 0
                    assert plus_old*minus_old <= plus_new*minus_new
                    cases += 1
    return cases


def h2_density_and_commutator():
    cases = 0
    # x = exp(t/2), so x > 1.
    for x in (F(11, 10), F(4, 3), F(2), F(5)):
        native = x + 1/x - (1/x)/(1 - x**(-4))
        k2 = (1-x**(-4))*native
        assert k2 == x-x**(-3)-x**(-5)
        cosh2_minus1 = (x**4+x**(-4))/2-1
        b2 = cosh2_minus1*native
        assert b2 == (x**4-1)*(x-x**(-3)-x**(-5))/2
        assert b2 == (x**5-2*x-x**(-1)+x**(-3)+x**(-5))/2
        cases += 1
    for n in range(2, 50):
        # Divide out Lambda(n); only the exact atom multiplier is checked.
        # Multiply by sqrt(n) so every quantity remains rational.
        lhs = (F(n*n)+F(1, n*n))/2-1
        rhs = F((n*n-1)**2, 2*n*n)
        assert lhs == rhs
        cases += 1
    return cases


def multiplicity_top_jet():
    cases = 0
    for m in range(1, 20):
        # A leading coefficient is c0*zeta^(m)/m!, V residue is m*B.
        # (m-1) differentiation must leave exactly c0*zeta^(m)*B.
        assert F(factorial(m-1)*m, factorial(m)) == 1
        cases += 1
    return cases


def main():
    checks = {
        "source_factor_modulus_exact_rational_cases": source_factor_contraction(),
        "binomial_nilpotent_and_weighted_shift_cases": shifted_source_matrices(),
        "gamma_free_density_commutator_and_atom_cases": h2_density_and_commutator(),
        "multiplicity_factorial_cases": multiplicity_top_jet(),
    }
    report = {
        "status": "PASS",
        "scope": "Finite exact rational algebra only; not an analytic or RH proof.",
        "checks": checks,
        "paper_arguments_not_computationally_verified": [
            "All inherited full-contact existence and source-classification premises",
            "All-right evaluation injectivity from the infinite Weil sum",
            "Infinite Hadamard product and Hardy multiplier theorem",
            "Source-specific infinite weighted exterior synthesis",
            "Uniform and minimax horizon limits",
            "Any native upper bound on the remaining prime discrepancy",
        ],
    }
    path = Path(__file__).with_name("PATH_C_EXACT_CONTROLS.json")
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
