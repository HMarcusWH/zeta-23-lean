# Joint campaign Path A continuation — results and claim ledger

Date: 13 October 2026.

**Outcome: several new exact reductions and independent sector bounds; no Step 4 closure.** The remaining estimate has been narrowed to a complete signed native field with a growing small-prime mask and a large rough core. The exact A+B+C composition is proved on paper and exposes that same uncontrolled term.

No repository or Lean source was changed. All new claims below are paper derivations, with their assumptions and proofs in the accompanying notes. Finite arithmetic controls check implementations of identities; they do not prove the asymptotic estimates.

## What is materially new

The original detector and its actual integer-lattice input are preserved. Its quantitative double-exponential input decay now controls every gcd-covariance ray outside

\[
\frac{\max(a,b)}{\min(a,b)}
\ge C_0(1+\log\min(a,b))^2
\]

absolutely and uniformly over all horizons, with one \(C_0\) valid for every positive damping. This improves the earlier polynomial-ratio exclusion.

The new arithmetic mask is

\[
w_P(k)=1_{\{\omega(\gcd(k,P))\le1\}}
=\sum_{Q\mid\gcd(k,P)}\mu(Q)(1-\omega(Q)).
\]

It fixes every prime power and removes every product containing two selected distinct primes. Restricted integer lattices retain the detector's two zero moments. Compensating their modulus loss by the exact cutoff

\[
Y_P(t)=\frac{e^t}{BP(t)t^2}
\]

gives a separately bounded remainder. Choosing \(P(t)\) as the largest initial primorial at most \(\log(t+2)\) leaves only \(m=O(t^2\log(t+2))\) cofactors, with a single \(B\) for all positive damping.

A separate elementary Rankin count controls all products whose complete rough core is at most \(\exp(t/\log(t+2))\). This whole sector belongs to every positively damped \(L^2\) space. At a fixed damping \(\epsilon\), the stronger core cutoff \(e^{\theta t}\) is allowed for every \(\theta<2\epsilon\).

These operations do not create a favorable pointwise sign. Complete small-divisor cancellation yields exactly \(\mu(b)\Lambda(a)\) when the entire small part \(a\) lies below the strict cutoff and the remaining primes are rough. Both \(-\log2\) on \(2q\) and \(+\log2\) on squarefree \(2pq\) occur in every late detector window. Their absolute budgets retain exponential rate \(1/2\), and both families survive the new mask and the small-core removal.

The final joint identity uses B and C's exact gamma-free measure \(\Delta_2=(1-e^{-2t})W_+\). With the original causal detector \(h_+\), the original contact exterior \(v\), and the remaining arithmetic field \(R_A\), it proves

\[
(1-e^{-2a})e^{-2a\epsilon}
\|h_+*v\|_{\epsilon,(T-2a)_+}
\le
\|f_+\|_{1,\epsilon}e^{-\epsilon d}
\|R_A\|_{\epsilon,(T-d)_+}
+C_\epsilon.
\]

The source-preserving history and feedback commutator are retained. The unproved right-hand norm is the exact closing input; the contraction does not independently bound it.

## Claim ledger

| ID | Claim | Status and assumptions | Proof location |
|---|---|---|---|
| PA-1 | Absolute uniform bound outside the logarithm-squared gcd wedge | Derived on paper from the supplied native Gevrey bound and exact finite covariance identity; no mean Möbius assumption | Note 01, Sections 2–4 |
| PA-2 | Squarefree-core identity and complete-small-divisor cancellation \(A_Y(ab)=\mu(b)\Lambda(a)\) | Finite elementary identity; requires \((a,b)=1\), all primes of \(b\) at least \(ab/Y\), and \(a<ab/Y\) for the complete form | Note 02, Sections 1–2 |
| PA-3 | Both signs \(\pm\log2\) on actual squarefree products in every late source window | Derived on paper; uses only fixed-ratio PNT for the existence/count of the displayed native primes | Note 02, Sections 3–4 |
| PA-4 | Small-rough-core sector is independently bounded in the stated weighted spaces | Derived on paper from elementary counting and the short cofactor range; strict \(\theta<2\epsilon\); no endpoint claim | Note 03 |
| PA-5 | Growing prime-power-preserving mask with an explicit stable remainder and \(O(t^2\log t)\) cofactors | Derived on paper on the original \(h\), with one fixed sufficiently large \(B\); time-varying \(P(t)\) appears explicitly in the bound | Note 04, Sections 1–5 |
| PA-6 | This modulus method cannot select every prime below its expanded cofactor scale | Elementary specified limitation: a prime divisor of \(P+1\) is absent from \(P\) but below \(L_P\) eventually; no general sieve impossibility claim | Note 04, Section 6 |
| PA-7 | Exact smoothed A+B+C bridge and finite-horizon contracted inequality | Derived on paper conditional on the supplied full-contact source foundations and B/C's proved continuation identities; no new contact source or backwards compact-filter inverse | Note 05, Sections 2–4 |
| PA-8 | Plain all-positive-damping \(L^2\) sensor equivalence for \(X=\Delta_2*h_+\) | Derived on paper using B's graph inverse plus all-order smooth-source interpolation; explicitly restricted to this smooth fixed detector | Note 05, Section 5 |
| PA-9 | Stable subtraction preserves any growing norm asymptotically and transfers every-horizon native leakage | Exact norm consequence, conditional on the native norm growing; no actual off-line zero is assumed to exist | Note 05, Section 6 |
| OPEN-PA | \(\sup_T\|R_A\|_{\epsilon,T}<\infty\) for every \(\epsilon>0\) | **Unproved. This is the remaining Step 4 arithmetic input.** | Note 05, equations (1)–(3), (19) |

## The failed final implication

The mask and smooth-sector estimates establish

\[
F=R_A+E_A,\qquad E_A\in\bigcap_{\epsilon>0}L^2_\epsilon.
\]

They do not establish a bound for \(R_A\). If the native norm were to grow at a given positive damping, then its ratio to the residual norm tends to one. Thus treating the zero-one mask as an attenuation factor below one would contradict the exact stable-subtraction relation on that growing signal.

The native squarefree sign budgets also rule out a proof by taking the absolute value of each surviving summand. The missing argument must estimate the complete signed field, retaining mixed cofactor correlations. C's stable feedback inverse and B's zero-free sensor supply legal interfaces and lower-bound detection; they supply no independent upper bound for that field.

## Validation and review

The companion exact script passed:

- 53,955 coefficient and strict-cutoff cases, including both sides of divisor seams;
- 11,343 rough-core truncated identities, including 1,838 complete-small-part cases;
- 24,576 prime-mask identities;
- 8,448 masked restricted-drive product identities.

All logarithms were represented by exact integer coefficients of logarithms of primes, and cutoff comparisons used rational arithmetic. The explicit seam \(A_7(42)=\log6\), while \(A_{20/3}(42)=0\), checks why the strict cutoff cannot be relaxed.

The parent/root, Path B, and Path C performed independent reviews of the new interfaces. The review receipt records scope and corrections. None of these reviews is represented as a Lean check or a proof of the open bound.

## Files

- 01_LOG_SQUARED_GCD_WEDGE.md
- 02_ROUGH_CORE_AND_SQUAREFREE_SIGN_BUDGETS.md
- 03_SMOOTH_SECTOR_BOUND.md
- 04_PRIME_POWER_PRESERVING_ADAPTIVE_SIEVE.md
- 05_JOINT_SOURCE_BRIDGE_AND_CLOSING_ATTEMPT.md
- 06_REVIEW_RECEIPT.md
- verify_path_a_exact.py
- PATH_A_EXACT_CONTROLS.json

The individual proof notes identify the exact inherited source files and sections. The canonical top-level authority remains the live repository and its explicit open assumptions; these continuation notes do not alter it.
