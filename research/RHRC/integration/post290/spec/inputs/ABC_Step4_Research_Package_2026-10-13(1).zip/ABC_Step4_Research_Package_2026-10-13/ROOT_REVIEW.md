# Root synthesis review and claim boundaries

13 October 2026. Internal mathematical review of this joint campaign. This is not external peer review, a new Lean build, or an independent reconstruction of every inherited project premise.

## Proofs checked

- **A01:** The exact finite covariance retains the common-divisor horizon. The Gevrey bound gives decay in the square root of the cofactor ratio. Summing the separated rays is legal for every positive damping with one fixed ratio constant. No limiting signed ray sum replaces the finite identity.
- **A02:** The squarefree-core reindexing, full-small-part convolution identity, strict-cutoff counterexample, and two squarefree sign families are exact. The sign-budget counts use only fixed-ratio PNT, with uniformity supplied by bases tending to infinity. They bound separate magnitudes, not the signed total.
- **A03:** Rankin's estimate controls the whole small-rough-core field. Its exponential bound requires the displayed additive sublinear error and the strict damping margin. Compatibility with the logarithm-squared times logarithm cofactor scale is valid; arbitrary larger subexponential moduli are not silently covered.
- **A04:** The mask fixes every prime power. The finite divisibility expansion and coefficient budget are correct. The factor q^(-1/2), the square-root loss in the Gevrey exponent, and the compensating factor P in the cutoff are retained. All identities are pointwise finite; the stepwise modulus is not differentiated.
- **A05:** The complete history bridge, its causal delays, the smoothing/feedback commutator, and the final weighted prefix inequality are consistent. The all-damping plain-sensor equivalence has a valid separate high-order interpolation proof on the fixed smooth detector. It is not extended to the finite-regularity source or to derivative-jumping adaptive fields.
- **B01:** The shifted rational inverse, finite-measure derivative including the initial atom, weighted graph bounds, integer-cutoff inverse convergence, multiplicity factors, gamma recurrence, finite-history advance, and native first-prime sign calculation were independently checked. Plain L2 suffices for a residue contradiction; only the stated H1 graph membership licenses the inverse estimate.
- **B02:** The source-feedback semigroup law holds with the shifted multiplier and also in the weighted vector basis. Safe-half-plane damping makes the returned terms independently stable. The exact telescope preserves the first forcing and every unshifted native right residue.
- **C01:** The restricted range test reduces the highest native jet to one source evaluation per distinct zero. Reflection in the complex-source Weil sum is handled correctly. The simple-critical-zero density and finite-type count establish injectivity. The uniform finite-dimensional lower bound is valid. The minimax upper proof explicitly identifies the differentiated same-source spectral limit and then uses the inherited weighted synthesis at the improved damping; it does not infer a Hardy bound from pole removal alone.
- **C02:** The paired source product, parity removal of its exponential factor, contractive ratio, exact source recovery factor, complete companion history, finite-prefix norm comparison, and local uniqueness argument are consistent. The derivative basis stops at r-1. The weighted nilpotent shift gives the stated all-nullity contraction.
- **Joint notes:** The supported quadratic exponential commutator has the correct sign, reflected factor two, regularized diagonal, and endpoint correlation. The even-shift recurrence retains both rational endpoints and its finite interior sum. Prime powers are removed only with the established positive-damping bound. Finite scalar averaging cancels the native residue exactly when it cancels the shared discrepancy.

The inherited C2 `EXTERIOR_L2_ABSCISSA.md` was reopened to check the full operator-domain logarithmic sampling and weighted synthesis invoked by the new minimax upper proof. The primary Bui-Conrey-Young PDF was reopened to verify that the density input counts simple critical zeros, hence genuinely distinct ordinates. NIST's digamma recurrence was reopened for the exact shift calculation.

## Corrections before release

1. Added the missing plus before the sublinear exponential error in A03 equation (8).
2. Added the missing plus before the constant in A05 equation (13).
3. Added the missing plus before the companion transform in B02 equation (4.6).
4. Clarified that the shifted Möbius truncation bound is stated at integer cutoffs.
5. Separated plain L2 residue contradiction from H1 graph inversion in B01.
6. Specified that the local mollifier scale is held fixed when differentiating in the smooth-source interpolation proof.
7. Normalized malformed inline math delimiters in the C notes and removed a control character in the synthesis source.
8. Replaced wording that could assert actual unboundedness with wording that states the absence of a proved upper bound. Actual positive growth remains a conditional conclusion under the hypothetical contact/off-line-zero premises.
9. Restricted the local-data limitation to the supported quadratic exponential-contact commutators considered here; the causal source forcing itself uses an increasing prime horizon.

The mathematical proof notes and the overview were reviewed separately. Final hashes in the package manifest identify the released versions.

## Scope limits

- This campaign has not closed Step 4 or RH, and none of its new analytic theorems has been compiled in Lean.
- The finite arithmetic controls do not establish an infinite signed upper bound.
- A stable native input does not imply stable output without the required range and domain condition.
- The shifted native sensor has a graph inverse, not a bounded raw L2 inverse.
- The arithmetic mask does not supply a norm contraction of the signed completed response.
- The higher-prime-power absolute estimate requires positive damping; no undamped finite-variation bound is claimed.
- Smoothing or exponentially tilting a contact source does not automatically give a new null vector.
- Removing finite poles alone does not establish an H2 bound.
- The local perturbation controls do not preserve all global native arithmetic identities.
- This campaign proves no general impossibility theorem for sieve methods or arbitrary filter combinations.

## Released mathematical status

The new reductions, isomorphisms, source contractions, rank formula, minimax rate, source bridge, and scoped falsifiers are PAPER results under their listed premises. The original-source prime-discrepancy upper estimate and the complete masked large-rough-core bound remain OPEN. The package records a completed research attempt and its exact stopping point.
