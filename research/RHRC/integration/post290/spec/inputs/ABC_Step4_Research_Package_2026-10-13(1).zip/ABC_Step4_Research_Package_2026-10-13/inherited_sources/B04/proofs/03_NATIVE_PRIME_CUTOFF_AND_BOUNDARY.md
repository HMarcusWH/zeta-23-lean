# B04.3 — Actual prime-prefix approximation with the exact escaping boundary

**Status:** PAPER construction and stopping theorem, importing A02's prime-pair/boundary calculation and ordinary PNT. Every quantity below uses the *original fixed* detector. No new upper bound capable of excluding an off-line zero was established.

## The exact first-prime and higher-power split

Set `d=1/2048`, `h=k_r*k_r` with support `[-d,d]`, `K(1/2)=K'(1/2)=0`, and define

\[
F_1(t)=\sum_{p}\frac{\log p}{\sqrt p}h(t-\log p),
\qquad F_{\ge2}(t)=\sum_{p}\sum_{k\ge2}\frac{\log p}{p^{k/2}}h(t-k\log p).
\]

Then `F=F_1+F_{>=2}`, with all genuine coefficients. A02 proves `||e^{-epsilon t}F_{>=2}||_2<infty` for every `epsilon>0`, via the weighted prime-power measure's finite total variation. This cannot be interpreted as dropping the channel: its full bounded contribution remains in the approximation and error.

For `X>2`, construct the *genuine finite prime prefix*

\[
F_{1,X}(t)=\sum_{p\le X}\frac{\log p}{\sqrt p}h(t-\log p).
\]

The equality `F_{1,X}(t)=F_1(t)` holds throughout `t<=T=log X-d`. It is not a global approximation in a weighted norm, because `F_{1,X}` has a deterministic escaping pulse at its upper cutoff.

## Exact continuum cutoff pulse

Define, for `u∈[-d,d]`,

\[
J(u)=\int_u^d e^{-s/2}h(s)\,ds.
\]

Extend `J` by zero outside the interval. This is legitimate since `J(d)=0` and `J(-d)=K(1/2)=0`. Put

\[
B_X(t)=\sqrt X\,e^{(t-\log X)/2} J(t-\log X).
\]

This explicit *late-time* function is compactly supported on `[log X-d,log X+d]`, with no overlap with `[0,T)` for large X. It is a continuum boundary counterterm, not a replacement of the genuine prime atoms. It has exactly computable weighted energy

\[
\boxed{\|e^{-\epsilon t}B_X\|_2^2=X^{1-2\epsilon}C_{\partial,\epsilon}},\qquad
C_{\partial,\epsilon}=\int_{-d}^d e^{(1-2\epsilon)u}|J(u)|^2du>0.
\]

A02's full horizon identity proves that the *actual* future cutoff energy has the same leading constant. Its two signed prime-pair constants satisfy `C_+-C_-=C_partial`, so the deterministic `X^(1-2epsilon)` part cancels in the **complete** interval energy.

## Corrected approximants and the PNT error

Define the purely prime/continuum-data approximant

\[
G_X(t)=F_{1,X}(t)-B_X(t)+F_{\ge2}(t).
\]

It is in every weighted `L²(e^{-2epsilon t})` because the first two terms are compact and the higher-power term is weighted stable. On `[0,T]`, `B_X=0` and `F_{1,X}=F_1`; therefore `G_X=F` on that interval. All construction ingredients are known genuine prime data, fixed h, and the explicit continuum cutoff counterterm; the unknown output F was *not* used as a definitional approximant.

On the cutoff edge `t=log X+u`, `u∈[-d,d]`, ordinary PNT for `theta(x)=x+o(x)` and Stieltjes integration give uniformly

\[
F_{1,X}(\log X+u)
=\sqrt X\,e^{u/2}J(u)+o(\sqrt X).
\]

The uniformity follows because the active prime interval is `X e^{-2d}<=p<=X`, the compact fixed source and its derivative are bounded, and `sup_{y∈[Xe^{-2d},X]} |theta(y)-y|/X=o(1)`. Therefore

\[
\|e^{-\epsilon t}(F_{1,X}-B_X)\|_{L^2([\log X-d,\log X+d])}
=o(X^{1/2-\epsilon}).
\]

On earlier times, the original pole-neutral detector similarly gives the unconditional PNT estimate `F_1(t)=o(e^{t/2})`: the continuum part is `e^{t/2}K(1/2)=0`. Combining the finite initial portion with this uniform late-time estimate yields, for `0<epsilon<1/2`,

\[
\boxed{\|e^{-\epsilon t}(F_{1,X}-B_X)\|_{L^2(0,\infty)}=o(X^{1/2-\epsilon}).}
\tag{B04-PNT}
\]

The higher-power channel contributes a fixed finite norm, hence `||e^{-epsilon t}G_X||_2=o(X^{1/2-epsilon})`. This is a genuine global estimate for an explicit approximant, but the norm is allowed to diverge; in particular, it is not a uniform bound as X→infty.

## Exact global range error and failed closure

The only legitimate range approximation is to apply the B03 operator to `g_{X,epsilon}=e^{-epsilon t}G_X` and examine

\[
\mathfrak e_{X,\epsilon}=v_\epsilon-\mathsf A_\epsilon g_{X,\epsilon}.
\]

The residual vanishes through the prefix T by causality. The independent bound currently furnished by Young and the PNT estimate is only

\[
\|\mathfrak e_{X,\epsilon}\|_2
\le \|v_\epsilon\|_2+M_\epsilon\|g_{X,\epsilon}\|_2
= o(X^{1/2-\epsilon})
\]

for `epsilon<1/2`; the fixed `||v_epsilon||` is absorbed into the diverging scale. It does **not** tend to zero. It does not prove `v_epsilon` is even in the closure of the range.

Under a hypothetical right zero with `delta=Re rho-1/2-epsilon>0`, note 01 forces

\[
\|\mathfrak e_{X,\epsilon}\|_2\ge c_{\rho,\epsilon}e^{\delta T}
\asymp c'_{\rho,\epsilon}X^\delta.
\]

Since every nontrivial `rho` has `Re rho<1`, one has

\[
\delta=\Re\rho-1/2-\epsilon < 1/2-\epsilon.
\]

The two estimates are compatible. This is why removing A02's *leading deterministic boundary pulse* is real progress but does not yet close the problem. The missing step is a **second cancellation**, controlling the *complete* global residual at a scale below every positive power, not merely PNT `o(X^(1/2-epsilon))`.

## Prime-pair fluctuation formulation

A02's exact signed identity, with the future boundary retained, gives

\[
\mathcal R_\epsilon(T)=\|e^{-\epsilon t}F_1\|_{L²(0,T)}^2-D_\epsilon(X).
\]

A sufficient independent final statement would be `sup_{T>=0} R_epsilon(T)<infty` for all epsilon>0. A weaker but still sufficient family would give subexponential positive-part growth in T for arbitrarily small epsilon. The existing unconditional PNT estimate is only `R_epsilon=o(X^{1-2epsilon})`.

The construction does not treat the prime-pair kernel as sign definite: A02 proves that the kernel changes sign and that both the positive and negative pair budgets have nonzero large main terms. It does not use a guessed pair-correlation sign.

## Falsification boundaries

1. Omitting `B_X` reproduces the false exponential full-prefix norm even under RH; the pulse is an approximation artifact.
2. The previous finite Euler inverse outputs diverge globally on the original U; local agreement cannot be promoted to norm convergence.
3. The same-input positive-kernel perturbation leaves any finite prefix unchanged but alters the global right pole. Therefore finite agreement and kernel positivity cannot by themselves imply closure.
4. The A02 estimate is arithmetic/PNT-level and does not distinguish the smaller hypothetical zeta-zero exponent `delta`.
