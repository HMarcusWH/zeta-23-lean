# C05 / round four — completed native forward kernel and original exterior

**Status: NEW DERIVED / PAPER.** The kernel theorem is unconditional for the exact native integer and completed-xi distributions. Its contact application is conditional on the audited PAPER full-contact and maximal-domain foundations. No new Lean declaration or RH closure is claimed.

## 1. Normalization and theorem

Use
\[
F_f(z)=\int f(x)e^{-izx}\,dx,\qquad \mathcal Lf(p)=F_f(-ip),
\]
and
\[
N=\sum_{n\ge1}n^{-1/2}\delta_{\log n},\qquad
\Pi=\sum_{n\ge2}\Lambda(n)n^{-1/2}\delta_{\log n}.
\]
Put \(B=\delta_0-e^{-t/2}1_{t\ge0}\), \(R=e^{-t}1_{t\ge0}\), and \(a_N=R*B*N\). B03's exact formula and bounds are
\[
a_N(t)=3e^{-t}\sum_{n\le e^t}\sqrt n
-2e^{-t/2}\lfloor e^t\rfloor\quad(t\ge0),\qquad a_N(t)=0\quad(t<0),
\tag{1.1}
\]
\[
\frac{e^{-t/2}}{6\sqrt2}\le a_N(t)\le\frac32e^{-t/2}.
\tag{1.2}
\]
Its transfer is
\[
A_N(p)=c_0(p)\zeta(p+1/2),\qquad
c_0(p)=\frac{p-1/2}{(p+1/2)(p+1)}.
\tag{1.3}
\]
The apparent singularity at \(p=1/2\) is removable.

The exact native causal half distribution \(W_+\), with its inherited half-diagonal normalization, has in \(\Re p>1/2\)
\[
\mathcal LW_+(p)=J(p)=\frac{\xi'}{\xi}(1/2+p)
=\frac{\zeta'}{\zeta}(1/2+p)+j(p),
\]
\[
j(p)=\frac1{p-1/2}+\frac1{p+1/2}
+\frac12\psi(p/2+1/4)-\frac12\log\pi.
\tag{1.4}
\]

**Theorem 1.** The actual proper causal convolution
\[
q_N:=a_N*W_+
\tag{1.5}
\]
is a real function, and
\[
\boxed{e^{\tau t}q_N(t)\in L^2(0,\infty)
\quad\text{for every }0\le\tau<1/2.}
\tag{1.6}
\]
Also
\[
e^{\tau t}a_N(t)\in H^s(\mathbb R)
\quad(0<s<1/2-\tau),
\tag{1.7}
\]
with zero extension. Its exact transfer is
\[
Q_N(p)=\mathcal Lq_N(p)=A_N(p)J(p)\quad(\Re p>1/2),
\tag{1.8}
\]
and the left side extends holomorphically to \(\Re p>-1/2\). No endpoint \(\tau=1/2\) assertion is made.

This constructs a stable forward input for the **original** contact exterior. It does not assert bounded inversion of \(a_N\).

## 2. Fractional regularity, including every integer edge

On an open cell \((\log n,\log(n+1))\),
\[
a_N'(t)=-3e^{-t}\sum_{j\le n}\sqrt j+n e^{-t/2}.
\]
The bound \(\sum_{j\le n}\sqrt j\le Cn^{3/2}\) gives \(|a_N'(t)|\le Ce^{t/2}\). At \(t=\log n\), including the initial jump \(n=1\), the jump is exactly \(n^{-1/2}\). Therefore \(u_\tau=e^{\tau t}a_N\), extended by zero, has
\[
|u_\tau(t)|\le Ce^{-(1/2-\tau)t},\qquad
|u_\tau'(t)|\le C_\tau e^{(1/2+\tau)t},
\tag{2.1}
\]
and jumps \(n^{\tau-1/2}\).

For \(0<h<1/8\), cut at \(L_h=\log(1/(4h))\). Up to this cutoff, every interval of length \(h\) meets at most one jump: the relevant spacings obey \(\log(n+1)-\log n\ge1/(n+1)>h\). The ordinary derivative part contributes at most
\[
C_\tau h^2\int_0^{L_h+h}e^{(1+2\tau)t}dt
\le C_\tau h^{1-2\tau}
\]
to the squared translation difference. The disjoint jump neighborhoods contribute at most
\[
Ch\sum_{n\le C/h}n^{2\tau-1}.
\]
The remaining two tails are bounded by (2.1), giving \(C_\tau h^{1-2\tau}\). Negative times near zero are already included in the initial jump. Hence
\[
\|u_0(\cdot+h)-u_0\|_2^2\le Ch\log(2/h),
\tag{2.2}
\]
\[
\|u_\tau(\cdot+h)-u_\tau\|_2^2
\le C_\tau h^{1-2\tau}\quad(0<\tau<1/2).
\tag{2.3}
\]

Plancherel and Tonelli give, for \(0<s<1\),
\[
\int_0^\infty h^{-1-2s}\|u(\cdot+h)-u\|_2^2dh
=c_s\int_{\mathbb R}|\omega|^{2s}|\widehat u(\omega)|^2d\omega,
\]
with \(0<c_s<\infty\), by substituting \(h|\omega|\) in the nonnegative inner integral. The large-\(h\) integral is bounded by \(4\|u\|_2^2/(2s)\). Equations (2.2)–(2.3) make the small-\(h\) integral finite in exactly the strict range (1.7). No pointwise smoothness assertion has replaced this zero-extension proof.

## 3. Exact native completion cancels the growing elementary term

Let
\[
\gamma_+(p)=\frac12\psi(p/2+1/4)-\frac12\log\pi.
\]
Direct logarithmic differentiation gives
\[
\frac{c_0'}{c_0}
=\frac1{p-1/2}-\frac1{p+1/2}-\frac1{p+1}.
\]
Thus
\[
C_N(p):=j(p)-\frac{c_0'(p)}{c_0(p)}
=\frac2{p+1/2}+\frac1{p+1}+\gamma_+(p),
\tag{3.1}
\]
and, first in the safe half-plane,
\[
\boxed{A_NJ=A_N'+C_NA_N.}
\tag{3.2}
\]
Every term on the right has an actual causal realization:
\[
\boxed{
q_N=-t a_N
+2(e^{-t/2}1_{t\ge0})*a_N
+(e^{-t}1_{t\ge0})*a_N+\Gamma_+*a_N,
}
\tag{3.3}
\]
where \(\Gamma_+\) is the native causal archimedean half distribution with transform \(\gamma_+\). The diagonal constant in (3.3) is the original one, not a constant chosen by asymptotics.

Fix \(0\le\tau<1/2\). The first term is square integrable after multiplication by \(e^{\tau t}\). The two rational kernels become \(e^{-(1/2-\tau)t}1_{t\ge0}\) and \(e^{-(1-\tau)t}1_{t\ge0}\), both in \(L^1\), so Young's inequality applies.

On the same weighted line the archimedean multiplier is
\[
\gamma_+(-\tau+i\omega)
=\frac12\psi((1/2-\tau)/2+i\omega/2)-\frac12\log\pi,
\]
and
\[
|\gamma_+(-\tau+i\omega)|\le C_\tau\log(2+|\omega|).
\tag{3.4}
\]
This bound follows directly by splitting the digamma series at \(n\asymp1+|\omega|\). Low terms give the harmonic logarithm and a bounded denominator sum; high difference terms are bounded by \(C(1+|\omega|)\sum_{n>|\omega|}n^{-2}\). There is no pole because \((1/2-\tau)/2>0\). The same fixed-line bound also follows from the sectorial digamma expansion in NIST DLMF, equation 5.11.2, read at https://dlmf.nist.gov/5.11#E2; the actual causal realization remains the project distribution used here.

Choose \(0<s<1/2-\tau\). By (1.7), the product of (3.4) with \(\widehat u_\tau\) is in \(L^2\). It realizes the actual proper causal convolution \((e^{\tau\cdot}\Gamma_+)*u_\tau\): approximate \(u_\tau\) in \(H^s\) by smooth compact causal functions, using a small positive translation, mollification with smaller radius, and then a distant smooth cutoff. Translation continuity, approximation by mollifiers, and the usual distant-cutoff approximation in \(H^s\) preserve convergence; every approximant has support in the positive half-line. The multiplier outputs converge in \(L^2\); continuity of lower-supported convolution on every compact time interval identifies the distributional limit with that proper convolution. This avoids substituting an unrelated boundary solution.

Therefore (3.3) belongs to every asserted weighted \(L^2\) space. Its safe Laplace transform is (3.2), equal to the transform of \(a_N*W_+\). Uniqueness for causal distributions of exponential order proves their equality and Theorem 1.

**Weighted \(L^1\) strengthening.** If \(0\le\tau<\tau'<1/2\), Cauchy–Schwarz gives
\[
\|e^{\tau t}q_N\|_1
\le \frac{\|e^{\tau't}q_N\|_2}{\sqrt{2(\tau'-\tau)}}<\infty.
\tag{3.4a}
\]
The same conclusion for \(a_N\) follows directly from (1.2). Thus both kernels define bounded actual causal convolution operators on \(L^2\), also after every one of these growing exponential weights. This is a forward-operator statement, not a bounded inverse.

### Independent check using the literal divisor identity

Put \(b=R*B=3e^{-t}1_{t\ge0}-2e^{-t/2}1_{t\ge0}\). The exact native identity \(N*\Pi=tN\) gives
\[
a_N*\Pi
=3e^{-t}\sum_{n\le e^t}\sqrt n\log n
-2e^{-t/2}\sum_{n\le e^t}\log n.
\tag{3.5}
\]
Elementary sum–integral bounds yield, uniformly for real \(x\ge2\),
\[
\sum_{n\le x}\sqrt n\log n
=\frac23x^{3/2}\log x-\frac49x^{3/2}
+O(\sqrt x\log x),
\]
\[
\sum_{n\le x}\log n=x\log x-x+O(\log x).
\]
Consequently (3.5) is
\[
\frac23e^{t/2}+O((1+t)e^{-t/2}).
\tag{3.6}
\]
Meanwhile \(A_N(1/2)=2/3\), from the ordinary zeta residue at one, so
\[
a_N*(e^{t/2}1_{t\ge0})=\frac23e^{t/2}+O(e^{-t/2}),\qquad
a_N*(e^{-t/2}1_{t\ge0})=O((1+t)e^{-t/2}).
\]
The entire growing term cancels. This agrees with (3.3), using no PNT error estimate and no exterior bound.

## 4. Direct equation for the unchanged contact generator, every nullity

Assume the audited full contact on \(I=[-a,a]\). Let \(f=f_0\) be the original canonical generator and
\[
c=-P_I(W_+*f)=-Tf.
\]
Both are actual compact \(L^2\) operator-domain sources. Let
\[
v(s)=(W*f)(a+s)\quad(s>0),
\]
extended by zero for \(s<0\). To the right of \(I\), \(W_+*f=W*f\). The audited maximal-domain theorem excludes endpoint distributions and gives the exact global decomposition
\[
f_+=T_af,\quad c_+=T_ac,\qquad
W_+*f_+=-c_++T_{2a}v,
\tag{4.1}
\]
where \(T_du(t)=u(t-d)\) and \(f_+,c_+\) are supported in \([0,2a]\).

Convolving with the unchanged \(a_N\) gives
\[
q_N*f_++a_N*c_+=T_{2a}(a_N*v).
\tag{4.2}
\]
The left side is constructed from known kernels and compact local sources. It vanishes before \(2a\) by (4.1), not by arbitrary truncation. Define
\[
\boxed{y_f(s)=(q_N*f_++a_N*c_+)(s+2a),\quad s\ge0.}
\tag{4.3}
\]
Then
\[
\boxed{a_N*v=y_f}
\tag{4.4}
\]
as actual causal distributions, and
\[
\boxed{e^{\tau s}y_f(s)\in L^2(0,\infty)
\quad(0\le\tau<1/2).}
\tag{4.5}
\]
Indeed exponential weights pass through proper convolution, compact sources are in \(L^1\), and the fixed advance multiplies the weighted norm by \(e^{-2a\tau}\). In particular
\[
\|y_f\|_2
\le\sqrt{2a}\left(\|q_N\|_2\|f\|_2+\|a_N\|_2\|c\|_2\right).
\tag{4.6}
\]
The second summand may instead be bounded by \(\|a_N\|_1\|c\|_2\).
The weighted \(L^1\) strengthening supplies the alternative bound, with no factor from the aperture,
\[
\|e^{\tau s}y_f\|_2
\le \|e^{\tau t}q_N\|_1\|f\|_2
+\|e^{\tau t}a_N\|_1\|c\|_2,\qquad 0\le\tau<1/2.
\tag{4.7}
\]
Here the fixed advance factor \(e^{-2a\tau}\) cancels the upper bound \(e^{2a\tau}\) for the weights on the compact shifted source supports.

This covers \(r=1,2\) and every higher nullity, without making \(f\) pole neutral or smooth, changing it, or enlarging its support. The construction also works for any compact actual domain source with its own compressed source and right exterior. PSD is needed here for the canonical real-zero generator and its universal off-line visibility, not for Theorem 1.

## 5. Residue audit and original-source adjoint obstruction

Write \(D_f(p)=F_f(-ip)\) and \(D_c(p)=F_c(-ip)\). The exact safe transforms are
\[
V_f(p)=e^{ap}[D_f(p)J(p)+D_c(p)],
\]
\[
\boxed{Y_f(p)=A_N(p)V_f(p)
=e^{ap}[Q_N(p)D_f(p)+A_N(p)D_c(p)].}
\tag{5.1}
\]
The last expression, not an assumption about the unknown exterior, proves the improved actual-input domain.

At an off-line zero \(\rho\) of multiplicity \(m\), put \(\lambda=\rho-1/2\), \(\gamma=-i\lambda\), and assume \(\Re\lambda>0\). The original exterior has exact residue
\[
\operatorname{Res}_{p=\lambda}V_f
=m e^{a\lambda}G(\gamma)\ne0.
\tag{5.2}
\]
The forward multiplier \(A_N\) has a zero of order \(m\). Thus the bounded observation \(Y_f\) has **no pole**; instead
\[
Y_f^{(k)}(\lambda)=0\quad(0\le k<m-1),
\]
\[
\boxed{Y_f^{(m-1)}(\lambda)
=c_0(\lambda)e^{a\lambda}G(\gamma)\zeta^{(m)}(\rho)\ne0.}
\tag{5.3}
\]
There is no missing factorial or factor \(m\). The sign is positive, unlike B's prime-only source \(-\zeta'K\). The factor \(e^{a\lambda}\) is C's actual exterior advance, not a later A/B delay. The companion term vanishes to order at least \(m\).

For \(0<\varepsilon<\Re\lambda\), the B03 operator
\[
\mathsf A_\varepsilon g=(e^{-\varepsilon\cdot}a_N)*g
\]
is bounded and injective. Its actual input \(e^{-\varepsilon\cdot}y_f\) is in \(L^2\), but its highest adjoint zero-jet is the nonzero value (5.3). It therefore lies outside the closure of the range if the hypothetical zero exists. The centered-jet and finite-pole leakage theorem applies directly to the unchanged \(v\), with coefficient (5.3).

This is a constructed original-source input and residue obstruction, not an independent range-membership theorem. The controlled forward observation cancels the off-line pole before its bound is obtained.

## 6. Exact global signed coupling from the full functional equation

The completed functional equation and reality imply that \(J(i\omega)\) is purely imaginary away from the discrete critical zeros. Hence almost everywhere
\[
\Re\left(\overline{A_N(i\omega)}Q_N(i\omega)\right)=0.
\tag{6.1}
\]
The products are integrable by the proved \(L^2\) membership. Since both kernels are also in \(L^1\), their convolution operators are bounded on the actual causal \(L^2\) space. Plancherel now gives, for every \(u\in L^2(0,\infty)\) extended by zero,
\[
\boxed{\Re\langle a_N*u,q_N*u\rangle_{L^2(\mathbb R)}=0.}
\tag{6.2}
\]
Equivalently, for these bounded causal operators,
\[
\mathsf A_0^*\mathsf Q_0+\mathsf Q_0^*\mathsf A_0=0.
\tag{6.3}
\]
This identity follows by polarization of (6.2); it is not transferred to positively damped vertical lines, where the native logarithmic derivative need not have zero real part.
The same argument directly gives \(\langle a_N,q_N\rangle=0\). Both kernels are real, \(a_N>0\), and \(q_N\ne0\), so \(q_N\) has positive and negative parts of nonzero measure. The new genuine global completion law is signed.

Using (4.2), equation (6.2) becomes a finite filtered exterior pairing on the actual contact. It gives no coercive norm for the unfiltered exterior. Its residue sensitivity fails for the same exact reason as (5.1): the controlled factors contain \(A_N\). The full functional equation has been used, but the pole information has already been removed before the global lossless pairing.

## 7. Falsification and source contracts

- **Positive power-consistent far-prime changes** preserve the contact and companion but break \(N*\Pi=tN\). Their extra term in \(a_N*\widetilde W_+\) is not absorbed by (3.3). They do not refute the native theorem and still refute a contact-only exterior bound.
- **Positive-theta quartet completion** retains prime atoms but changes \(j\). A planted pole contributes \(a_N*\Delta W_+\); if native \(A_N\) does not vanish there, the extra term fails the improved weighted domain. Exact native completion is essential to (3.1).
- **All-orders Herglotz controls** supply neither the exact integer identity nor (3.1). They do not provide an inverse bound.
- **Divergent native jump compensation:** no positive global jump sum is formed. The growing terms cancel in a signed convolution before \(L^2\) is claimed. The unavoidable sign change of \(q_N\) blocks positivity promotion.
- **Low-nullity collar:** no pole-neutral null vector or support enlargement appears.
- **Positive-kernel unstable inverse:** positivity and actual-input decay still do not imply range membership. The new coupling retains the B03 adjoint obstruction.

The new theorem gives B a direct original-contact input and C an all-nullity residue-sensitive adjoint test. The missing independent native coupling would place this particular \(y_f\) in the closure of the actual \(\mathsf A_\varepsilon\) range, or control an unfiltered residue-sensitive exterior observation. That coupling remains **OPEN**.
