# Paths A, B and C: joint Step 4 paper campaign

Date: 13 October 2026.

**Outcome: new paper results and an exact combined closing attempt; Step 4 remains open.**

Read `ABC_Step4_Paper_2026-10-13.pdf` for the narrative synthesis and all detailed new proofs. The opening chapter states the current result and the remaining prime-discrepancy lemma. The proof notes are also available individually under `path_a`, `path_b`, `path_c`, and `cross_path`.

The campaign continues the supplied A03/B04/C05 sources. `inherited_sources` contains selected unchanged proof files used in the new deductions; `SOURCE_MANIFEST.json` records their provenance and SHA-256 hashes. It is a selected dependency set, not a claim to include or independently reprove every file in the earlier archives. `ROOT_REVIEW.md` records the final claim boundaries and corrections.

## Reproduce the exact finite controls

Python 3 with its standard library is sufficient. From this folder run:

```bash
python3 path_a/verify_path_a_exact.py
python3 path_b/exact_controls.py
python3 path_c/verify_path_c_exact.py
python3 cross_path/exact_cross_controls.py
```

Each script writes its result JSON next to itself and fails with an assertion error if a checked identity or intended falsifier changes. `VALIDATION_SUMMARY.json` records the final campaign run. The algebra checks are finite controls; the infinite and analytic statements rely on the written proofs and their inherited premises. No Lean theorem or RH closure is certified by these scripts.

## Regenerate the paper

The `build_paper.py` script assembles the proof chapters and calls Pandoc and XeLaTeX. It requires those tools and the standard TeX packages listed in its header. Rendering intermediates are written to `build`; the final PDF is written in this folder. The source notes preserve their local equation tags, so refer to a chapter together with its equation number.

## File integrity

`PACKAGE_SHA256SUMS.txt` lists the included payload files, excluding itself and the final ZIP. `SOURCE_MANIFEST.json` distinguishes new campaign work from unchanged source dependencies. The PDF and ZIP are new research deliverables; the external repository and original Drive documents were not modified.

## Exact remaining closing target

For the original canonical contact source f0 on [-a,a], let D(p) be its bilateral Laplace transform. The joint paper proves stable same-source transfers to

    P_f0(s) = exp((a+s)/2) D(1/2)
              - sum_{p prime} (log p)/sqrt(p) f0(a+s-log p).

An independent quiet-subsequence upper bound for the cumulative squared norm of this expression would contradict the existing contact leakage law. This package does not prove that upper bound. The A-side equivalent fixed-detector target retains the complete signed masked large-rough-core field and all mixed cofactor terms.
