# The contact does produce a positive spectral function, with the native poles canceled

Status: DERIVED paper theorem and a completed failed native transport.
Round-two date: 2026-10-12. No Lean declaration or RH proof.
The Volterra/Nevanlinna calculation was independently derived by the root
and native-structure branches; BC independently checked the positive-real
conversion and native Dirichlet cancellation.

## 1. Exact source and conventions

Let I=[-a,a]. Assume the native supported Weil operator is PSD and has a
nonzero finite-dimensional nullspace E. Choose the real definite-parity
common generator g of the polynomial-module theorem. Write

    G(z)=integral g(x)exp(-i z x)dx,
    G*(z)=conjugate(G(conjugate(z)))=eta G(z), eta in {+1,-1}.

G has only simple real zeros. All zero sums below run over DISTINCT native
coordinates gamma=-i(rho-1/2), with their multiplicities m_gamma inserted
once. Set

    b_gamma=m_gamma G(gamma)G*(gamma)=m_gamma eta G(gamma)^2,
    S(z)=sum_gamma b_gamma/(z-gamma),
    T_+(z)=sum_gamma m_gamma G(gamma)exp(i a gamma)/(z-gamma),
    T_-(z)=sum_gamma m_gamma G(gamma)exp(-i a gamma)/(z-gamma).

The sampling theorem gives sum |b_gamma|<infinity and
sum m_gamma |G(gamma)|^2<infinity. The native local zero count gives
sum m_gamma/(1+|gamma|^2)<infinity. Cauchy-Schwarz therefore makes T_+ and
T_- absolutely and locally normally convergent away from their poles.
The factors exp(plus or minus i a gamma) are bounded because the zero
coordinates stay in the fixed strip |Im gamma|<1/2. S has the same normal
convergence by absolute summability of b.

Use the polarized form B linear in its first slot:

    B(u,v)=sum_gamma m_gamma F_u(gamma)F_v*(gamma).

Its diagonal is the project's real Weil quadratic form q. This convention
is the conjugate of the alternative convention linear in the second slot;
the identities and PSD statements are unchanged.

## 2. Construct the actual supported Volterra vector and retain its endpoint

For z not real, define, on the open interval I,

    h_z(x)=i exp(i z x) integral_(-a)^x exp(-i z t)g(t)dt,

and extend it by zero outside I. It is H1 inside I. Its left trace is zero,
while its right trace is i exp(i a z)G(z). The zero extension generally
jumps at a. In particular it is not claimed to be globally H1 or in the
domain of the closed momentum operator.

Put D=-i d/dx on distributions and A_z=exp(i a z)G(z). The exact full-line
equation, INCLUDING the endpoint distribution, is

    (D-z)h_z=g-A_z delta_a.                                (1)

Taking the compact-support Fourier transform gives

    F_(h_z)(w)=[G(w)-A_z exp(-i a w)]/(w-z).                (2)

The quotient is removable at w=z. Since G is bounded on the real axis and
in every fixed horizontal strip, (2) is O(1/|w|) on the real axis. Hence
h_z belongs to D_log(I); even a logarithm-squared Fourier weight is
integrable. This is exactly the domain needed to use contact PSD and null
orthogonality. No endpoint delta is inserted into the form domain itself.

## 3. Null orthogonality produces the two source identities

The equations B(g,h_z)=0 and B(h_z,g)=0, using (2), give

    S(z)=eta G(z)exp(i a z)T_-(z)
        =eta G(z)exp(-i a z)T_+(z).                        (3)

One identity is obtained directly and the other by conjugation/parity;
both also follow by writing the two polarized sums. Each manipulation is
absolutely convergent by the estimates in Section 1 and the sampling bound
for h_z. They are first valid away from native zero coordinates and then
hold meromorphically.

These equations already retain a nontrivial source defect. They do not
state that T_+ or T_- vanishes.

## 4. Exact norm identity and the Herglotz function

Define

    M(z)=S(z)/(G(z)G*(z))-Xi'(z)/Xi(z)
        =S(z)/(eta G(z)^2)-Xi'(z)/Xi(z).                   (4)

Then for z not real, initially away from the native zero set,

    q(h_z)/(|G(z)|^2 exp(-2 a Im z))
      = Im M(z)/Im z.                                    (5)

**Direct verification.** Write S0(z)=sum m_gamma/(gamma-z), interpreted
by symmetric gamma,-gamma pairing, so S0=-Xi'/Xi. This is the convergent
even canonical-product logarithmic derivative. Also put

    U_+(z)=sum m_gamma G(gamma)exp(i a gamma)/(gamma-z),
    U_-(z)=sum m_gamma G*(gamma)exp(-i a gamma)/(gamma-z).

On expanding (2) in q(h_z), the numerator of each term is

    G(gamma)G*(gamma)
    -A_z exp(-i a gamma)G*(gamma)
    -conjugate(A_z)exp(i a gamma)G(gamma)+|A_z|^2,

divided by (gamma-z)(gamma-conjugate(z)). Use

    1/[(gamma-z)(gamma-conjugate(z))]
      =[1/(gamma-z)-1/(gamma-conjugate(z))]/(z-conjugate(z)).

The two null identities cancel the corresponding diagonal cross terms.
Conjugation of the native zero set gives
U_-(conjugate(z))=conjugate(U_+(z)). What remains is

    q(h_z)=|A_z|^2
      Im[S0(z)-U_+(z)/A_z]/Im z.

Because -U_+(z)/A_z=exp(-i a z)T_+(z)/G(z), (3) identifies the bracket
with (4). This proves (5). The original quadratic sum is absolutely
convergent; only S0 individually uses the explicit symmetric convention.
Its difference S0(z)-S0(conjugate(z)) is absolutely convergent, so no
unjustified rearrangement changes a constant.

Since q is PSD and G has no nonreal zero, M has nonnegative imaginary part
in the upper half-plane and is a Herglotz/Nevanlinna function there.

## 5. The native poles cancel exactly

At any native zero coordinate gamma where G(gamma)!=0,

    Res_gamma S/[eta G^2]=m_gamma=Res_gamma Xi'/Xi.

Thus the pole in M is removable. This includes every hypothetical
off-line zero, since G has only real zeros, and it includes every native
critical ordinate that is not a zero of G. Multiplicity of a native zero
changes the common residue m_gamma, not the cancellation argument.

Consequently the positive function (4) has no off-real native poles even
when the underlying Xi hypothetically does. Its positivity cannot be
reinterpreted as positivity of Xi'/Xi alone: the first term in (4) carries
and cancels exactly those native poles. This is the concrete obstruction in
the attempted source-to-native-spectrum identification.

## 6. The positive spectral atoms are exactly the common source roots

Let t be any real zero of G; it is simple. The supported real-root division
r_t has transform G(w)/(w-t). It belongs to D_log(I), by the same supported
Volterra construction with zero right trace. It cannot belong to E, since
the polynomial-module theorem would require 1/(z-t) to be a polynomial.
Therefore contact PSD gives q(r_t)>0.

Null polarization gives S(t)=0. Let m_t be the native multiplicity at t,
zero when t is not a native zero. A direct sampling calculation gives

    q(r_t)=-S'(t)+m_t |G'(t)|^2.

The last term is retained when a native zero and a source zero coincide:
the divided transform at that coordinate is G'(t), not zero. Hence

    Res_t M=S'(t)/|G'(t)|^2-m_t
           =-q(r_t)/|G'(t)|^2<0.                          (6)

Equivalently the positive Herglotz mass at t is

    mu_M({t})=q(r_t)/|G'(t)|^2>0.                         (7)

These are all its real singularities. M is real-type meromorphic in the
whole plane, with poles precisely at the simple common zeros of G, so the
representing measure has no additional continuous part. Its support has
only O(T) distinct points up to height T, because G is the transform of a
nonzero compact source. The native critical ordinates have superlinear
count, and all but O(T) of their poles have canceled from M.

Thus this construction does yield a genuine positive spectral measure.
It is the measure of the compact contact source divisor, with exact weights
(7). It is not a measure whose atoms independently retain all native zeros.

### 6A. No linear Herglotz term; the atom weights cannot be uniformly bounded

The general Herglotz representation can also contain a nonnegative linear
term beta z, separate from its representing measure. Here beta=0 follows
from the exact native large-imaginary-axis behavior.

Indeed, G is an entire function of exponential type with only simple real
zeros and definite parity. Its parity-paired Hadamard product has the form

    G(z)=c z^epsilon product_(t>0:G(t)=0) (1-z^2/t^2),
    epsilon in {0,1}, c!=0.

The product converges locally normally since the zero count is O(T);
the possible exponential linear factor is constant by parity. Thus
|G(i y)|>=|c|y^epsilon for y>0. Every native coordinate has
|Im gamma|<1/2, so absolute sampling gives

    |S(i y)|<=sum |b_gamma|/(y-1/2), y>1/2.

The first term in (4) is consequently O(1/y) on the positive imaginary
axis. The xi functional equation and the elementary large-positive-real
expansion of its gamma factor give

    Xi'(i y)/Xi(i y)=-i xi'(1/2+y)/xi(1/2+y),
    xi'(1/2+y)/xi(1/2+y)=(1/2)log(y/(2 pi))+O(1/y).

Therefore

    M(i y)=(i/2)log(y/(2 pi))+O(1/y), y->infinity.         (7a)

It follows that beta=lim_(y->infinity) Im M(i y)/y=0. In
particular the positive measure in (7) has infinite total mass. Its atom
weights cannot be uniformly bounded: if mu_M({t})<=C for all source roots,
their O(T) count and the Stieltjes integral estimate would imply

    Im M(i y)=sum_t mu_M({t}) y/(t^2+y^2)=O(1),

contradicting (7a). For example, integrate against N_G(u)=O(1+u) to obtain
the asserted bounded estimate. Thus q(r_t)/|G'(t)|^2 is unbounded along
the common source roots.

This is a weighted spectral constraint, not a source/native divisor
identification. A finite smooth-quartet modification changes the completed
logarithmic derivative by O(1/y) on this axis; at its own contact the same
argument gives the same leading logarithmic profile. The matched control
therefore satisfies (7a) too.

### 6B. Explicit sparse positive-atom control with the exact native profile

The logarithmic profile does not contradict an O(T) support count. Here is
an explicit control matching both its leading constant and its constant
offset. Put c=2 pi and

    w_n=(1/(2 pi))log(max(n,7)/(2 pi)), n>=1,
    M_ctl(z)=sum_(n>=1) 2 z w_n/(n^2-z^2).              (7b)

Every w_n is strictly positive. The series converges locally normally away
from the integers because sum w_n/n^2<infinity. It is odd, real-type, and
Herglotz: each term is the sum of the two positive-atom resolvents
w_n/(n-z)+w_n/(-n-z). Its positive measure has atoms w_n at both n and -n,
exactly 2 floor(T) distinct support points in [-T,T], and no linear term.

On the positive imaginary axis,

    Im M_ctl(i y)=2 y sum_(n>=1) w_n/(n^2+y^2)
                =(1/2)log(y/(2 pi))+O(1/y).             (7c)

For completeness the O(1/y) error, rather than merely a leading-order
equivalence, follows by elementary summation. Define

    F_y(t)=y log(t/c)/(t^2+y^2), t>0.

The exact integral is

    integral_0^infinity F_y(t)dt=(pi/2)log(y/c),

because the substitution t=y u gives integral log(u)/(1+u^2)du=0 by
u -> 1/u. Euler summation with its second-derivative remainder on [1,infinity)
gives

    sum_(n>=1)F_y(n)-integral_1^infinity F_y(t)dt=O(1/y).

Indeed F_y(1), F_y'(1) are O(1/y), and, writing k_y(t)=y/(t^2+y^2),

    F_y''=k_y'' log(t/c)+2 k_y'/t-k_y/t^2.

The last two terms have L1([1,infinity)) bounds O(1/y^2) and O(1/y), respectively.
The first has bound O((1+log y)/y^2), by t=y u and integrability of
|3u^2-1|(1+u^2)^(-3)(1+|log u|). Hence the full remainder is O(1/y).
The missing integral over (0,1) is also O(1/y). Replacing the first six
possibly negative weights by the positive value in (7b) changes the sum
by O(1/y). Multiplication by 1/pi now proves (7c).

Even the support can be the simple real divisor of a nonzero compact L2
source: G_ctl(z)=sin(pi z)/z is the minus-Fourier transform of
(1/2)1_[-pi,pi], and its zeros are precisely the nonzero integers, all
simple. Thus the profile, support count, source exponential type, real
parity, and simplicity of the source divisor are compatible.

There is also an elementary positive compact-resolvent realization of this
particular control. On L2([-pi,pi]) define the Fourier-series form

    q_ctl(f)=sum_(n in Z, n!=0) w_|n| |F_f(n)|^2,
    Dom(q_ctl)={f:the displayed sum is finite}.

The normalized Fourier exponentials diagonalize the associated operator,
with eigenvalues 2 pi w_|n| tending to infinity and with constants as its
one-dimensional nullspace. The supported Volterra vector for its constant
generator has

    q_ctl(h_z)/(|G_ctl(z)|^2 exp(-2 pi Im z))
      =Im M_ctl(z)/Im z.

For a source root n, the supported divided vector has
q_ctl(r_n)/|G_ctl'(n)|^2=w_|n|, exactly as in (7). This realization uses its
stated Fourier-series form domain; no identification with the exact native
prime form or its global completion is asserted or needed for the control.
It falsifies precisely the proposed incompatibility of positive source-root
atoms, O(T) support, compact-source divisor, and the exact logarithmic
vertical asymptotic. It is not a model of the complete native zeta data.

In particular, the compact-resolvent assertion for q_ctl concerns exactly
[-pi,pi]. On any larger support, the same integer-sampling form has an
infinite-dimensional kernel: multiply G_ctl by the transforms of arbitrary
small-support sources. Its weights w_n are not integer native zero
multiplicities, and its constant null source has C_g(t) identically zero
because all nonzero-integer samples vanish. Thus it does not satisfy the
all-aperture compactness or the strict native critical-energy balance used
elsewhere in the campaign. These limitations are why (7b) is used only
against the stated high-energy/support-count incompatibility, not against
the complete native contact construction or the no-silent-window theorem.

## 7. The correction is an invariant of the entire nullspace

Let r=dim E. Every null vector has transform F_f=pG, deg p<=r-1. Put
p*(z)=conjugate(p(conjugate(z))). Its reflected coefficient is

    b_gamma^(f)=p(gamma)p*(gamma)b_gamma^(g).

The moment nullity sum gamma^ell b_gamma^(g)=0 for ell<=2r-2 makes the
polynomial difference quotient vanish after summation, and gives exactly

    S_f(z)=p(z)p*(z)S_g(z).                               (8)

Indeed [p(gamma)p*(gamma)-p(z)p*(z)]/(z-gamma) is a polynomial in gamma of
degree at most 2r-3, and its moments vanish; constant p is immediate.
The weighted absolute sampling result justifies this finite polynomial
summation. Therefore

    S_f/(F_f F_f*)=S_g/(G G*).                             (9)

The M in (4) is consequently independent of the nonzero chosen null vector.
Any extra polynomial roots of F_f cancel from (9). This is a canonical
contact invariant, not an additional independent positivity premise.

## 8. Exact comparison to the exterior Laplace residual

Use the root record's same-source definitions

    v(s)=(W*g)(a+s),
    V(p)=integral_0^infinity v(s)exp(-p s)ds,
    B_g(p)=exp(a p)G(-i p).

The exterior L2 theorem makes V an ordinary Laplace transform for
Re p>1/2, followed by its proved meromorphic continuation. The residue
formula, or the absolutely convergent source sum in its initial domain,
gives V(i z)=-i T_+(z). Thus (3)-(4) give the exact identity

    M(z)=-Xi'(z)/Xi(z)+i V(i z)/B_g(i z).                 (10)

With p in the right half-plane define

    P(p)=xi'(1/2+p)/xi(1/2+p)-V(p)/B_g(p).               (11)

The real-type/odd symmetry of M gives P(p)=-i M(i p)=i M(-i p), so
Re P(p)>=0. The positive-real function is the COMPLETED LOGARITHMIC
DERIVATIVE MINUS THE EXACT EXTERIOR QUOTIENT. The quotient cannot be
dropped: its residues cancel the prohibited native poles.

## 9. Insert the exact native Dirichlet formula: the zeta term disappears

Set tau_k=2k+1/2 and let J_(a,g) be the finite entire interior-prime
correction defined in the root's equation (4.1). Substituting its complete
equation (4.2) into (11) cancels zeta'/zeta exactly and yields

    P(p)=1/(p+1/2)-(log pi)/2+(1/2)digamma(p/2+1/4)
       +[B_g(p)-B_g(1/2)]/[B_g(p)(p-1/2)]
       -J_(a,g)(p)/B_g(p)
       +sum_(k>=1) B_g(-tau_k)/[B_g(p)(p+tau_k)].          (12)

The pole at p=1/2 is removable. At p=-1/2, the pole of 1/(p+1/2) cancels
the first pole of the half-digamma term. The remaining negative-real
archimedean poles p=-tau_k, k>=1, cancel with the corresponding series
terms as established in the native residual note.
The source B_g has no zero off the imaginary p axis.

This is a real, source-specific positivity law, but it is not the desired
native zero exclusion: the very native logarithmic derivative whose poles
were to be excluded has canceled from the positive object. Equation (12)
involves the archimedean part and finite interior-prime correction determined
by the contact. It does not bound V/B_g, which retains the full signed
prime tail and all hypothetical off-line residues.

## 10. Match the quartet falsifier without changing the contact witness

At the smooth-quartet model's OWN contact, every argument above applies
with its complete W_new and Xi_new. The model's real-zero generator has
the same module and Volterra domains. Its M_new is Herglotz; the inserted
off-line poles cancel between the two terms in (4) just as the native ones
do. Thus (4)-(7) do not contradict that model.

For a fixed real-zero model-contact generator f, the exact exterior
positive-real expression changes
by

    P_new(p)-P_native[f](p)
      =sum_(inserted lambda) [1-B_f(lambda)/B_f(p)]/(p-lambda).
                                                                  (13)

The inserted poles in (13) are removable because B_f(lambda)!=0 at every
inserted off-real coordinate, but the analytic remainder is generally
nonzero. For an arbitrary source that vanishes at an inserted coordinate,
the displayed difference need not have a removable pole; the generator
premise is substantive. One must not claim that the whole correction is unchanged.
At the model contact, f need not be a native contact, so positivity cannot
be imposed on P_native[f] separately.

## 11. Outcome of the attempted native closure

The proposed construction has been carried through: it produces an actual
positive Herglotz function, its exact positive spectral atoms, a nullspace
invariance theorem, and an explicit native Dirichlet expression. Its pole
calculation establishes why it does not prove RH. Positivity belongs to the
source correction after all native zero poles have canceled. Recovering a
positive-real law for the uncorrected native logarithmic derivative would
require independent control of V/B_g, precisely the exterior information
that remains open. No additional norm bound on that term was obtained.

The classical connection is to de Branges/Krein positive spectral functions;
no priority claim is made for that general method. The same-source domains,
the endpoint delta in (1), the exact cancellations (6),(10),(12), and the
matched quartet remainder (13) are the proof-bearing content for this
project's current interface.

For the classical meromorphic Herglotz representation used in Section 6,
see Jakob Reiffenstein, *Higher-order interlacing for matrix-valued
meromorphic Herglotz functions*, https://arxiv.org/pdf/2108.10746v3,
Theorem 2.2, in its scalar specialization. Its positive atoms are negative
residues, with no continuous part in the meromorphic real-type case.
The actual function M and its precise source-zero weights are derived here,
not imported from that theorem as an unproved identification with Xi.
