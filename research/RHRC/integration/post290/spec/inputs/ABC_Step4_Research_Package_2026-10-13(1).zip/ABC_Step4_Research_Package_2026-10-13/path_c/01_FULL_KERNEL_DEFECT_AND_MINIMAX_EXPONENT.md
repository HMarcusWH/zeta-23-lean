# Path C continuation — full-kernel range defect and exact weakest exterior exponent

Date: 13 October 2026. **DERIVED / PAPER, conditional on the supplied full-contact and operator-domain foundations.** This note advances the all-nullity source analysis. It does not prove the missing native upper estimate or RH. No Lean claim is made.

## 1. Fixed native objects and imported inputs

Keep one hypothetical full native PSD contact on \(I=[-a,a]\):

\[
H_a\ge0,\qquad E=\ker H_a,\qquad 1\le r=\dim_{\mathbb C}E<\infty.
\]

The supplied source theorem gives a real definite-parity generator \(f_0\),

\[
G(z)=\int_{-a}^a f_0(x)e^{-izx}\,dx,\qquad
\widehat E=G\,\mathbb C[z]_{<r}.
\tag{1.1}
\]

All zeros of \(G\) are real and simple. In particular, \(G(\gamma)\ne0\) whenever \(\operatorname{Im}\gamma\ne0\). Formula (1.1) is an actual operator-domain theorem: a polynomial of degree below \(r\) gives a member of the same contact kernel. It is not an instruction to smooth a null vector or enlarge its support.

Write \(F_f=GP_f\) for \(f\in E\), \(\lambda_\rho=\rho-1/2\), and \(\gamma_\rho=-i\lambda_\rho\). All native zero sums below run over **distinct zeros**, with their multiplicities \(m_\rho\) inserted once.

The exact full Weil quadratic form and its sampling theorem give

\[
q_a(f)=\sum_\rho m_\rho F_f(\gamma_\rho)
                 \overline{F_f(\overline{\gamma_\rho})}=0,
\tag{1.2}
\]

with absolute convergence. In particular, no off-line product is replaced by a modulus square. The operator-domain weighted sampling theorem supplies the absolute convergence and the weighted spectral synthesis used below.

For every \(f\in E\), keep its original right exterior and actual C05 input:

\[
v_f(s)=(W*f)(a+s),\qquad a_N*v_f=y_f,
\tag{1.3}
\]

\[
e^{\tau s}y_f\in L^2(0,\infty)\quad(0\le\tau<1/2),
\tag{1.4}
\]

where \(a_N\) is the unchanged native positive kernel and

\[
A(p)=c_0(p)\zeta(p+1/2),\qquad
c_0(p)=\frac{p-1/2}{(p+1/2)(p+1)}.
\]

The compact companion for this \(f\) is \(c_f=-P_I(W_+*f)\). C05's source construction applies to any compact actual operator-domain source with its own compressed companion; the contact null identity gives the particular causal exterior formula used here. Thus its linear extension from \(f_0\) to all of \(E\) is legitimate.

On the original safe half-plane,

\[
V_f(p)=e^{ap}\{F_f(-ip)J(p)+F_{c_f}(-ip)\},\qquad
J(p)=\frac{\xi'}{\xi}(1/2+p).
\tag{1.5}
\]

At a right zero of multiplicity \(m\),

\[
\operatorname{Res}_{p=\lambda}V_f(p)
  =m e^{a\lambda}F_f(-i\lambda).
\tag{1.6}
\]

This residue may vanish for a noncanonical member of the kernel. Tracking that possibility is the point of the present note.

## 2. Multiplicity collapses to one source evaluation

Fix \(\epsilon>0\). Let

\[
\mathcal Z_\epsilon=
\{\rho:\zeta(\rho)=0,\ \operatorname{Re}\rho>1/2+\epsilon\},
\]

where each distinct zero occurs once, and let \(N_\epsilon\) be its cardinality, possibly infinite. B04 proves

\[
\overline{\operatorname{Ran}\mathsf A_\epsilon}
\longleftrightarrow B_\epsilon H^2(\mathbb C_+),
\qquad
\mathsf A_\epsilon g=(e^{-\epsilon\cdot}a_N)*g.
\tag{2.1}
\]

The Blaschke zeros are \(\lambda_\rho-\epsilon\), with the actual native multiplicities. Hence membership requires all Laplace jets of orders \(0,\ldots,m_\rho-1\) to vanish at each such point.

**Theorem 2.1 (exact kernel-source range test).** For \(f\in E\),

\[
\boxed{
e^{-\epsilon\cdot}y_f\in
\overline{\operatorname{Ran}\mathsf A_\epsilon}
\quad\Longleftrightarrow\quad
P_f(\gamma_\rho)=0\quad\text{for every }\rho\in\mathcal Z_\epsilon.
}
\tag{2.2}
\]

**Proof.** Near a multiplicity-\(m\) zero \(\lambda\),

\[
A(p)=\frac{c_0(\lambda)\zeta^{(m)}(\rho)}{m!}
       (p-\lambda)^m+O((p-\lambda)^{m+1}).
\]

Equation (1.5) has at most a simple pole. Therefore \(Y_f=A V_f\) has vanishing jets below \(m-1\), and

\[
Y_f^{(m-1)}(\lambda)
=c_0(\lambda)e^{a\lambda}
 F_f(\gamma_\rho)\zeta^{(m)}(\rho).
\tag{2.3}
\]

If \(F_f(\gamma_\rho)=0\), the pole of \(V_f\) is removable; \(Y_f\) then vanishes to order at least \(m\), so all required jets vanish. If it is nonzero, (2.3) is the failed highest jet. Since \(G(\gamma_\rho)\ne0\) at a right zero, the condition is exactly \(P_f(\gamma_\rho)=0\). Apply the necessary and sufficient B04 range test at every zero. QED.

Thus a multiplicity-\(m\) native zero supplies \(m\) Hardy range tests, but for these **actual contact inputs** their failure has rank one in the source variable. One polynomial root, not \(m\) repeated polynomial roots, cancels the defect at that native zero.

Let \(\Pi_\epsilon\) be orthogonal projection onto
\((\overline{\operatorname{Ran}\mathsf A_\epsilon})^\perp\), and define

\[
\mathcal D_\epsilon:E\longrightarrow L^2(0,\infty),\qquad
\mathcal D_\epsilon f=\Pi_\epsilon(e^{-\epsilon\cdot}y_f).
\]

The map is linear and bounded, because \(E\) is finite dimensional and the actual-input construction is linear.

**Corollary 2.2 (defect rank).**

\[
\boxed{
\dim\ker\mathcal D_\epsilon=\max(r-N_\epsilon,0),\qquad
\operatorname{rank}\mathcal D_\epsilon=\min(r,N_\epsilon).
}
\tag{2.4}
\]

For infinite \(N_\epsilon\), these mean kernel dimension zero and rank \(r\). Indeed evaluation at \(N_\epsilon\) distinct nodes has rank \(\min(r,N_\epsilon)\) on polynomials of degree below \(r\). Finite evaluation matrices are ordinary Vandermonde matrices. This is rank of the **restricted source-to-defect map**, not dimension of the full Hardy model space; the latter still counts native multiplicity.

## 3. The all-right evaluation map is injective

**Theorem 3.1 (no contact vector can cancel every right zero).** If \(f\in E\) satisfies

\[
F_f(\gamma_\rho)=0
\qquad\text{for every native }\rho\text{ with }\operatorname{Re}\rho>1/2,
\tag{3.1}
\]

then \(f=0\). Consequently there are at least \(r\) distinct right zeros under the hypothetical contact assumptions.

**Proof, including complex-source conventions.** The native reflection \(\rho\mapsto1-\overline\rho\) sends \(\lambda\mapsto-\overline\lambda\) and hence \(\gamma\mapsto\overline\gamma\). A right zero has \(\operatorname{Im}\gamma<0\); its reflected left partner has \(\operatorname{Im}\gamma>0\). Their two terms in (1.2) are

\[
m F_f(\gamma)\overline{F_f(\overline\gamma)},\qquad
m F_f(\overline\gamma)\overline{F_f(\gamma)}.
\]

Assumption (3.1) makes both zero, even if \(f\) is complex and has no definite parity. Absolute convergence permits removing every such reflected pair. The remaining terms are precisely critical-line terms, where \(\gamma\in\mathbb R\), so (1.2) becomes

\[
0=\sum_{\operatorname{Re}\rho=1/2}m_\rho
       |F_f(\gamma_\rho)|^2.
\tag{3.2}
\]

Every summand is nonnegative; all evaluations at critical-line ordinates vanish.

The supplied primary-source count of simple critical-line zeros gives at least \(cT\log T\) distinct real ordinates up to \(T\), for all sufficiently large \(T\). A nonzero compactly supported \(L^2\) transform is an entire function of finite exponential type and has only \(O(T)\) zeros in the disk \(|z|\le T\), by Jensen's formula. Thus (3.2) forces \(F_f\equiv0\) and \(f=0\).

If the total number \(N_0\) of distinct right zeros were below \(r\), the nonzero polynomial
\(P(z)=\prod_{\rho\in\mathcal Z_0}(z-\gamma_\rho)\)
would have degree below \(r\). Its corresponding actual contact vector \(F_f=GP\) would satisfy (3.1), a contradiction. QED.

This argument does **not** claim that all original canonical critical evaluations vanish. It proves that an attempted cancellation of every right evaluation would force that impossible consequence. The role of critical-line positivity is confined to the already canceled off-line sum (3.2).

**Corollary 3.2 (full defect at sufficiently small damping).** There exists \(\epsilon_0>0\), depending on this fixed contact, such that

\[
\ker\mathcal D_\epsilon=\{0\},\qquad
\operatorname{rank}\mathcal D_\epsilon=r
\quad(0<\epsilon<\epsilon_0).
\tag{3.3}
\]

Choose any \(r\) distinct right zeros and take \(\epsilon_0\) below their minimum positive displacement. No uniform lower bound on zeta derivatives or zero displacement is needed.

## 4. Uniform lower leakage on the full contact kernel

Fix \(r\) distinct right zeros \(\rho_1,\ldots,\rho_r\), with multiplicities \(m_j\), and fix

\[
0\le\epsilon<\min_j\operatorname{Re}\lambda_j,
\quad \delta_j=\operatorname{Re}\lambda_j-\epsilon>0,
\quad \delta_* =\min_j\delta_j.
\]

For \(f\in E\), define exactly

\[
x_{f,T}=1_{[0,T]}e^{-\epsilon\cdot}v_f,\qquad
e_{f,T}=e^{-\epsilon\cdot}y_f-\mathsf A_\epsilon x_{f,T}.
\tag{4.1}
\]

Both are actual \(L^2\) functions and \(e_{f,T}=0\) on \([0,T]\). C05's centered Laguerre jet calculation applies to each zero, including a zero at which the particular \(F_f\) vanishes; in that case its lower bound is zero. It gives

\[
\|e_{f,T}\|_2\ge b_j|F_f(\gamma_j)|e^{\delta_jT},
\tag{4.2}
\]

where the fixed positive constants are

\[
b_j=
\frac{|c_0(\lambda_j)e^{a\lambda_j}\zeta^{(m_j)}(\rho_j)|
      (2\delta_j)^{m_j-1/2}}{(m_j-1)!}>0.
\tag{4.3}
\]

The finite weighted evaluation map is invertible on \(E\):

\[
\kappa^2:=
\min_{\|f\|_2=1,\ f\in E}
\sum_{j=1}^r b_j^2|F_f(\gamma_j)|^2>0.
\tag{4.4}
\]

This is compactness of a fixed finite-dimensional unit sphere plus the Vandermonde determinant, not a zero-uniform estimate. Summing the \(r\) squared bounds (4.2) yields

\[
\|e_{f,T}\|_2\ge\frac\kappa{\sqrt r}
 e^{\delta_*T}\|f\|_2.
\tag{4.5}
\]

The linear input map has a fixed finite norm
\(K_\epsilon=\sup_{\|f\|_2=1}\|e^{-\epsilon\cdot}y_f\|_2<\infty\).
With \(M_\epsilon=\|\mathsf A_\epsilon\|\), the triangle inequality gives

\[
\|x_{f,T}\|_2\ge
\frac{\kappa e^{\delta_*T}/\sqrt r-K_\epsilon}{M_\epsilon}
\|f\|_2.
\tag{4.6}
\]

Consequently, for all sufficiently large \(T\), **uniformly for every \(f\in E\)**,

\[
\boxed{
\int_0^T e^{-2\epsilon s}|v_f(s)|^2ds
\ge C e^{2\delta_*T}\|f\|_2^2.
}
\tag{4.7}
\]

The constant and horizon threshold depend on the fixed contact and the chosen finite zeros. They do not depend on the contact vector or on a rule \(f=f_T\) that changes that vector with the horizon.

No cross-zero orthogonality or uniform separation is used. The single-zero Laguerre bounds suffice; the factor \(\sqrt r\) is a harmless finite aggregation cost.

## 5. Exact minimax exponential rate

The lower result has a matching upper result using the actual polynomial module. Define the \(r\)-th distinct-zero displacement level

\[
\Delta_r:=\sup\{d\ge0:
\#\{\rho:\operatorname{Re}\rho>1/2+d\}\ge r\}.
\tag{5.1}
\]

The count is of distinct right zeros, including both signs of the ordinate as distinct nodes. Theorem 3.1 gives \(\Delta_r>0\). Set \(\Delta=\sup_{\operatorname{Re}\rho>1/2}(\operatorname{Re}\rho-1/2)\), which equals the full reflected zero width. Then \(\Delta_r\le\Delta\le1/2\). A largest or \(r\)-th largest zero need not exist; the supremum definition covers that case.

Let

\[
\mathcal M_\epsilon(T)=
\inf_{f\in E,\ \|f\|_2=1}
\int_0^T e^{-2\epsilon s}|v_f(s)|^2ds.
\tag{5.2}
\]

**Theorem 5.1 (exact weakest full-kernel exponent).** For every \(\epsilon\ge0\),

\[
\boxed{
\lim_{T\to\infty}\frac1T\log(1+\mathcal M_\epsilon(T))
=2(\Delta_r-\epsilon)_+.
}
\tag{5.3}
\]

**Lower bound.** If \(\epsilon<\Delta_r\), fix \(d\in(\epsilon,\Delta_r)\). There are \(r\) distinct right zeros with displacement greater than \(d\). Apply (4.7) to them. This gives a lower logarithmic limit at least \(2(d-\epsilon)\), uniformly on the unit sphere. Let \(d\uparrow\Delta_r\) **after** the lower limit in \(T\). If \(\epsilon\ge\Delta_r\), nonnegativity supplies the required lower bound zero.

**Upper bound, with all canceled sources kept in the original kernel.** Fix \(d>\Delta_r\). There are at most \(r-1\) distinct right zeros with displacement greater than \(d\). Form the finite polynomial

\[
P_d(z)=\prod_{\operatorname{Re}\lambda_\rho>d}
                    (z-\gamma_\rho).
\tag{5.4}
\]

The empty product is one. Since \(\deg P_d<r\), it defines a nonzero actual vector \(f_d\in E\); normalize it in \(L^2\). Equation (1.6) and the exact spectral synthesis remove all right exponents above \(d\). All remaining right exponents are at most \(d\), critical exponents have real part zero, and left exponents have negative real part.

Here is the full source identification behind that invocation of spectral synthesis. It is needed because cancellation of finitely many meromorphic poles, by itself, would not imply an \(H^2\) bound. Absorb the fixed normalization into \(P_d\), and put \(Q(p)=P_d(-ip)\), so \(f_d=Q(\partial_x)f_0\). Every derivative used has order below \(r\), and is an actual operator-domain kernel vector. Proper convolution commutes with these distributional derivatives; thus on the **open** exterior \(s>0\),

\[
v_{f_d}=Q(\partial_s)v_{f_0}
\quad\text{as distributions}.
\tag{5.4a}
\]

No derivative of a causal zero extension at \(s=0\) is taken in (5.4a), so no endpoint term is dropped. Both sides have the actual locally \(L^2\) representatives supplied by the operator-domain theorem.

For a fixed safe \(c>\Delta\), the supplied C2 theorem represents \(e^{-cs}v_{f_0}\) as the \(L^2\) limit of finite sums

\[
\sum_{\rho\in\mathcal F}m_\rho G(\gamma_\rho)
       e^{a\lambda_\rho}e^{(\lambda_\rho-c)s}.
\]

Undamping on compact subintervals of \(s>0\) gives distributional convergence. Applying \(Q(\partial_s)\) is continuous in that distribution topology and replaces \(G(\gamma_\rho)\) by
\(Q(\lambda_\rho)G(\gamma_\rho)=F_{f_d}(\gamma_\rho)\).
Independently, the full operator-domain logarithmic sampling theorem applies to \(f_d\) and the same weighted synthesis estimate proves \(L^2\) convergence of these new coefficients at \(c>\Delta\). The two limits coincide distributionally on \(s>0\), so this new \(L^2\) sum is exactly the actual \(e^{-cs}v_{f_d}\). This establishes the same-source spectral expansion without assuming additional smoothness.

For completeness, the inherited weighted synthesis proof applies to this restricted coefficient set without alteration. Its operator-domain estimate gives

\[
\sum_\rho m_\rho\log(2+|\gamma_\rho|)
                    |F_{f_d}(\gamma_\rho)|^2<\infty.
\]

For any \(\alpha>d\), the uncanceled Laplace sampling nodes
\(\alpha-\overline{\lambda_\rho}\)
have real parts bounded below by \(\alpha-d>0\), bounded above by \(\alpha+1/2\), and the same unconditional local weighted count as before. The same disk mean-value and Plancherel argument therefore constructs

\[
e^{-\alpha s}v_{f_d}(s)\in L^2(0,\infty).
\tag{5.5}
\]

To identify this new synthesis at \(\alpha>d\) with the actual exterior, take \(c>\max(\alpha,\Delta)\). Multiplication by \(e^{-(c-\alpha)s}\) is bounded on \(L^2\). Applied to each finite partial sum at \(\alpha\), it gives the corresponding partial sum at \(c\), whose limit has just been proved to be the actual \(e^{-cs}v_{f_d}\). Uniqueness of \(L^2\) limits proves that the synthesis at \(\alpha\) is the actual \(e^{-\alpha s}v_{f_d}\). This uses no inference from pole cancellation alone and no additional Sobolev derivative beyond the contact theorem. Hence

\[
\mathcal M_\epsilon(T)
\le \|e^{-\alpha\cdot}v_{f_d}\|_2^2
 e^{2(\alpha-\epsilon)_+T}.
\tag{5.6}
\]

First take the upper limit in \(T\), then take \(\alpha\downarrow d\), and finally \(d\downarrow\Delta_r\). This proves the upper bound in (5.3). There is no uniform constant as \(d\) approaches \(\Delta_r\), and none is required. QED.

The same exponent holds if the infimum is restricted to the real full contact kernel. The high-displacement set in (5.4) is closed under \(\rho\mapsto\overline\rho\), hence its \(\gamma\)-nodes are closed under \(\gamma\mapsto-\overline\gamma\). Multiplying \(P_d\) by a constant phase makes \(P_d^\#(z)=P_d(-z)\), which is precisely the reality condition for \(G P_d\), since \(G^\#=G(-z)=\eta G\). Alternatively write the annihilating polynomial in \(p=i z\), where its roots \(\lambda_\rho\) form conjugate pairs and its coefficients are real. A definite-parity restriction is a smaller optimization problem and is not identified with (5.2).

## 6. What this rules out, and what it does not prove

The canonical source sees every right zero and has exponent governed by \(\Delta=\sup\operatorname{Re}\lambda_\rho\). A different null vector can cancel a finite selection of those residues. The full kernel can spend at most \(r-1\) polynomial roots on that cancellation, and the exact weakest remaining rate is governed by \(\Delta_r>0\).

In particular, a proposed closure strategy that chooses a new normalized null vector at each increasing horizon cannot escape exponential exterior growth. Its missing estimate would have to contradict (4.7) or (5.3); selecting vectors alone does not supply such an estimate.

This is a new restriction on the possible contact-based closing argument. It still supplies a **lower** law. It does not derive the native quiet-subsequence upper law, native range membership, or a stable inverse. There is no contradiction in the proved statements: a hypothetical non-RH contact necessarily exhibits the positive exterior rate (5.3).

## 7. Source and validation record

The proof uses the supplied source contents, with no external writes:

1. C05 `root/03_COMPLETE_NATIVE_CHAIN_AND_ONE_OPEN_COUPLING.md`, §§1–4: native full-contact setup, polynomial module, original exterior, actual-input construction, highest input jet, and centered leakage.
2. C05 `b_residue_range/01_COMPLETED_NATIVE_FORWARD_KERNEL_AND_ORIGINAL_EXTERIOR.md`, especially §4's statement that the construction works for any compact actual domain source with its own companion.
3. B04 `proofs/02_HARDY_RANGE_AND_ZERO_TEST.md`: necessary and sufficient closed-range jet conditions.
4. C05 inherited C2 `native_structure/CONTACT_NEVANLINNA_CORRECTION.md`, §1: complex-polarized Weil form and absolute sampling.
5. C05 inherited C2 `bc_orbit/EXTERIOR_L2_ABSCISSA.md`, §§2–5: full operator-domain logarithmic sampling and weighted spectral synthesis.
6. C05 inherited C04 `authority/NO_GLOBAL_FINITE_TYPE_QUOTIENT.md`, §§1–2: already checked primary simple-critical-zero count and elementary Jensen bound.

The new work is the restriction of the complete range test to the entire polynomial module, the all-right injectivity argument, uniform leakage on its unit sphere, and the matching minimax exponent. These are mathematical deductions from the above PAPER premises, not numerical extrapolations or a new audit of every inherited premise.
