# Path B independent review and the final contraction iteration

**Date:** 2026-10-13. **Status:** new paper review and derivation. The contact foundation remains the supplied paper premise. This note independently checks the new Path C source contraction and the joint even-shift reduction, then carries one further native closing attempt through its full causal domain.

## 1. Sources reviewed

- [Path C: source-tilt contraction and gamma-free forcing](../path_c/02_SOURCE_TILT_CONTRACTION_AND_GAMMA_FREE_FORCING.md).
- [Joint campaign: even-shift family and prime-only target](../cross_path/02_EVEN_SHIFT_FAMILY_AND_PRIME_ONLY_TARGET.md).
- [Path B: shifted native sensor and exact defect](01_SHIFTED_NATIVE_SENSOR_AND_GAMMA_FREE_DEFECT.md).
- [Path A: joint source bridge, Section 5](../path_a/05_JOINT_SOURCE_BRIDGE_AND_CLOSING_ATTEMPT.md).

The scalar and full-nullity contraction, the source and history factors, the general even-shift endpoints, and the positive-damping prime-power remainder are consistent. No omitted endpoint distribution or unjustified global-input assumption was found in those arguments.

## 2. Scalar source contraction: independent check

The canonical transform has the paired product
\[
D(p)=C p^\nu\prod_k(1+p^2/\gamma_k^2),\qquad \nu\in\{0,1\},
\]
because the entire source has exponential type, simple imaginary-axis zeros, and definite parity. The exponential factor in the order-one Hadamard product is constant by parity.

For \(h>0\),
\[
T_h(p)=\frac{D(p)}{D(p+h)}
\]
is holomorphic on \(\Re p>0\). Each paired linear factor has modulus at most one there, since adding \(h\) increases the distance to each imaginary-axis zero. The locally normal limit preserves the bound
\[
\|T_h\|_{H^\infty(\mathbb C_+)}\le1.
\]
The possible factor \(p/(p+h)\) in the odd case has the same bound.

Let \(f_+(t)=f_0(t-a)\), \(L=2a\), and \(F_+(p)=e^{-ap}D(p)\). Its exact recovery multiplier is
\[
S_h(p)=e^{ah}T_h(p),\qquad S_h(p)F_+(p+h)=F_+(p).
\]
The factor \(e^{ah}\) is necessary. Tilting the complete source equation contributes the separate factor \(e^{-Lh}\) to its delayed exterior. Consequently the feedback operator is
\[
\mathsf B_h=e^{-ah}\mathsf T_h\mathsf M_h,\qquad
\mathsf M_h u(t)=e^{-ht}u(t).
\tag{2.1}
\]
This has norm at most \(q_h=e^{-ah}<1\).

With \(k_h=(1-e^{-ht})W_+\), the complete identity is
\[
k_h*f_+ +c_+-\mathsf S_h\mathsf M_hc_+
=T_L[(I-\mathsf B_h)v].
\tag{2.2}
\]
The separate terms on the left need not vanish before \(L\). Their complete sum does. After advancing, the compact \(c_+\) term has no positive-time tail, while the advanced term from \(\mathsf S_h\mathsf M_hc_+\) remains as the stable history correction \(j_h\).

For every locally square-integrable \(v\), causality and boundedness on truncated inputs give
\[
(1-q_h)\|v\|_{\epsilon,[0,T]}
\le\|(I-\mathsf B_h)v\|_{\epsilon,[0,T]}
\le(1+q_h)\|v\|_{\epsilon,[0,T]},
\tag{2.3}
\]
for all \(T>0\) and \(\epsilon\ge0\). Damping replaces \(T_h(p)\) by \(T_h(p+\epsilon)\); it does not change the bound \(q_h\). This proof is local on the input and does not assume the unknown exterior belongs to global \(L^2\).

If the forcing belongs to global \(L^2_\epsilon\), the global Neumann inverse is legitimate, and it agrees with the original exterior: a locally \(L^2\) difference satisfying \(u=\mathsf B_hu\) has zero norm on every prefix by (2.3). The domain issue is therefore genuinely resolved, subject to the forcing hypothesis.

## 3. Full-nullity matrix: independent check

For \(0\le j<r\), the inherited supported-domain theorem allows the actual kernel source \(f_j=\partial_x^j f_0\). Its transform is
\[
F_{j,+}(p)=e^{-ap}p^jD(p).
\]
The available zero-extension regularity justifies these derivatives through \(r-1\), with no endpoint atom. No derivative of order \(r\) is used.

The lower-triangular matrix
\[
C(-h)_{jk}=\binom jk(-h)^{j-k}\quad(k\le j)
\]
satisfies
\[
\sum_{k=0}^j C(-h)_{jk}(p+h)^k=p^j.
\]
Thus
\[
\mathbf F_+(p)=e^{ah}T_h(p)C(-h)\mathbf F_+(p+h)
\]
is exact. Each basis source retains its own actual companion; equality with derivatives of a single companion is unnecessary and is not assumed.

Writing \(C(-h)=e^{-hN}\), \(N_{j,j-1}=j\), and using weights
\[
w_j=(a/2)^j/j!,
\]
the transformed shift coefficients are \(j w_j/w_{j-1}=a/2\). Therefore \(\|N\|_w\le a/2\), and
\[
\|\mathsf B_h^{(r)}\|_w
\le e^{-ah}\|C(-h)\|_w
\le e^{-ah/2}<1.
\]
The same weighted-prefix and local-uniqueness proof applies. For \(r=1\), the sharper scalar bound is retained. These are valid finite-dimensional norm statements and do not impose an extra nullity assumption.

## 4. A further exact closing attempt: iterate the source contraction

The source filters have more structure than an arbitrary family of contractions:
\[
T_h(p)T_k(p+h)
=\frac{D(p)}{D(p+h)}\frac{D(p+h)}{D(p+h+k)}
=T_{h+k}(p).
\]
Since time damping shifts a Laplace multiplier, it follows that
\[
\boxed{\mathsf B_h\mathsf B_k=\mathsf B_{h+k}.}
\tag{4.1}
\]
For the full-nullity lift the matrices also multiply exactly:
\[
C(-h)C(-k)=C(-(h+k)),
\]
so (4.1) holds for the matrix operators in their stated weighted norm as well.

Let \(u_h=(I-\mathsf B_h)v=z_h-j_h\), where \(z_h\) is the actual source forcing. For each integer \(N\ge1\), local causality gives the exact telescope
\[
\boxed{
\sum_{j=0}^{N-1}\mathsf B_{jh}u_h
=v-\mathsf B_{Nh}v.
}
\tag{4.2}
\]
This is an actual original-source identity, not merely a formal inverse series.

### The returned terms are independently stable

For \(h>1/2\), the rough native exterior satisfies
\[
\mathsf M_h v\in L^2.
\tag{4.3}
\]
This uses only the safe half-plane. Indeed, \(J(p+h)\) has an absolutely convergent prime logarithmic derivative and at most logarithmic gamma growth. Thus \(e^{-ht}W_+\) maps a compact \(H^s\) source, for any fixed \(s>0\), into \(L^2\). Apply this to the tilted complete source equation, retaining its compact companion and finite shift. No critical-strip zero-free estimate is used in (4.3).

For every \(N\ge1\),
\[
\|\mathsf B_{Nh}v\|_2
\le e^{-aNh}\|\mathsf M_{Nh}v\|_2
\le e^{-aNh}\|\mathsf M_hv\|_2\longrightarrow0.
\tag{4.4}
\]
Also \(\mathsf M_hu_h\in L^2\), because \(u_h=v-\mathsf B_hv\) and both terms become stable after that damping. For \(j\ge1\),
\[
\|\mathsf B_{jh}u_h\|_2
\le q_h^j\|\mathsf M_hu_h\|_2.
\]
Hence
\[
\sum_{j=1}^\infty\mathsf B_{jh}u_h
\]
converges absolutely in global \(L^2\). Equations (4.2)–(4.4), restricted to any fixed finite interval before passing to the limit, prove
\[
\boxed{
v=u_h+\sum_{j=1}^\infty\mathsf B_{jh}u_h,
\qquad
\left\|\sum_{j=1}^\infty\mathsf B_{jh}u_h\right\|_2
\le\frac{q_h}{1-q_h}\|\mathsf M_hu_h\|_2.
}
\tag{4.5}
\]
This proof is valid even if \(v\) and \(u_h\) themselves fail to belong to global \(L^2\). The unweighted matrix version uses \(q_h=e^{-ah/2}\) and the vector norm. The positive-damping scalar and matrix versions follow in the same way.

### Exact stopping point of the iteration

The whole returned series in (4.5) is controlled. Its first, unreturned term \(u_h=z_h-j_h\) is the unknown gamma-free forcing. Thus the strict contraction yields
\[
\text{original exterior}=\text{same uncancelled forcing}
 +\text{an independently stable correction}.
\]
It supplies no upper bound on the first term.

The transform gives the same conclusion explicitly. Using
\[
V(p)=e^{ap}[D(p)J(p)+D_c(p)]
\]
and (2.1),
\[
U_h(p)=e^{ap}\left[
D(p)(J(p)-J(p+h))
+D_c(p)-T_h(p)D_c(p+h)
\right].
\tag{4.6}
\]
The finite sum in (4.2) telescopes the consecutive differences
\[
J(p+jh)-J(p+(j+1)h).
\]
It leaves coefficient one on the unshifted \(J(p)\). The companion terms telescope at the same time and must be retained; dropping them would not preserve the exact source or its history.

For \(h>1/2\), \(V(p+h)\) and therefore the transform of \(\mathsf B_hv\) are holomorphic on \(\Re p>0\). Hence every native right-zero residue of \(V\) remains unchanged in \(U_h\). The stable return cannot cancel that residue. This directly identifies why the convergent feedback series does not close the proof.

## 5. Independent check of the complete even-shift family

For integer \(m\ge1\),
\[
\frac12\psi\left(\frac p2+\frac14\right)
-\frac12\psi\left(\frac p2+m+\frac14\right)
=-\sum_{j=0}^{m-1}\frac1{p+\frac12+2j}.
\]
The \(j=0\) term cancels the unshifted rational \(1/(p+1/2)\), leaving exactly
\[
\begin{aligned}
J(p)-J(p+2m)={}&
\frac{\zeta'}{\zeta}(p+\tfrac12)
-\frac{\zeta'}{\zeta}(p+2m+\tfrac12)
+\frac1{p-\frac12}\\
&-\frac1{p+2m-\frac12}
-\frac1{p+2m+\frac12}
-\sum_{j=1}^{m-1}\frac1{p+\frac12+2j}.
\end{aligned}
\tag{5.1}
\]
The two endpoint terms and the interior finite sum are all needed. The root note's inverse transform follows term by term, and agrees with direct multiplication of the native density by \(1-e^{-2mt}\).

On the unchanged compact \(L^2\) source, each such forcing differs from
\[
\mathcal C_f^\Lambda(s)
=e^{(a+s)/2}D_f(1/2)
-\sum_{n\ge2}\Lambda(n)n^{-1/2}f(a+s-\log n)
\]
by an unweighted \(L^2\) remainder. All elementary terms decay, and the extra prime measure has finite variation with weight \(n^{-1/2-2m}\).

The removal of powers \(p^k\), \(k\ge2\), is different: it is justified at every positive damping, because
\[
\sum_p\sum_{k\ge2}\log p\;p^{-k(1/2+\epsilon)}<\infty
\qquad(\epsilon>0).
\tag{5.2}
\]
At \(\epsilon=0\), the square-prime series is not absolutely summable. The root note correctly keeps this distinction. Weighted Young's inequality is legal for the original source on \([-a,a]\); compact negative support contributes only a finite constant.

Consequently the stated same-source positive-damping equivalence with
\[
\mathcal C_f^{\mathrm{prime}}(s)
=e^{(a+s)/2}D_f(1/2)
-\sum_{p\ {\rm prime}}\frac{\log p}{\sqrt p}f(a+s-\log p)
\]
is correct for the canonical source. A remainder in every positively damped \(L^2\) space has cumulative upper logarithmic energy exponent zero, so the claimed quiet-subsequence equivalence also follows from the prefix norm comparison and the triangle inequality.

For finite constant-coefficient shift combinations, the common unshifted forcing has coefficient \(\sum_j\alpha_j\). If this is nonzero, the same unknown prime discrepancy remains. If it is zero, the combination is independently stable but all native right-zero residues cancel. The limitation is correct for this specified class; it does not cover arbitrary time-dependent or vector filters.

## 6. Final remaining estimate after both constructions

The two new mechanisms now have complete causal inverses:

- the shifted native sensor has its explicit Möbius \(H^1_0\)-to-\(L^2\) inverse;
- the source contraction has its explicit stable feedback inverse, including the full-nullity weighted version.

Combining them does not create a smaller growth exponent. They transfer the norm or exponent of the same native forcing with constants independent of the horizon.

A sufficient genuinely new input is the unchanged-source estimate
\[
\liminf_{T\to\infty}\frac1T
\log\left(1+\int_0^T
|\mathcal C_{f_0}^{\mathrm{prime}}(s)|^2\,ds\right)=0.
\tag{6.1}
\]
Equivalently for the intended contradiction, one can prove arbitrarily small positive exponential upper rates on a cofinal sequence, retaining the precise positive damping required by the selected right zero.

No estimate (6.1) follows from the iteration: (4.5) returns a stable tail and retains the entire uncancelled first forcing. The exact native sign calculation in Path B Note 01 also prevents a coefficientwise positivity shortcut for its positively filtered gamma-free kernel. The lossless local contact calculation retains its signed future boundary flux. These are concrete failures of the tested closing routes, while the operator identities and domain repairs above remain valid new results.

## 7. Independent review of A's smooth-source removal of graph loss

Path A Note 05, Section 5, proves an additional statement on its unchanged infinitely smooth detector. This is compatible with, and stronger than, the graph-domain theorem on that restricted source class.

Let \(X=\Delta_2*h_+\), where the fixed smooth causal detector \(h_+\) is flat at zero, and let \(z=r_2*X\). The elementary native prime bound gives
\[
|X^{(j)}(t)|+|z^{(j)}(t)|
\le C_j(1+t)e^{t/2}
\]
for every integer \(j\ge0\). The second estimate follows by putting derivatives on the smooth \(X\), not on \(r_2\). Flatness prevents causal endpoint atoms.

Suppose \(z\in L^2_\eta\) for every \(\eta>0\). For a target \(\epsilon>0\), take \(c=\epsilon/4\), \(\eta=\epsilon/8\), and \(j\) large enough that \(c(j-1)>1/2\). A compact smooth mollifier with vanishing moments through order \(j-2\), at scale \(\ell=e^{-ct}\), gives
\[
|z'(t)|\le C_j\left[
\ell^{-3/2}\|z\|_{L^2(t-1,t+1)}
+\ell^{j-1}\sup_{|s-t|\le1}|z^{(j)}(s)|
\right].
\]
The first factor \(\ell^{-3/2}\) is exactly the \(L^2\) norm scaling of the derivative mollifier. The moment cancellation leaves the second remainder of order \(\ell^{j-1}\), involving \(z^{(j)}\).

The first term grows at most like \(e^{(\eta+3c/2)t}=e^{\epsilon t/2}\); the second decays exponentially up to a polynomial. Thus \(z'\in L^2_\epsilon\). The exact Möbius graph inverse now applies and gives \(X\in L^2_\epsilon\).

This proves the stated all-positive-damping equivalence for the fixed smooth detector. It does not give a fixed-\(\epsilon\), plain-\(L^2\) inverse, and it does not apply to the finite-regularity unsmoothed contact source or the moving-cutoff arithmetic fields. Those restrictions in A's note are necessary and are correctly retained.
