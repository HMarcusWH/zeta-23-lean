# Joint campaign Path A paper result: logarithm-squared localization of the native Möbius covariance

Date: 13 October 2026. Status: **PAPER / DERIVED, not formalized.**

This note proves an unconditional estimate for a genuine sector of the original fixed-detector covariance. It does not assume a zero-free half-plane, a mean Möbius bound, or the desired total energy estimate.

## 1. Source and inherited finite identity

The source is unchanged: the original B detector \(h=k_r*k_r\), with \(r=1/4096\), \(d=1/2048\), and the widths \(c_j=r/[j(j+1)]\). Put

\[
U(t)=\sum_{m\ge1}\frac{\log m}{\sqrt m}h(t-\log m),
\qquad
F(t)=\sum_{n\ge1}\frac{\mu(n)}{\sqrt n}U(t-\log n).
\]

Every value of these sums is locally finite. The inherited A03 Gevrey argument gives constants \(C,\kappa>0\) such that

\[
U(t)=0\quad(t<t_0:=\log2-d),\qquad
|U(t)|\le C e^{-\kappa e^{t/2}}\quad(t\ge0).
\tag{1}
\]

For a fixed \(\epsilon>0\), set \(\sigma=1/2+\epsilon\) and \(u(t)=e^{-\epsilon t}U(t)\), extended by zero before \(t_0\). A02 proves, before taking any infinite limit, the exact identity

\[
\begin{split}
E_\epsilon(T)
&:=\int_0^T e^{-2\epsilon t}|F(t)|^2\,dt\\
&=\sum_{\substack{a,b\ge1\\(a,b)=1}}
\frac{\mu(a)\mu(b)}{(ab)^\sigma}
\sum_{\substack{q\ge1\\(q,ab)=1}}
\frac{\mu(q)^2}{q^{2\sigma}}
I_{T-\log q}(a,b),\\
I_H(a,b)
&:=\int_0^H u(s-\log a)\overline{u(s-\log b)}\,ds.
\end{split}
\tag{2}
\]

The integral is zero when its upper endpoint is nonpositive. Causality restricts the actual sum to \(q\max(a,b)\le e^{T-t_0}\), so (2) is finite at every horizon. In particular no infinite sum of limiting ray correlations is being substituted for it.

## 2. A quantitative uniform covariance bound

Suppose \(a\ge b\), write \(r=a/b\), and change variable \(v=s-\log a\). An active integrand has \(v\ge t_0\), and

\[
\begin{split}
|I_H(a,b)|
&\le\int_{t_0}^{\infty}|u(v)u(v+\log r)|\,dv\\
&\le C\|u\|_1
 \exp\{-\kappa e^{t_0/2}\sqrt r\}.
\end{split}
\tag{3}
\]

The last inequality uses \(e^{-\epsilon(v+\log r)}\le1\) and (1) on the second factor. Thus, for \(c=\kappa e^{t_0/2}>0\),

\[
\boxed{|I_H(a,b)|\le C_\epsilon
e^{-c\sqrt{\max(a,b)/\min(a,b)}}}
\tag{4}
\]

for every real \(H\). The exponent constant \(c\) is independent of \(\epsilon\), \(H\), \(a\), and \(b\). The prefactor may depend on \(\epsilon\). The extra useful factor \(r^{-\epsilon}\) was not needed.

The complete common-divisor budget is also bounded independently of \(a,b,T\):

\[
\sum_{\substack{q\ge1\\(q,ab)=1}}\frac{\mu(q)^2}{q^{2\sigma}}
\le \sum_{q\ge1}q^{-1-2\epsilon}
=\zeta(1+2\epsilon)<\infty.
\tag{5}
\]

Using the exact squarefree Euler product would improve the constant but is unnecessary here.

## 3. Absolute summation outside a logarithm-squared wedge

Choose one \(C_0\ge1\) such that

\[
c\sqrt{C_0}>1.
\tag{6}
\]

This single choice works for every positive \(\epsilon\). Define

\[
L(b)=C_0(1+\log b)^2.
\]

For fixed \(b\), the positive function \(x^{-\sigma}e^{-c\sqrt{x/b}}\) decreases in \(x>0\). With \(A=bL(b)\),

\[
\begin{split}
\sum_{a\ge A}a^{-\sigma}e^{-c\sqrt{a/b}}
&\le A^{-\sigma}e^{-c\sqrt{L(b)}}
 +\int_A^\infty x^{-\sigma}e^{-c\sqrt{x/b}}\,dx\\
&= A^{-\sigma}e^{-c\sqrt{L(b)}}
 +2b^{1-\sigma}\int_{\sqrt{L(b)}}^\infty
 z^{1-2\sigma}e^{-cz}\,dz\\
&\le C_c\,b^{1-\sigma}e^{-c\sqrt{L(b)}}.
\end{split}
\tag{7}
\]

Here \(1-2\sigma=-2\epsilon<0\) and \(\sqrt{L(b)}\ge1\), so the power inside the last integral is at most one. The first term obeys the same bound because \(b\ge1\) and \(L(b)\ge1\). If \(A\) is not integral, replacing it by its ceiling preserves the estimate.

Multiplying (7) by \(b^{-\sigma}\) and summing,

\[
\begin{split}
\sum_{b\ge1}\sum_{a\ge bL(b)}
(ab)^{-\sigma}e^{-c\sqrt{a/b}}
&\le C_c\sum_{b\ge1}b^{-2\epsilon}
e^{-c\sqrt{C_0}(1+\log b)}\\
&=C_c e^{-c\sqrt{C_0}}
\sum_{b\ge1}b^{-2\epsilon-c\sqrt{C_0}}
<\infty.
\end{split}
\tag{8}
\]

The coprimality and squarefree restrictions only reduce this positive majorant. Equations (4), (5), and (8), including the symmetric region \(b\ge aL(a)\), prove:

**Theorem.** For the unchanged native detector, there is one \(C_0>0\) such that, for every \(\epsilon>0\), the total absolute contribution to (2) of all rays satisfying

\[
\boxed{
\frac{\max(a,b)}{\min(a,b)}
\ge C_0(1+\log\min(a,b))^2
}
\tag{9}
\]

is finite uniformly over all horizons \(T\).

This improves the inherited estimate for each polynomially separated region \(a\ge b^{1+\eta}\). It gives a substantially thinner residual region, with no unproved summation of native Möbius signs.

## 4. The exact remaining signed energy

Let \(E_{\epsilon,\mathrm{near}}(T)\) be exactly the finite sum (2) restricted to the complement of (9). The result supplies a constant \(D_\epsilon\) such that

\[
|E_\epsilon(T)-E_{\epsilon,\mathrm{near}}(T)|\le D_\epsilon
\quad\text{for every }T.
\tag{10}
\]

Consequently the desired bounded energy is equivalent to a uniform upper bound on this remaining signed finite-horizon sum. The near part need not be nonnegative by itself.

The inherited A02 argument proves absolute divergence already among coprime squarefree \(a,b\) in any sufficiently narrow fixed-ratio band around \(1\), for \(0<\epsilon\le1/2\). Every such band lies inside (9)'s complement eventually. Thus the new tail estimate does not make the full series absolutely convergent.

Any conditional all-horizon exponential lower bound on \(E_\epsilon(T)\) transfers through (10) to the same signed near part, up to the fixed additive constant \(D_\epsilon\). This transfer uses the same \(T\), the same fixed source, and the same damping. It does not use the different cofinal positivity quantifiers of the dilating A kernel.

## 5. General source-order interpretation

The proof works more generally if a causal source satisfies \(|U(t)|\le C\exp(-\kappa e^{\alpha t})\). Its separated covariance is \(O(\exp[-c(a/b)^\alpha])\), and the corresponding absolutely summable sector starts at

\[
a/b\ge C_0(1+\log b)^{1/\alpha}.
\]

The exponent two in the native result comes from the actual detector's Gevrey order two. This observation provides no estimate on the remaining signs.

## Source record

- A03 original proof: new/arithmetic/03_native_gevrey_drive_and_log_squared_cofactors.md, Sections 1–3, in the 13 October signed-arithmetic research package.
- A02 exact covariance and existing stopping point: a02/01_NEW_PROOFS/mobius/03_GCD_COVARIANCE_AND_STOPPING_POINT.md, Sections 2–4.
- All arguments after the cited source bound and finite identity are derived in this campaign.
