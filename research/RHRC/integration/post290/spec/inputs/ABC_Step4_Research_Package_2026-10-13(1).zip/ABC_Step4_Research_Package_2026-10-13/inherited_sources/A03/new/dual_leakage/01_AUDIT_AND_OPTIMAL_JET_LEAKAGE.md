# A03 — audit and optimal adjoint-jet leakage

**Status: PAPER / DERIVED. Conditional native lower bounds; RH remains OPEN.**

The integration lemma `03_MATH/DUAL_LEAKAGE_TO_SIGNED_PRIME_FLUCTUATION.md`
is valid, with the stated inherited PAPER premises. Its polynomial loss at a
multiple zero is unnecessary. The improvement below uses all the lower
adjoint jets that the exact input annihilates. It proves an eventual pure
exponential lower bound, including at multiple zeros, and supplies an exact
finite-set version. No new Lean declaration or repository mutation is involved.

## 1. Exact audited objects and interfaces

Throughout use the same original real even detector

\[
r=1/4096,\quad d=2r=1/2048,\quad h=k_r*k_r\in C_c^\infty([-d,d]),
\quad K(p)=\int h(t)e^{-pt}\,dt.
\]

The inherited detector proof gives double zeros at \(p=\pm1/2\), and
\(K(\rho-1/2)\ne0\) at every off-line nontrivial native zero. This universal
statement remains PAPER. All transforms below are Laplace transforms with
negative exponential; no Fourier convention is changed.

The exact native causal functions are

\[
F=\Pi*h=M_\mu*U,\quad U=(tN)*h,\qquad N*F=U.
\]

They vanish before \(\log2-d>0\). Define

\[
R(t)=e^{-t}1_{t\ge0},\quad B=\delta_0-e^{-t/2}1_{t\ge0},
\quad a=R*B*N,\quad v=R*B*U.
\]

The source equation \(a*F=v\) holds in the causal distribution algebra and
in local \(L^2\). The B03 derivation gives

\[
\frac{e^{-t/2}}{6\sqrt2}\le a(t)\le\frac32e^{-t/2},\qquad
v(t)=O(e^{-t}),
\]

\[
A(p)=\mathcal La(p)=q(p)\zeta(p+1/2),\qquad
V(p)=\mathcal Lv(p)=-q(p)K(p)\zeta'(p+1/2),
\quad q(p)=\frac{p-1/2}{(p+1/2)(p+1)}.
\tag{1.1}
\]

The initial transform justification is \(\Re p>1/2\); the displayed
continuation and the actual decaying input justify subsequent evaluation at
\(\Re p>0\). This is not an inference that \(F\) has a global weighted norm.

For \(\epsilon>0\), write

\[
a_\epsilon=e^{-\epsilon t}a,\quad v_\epsilon=e^{-\epsilon t}v,
\quad\mathsf A_\epsilon g=a_\epsilon*g.
\]

This is a bounded causal operator on \(L^2(\mathbb R_+)\). Its exact norm is

\[
\boxed{\|\mathsf A_\epsilon\|=A(\epsilon)>0.}\tag{1.2}
\]

Indeed weighted Young gives the upper bound by the positive kernel's mass.
For the reverse bound apply the operator to \(1_{[0,L]}/\sqrt L\). On
\([S,L]\) its value is at least \(L^{-1/2}\int_0^S a_\epsilon\), and let
first \(L\to\infty\), then \(S\to\infty\). This uses no inverse estimate.
In particular \(A(\epsilon)\le3/[2(\epsilon+1/2)]\). At \(\epsilon=1/2\)
the expression in (1.1) is interpreted at its removable singularity and
equals \(2/3\).

For \(T\ge0\), set

\[
g_T=1_{[0,T]}e^{-\epsilon t}F(t),\qquad
e_T=v_\epsilon-\mathsf A_\epsilon g_T.
\tag{1.3}
\]

Both are genuine \(L^2\) functions. Causality gives \(e_T=0\) on \([0,T]\).
All the assertions below are about the entire tail \([T,\infty)\), not a
finite fragment of it.

## 2. The full adjoint jet, including the vanished input jets

Suppose \(\rho\) is a hypothetical native zero of multiplicity \(m\ge1\)
with \(\Re\rho>1/2+\epsilon\). Put

\[
\lambda=\rho-1/2,\quad z=\lambda-\epsilon,\quad
\delta=\Re z>0,\quad n=m-1.
\]

For \(0\le j\le n\), let

\[
\ell_j(w)=\int_0^\infty(-t)^j e^{-zt}w(t)\,dt.
\]

Each functional is bounded on \(L^2\), and every one annihilates
\(\operatorname{Ran}\mathsf A_\epsilon\), because its value there is the
\(j\)-th derivative of \(A(p)\mathcal Lg(p-\epsilon)\) at \(p=\lambda\).
The factor \(A\) has a zero of order \(m\). The actual input satisfies

\[
\ell_j(v_\epsilon)=0\quad(j<n),\qquad
\ell_n(v_\epsilon)=c,
\quad c=-q(\lambda)K(\lambda)\zeta^{(m)}(\rho)\ne0.
\tag{2.1}
\]

There is no missing factorial: differentiating the order-\(m-1\) zero of
\(\zeta'\) exactly \(m-1\) times gives \(\zeta^{(m)}\). The vanishing of
the lower input jets is essential for the improvement.

The original integrator's use of \(\ell_n\) and
\(\int_T^\infty t^{2n}e^{-2\delta t}dt\) was therefore valid, but weaker
than the consequence of the full jet (2.1).

## 3. Sharp shifted-Laguerre leakage

Use the ordinary Laguerre polynomial

\[
L_n(x)=\sum_{j=0}^n\binom nj\frac{(-x)^j}{j!}.
\]

Its leading coefficient is \((-1)^n/n!\), and
\(\int_0^\infty e^{-x}L_n(x)^2dx=1\). The latter identity follows, for
example, from the Rodrigues formula and integration by parts \(n\) times;
all boundary terms vanish and the final derivative is \((-1)^n\).

For each horizon use the bounded functional

\[
\mathcal J_T(w)=\int_0^\infty
e^{-zt}L_n(2\delta(t-T))w(t)\,dt.
\]

It is a linear combination of \(\ell_0,\ldots,\ell_n\). Its coefficient
of \(\ell_n\) is \((2\delta)^n/n!\), independent of \(T\). Consequently

\[
\mathcal J_T(e_T)=\frac{(2\delta)^n}{n!}c.
\]

Because \(e_T\) is supported after \(T\), the squared norm of this test
on its actual support is exactly

\[
\int_T^\infty e^{-2\delta t}L_n(2\delta(t-T))^2dt
=\frac{e^{-2\delta T}}{2\delta}.
\]

Thus for **every** \(T\ge0\),

\[
\boxed{
\|e_T\|_2\ge
\frac{|c|(2\delta)^{m-1/2}}{(m-1)!}\,e^{\delta T}.
}\tag{3.1}
\]

No uniformity in the zero, multiplicity, damping or detector is claimed.

### Optimality within the given jet data

After shifting to \(s=t-T\), the moment data against \((-s)^j\) are zero
through degree \(n-1\) and have the prescribed degree-\(n\) value
\(ce^{zT}\). Among
polynomials with a specified leading coefficient, the monic orthogonal
polynomial minimizes its \(e^{-2\delta s}\)-weighted norm: subtracting
that polynomial leaves a lower-degree polynomial, orthogonal to it.
The Laguerre polynomial is that minimizer. Therefore (3.1) is the exact
best lower bound for complex \(L^2\) tails obtainable from this one complete
jet without additional information on the tail. Requiring a real tail or
supplying the conjugate zero's jet can add constraints; Note 02 includes
that finite-set information. The synthetic Blaschke example in Note 04
attains the one-jet bound for every multiplicity and every horizon.

## 4. Transfer to the unchanged prime output and complete signed fluctuation

Since \(e_T\) is supported in the future,

\[
\|e_T\|_2\le
\|1_{(T,\infty)}v_\epsilon\|_2+A(\epsilon)\|g_T\|_2.
\tag{4.1}
\]

The first term is \(O(e^{-(1+\epsilon)T})\). Combining with (3.1) gives
the explicit all-horizon inequality

\[
\|g_T\|_2\ge
\frac{|c|(2\delta)^{m-1/2}}{(m-1)!A(\epsilon)}e^{\delta T}
-\frac{\|1_{(T,\infty)}v_\epsilon\|_2}{A(\epsilon)}.
\tag{4.2}
\]

Let \(F_1=\Pi_1*h\) and \(F_{\ge2}=\Pi_{\ge2}*h\). The exact A02
weighted total-variation estimate gives, for the same \(\epsilon>0\),
\(H_\epsilon=\|e^{-\epsilon t}F_{\ge2}\|_{L^2(0,\infty)}<\infty\).
Hence the first-prime norm is at least the right side of (4.2) minus
\(H_\epsilon\). This retains all powers and their possible cross terms by
the triangle inequality, rather than assigning entrywise signs.

For \(0<\epsilon<1/2\), retain A02's exact choices
\(X=e^{T+d}\), \(\beta=1-2\epsilon\), and its entire boundary
\(\mathcal B_\epsilon(T)=\int_T^{T+2d}|G_{\epsilon,X}|^2\). The signed
fluctuation in the integrator satisfies the exact identity

\[
\mathcal R_\epsilon(T)=
\|e^{-\epsilon t}F_1\|_{L^2(0,T)}^2-D_\epsilon(X),
\quad 0\le D_\epsilon(X)\le D_\epsilon^*<\infty.
\tag{4.3}
\]

Consequently the stronger quantitative native conclusion is

\[
\boxed{
\liminf_{T\to\infty}e^{-2\delta T}\mathcal R_\epsilon(T)
\ge
\frac{|c|^2(2\delta)^{2m-1}}
{((m-1)!)^2A(\epsilon)^2}>0.
}\tag{4.4}
\]

In particular there is a positive constant such that
\(\mathcal R_\epsilon(T)\ge C e^{2\delta T}\) for every sufficiently
large \(T\), without a polynomial denominator. This is a conditional
lower bound, not the independently missing arithmetic upper bound.

## 5. Why native PNT cancellation remains compatible

A02 proves \(\mathcal R_\epsilon(T)=o(X^\beta)\). A nontrivial zero
satisfies \(\Re\rho<1\), so

\[
2\delta=2\Re\rho-1-2\epsilon<1-2\epsilon=\beta.
\]

Removing the polynomial loss does not close this strict exponential gap.
Neither ordinary PNT nor its known subpower relative remainder conflicts
with (4.4). The entire future-boundary contribution in (4.3) is necessary:
omitting it leaves A02's already known escaping deterministic pulse at
scale \(X^\beta\).

## 6. Audit disposition

- Same source, time origin, all prime powers and native inverse: PASS.
- Adjoint derivative and factorial at \(m=1,2\), and general \(m\): PASS.
- Causal support and actual global domains of \(a,v,g_T,e_T\): PASS.
- Full future boundary in the signed-fluctuation identity: PASS.
- Original integration lemma: valid DERIVED_FROM_PAPER, sharpened here.
- Eventual rather than cofinal conclusion: preserved; all \(T\ge T_0\).
- Native arithmetic upper bound: OPEN; not implied by any displayed identity.
- No assertion about the dilating \(K=2\) source or C's contact generator.
- No Lean or finite-check promotion of universal analytic claims.

