# A03: a definite-sign post-cancellation prime-tail countermodel

**Status: PAPER / DERIVED universal countermodel.** This is not a model of
the actual unmodified zeta function and does not refute its open arithmetic
bound. It quantitatively tests the new *complete signed fluctuation*, with
the exact fixed detector and its entire future boundary retained.

## 1. Statement

Retain the exact source `h`, `K`, `r`, and `d` from Note01, and put

\[
 P_*:=P_r(i/2)>0,\qquad K''(1/2)=2P_*^2.
\]

The strict positivity follows from the inherited nonnegative probability
density defining `P_r`: `P_r(i/2)=int q_r(u)e^{u/2}du>0`.

Choose constants `C0,c0,B` in the unconditional native theta estimate

\[
 |\theta(x)-x|\le C_0x(\log x)^B e^{-c_0\sqrt{\log x}}.
 \tag{1.1}
\]

Fix any finite prime-prefix threshold `P0>=2`, any `eta>0`, and any
`0<c<c0`. Define a single positive multiplier for **every power** of
each prime base:

\[
 w(p)=\begin{cases}1,&p\le P_0,\\
 1+\eta e^{-c\sqrt{\log p}},&p>P_0,
 \end{cases}
 \qquad \widetilde\Lambda(p^k)=w(p)\log p\quad(k\ge1).
 \tag{1.2}
\]

All coefficients away from prime powers are zero. Let

\[
 \widetilde F_1(t)=\sum_p\frac{w(p)\log p}{\sqrt p}
                         h(t-\log p).
\]

Let `widetilde R_epsilon` be A02's full signed prime-pair fluctuation with
these coefficients, the same `h`, the same cutoff `X=exp(T+d)`, and the
entire actual future-boundary norm subtracted. The continuum constants
remain the original `C_+`, `C_-`, `C_partial`, since the altered prime
measure still has density1.

### Theorem A3-ST

The altered first-prime field has the **one-sign, all-large-time** asymptotic

\[
 \boxed{\widetilde F_1(t)
 =A\,t^{-1}e^{t/2-c\sqrt t}(1+O(t^{-1/2})),
 \qquad A=\frac{\eta c^2P_*^2}{4}>0.}\tag{1.3}
\]

For every fixed `0<epsilon<1/2`, with `beta=1-2epsilon`,

\[
 \boxed{\widetilde{\mathcal R}_\epsilon(T)
 \sim\frac{A^2}{\beta}\,T^{-2}
              e^{\beta T-2c\sqrt T}.}\tag{1.4}
\]

The altered higher-power output remains square integrable after every
positive damping, so the complete Mangoldt output has the same leading
weighted-energy asymptotic. No actual native zero, zero multiplicity,
or hypothesis about RH is used in this countermodel.

Unlike the inherited oscillatory two-sign controls, (1.3) identifies this
specific `+` perturbation as an eventual violating system. It does so by
making its smooth relative tail decay slower than a rigorously available
bound on the genuine background, while still tending to zero.

## 2. The exact fixed-source moment calculation

Set `f(s)=exp(-c sqrt(s))` for `s>0`. For large `t`, finite-prefix deletion
has no effect because the support of `h(t-log p)` lies above `P0`. The
continuum approximation to the perturbation is exactly

\[
 \eta\int_0^\infty x^{-1/2}f(\log x)h(t-\log x)dx
 =\eta e^{t/2}\int_{-d}^d e^{-u/2}h(u)f(t-u)du.
 \tag{2.1}
\]

Only `x` near `exp(t)` is active, so the irrelevant expression of `f`
near or below1 need never be defined; equivalently restrict (2.1) to its
compact active interval.

The known source identities give

\[
 \int e^{-u/2}h(u)du=0,\quad
 \int ue^{-u/2}h(u)du=0,\quad
 \int u^2e^{-u/2}h(u)du=2P_*^2.
 \tag{2.2}
\]

Taylor's theorem is applied **only to the explicitly constructed smooth
function f**, never to the native counting error. On the fixed source
interval,

\[
 \int e^{-u/2}h(u)f(t-u)du
 =P_*^2 f''(t)
   +O_h\!\left(\sup_{|v-t|\le d}|f'''(v)|\right).
 \tag{2.3}
\]

The derivatives are

\[
 f''(t)=f(t)\left(\frac{c^2}{4t}+rac{c}{4t^{3/2}}\right),
\]

\[
 f'''(t)=-f(t)\left(\frac{c^3}{8t^{3/2}}
             +\frac{3c^2}{8t^2}+rac{3c}{8t^{5/2}}\right).
 \tag{2.4}
\]

Consequently (2.3) is

\[
 \frac{c^2P_*^2}{4t}e^{-c\sqrt t}(1+O(t^{-1/2})).
 \tag{2.5}
\]

Thus the exact double pole-neutral moment imposes a polynomial loss
`t^{-1}` on this profile. It does not change its exponential scale.

## 3. Discrete genuine-prime errors and the unmodified background

The perturbation itself sums over the **actual primes**, not a continuous
prime replacement. Write its Stieltjes sum as the integral in (2.1) plus
integration against `d(theta(x)-x)`. Integration by parts puts its
derivative on

\[
 W_t(x)=x^{-1/2}f(\log x)h(t-\log x),
\]

whose source endpoints vanish. On its active interval,

\[
 |W_t'(x)|\le C_h x^{-3/2}f(\log x)
\]

for large `t`, because `|f'(s)|=O(f(s)/sqrt(s))`. Applying (1.1) gives
the full discrete error

\[
 O\!\left(e^{t/2}t^B e^{-(c+c_0)\sqrt t}\right).
 \tag{3.1}
\]

The undisturbed native field independently obeys Note01's bound

\[
 F_1(t)=O\!\left(e^{t/2}t^B e^{-c_0\sqrt t}\right).
 \tag{3.2}
\]

Since `c<c0`, both (3.1) and (3.2) are smaller than the main term
`e^{t/2-c sqrt(t)}/t` by more than any power of `t`. Equations
(2.1)--(3.2) prove (1.3), including its stated relative
`O(t^{-1/2})` remainder. No sign estimate for the genuine field was
needed: its unconditional magnitude is smaller.

## 4. PNT, consistent powers, and the exact fluctuation

Partial summation gives

\[
 \widetilde\theta(x)-\theta(x)
 \sim \eta x e^{-c\sqrt{\log x}},
 \qquad \widetilde\theta(x)\sim x.
 \tag{4.1}
\]

For example the continuum integral of `f(log x)` is
`x f(log x)(1+O((log x)^{-1/2}))`, and its native Stieltjes error
is smaller by (1.1). The finite prefix only changes a fixed constant.
Thus this control retains ordinary PNT and a classical subpower relative
error profile, with a smaller exponent constant `c`. It is not asserted
to retain every stronger published PNT estimate for the true primes.

Since `1<=w(p)<=1+eta`, A02's weighted-total-variation bound on all
prime powers `k>=2` applies with a factor at most `1+eta`. In particular
no prime-power channel or mixed term has been omitted. Its complete
weighted norm is finite for each epsilon>0.

The altered diagonal has the same property:

\[
 \widetilde D_\epsilon(X)=\|e^{-\epsilon\cdot}h\|_2^2
    \sum_{p\le X}w(p)^2(\log p)^2p^{-1-2\epsilon}
 \longrightarrow \widetilde D_\epsilon^*<\infty.
\]

The exact finite-horizon Gram identity and the kernel identity
`C_+-C_-=C_partial` are algebraic and hold for these altered coefficients:

\[
 \widetilde{\mathcal R}_\epsilon(T)
 =\int_0^T e^{-2\epsilon t}|\widetilde F_1(t)|^2dt
       -\widetilde D_\epsilon(e^{T+d}).
 \tag{4.2}
\]

Squaring (1.3) and using the elementary endpoint asymptotic

\[
 \int^{T}t^{-2}e^{\beta t-2c\sqrt t}dt
 \sim \beta^{-1}T^{-2}e^{\beta T-2c\sqrt T}
\]

proves (1.4). Subtracting the finite limiting diagonal is negligible.
The same applies to the full output by the weighted triangle inequality:
the finite higher-power norm is negligible compared with the growing
first-prime norm. This proves a post-cancellation growth law for the
**complete** retained-boundary budget, not for an uncorrected positive
prime-pair majorant.

## 5. Generic divisor compatibility can be retained; the native one is lost

The positive exponent Euler product

\[
 Z_w(s)=\prod_p(1-p^{-s})^{-w(p)}\qquad(\Re s>1)
\]

defines multiplicative coefficient functions

\[
 N_w(p^k)=\frac{(w(p))_k}{k!}\ge0,
 \qquad M_w(p^k)=(-1)^k\binom{w(p)}k.
\]

Their absolutely convergent Euler series, or finite local coefficient
algebra, gives

\[
 M_w*_{\rm Dir}N_w=\delta_1,\qquad
 \widetilde\Lambda*_{\rm Dir}N_w=N_w\log.
 \tag{5.1}
\]

After logarithmic lifting this is the same abstract causal identity
`M_w*N_w=delta0`, `Pi_w*N_w=tN_w`. Thus existence of a positive integer
measure and a signed Euler inverse with a compatible logarithmic
derivative is not enough. Here those coefficients are **not**
`N(n)=1` and **not** the genuine `mu(n)`.

The exact native defect is explicit and nonzero:

\[
 (\widetilde\Lambda*_{\rm Dir}1)(n)-\log n
 =\eta\sum_{\substack{p\mid n\\p>P_0}}
     v_p(n)\log p\,e^{-c\sqrt{\log p}}.
 \tag{5.2}
\]

In particular the original native drive `U=(tN)*h` is not the drive of
this altered equation. The control does not preserve B03's actual input,
the literal native `mu` signs and squarefree support, the normalized
global xi/functional equation, or the full native cardinal law. Keeping
the production pole and archimedean terms in the arithmetic Weil formula
does not restore that global analytic identity.

## 6. Precise falsified inference and surviving arithmetic problem

FALSIFIED: the inference from the exact fixed source, its double moments,
positive prime-power-consistent weights, arbitrary finite genuine prefix,
PNT-scale centering, generic divisor/Euler compatibility, and the complete
future-boundary cancellation to a bounded or subexponential signed
fluctuation.

NOT FALSIFIED: the desired theorem for `Lambda(p^k)=log p`,
`N(n)=1`, and `M_mu`, with the unchanged actual input and completion.
The extra native law (5.2) equals zero in that setting and is a possible
place for genuinely new cancellation. No proof of such cancellation is
given here. This control does not establish or assume an off-line zeta
zero and does not claim a meromorphic continuation of `Z_w` beyond its
initial half-plane.

## 7. Relation to previous controls

The inherited A0/A02 slow-tail construction already produced a negative
dilating K2 scalar with consistent positive powers and PNT-scale
information. This note does not recount that as new. Its new content is
the exact fixed-detector transfer through the two vanishing moments, the
unconditional dominance of one fixed positive perturbation over the
native background, and the asymptotic of the **completed signed
prime-pair/boundary fluctuation** after leading cancellation. It is
different from B03's same-input positive-forward-kernel perturbation,
which retains the actual drive but changes the global integer kernel.

All statements are PAPER / DERIVED; finite algebra checks below verify
normalizations only and cannot certify these infinite asymptotics. RH
remains OPEN.
