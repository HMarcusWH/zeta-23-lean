# A fourth attack: exact contact inequalities after removal of the gamma term

Date: 13 October 2026.

Status: NEW PAPER DERIVATION, under the inherited full native contact and maximal-domain hypotheses. This note attempts to turn the new shifted native observation into an independent closing sign. The resulting finite-prefix identities are established below; the required global upper bound is not established.

## 1. Fixed conventions and imported source

Use the actual full even Weil distribution W and its causal half W_+, with the original half-diagonal normalization. In the safe half-plane Re p > 1/2,

\[
\mathcal L W_+(p)=J(p)=\frac{\xi'}{\xi}(1/2+p)
=\frac{\zeta'}{\zeta}(1/2+p)+\frac1{p-1/2}+\frac1{p+1/2}
+\frac12\psi(p/2+1/4)-\frac12\log\pi.
\]

For t>0, away from its diagonal regularization, the exact positive-half kernel is

\[
W_+(dt)=\left(e^{t/2}+e^{-t/2}
-\frac{e^{-t/2}}{1-e^{-2t}}\right)dt
-\sum_{n\ge2}\Lambda(n)n^{-1/2}\delta_{\log n}.
\tag{1}
\]

This is the normalization in C05,
 b_residue_range/01_COMPLETED_NATIVE_FORWARD_KERNEL_AND_ORIGINAL_EXTERIOR.md,
 equations (1.1)--(1.4) and the inherited causal archimedean distribution. No pole, prime power, or scalar correction is removed from W.

Let I=[-a,a]. Let q be the closed Weil form on zero-extended functions supported in I, with operator H=P_I W P_I. Assume H is positive semidefinite and f is an actual vector in ker H. All contact vectors have compact support and positive fractional Sobolev regularity by the inherited contact-kernel classification. Multiplication by a smooth bounded function on I preserves this form domain.

Fix the inner-product convention

\[
q(u,v)=\int \overline{u(x)}(W*v)(x)\,dx.
\]

The operator-domain contact equation gives q(f,v)=q(v,f)=0 for every v in the form domain. This is stronger than assuming only the scalar q(f,f)=0 without the closed positive-form implication.

## 2. The exact exponential commutator identity

For real theta, put M_theta f(x)=e^{theta x}f(x). On the fixed compact interval this is a bounded smooth multiplier. For f,g in ker H,

\[
q(M_\theta f,M_\theta g)
-\tfrac12q(f,M_{2\theta}g)
-\tfrac12q(M_{2\theta}f,g)
\]
\[
=-\iint W(x-y)e^{\theta(x+y)}
[\cosh(\theta(x-y))-1]\overline{f(x)}g(y)\,dx\,dy.
\]

Both subtracted terms vanish by the contact equation. Define the cross-correlation

\[
C_\theta^{f,g}(t)=
\int \overline{e^{\theta x}f(x)}
e^{\theta(x-t)}g(x-t)\,dx.
\]

It is continuous, supported in [-2a,2a], and bounded by the product of the two L2 norms. Therefore

\[
\boxed{\;
q(M_\theta f,M_\theta g)
=-\langle [\cosh(\theta t)-1]W(t),C_\theta^{f,g}(t)\rangle.
\;}
\tag{2}
\]

The matrix of the right side on any basis of ker H is positive semidefinite.

### Domain justification

The identity first follows for compact smooth approximations from the kernel representation and the elementary equality

\[
e^{\theta(x+y)}-\tfrac12(e^{2\theta x}+e^{2\theta y})
=-e^{\theta(x+y)}(\cosh(\theta(x-y))-1).
\]

The multiplier has a second-order zero at t=0. It kills the original diagonal distribution, and its product with the archimedean 1/|t| singularity is locally O(|t|). On [-2a,2a] only finitely many prime atoms occur. Convergence in the form domain gives convergence of the left side; convergence in L2 gives uniform convergence of the correlations, which gives convergence of the now-regular kernel pairing. This proves (2) for the original contact vectors, including nullity one or two. No derivative of f, smoothing of the target vector, or enlargement of I is assumed.

## 3. An integer tilt removes the entire gamma kernel

For t>0,

\[
(\cosh(2t)-1)
\left(e^{t/2}+e^{-t/2}-\frac{e^{-t/2}}{1-e^{-2t}}\right)
=b_2(t),
\]

where

\[
\boxed{\;
b_2(t)=\frac12(e^{2t}-1)
(e^{t/2}-e^{-3t/2}-e^{-5t/2}).
\;}
\tag{3}
\]

Equivalently,

\[
b_2(t)=\frac12
(e^{5t/2}-2e^{t/2}-e^{-t/2}+e^{-3t/2}+e^{-5t/2}).
\]

The prime-atom weight after multiplication is

\[
\alpha_n=(\cosh(2\log n)-1)\Lambda(n)n^{-1/2}
=\frac{(n^2-1)^2}{2n^{5/2}}\Lambda(n).
\tag{4}
\]

For \(g=M_2 f\) and \(C_g(t)=\int\overline{g(x)}g(x-t)\,dx\), the exact full-contact inequality is therefore

\[
\boxed{\;
0\le q(g,g)
=2\sum_{\log n\le 2a}\alpha_n\Re C_g(\log n)
-2\int_0^{2a}b_2(t)\Re C_g(t)\,dt.
\;}
\tag{5}
\]

At t=2a the correlation is zero, so the endpoint convention for the finite prime sum does not change the formula. All higher prime powers with log n <= 2a remain in the sum with Lambda(p^k)=log p.

Equation (5) is a new explicitly gamma-free family of necessary inequalities for the original full contact. It follows from PSD and contact; it does not supply a global exterior estimate.

## 4. Why the immediate sign-closing argument fails

The density in (3) has the sign of

\[
e^{3t}-e^t-1.
\]

The polynomial x^3-x-1 is strictly increasing on x>=1, is negative at 1, and tends to infinity. If rho_pl>1 is its unique positive root, then b_2(t)<0 for 0<t<log rho_pl and b_2(t)>0 for t>log rho_pl. Meanwhile every nonzero prime atom in the multiplied W is negative.

There is consequently no universal fixed sign in the gamma-free kernel. Also C_g(t), though a positive-definite function of t, need not be nonnegative at each t. Replacing it by an absolute value changes the exact balance.

The inequality only contains prime data with log n <= 2a. Making theta arbitrarily large in (2) changes the weighting within this same interval; it does not extend the interval observed by the correlation.

## 5. A precise local-data falsification

Suppose two real even distributions W and W_tilde agree on a neighborhood of [-2a,2a]. Then their compressed forms on I agree, their contact spaces agree, and EVERY exponential-commutator form (2) agrees for all real theta and all contact vectors.

Nevertheless their exteriors can be arbitrarily different. To see this without imposing any native claim, first extend the common local distribution with compact support. Then add

\[
E(t)=\sum_{j\ge1}e^{\alpha T_j}
(\delta_{T_j}+\delta_{-T_j}),
\qquad
T_j=T_0+jD,\quad T_0>2a,\quad D>2a.
\]

This is a locally finite real even distribution of exponential order alpha, invisible to the compressed form and every identity (2). For any fixed nonzero contact f, its added right exterior is the disjoint pulse family

\[
\sum_j e^{\alpha T_j}f(a+s-T_j).
\]

The squared norm of the completed jth pulse is e^{2alpha T_j}||f||_2^2. Since successive pulse times have a fixed gap D, its cumulative exterior energy has positive exponential rate 2alpha. Thus even the unbounded family of all exponential-contact inequalities does not imply an exterior quiet-subsequence bound from local PSD data alone.

This is a falsification of a specified local-data implication. It does NOT preserve the full native integer kernel, completed zeta function, or all B/C global constraints. It is not a counterexample to RH. A valid closing proof must use some additional native information that distinguishes the actual tail from this control.

## 6. Connection to the new shifted sensor

The Path B sensor r_2(t)=e^{-2t}a_N(t) is zero-free and has an explicit stable first-order inverse. Its uncontrolled term involves the one-sided difference

\[
(1-e^{-2t})W_+(dt)
=(e^{t/2}-e^{-3t/2}-e^{-5t/2})dt
-\sum_{n\ge2}\Lambda(n)n^{-1/2}(1-n^{-2})\delta_{\log n}.
\tag{6}
\]

The same elementary factorization removes gamma in both (5) and (6). Equation (5) controls a finite-prefix pairing of that native discrepancy against a contact correlation. The sensor requires a global weighted norm or subexponential-energy statement. No step converting these finite-prefix pairings into that global norm has been established here.

This identifies the exact failure of the attempted combined closure, while retaining a useful new native contact identity.
