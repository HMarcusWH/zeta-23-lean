# B04.5 — Cross-path source audit, support shifts and residue sensitivity

**Status:** PAPER interface audit, not a new null-state or native spectral exclusion theorem. Imported A02 polarized contact and C04 smooth-negative constructions remain separately attributed. The original B detector is never silently replaced.

## Three objects which must remain distinct

- **B original:** `k_r=q_r''-q_r/4` for `r=1/4096`, `h=k_r*k_r`, compact smooth support `[-d,d]`, `d=1/2048`; double pole neutral, universal off-line visibility, causal native source `F=Pi*h=M_mu*U`. It is not a contact null vector.
- **A02 polarized:** at a hypothetical full PSD contact on `[-a,a]`, A02 forms a *smooth cross-source* `h_{f,v}=v*tilde f` by choosing a compact interior smooth pole-neutral test v and the canonical contact source f. This works at all nullities, with a local silence condition from polarization. It is **not** generally an autocorrelation, a null vector, or a negative-energy source.
- **C04 smoothed negative:** smoothing or translating a full contact kernel source can construct a smooth negative test at enlarged aperture in the stated higher-nullity strata; smoothing destroys the exact equation `H_a f=0`, so a nonzero interior residual remains. The source does not become the original B h by analogy.

The nullity-three construction `f_pn=(D²+1/4) f_0`, from C2, is different again: it lies in the same full nullspace only for nullity at least three, and has finite Sobolev regularity, not Gevrey. Its prime-integer drive can decay exponentially without providing an inverse bound. It gives no contact-null source for r_c=1 or 2.

## Source, support and nonzero factors

For real compact functions, the positive-sign B Fourier convention is `hat g(z)=∫g(t)e^{izt}dt`. For a right time delay by L,

\[
\widehat{\tau_Lg}(z)=e^{izL}\widehat g(z),
\qquad \mathcal L(\tau_Lg)(p)=e^{-pL}\mathcal Lg(p).
\]

At a hypothetical zero coordinate `lambda=rho-1/2`, the Laplace residue acquires the **nonzero** factor `e^{-lambda L}`. A shift cannot extinguish a visible pole. This is not an equality between two different source coefficients.

For a two-sided correlation `C(t)` with bilateral definition, delaying first and then retaining `t>=0` is *not* the same operation as delaying its already causal part. In a common safe half-plane,

\[
\mathcal L\{1_{t\ge0}C(t-L)\}(p)
=e^{-pL}\left[
\mathcal L\{1_{t\ge0}C(t)\}(p)
+\int_{-L}^0e^{-pu}C(u)du
\right].
\]

The extra finite-history integral is entire in p if C is continuous there. It can alter the regular part but not cancel a nonzero native pole residue. This is the correction required by the interrupted B04 audit.

A02's polarized contact source is generally supported in `[-a-b,a+b]` if f and v are supported in `[-a,a]` and `[-b,b]`; the associated positive-time shift must account for that whole support. The individual source transform factors are kept explicit, and nonzero of the product at an off-line rho is an independent visibility premise for the selected v, not a claim for all v.

## Why the previous bounded coupled observation is blind

In C/B contact notation, on the appropriate safe Laplace half-plane the native exterior for the contact generator f has structure

\[
X_f(p)=D_f(p)[J(p)-\mathfrak p(p)]
\]

and its compact companion c obeys

\[
X_c(p)+\mathfrak p(p)X_f(p)=D_{d_c}(p)-\mathfrak p(p)^2D_f(p).
\]

At a right off-line zero `lambda` where `D_f(lambda) !=0`, the native exterior pair's residue vector is proportional to

\[
\mathbf r(\lambda)=m_\rho D_f(\lambda)
\begin{pmatrix}1\\-\mathfrak p(\lambda)\end{pmatrix}.
\]

A linear observation row `(u(p),v(p))` is residue sensitive exactly when

\[
\boxed{u(\lambda)-v(\lambda)\mathfrak p(\lambda)\ne0.}
\]

The bounded row `(mathfrak p,1)` gives identically zero. Its stability is a theorem about the **quotiented, pole-cancelled observation**, not a bound on the original exterior, the B detector output, or the native causal input.

The A02 mutual filtering identity also cancels reflected residues pairwise; it is a legitimate adapter but not a bound on either observation. Before trying another positive row or norm law, compute this residue response and ensure it stays nonzero at hypothetical zeros.

## Matched falsifiers

1. **C smooth-quartet:** preserves literal native prime atoms in the local contact model but changes the smooth completion. The result cannot be used as a model preserving the original unmodified xi completion.
2. **B far-prime surgery:** preserves the entire finite-aperture local contact, generator, companion and local Herglotz object, while changing global high-prime coefficients. It cannot be called the unchanged zeta Euler product.
3. **B same-input positive-kernel perturbation:** preserves the actual input and an arbitrarily long causal prefix, but perturbs the global positive kernel. It falsifies an argument based only on positivity and finite agreement, not the exact native convolution algebra.
4. **A02 polarized probe:** holds in all nullity strata and can be smooth/pole neutral/off-line visible, but the silence identity is polarized; no independent sign of its global forcing follows.
5. **C04 smoothed negative:** negative larger-aperture witnesses are available under their hypotheses, but the original full-contact null equation has been lost.

These controls do not form one synthetic zeta preserving all native invariants at once. A successful future inequality must use a native global condition absent from each relevant control; no such inequality is established here.
