# Joint campaign Path A continuation — final review receipt

Date: 13 October 2026.

## Scope of this receipt

This records the derivations, exact finite controls, and independent mathematical reviews completed in this campaign. It is not a formal-verification certificate. No Lean declaration, repository source, external document, or earlier project note was modified.

## Exact arithmetic controls

The script verify_path_a_exact.py completed successfully and wrote PATH_A_EXACT_CONTROLS.json with status PASS.

The checks use rational thresholds and integer coefficients of \(\log p\). They compare exact finite divisor identities, not floating-point evaluations of logarithms. The coverage is:

| Control | Number of checked cases | What it checks |
|---|---:|---|
| Product/cofactor/squarefree-core coefficient agreement | 53,955 | Strict \(n>Y\) agrees with strict \(m<k/Y\), including equality seams |
| Truncated rough-core factorization | 11,343 | The complete remaining prime factor and the incomplete small divisor sum are preserved |
| Complete-small-part specialization | 1,838 | \(\mu(b)\Lambda(a)\) is used only with the strict \(a<k/Y\) condition |
| Mask/divisibility expansion | 24,576 | The zero-one mask, coefficient signs, and prime-power preservation |
| Restricted integer-drive expansion | 8,448 | \(Q\mid mn\iff Q/\gcd(Q,n)\mid m\), inclusive small side, and full divisor reconstruction |

The tested moduli were \(1,2,6,30,210,2310\), with exact coefficient budgets \(1,1,2,6,18,50\). The controls also check the concrete squarefree coefficients \(+\log2\) and \(-\log2\) and verify that the modulus-30 mask leaves both.

These finite controls do not certify PNT, Gevrey estimates, infinite products, uniform horizon bounds, or the open signed energy estimate. Those claims rest on their stated paper proofs and imported source foundations.

## Independent review received

### Parent/root

The parent/root independently read the adaptive-mask proof and checked the prime-power preservation, strict cutoff, modulus dependence of the error, and source preservation. The parent also read the exact history bridge, feedback commutator, and smooth-source derivative interpolation in Note 05 and reported that those derivations check.

Two missing plus signs in displayed estimates were found during that review and corrected:

- Note 03, equation (8): \(+C_{\delta,B}t^{1-2\delta}\) in the exponent.
- Note 05, equation (13): \(+C_\epsilon\) after the residual norm.

The original smooth source and its flat causal initial data are stated explicitly in the interpolation proof. All note headers use neutral joint-campaign continuation wording.

### Path C reviewer

The Path C reviewer independently checked the adaptive mask, its coefficient budget, the compensated \(nq\) cutoff, the stable remainder, and the surviving \(2q\) and \(2pq\) coefficients. The review emphasized two correct restrictions that are retained:

1. The Gevrey lattice estimate cannot simply be applied to the finite-regularity contact generator \(f_0\), whose exponential moment need not vanish.
2. Convolution with the original \(h_+\) is legitimate on the existing contact equation, but no bounded backwards \(L^2\) inverse for that compact convolution has been proved.

The same-source stable-error relation also implies that an unbounded native output is not attenuated by a fixed factor merely because the arithmetic mask is zero-one. Note 05 records the exact conditional norm-ratio statement.

In a subsequent independent read, the Path C reviewer also checked Note 05's full-history bridge, all shifts and signs in equations (5) and (9)–(12), and the exact feedback commutator. The reviewer reported that the source bridge and smooth-sensor upgrade pass. At that reviewer's suggestion, the interpolation proof now explicitly fixes the mollifier scale at the selected time while taking a convolution derivative; no derivative of the moving scale is intended. The previously identified plus sign in (13) had already been corrected.

### Path B reviewer

The Path B reviewer independently checked Note 05's smooth-source interpolation:

- moments through order \(j-2\) leave the \(\ell^{j-1}z^{(j)}\) Taylor remainder;
- the differentiated mollifier has \(L^2\) size \(\ell^{-3/2}\);
- \(\eta+3c/2=\epsilon/2\) for the displayed choices;
- flat causal initial data justify \(z^{(j)}=r_2*X^{(j)}\);
- the all-positive-damping and fixed-smooth-source restrictions are necessary and correctly stated.

The reviewer reported that this proof passes. The same display-sign correction in Note 05 had already been made.

## Cross-review performed by this branch

For B's 01_SHIFTED_NATIVE_SENSOR_AND_GAMMA_FREE_DEFECT.md, this branch checked:

- the interval derivative and every atomic jump of \(r_h\);
- the finite-variation estimate and zero-trace graph domain;
- the exact rational inverse and its Möbius measure;
- multiplicity and factorial normalization of the native zero jet;
- the full \(h=2\) digamma cancellation and three exponential terms.

A small precision issue was identified: the tail-integral estimate for the Möbius truncation is immediate for integer cutoffs, not unrestricted real cutoffs as written. The B note was corrected to state integer \(X\ge1\). No other issue was identified in those reviewed sections.

For C's 02_SOURCE_TILT_CONTRACTION_AND_GAMMA_FREE_FORCING.md, this branch checked:

- the paired real-zero Hadamard-product contraction and the role of parity;
- the shift factors in the original contact-source identity;
- the weighted causal prefix contraction;
- the exact \(h=2\) gamma cancellation;
- the source factors \(D(1/2)\), \(D(-3/2)\), \(D(-5/2)\) in the unchanged-source prime forcing.

The inspected h=2 source formulas and signs agree with B's independent calculation.

## Final claim discipline

The ledger marks the global residual bound OPEN. The contact results remain conditional on the imported paper contact foundations. The new source adapters do not create a new contact vector or prove new contact positivity. The result about the sieve cutoff concerns this explicit modulus method only. The magnitude obstruction concerns termwise absolute-value estimates only. No general sieve impossibility theorem is asserted.

No numerical result has been promoted to a universal theorem, and no paper result has been promoted to formal repository authority.

The final editorial pass replaced two opening descriptions of an “unbounded” term with “uncontrolled” or “without a proved upper bound.” Actual divergence is asserted only conditionally, for example under a hypothetical off-line zero. This wording correction introduces no new mathematical claim.
