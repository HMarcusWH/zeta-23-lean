# A03 — exact exponential profile and boundary-damping mean

**Status: DERIVED from the inherited PAPER fixed-detector explicit formula
and the new adjoint-jet bound. Descriptive consequences, not an independent
arithmetic closing theorem.**

This note records what the combined estimates say without assuming there
is a most displaced zero. It also distinguishes exponential growth from
the possible linear growth at its boundary damping.

## 1. Exact fixed-source expansion

For each distinct nontrivial native zero let
\(\lambda_\rho=\rho-1/2\), retaining multiplicity in
\(a_\rho=m_\rho K(\lambda_\rho)\). The inherited fixed-detector explicit
formula and evenness give, for positive time,

\[
F(t)=-\sum_\rho a_\rho e^{\lambda_\rho t}+R_h(t),
\qquad R_h(t)=O(e^{-5t/2})\quad(t\ge d+1),
\tag{1.1}
\]

with a harmless continuous compact initial part in \(R_h\). In particular
\(\sum_\rho|a_\rho|<\infty\). This follows from the compact smooth
detector's arbitrarily high vertical-strip transform decay and the native
zero-counting bound with multiplicity. No summation of positive off-line
residue magnitudes is substituted for the actual complex coefficients.

Set

\[
\alpha=\sup_\rho\Re\lambda_\rho\in[0,1/2].
\]

The native reflection symmetry gives \(\alpha\ge0\). A supremum is
used; no extremal zero is assumed. Formula (1.1) gives the actual bound
\(|F(t)|\le C e^{\alpha t}\).

## 2. Exact exponential growth rate of the complete signed fluctuation

For any fixed \(0<\epsilon<1/2\), let \(\mathcal R_\epsilon(T)\) be the
complete A02 signed fluctuation, with all boundary terms. Then

\[
\boxed{
\lim_{T\to\infty}\frac1T
\log\bigl(1+[\mathcal R_\epsilon(T)]_+\bigr)
=2\max(\alpha-\epsilon,0).
}\tag{2.1}
\]

**Proof.** The upper bound follows by integrating
\(e^{-2\epsilon t}|F(t)|^2\): it is bounded if \(\alpha<\epsilon\),
\(O(T)\) if \(\alpha=\epsilon\), and
\(O(e^{2(\alpha-\epsilon)T})\) otherwise. The higher-power channel has a
finite weighted \(L^2\) norm, so the same exponential upper rate holds for
\(F_1\) and for its energy minus the bounded diagonal.

If \(\alpha>\epsilon\), every zero with
\(\Re\lambda_\rho>\epsilon\) supplies Note 01's eventual lower bound
of rate \(2(\Re\lambda_\rho-\epsilon)\). Taking the supremum over these
fixed-zero lower bounds gives the lower rate in (2.1); constants need not
be uniform as the zero varies. If \(\alpha\le\epsilon\), the logarithm
is nonnegative, proving the remaining lower rate zero. QED.

The positive part and added one merely accommodate the bounded possible
negative values of \(\mathcal R\); they do not modify its native definition.
When \(\alpha>\epsilon\), Note 01 says \(\mathcal R\) itself is positive
and exponentially large on the full eventual tail.

## 3. Boundary damping detects only zeros attaining the supremum

Assume \(0<\alpha<1/2\). At the boundary damping \(\epsilon=\alpha\),

\[
\boxed{
\lim_{T\to\infty}\frac{\mathcal R_\alpha(T)}T
=\sum_{\Re\lambda_\rho=\alpha}|m_\rho K(\lambda_\rho)|^2.
}\tag{3.1}
\]

If \(\alpha=1/2\), define separately
\(\widehat{\mathcal R}_{1/2}=E_{1,1/2}-D_{1/2}\). Its mean divided by
\(T\) tends to zero by the same proof. This endpoint does not use or
extend the A02 separate \(\beta>0\) leading-term constants. Since every
individual nontrivial zero has \(\Re\rho<1\), its edge set is empty.

**Proof.** Absolute summability in (1.1) implies

\[
e^{-\alpha t}F(t)=
-\sum_{\Re\lambda_\rho=\alpha}a_\rho e^{i\Im\lambda_\rho t}+o(1).
\tag{3.2}
\]

Indeed every strictly-left term tends to zero, and its absolute value is
bounded by \(|a_\rho|\); dominated convergence for the series applies.
The edge series is uniformly absolutely convergent. For any finite part,
the Cesàro mean of its squared modulus is the sum of squared coefficients:
distinct ordinates have vanishing cross averages. Approximate the full
edge series uniformly by finite parts and pass to the mean. The \(o(1)\)
error in (3.2) is bounded and changes that mean by zero. Thus

\[
T^{-1}\int_0^T e^{-2\alpha t}|F(t)|^2dt
\longrightarrow\sum_{\Re\lambda_\rho=\alpha}|a_\rho|^2.
\]

Since \(\alpha>0\), the weighted higher-power norm is finite. Its squared
energy divided by \(T\), and its cross term with the \(O(T)\) full energy
divided by \(T\), both vanish. The diagonal is bounded. This proves (3.1).
QED.

Thus an unattained supremum can still govern the exact positive exponential
rates at every smaller damping, while its own normalized linear energy
limit is zero. It would be incorrect to infer an attained maximal zero
from exponential growth of the native observable.

## 4. Arithmetic limitation

Equations (2.1)--(3.1) refine the falsifier contract for an arithmetic upper
bound. They do not prove such an upper bound. In particular A02's
unconditional \(o(e^{(1-2\epsilon)T})\) bound remains compatible with
every possible \(0<\alpha<1/2\), and the native zero-free line at one is
compatible with an unattained supremum \(\alpha=1/2\).

The proof has not changed the fixed source into the dilating \(K=2\)
carrier, nor identified a contact exterior with \(F\). An independent
restriction on the exact signed native fluctuation remains OPEN.

