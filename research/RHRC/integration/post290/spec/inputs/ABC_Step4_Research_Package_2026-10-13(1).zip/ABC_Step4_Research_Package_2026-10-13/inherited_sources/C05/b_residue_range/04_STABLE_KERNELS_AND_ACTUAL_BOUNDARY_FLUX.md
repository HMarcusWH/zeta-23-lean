# C05 / round four — stable kernels, residue transfer, and the exact finite-horizon flux

**Status: DERIVED / PAPER.** This note distinguishes a bounded convolution operator from a bound on its action on the actual, potentially non-square-integrable native exterior. All kernels, shifts, and source residues are those of Note 01. No new positivity or range premise is asserted.

## 1. Residue-sensitive stable native kernels already exist

Write
\[
A(p)=A_N(p)=c_0(p)\zeta(p+1/2),\qquad
Q(p)=Q_N(p)=A(p)J(p),
\]
and let \(a_N,q_N\) be their actual causal kernels. Note 01 proves
\[
e^{\tau t}a_N,e^{\tau t}q_N\in L^1\cap L^2
\quad(0\le\tau<1/2).
\tag{1.1}
\]
Suppose \(\rho=1/2+\lambda\) is a hypothetical right native zero of multiplicity \(m\). The original unchanged generator has
\[
\operatorname{Res}_{p=\lambda}V_f(p)
 =m e^{a\lambda}G(-i\lambda)\ne0.
\tag{1.2}
\]

For every nonnegative integer \(k\), define the actual stable causal kernel
\[
r_k(t)=(-t)^k a_N(t),\qquad R_k(p)=A^{(k)}(p).
\tag{1.3}
\]
The pointwise exponential envelope for \(a_N\) implies the same weighted \(L^1\cap L^2\) property as (1.1), for every fixed \(k\) and every strict \(\tau<1/2\). Differentiation under the Laplace integral is therefore valid throughout \(\Re p>-1/2\).

At the specified zero, Leibniz differentiation gives
\[
A^{(k)}(\lambda)=0\quad(k<m),\qquad
A^{(m)}(\lambda)=c_0(\lambda)\zeta^{(m)}(\rho)\ne0.
\tag{1.4}
\]
Thus
\[
\boxed{
\operatorname{Res}_{p=\lambda}
 \mathcal L(r_m*v)(p)
=m c_0(\lambda)\zeta^{(m)}(\rho)
  e^{a\lambda}G(-i\lambda)\ne0.
}
\tag{1.5}
\]
The convolution is the actual locally \(L^2\) causal convolution: on any bounded time interval it involves only a bounded piece of \(r_m\) and the locally \(L^2\) exterior. Its transform equality holds first in the genuine common safe half-plane, and then meromorphically. There is no boundary-defined inverse transform substitution.

For simple native zeros, the completed kernel is already such an observation:
\[
Q(\lambda)=c_0(\lambda)\zeta'(\rho)\ne0,
\]
\[
\boxed{
\operatorname{Res}_{p=\lambda}\mathcal L(q_N*v)(p)
=c_0(\lambda)\zeta'(\rho)e^{a\lambda}G(-i\lambda).
}
\tag{1.6}
\]
For multiplicity \(m\ge2\), however, \(Q\) vanishes to order \(m-1\), so \(q_N*v\) is pole-blind at that zero. Equation (1.5) treats every finite multiplicity without assuming simplicity or a lower bound on a zeta derivative.

The complete residue audit is therefore:

| Actual channel acting on the original exterior | Transfer at a zero of multiplicity \(m\) | Residue | Established output bound |
|---|---|---|---|
| \(a_N*v=y_f\) | zero of order \(m\) | removed | \(e^{\tau t}y_f\in L^2\), all \(\tau<1/2\) |
| \(q_N*v\), \(m=1\) | nonzero | (1.6) | OPEN |
| \(q_N*v\), \(m\ge2\) | zero of order \(m-1\) | removed | no general new bound asserted |
| \(r_k*v\), \(k<m\) | zero of order \(m-k\) | removed | no general new bound asserted |
| \(r_m*v\) | nonzero | (1.5) | OPEN |

Hence the missing construction is not merely a bounded kernel whose transfer is nonzero at the off-line residue. Such genuine native kernels have now been displayed explicitly. What is absent is an independently established bound on the output of one of these kernels acting on this particular exterior. Applying a bounded \(L^2\) operator to an input not known to belong to \(L^2\) does not provide that bound.

## 2. Differentiating the stable input preserves its cancellations

The new native input is exponentially square integrable. Therefore every fixed time moment \(t^k y_f\) is square integrable, by choosing any fixed positive decay margin in Note 01. Its transforms satisfy the exact identities
\[
Y_f^{(k)}(p)
=\sum_{j=0}^k\binom{k}{j}A^{(j)}(p)V_f^{(k-j)}(p).
\tag{2.1}
\]
These are bounded combined observations, with every native pole canceled in the sum. They do not bound any summand separately.

For example, at a simple zero,
\[
\operatorname{Res}_{\lambda}(A'V_f)=A'(\lambda)\operatorname{Res}_{\lambda}V_f,
\]
whereas
\[
\operatorname{Res}_{\lambda}(AV_f')=-A'(\lambda)\operatorname{Res}_{\lambda}V_f.
\]
The stable derivative \(Y_f'=A'V_f+AV_f'\) therefore removes the same nonzero residue. No transfer of a bound to \(A'V_f\) is legitimate without an independent estimate of \(AV_f'\). For all fixed \(k\), (2.1) is an exact product rule, not an additional stability law.

This is the direct native version of the finite-jet observability issue classified for local controls in Note 02. It does not invoke a derivative-domain theorem for the compact source; Laplace differentiation here is multiplication of the actual causal output by physical time.

## 3. A rigorous finite-horizon lossless flux identity

The undamped native functional equation gives the bounded causal operator identity from Note 01,
\[
\mathsf A^*\mathsf Q+\mathsf Q^*\mathsf A=0.
\tag{3.1}
\]
One must not substitute the unknown global exterior directly into (3.1). Use its actual finite truncation
\[
x_T(t)=\mathbf1_{[0,T]}(t)v(t)\in L^2(\mathbb R_+),
\]
and put
\[
u_T=\mathsf A x_T,
\qquad z_T=\mathsf Q x_T.
\]
Both belong to \(L^2\) by (1.1), so all products below are integrable. Causality and \(a_N*v=y_f\) give
\[
u_T(t)=y_f(t),\qquad z_T(t)=(q_N*v)(t),
\quad\text{for almost every }t\in[0,T].
\]
Applying (3.1) to \(x_T\), then splitting the absolutely convergent pairing at \(T\), proves
\[
\boxed{
\Re\int_0^T\overline{y_f(t)}(q_N*v)(t)\,dt
=-\Re\int_T^\infty\overline{u_T(t)}z_T(t)\,dt.
}
\tag{3.2}
\]
This is an exact native boundary-flux identity with its full future term retained. The future term has no established sign. Cauchy–Schwarz only gives
\[
\left|\Re\int_0^T\overline{y_f}(q_N*v)\right|
\le \|\mathbf1_{(T,\infty)}u_T\|_2
     \|\mathbf1_{(T,\infty)}z_T\|_2,
\]
which contains the uncontrolled second output. The original aperture PSD condition does not assert positivity of this growing-support future pairing.

For positive damping, set \(a_\epsilon=e^{-\epsilon t}a_N\), \(q_\epsilon=e^{-\epsilon t}q_N\). Use the Fourier convention \(\widehat x(\omega)=\int_{\mathbb R}e^{-i\omega t}x(t)\,dt\), with its Plancherel normalization \(1/(2\pi)\). The literal identity is instead
\[
2\Re\langle a_\epsilon*x,q_\epsilon*x\rangle
=\frac1\pi\int_{\mathbb R}
 \Re\{\overline{A(\epsilon+i\omega)}Q(\epsilon+i\omega)\}
 |\widehat x(\omega)|^2\,d\omega.
\tag{3.3}
\]
Both multipliers are bounded, so this is valid for every causal \(x\in L^2\). Away from zeros, the coefficient is \(|A|^2\Re J\); the first expression remains defined at canceled zeros. The undamped functional equation does not make (3.3) zero or nonnegative on the shifted vertical line. Thus neither damping nor polarization produces the missing favorable sign.

## 4. A matched impossibility check

The complete proof in
`round4/root/02_GLOBAL_LOSSLESS_PAIR_AND_SCATTERING_COUNTERMODEL.md`
constructs an explicit positive real causal kernel with
\[
A(p)=\frac{(p+4)X(p)}{D(p)},\qquad
X(p)=p^4+\tfrac{67}4p^2+\tfrac{289}4,
\qquad J=X'/X.
\]
Both its forward kernel and \(Q=AJ\) decay at every strict rate below \(1/2\). The complete even real divisor gives exactly (3.1), and its positive kernel has a two-sided \(e^{-t/2}\) envelope. Yet at the simple zero
\[
\lambda=\tfrac14+i\tfrac{3\sqrt{15}}4,
\]
the actual output \(v_\lambda(t)=e^{\lambda t}\) has a nonzero stable input \(a*v_\lambda\), while \(q*v_\lambda\) retains a pole. In particular (3.2) is fully valid on every truncation and supplies no stability contradiction. The apparently unitary boundary scattering quotient has genuine right-half-plane poles.

This control jointly preserves the proposed abstract forward positivity, exact reflection symmetry, completed-kernel decay, lossless pair, and specified actual input. It loses the literal native integer/gamma data and the supported full contact. It therefore proves that the new bounded pair cannot by itself justify the needed output estimate, without asserting an alternative native xi function.

## 5. The precise remaining statement

For each specified hypothetical right zero, it would suffice to prove, from an additional genuine native source property, that the output in (1.5) is positively damped square integrable at some rate \(0<\epsilon<\Re\lambda\). Its nonzero residue would then contradict the analytic Laplace transform in \(\Re p>\epsilon\). At simple zeros the candidate output may be \(q_N*v\) in (1.6).

No such output estimate has been proved here. Uniform bounds for arbitrary causal inputs, the boundedness of \(q_N*\), the stable input \(y_f\), its differentiated identities, and the exact signed flux (3.2) do not provide it. The new direct input theorem and the sharp finite-pole lower bounds remain valid and useful; the closing native coupling remains **OPEN**.

No Lean theorem or repository change is involved. **RH remains OPEN.**
