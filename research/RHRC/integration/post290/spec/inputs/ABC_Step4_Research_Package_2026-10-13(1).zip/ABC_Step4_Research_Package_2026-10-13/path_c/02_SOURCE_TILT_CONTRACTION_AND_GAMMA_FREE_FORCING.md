# Path C continuation — a source-derived causal contraction with exact native forcing

Date: 13 October 2026. **DERIVED / PAPER, conditional on the supplied contact-source foundations.** The contraction proved here is genuine. Its forcing remains an actual native prime-discrepancy output whose required global bound is unproved. No RH closure or new formal result is claimed.

## 1. A contractive multiplier from the real source divisor

Let \(f_0\), \(a>0\), and \(G\) be the unchanged canonical full-contact source from the supplied C05 construction. Define

\[
D(p)=G(-ip)=\int_{-a}^a f_0(x)e^{-px}\,dx.
\]

The source is real and has definite parity \(\eta\in\{1,-1\}\). Thus \(D\) is real-type and \(D(-p)=\eta D(p)\). Its zeros are simple and lie on the imaginary axis.

**Theorem 1.1 (source-tilt contraction).** For every \(h>0\),

\[
\boxed{T_h(p):=\frac{D(p)}{D(p+h)}\in H^\infty(\mathbb C_+),\qquad
\|T_h\|_\infty\le1.}
\tag{1.1}
\]

**Proof.** The compact-support bound makes \(D\) entire of order at most one and finite exponential type. Let \(\nu=0\) in the even branch and \(\nu=1\) in the odd branch. Simplicity of all source zeros gives precisely this origin multiplicity: an even function cannot have a simple zero at zero, and an odd function must have one.

Enumerate the positive real source zeros as \(\gamma_k>0\), so the nonzero zeros of \(D\) are \(\pm i\gamma_k\). Its \(O(R)\) zero count gives \(\sum_k\gamma_k^{-2}<\infty\). Pairing opposite zeros in the order-one Hadamard product yields

\[
D(p)=C e^{bp}p^\nu\prod_k\left(1+\frac{p^2}{\gamma_k^2}\right).
\]

The product is locally normally convergent. The parity relation forces \(b=0\), because division of the formulas at \(p\) and \(-p\) would otherwise give \(e^{2bp}=1\) for every \(p\). Therefore

\[
D(p)=C p^\nu\prod_k\left(1+\frac{p^2}{\gamma_k^2}\right).
\tag{1.2}
\]

For \(\operatorname{Re}p>0\), every factor satisfies

\[
\frac{|p-i\gamma_k|}{|p+h-i\gamma_k|}\le1,
\qquad
\frac{|p+i\gamma_k|}{|p+h+i\gamma_k|}\le1,
\qquad
\frac{|p|}{|p+h|}\le1.
\]

Their finite products have modulus at most one. Passing to the locally normal limit proves (1.1). The denominator has no zero in the right half-plane, so the ratio is holomorphic there. QED.

Let \(\mathsf T_h\) be the bounded causal operator on \(L^2(0,\infty)\) whose Laplace multiplier is \(T_h\). The Paley–Wiener theorem gives \(\|\mathsf T_h\|\le1\). This asserts a bounded causal multiplier; it does **not** assert that its impulse response is an \(L^1\) function. A possible distributional or instantaneous component must not be dropped.

For locally square-integrable inputs, causality defines the output on each finite interval by first truncating the input on that interval. The resulting prefixes agree as the interval grows. This permits the exact identities below without assuming that the original exterior is globally \(L^2\).

## 2. Preserve the original source and its compact companion

Set

\[
L=2a,\quad f_+(t)=f_0(t-a),\quad c_+(t)=c_0(t-a),
\]

where \(c_0=-P_I(W_+*f_0)\) is the actual compact companion. Both shifted sources are supported in \([0,L]\). To avoid confusion, this \(c_0\) is a source; the rational factor in the native multiplier will not be used in this note.

Write \(\tau_Lu(t)=u(t-L)\) with causal zero extension, and let
\(\mathsf M_hu(t)=e^{-ht}u(t)\). The original null identity is

\[
W_+*f_++c_+=\tau_Lv,
\qquad v(s)=(W*f_0)(a+s).
\tag{2.1}
\]

No tilted source is being declared null. We only multiply this **existing exact equation** by the exponential. Because exponential multiplication respects proper causal convolution,

\[
(e^{-h\cdot}W_+)*(\mathsf M_h f_+)+\mathsf M_h c_+
=e^{-Lh}\tau_L(\mathsf M_hv).
\tag{2.2}
\]

Define

\[
S_h(p)=e^{ah}T_h(p),\qquad \mathsf S_h=e^{ah}\mathsf T_h.
\tag{2.3}
\]

The compact source transforms obey

\[
F_+(p)=e^{-ap}D(p),\qquad
S_h(p)F_+(p+h)=F_+(p).
\tag{2.4}
\]

Applying \(\mathsf S_h\) to (2.2), and using (2.4), gives

\[
(e^{-h\cdot}W_+)*f_+
 +\mathsf S_h\mathsf M_hc_+
=e^{-Lh}\tau_L(\mathsf S_h\mathsf M_hv).
\tag{2.5}
\]

All transform manipulations start in a common safe half-plane. They identify the same proper causal distributions; the multiplier action agrees with its bounded causal realization on the compact \(L^2\) inputs. Subtracting (2.5) from (2.1) is therefore legitimate locally even before any global exterior bound.

## 3. Exact forcing identity and a true finite-horizon norm equivalence

Let

\[
k_h=(1-e^{-h\cdot})W_+,
\qquad
\mathsf B_h=e^{-Lh}\mathsf S_h\mathsf M_h
           =e^{-ah}\mathsf T_h\mathsf M_h.
\tag{3.1}
\]

The subtraction just performed yields the exact native identity

\[
\boxed{
k_h*f_+ + c_+ -\mathsf S_h\mathsf M_hc_+
=\tau_L[(I-\mathsf B_h)v].
}
\tag{3.2}
\]

In particular, the complete left side vanishes before \(L\). Its separate terms generally do not vanish there. Taking a finite advance is justified by the complete identity, not by ignoring its compact history.

Define, for \(s>0\),

\[
z_h(s)=(k_h*f_+)(L+s),\qquad
j_h(s)=(\mathsf S_h\mathsf M_hc_+)(L+s),\qquad
w_h=z_h-j_h.
\tag{3.3}
\]

The compact \(c_+\) term has no tail beyond \(L\), and (3.2) becomes

\[
\boxed{w_h=(I-\mathsf B_h)v.}
\tag{3.4}
\]

Here \(j_h\in L^2(0,\infty)\) with the proved bound

\[
\|j_h\|_2\le e^{ah}\|\mathsf M_hc_+\|_2
             \le e^{ah}\|c_0\|_2.
\tag{3.5}
\]

The important quantitative fact is

\[
\|\mathsf B_h\|_{L^2\to L^2}\le q_h:=e^{-ah}<1.
\tag{3.6}
\]

This is an actual contraction. It is not a positivity inference about an inverse of \(a_N\).

**Theorem 3.1 (finite-horizon coercivity, without a global input assumption).** For every \(T>0\),

\[
\boxed{
(1-q_h)\|v\|_{L^2(0,T)}
\le\|w_h\|_{L^2(0,T)}
\le(1+q_h)\|v\|_{L^2(0,T)}.
}
\tag{3.7}
\]

**Proof.** Causality gives
\(1_{[0,T]}\mathsf B_hv
=1_{[0,T]}\mathsf B_h(1_{[0,T]}v)\).
The norm of this output prefix is at most \(q_h\|v\|_{L^2(0,T)}\). Apply both triangle inequalities to (3.4). All quantities involved are legal \(L^2\) prefixes. QED.

For every \(\epsilon\ge0\), the same statement holds after damping every signal by \(e^{-\epsilon s}\). The multiplier becomes \(T_h(p+\epsilon)\), whose \(H^\infty\) norm is still at most one, so the same \(q_h\) works.

**Corollary 3.2 (global equivalence and legal inversion).**

\[
\boxed{v\in L^2\ \Longleftrightarrow\ w_h\in L^2
\ \Longleftrightarrow\ z_h\in L^2.}
\tag{3.8}
\]

If \(w_h\in L^2\), the Neumann series \((I-\mathsf B_h)^{-1}w_h\) converges in \(L^2\), with norm at most \((1-q_h)^{-1}\|w_h\|_2\). Its value agrees with the original locally \(L^2\) exterior: the difference solves \(u=\mathsf B_hu\), and its norm on each finite interval is at most \(q_h\) times itself, hence is zero. This is a proof of uniqueness on the actual local domain, not an assumption that the unknown exterior was in the global inverse domain.

Because \(j_h\) is globally square integrable, (3.7) also shows that \(v,z_h,w_h\) have the same cumulative logarithmic energy exponent and the same quiet-subsequence property, with the harmless \(1+\) inside the logarithm. The same statements hold at positive damping. This is an exact norm comparison for a source-specific native output.

## 4. At \(h=2\), the archimedean tail disappears exactly

The native causal logarithmic derivative is

\[
J(p)=\frac{\zeta'}{\zeta}(p+1/2)
 +\frac1{p-1/2}+\frac1{p+1/2}
 +\frac12\psi(p/2+1/4)-\frac12\log\pi.
\]

Using \(\psi(z+1)-\psi(z)=1/z\) gives the exact identity

\[
\boxed{
J(p)-J(p+2)
=\frac{\zeta'}{\zeta}(p+1/2)
 -\frac{\zeta'}{\zeta}(p+5/2)
 +\frac1{p-1/2}-\frac1{p+3/2}-\frac1{p+5/2}.
}
\tag{4.1}
\]

Hence the actual proper causal distribution \(k_2=(1-e^{-2t})W_+\) is the signed locally finite measure

\[
\boxed{
k_2(dt)=
 (e^{t/2}-e^{-3t/2}-e^{-5t/2})\,dt
-\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}(1-n^{-2})\,
                       \delta_{\log n}(dt).
}
\tag{4.2}
\]

There is no residual diagonal atom or gamma tail in (4.2). Multiplication by \(1-e^{-2t}\) kills the diagonal and turns the gamma singularity into the displayed exact elementary terms. All prime powers remain, through the literal von Mangoldt function.

At \(x=a+s\), the original-source output in (3.3) is therefore

\[
\begin{aligned}
z_2(s)={}&e^{x/2}D(1/2)
 -e^{-3x/2}D(-3/2)-e^{-5x/2}D(-5/2)\\
&-\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}(1-n^{-2})
                      f_0(x-\log n),\qquad s>0.
\end{aligned}
\tag{4.3}
\]

The prime sum is locally finite and the equality is an \(L^2_{\rm loc}\) identity. It uses the unchanged finite-regularity source \(f_0\), with no smoothing, no altered aperture, and no parity switch.

Combining (3.3)–(3.7), the complete gamma-free forcing is

\[
\boxed{z_2-j_2=(I-e^{-2a}\mathsf T_2\mathsf M_2)v,}
\tag{4.4}
\]

and

\[
(1-e^{-2a})\|v\|_{L^2(0,T)}
\le\|z_2-j_2\|_{L^2(0,T)}
\le(1+e^{-2a})\|v\|_{L^2(0,T)}.
\tag{4.5}
\]

Thus the history correction is proved stable and the feedback inverse is proved stable. The uncontrolled term is now precisely the actual gamma-free prime-discrepancy output \(z_2\), with its full continuum cancellation in (4.3).

## 5. An all-nullity vector version inside the original kernel

The scalar construction already covers the canonical generator at every nullity. It can also be lifted to the full derivative basis without replacing any source by a non-null tilt.

Let

\[
f_j=\partial_x^j f_0\quad(0\le j<r).
\]

These are actual supported kernel vectors by the supplied polynomial-module/domain theorem. In particular, the finite Sobolev ceiling is respected: only derivatives through \(r-1\) are taken. Put \(\mathbf f_+=(f_{0,+},\ldots,f_{r-1,+})^\top\), with corresponding **individual actual companions** \(\mathbf c_+\) and original exteriors \(\mathbf v\). No companion is assumed to equal a derivative of another companion.

Let the lower-triangular matrix \(C(-h)\) have entries

\[
C(-h)_{jk}=\begin{cases}\binom jk(-h)^{j-k},&k\le j,\\0,&k>j.\end{cases}
\tag{5.1}
\]

Since \(\mathcal Lf_{j,+}(p)=e^{-ap}p^jD(p)\), the binomial theorem gives

\[
\mathbf F_+(p)
=e^{ah}T_h(p) C(-h)\mathbf F_+(p+h).
\tag{5.2}
\]

Define the vector multiplier

\[
\mathsf S_h^{(r)}=e^{ah}\mathsf T_h C(-h),\qquad
\mathsf B_h^{(r)}=e^{-ah}\mathsf T_h C(-h)\mathsf M_h.
\]

The preceding source-equation subtraction now gives, componentwise,

\[
\boxed{
k_h*\mathbf f_+ +\mathbf c_+
 -\mathsf S_h^{(r)}\mathsf M_h\mathbf c_+
=\tau_L[(I-\mathsf B_h^{(r)})\mathbf v].
}
\tag{5.3}
\]

To get an explicit contraction norm, write \(C(-h)=e^{-hN}\), where
\(N_{j,j-1}=j\) and all other entries vanish. Equip component space with

\[
\|\mathbf x\|_w^2=\sum_{j=0}^{r-1}w_j^2|x_j|^2,
\qquad w_j=\frac{(a/2)^j}{j!}.
\tag{5.4}
\]

Then \(\|N\|_w\le a/2\), because each nonzero weighted shift coefficient is
\(j w_j/w_{j-1}=a/2\). Consequently

\[
\|C(-h)\|_w\le e^{ah/2},\qquad
\boxed{\|\mathsf B_h^{(r)}\|_{L^2_w\to L^2_w}
\le e^{-ah/2}<1.}
\tag{5.5}
\]

Thus (3.7), the global equivalence, and the legal causal Neumann inversion hold for the full vector in this explicit fixed norm. In the \(r=1\) case the sharper scalar constant \(e^{-ah}\) applies. The forcing in (5.3) retains all components of the compact history; low nullity is not bypassed by inventing an unavailable pole-neutral source.

## 6. Actual closing attempts and their exact stopping point

### Attempt A: declare exponential source tilting a null-preserving map

This fails. The function \(e^{-hx}f_0(x)\) has transform \(G(z-ih)\), which is generally not \(G(z)\) times a polynomial of degree below \(r\). It belongs to the original supported form domain, but the original null equation does not follow. Equations (2.2)–(3.2) avoid that error: they tilt the complete existing source equation and retain its shifted native operator and compact forcing.

### Attempt B: use the proven feedback contraction to infer exterior stability

The operator \(I-\mathsf B_h\) really is invertible on global \(L^2\). The proof in §3 also repairs the possible local-versus-global uniqueness problem. Nevertheless its right side is \(w_h=z_h-j_h\). Only \(j_h\) has a proved global bound. The native term \(z_h\) may have precisely the off-line exponential rate of \(v\), as (3.7) proves. Therefore an unproved forcing bound cannot be inserted as part of the inversion.

### Attempt C: obtain the forcing bound from local PSD and finite support

Formula (4.3) makes the difficulty concrete. A prefix through time \(T\) uses prime powers up to \(e^{2a+T}\). The supported contact equation and PSD form at aperture \(a\) only directly involve prime shifts through \(e^{2a}\). The exact native integer/divisor identities and the \(k_2\) formula are retained, but no inequality established here bounds the full increasing prime discrepancy using that finite local information. Changing the far-prime tail preserves the local source-filter argument while changing this forcing; it is a control on an argument that omits global native arithmetic, not a counterexample to the exact native problem.

The new source-derived contraction therefore places the missing information in a specific place: a global \(L^2\) or quiet-subsequence bound for the unchanged-source expression (4.3) would propagate to the original exterior by a completely proved causal estimate. The all-kernel lower law from the companion note would then give the intended contradiction. No such native forcing bound is proved in this continuation.

## 7. Source and validation record

- C05 `root/03_COMPLETE_NATIVE_CHAIN_AND_ONE_OPEN_COUPLING.md`, §§1–3: exact source, parity, compact companion, same original exterior, domain and causal shifts.
- C05 inherited full polynomial-module theorem, as explicitly restated in that source: allowed derivative basis and its finite Sobolev ceiling.
- C05 `b_residue_range/01_COMPLETED_NATIVE_FORWARD_KERNEL_AND_ORIGINAL_EXTERIOR.md`, equation (1.4): exact completed causal logarithmic derivative.
- Path B continuation independently obtained and communicated the same \(J(p)-J(p+2)\) identity and the gamma-free measure (4.2). The present addition is the source-divisor contraction, the exact compact-history feedback identity, its domain-safe norm equivalence, and its all-nullity vector form.

Hadamard pairing, the elementary modulus comparison, the binomial matrix identity, the weighted shift norm, and the finite-prefix uniqueness argument are proved explicitly above. They do not rely on numerical evidence. The inherited contact existence/classification remains PAPER; it has not been newly formalized here.
