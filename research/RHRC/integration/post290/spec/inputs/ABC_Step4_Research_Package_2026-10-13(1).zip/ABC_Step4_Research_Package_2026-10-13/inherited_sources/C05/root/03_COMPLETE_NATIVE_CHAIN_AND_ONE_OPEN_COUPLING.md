# C05 / Round Four - the complete native chain and one remaining coupling

**Status: DERIVED / PAPER synthesis and conditional closing theorem. RH remains OPEN.**
This record gives the full original-source calculation used in this campaign. It
does not assume a proposed closing claim. The new proof records establish the
forward input, residue lower bounds, and failed closing mechanisms. The final
upper coupling is explicitly OPEN.

## 1. Fixed source, full domain, and inherited foundation

Assume an actual nontrivial zero of native zeta off the critical line. The
project's PAPER full-contact construction supplies one aperture \(a>0\),

\[
I=[-a,a],\qquad H_a\ge0,\qquad
E=\ker H_a\ne\{0\},\qquad \dim E=r,
\]

and its canonical real definite-parity generator \(f=f_0\ne0\). The form uses
zero extensions and the domain

\[
\mathcal D_{\log}(I)=
\left\{f\in L^2(\mathbb R):\operatorname{supp}f\subset I,
\int_{\mathbb R}\log(2+|u|)|F_f(u)|^2du<\infty\right\}.
\]

The operator is the self-adjoint compact-resolvent realization of the exact
native form. Its maximal-domain theorem, not an interior formal differential
equation, is used below. The inherited classification states

\[
F_f(z)=\int f(x)e^{-izx}dx=:G(z),\qquad
\widehat E=G\mathbb C[z]_{\le r-1},
\]

\[
f(-x)=\eta f(x),\quad\eta\in\{1,-1\},\quad
G(-z)=G^\#(z)=\eta G(z),
\]

where \(G^\#(z)=\overline{G(\bar z)}\). All zeros of \(G\) are real and
simple; both essential support endpoints are attained. The zero extension
satisfies \(f\in H^{r-1+s}\) for each fixed \(0<s<1/2\), and \(f\notin H^r\).
These are imported PAPER results. No new finite-state Lean certificate is
identified with this full-domain source.

Let \(P=P_I\), \(T=PW_+P\), and \(c=-Tf\). The inherited companion theorem
places this actual compact opposite-parity source in the required operator
domain. It has positive energy; it is not another null vector. The only null
equation used is \(W*f=0\) on the original \(I\). The construction takes the
full minimum over both parities and works for \(r=1,2\) as well as \(r\ge3\).
No pole-neutral null vector, support enlargement, or derivative beyond its
zero-extension domain is used in the original-source chain.

## 2. The complete unmodified residual

Write \(w=W*f\), \(v(s)=w(a+s)\) for \(s>0\), extended by zero for \(s<0\).
The actual maximal-domain theorem makes \(v\in L^2_{\mathrm{loc}}\) and
excludes endpoint distributions. Put

\[
\varrho(t)=\frac{e^{-t/2}}{1-e^{-2t}},\qquad
\Pi=\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}\delta_{\log n}.
\]

For \(x>a\), the literal native completion gives the following identity
almost everywhere, equivalently as an \(L^2_{\mathrm{loc}}\) identity:

\[
\begin{aligned}
w(x)={}&e^{x/2}G(-i/2)+e^{-x/2}G(i/2)\\
&-\int_{-a}^a\varrho(x-u)f(u)du
-\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}f(x-\log n).
\end{aligned}
\tag{2.1}
\]

The prime sum is locally finite, but its global tail is not truncated.
Equivalently, with the native Chebyshev function \(\psi_0\),

\[
w(x)=-\int e^{-t/2}f(x-t)\,d\{\psi_0(e^t)-e^t\}
-\sum_{j\ge1}e^{-(2j+1/2)x}G(i(2j+1/2)).
\tag{2.2}
\]

Here the \(j=0\) gamma term cancels the second elementary exponential in
(2.1); the entire remaining series is retained. No asymptotic remainder is
discarded. In the genuine initial half-plane \(\Re p>1/2\), let

\[
J(p)=\frac{\xi'}{\xi}(1/2+p),\qquad D_f(p)=G(-ip),\qquad
D_c(p)=F_c(-ip).
\]

The original-source identity is exactly

\[
\boxed{V_f(p):=\mathcal Lv(p)
=e^{ap}\{D_f(p)J(p)+D_c(p)\}.}
\tag{2.3}
\]

For completeness, if \(B_f(p)=e^{ap}G(-ip)\) and \(\tau_j=2j+1/2\), the
same transform has the full Dirichlet-prefix expression

\[
\begin{aligned}
V_f(p)={}&B_f(p)\frac{\zeta'}{\zeta}(p+1/2)
+\frac{B_f(1/2)}{p-1/2}+J_{\mathrm{pref}}(p)
-\sum_{j\ge1}\frac{B_f(-\tau_j)}{p+\tau_j},\\
J_{\mathrm{pref}}(p)={}&\sum_{2\le n<e^{2a}}
\frac{\Lambda(n)}{\sqrt n}e^{p(a-\log n)}
\int_{-a}^{a-\log n}f(u)e^{-pu}du.
\end{aligned}
\tag{2.4}
\]

The finite prefix has the positive sign shown. Its endpoint summand is zero
if \(n=e^{2a}\); it is not inferred to vanish at other terms. The elementary
and trivial poles cancel as required by the actual completion. Equations
(2.1)-(2.4) are the inherited C04 identities, with notation made consistent
with the new native forward equation.

If \(\rho=1/2+\lambda\) is a native zero of multiplicity \(m\), with
\(\Re\lambda>0\), set \(\gamma=-i\lambda\). Then

\[
\boxed{\operatorname{Res}_{p=\lambda}V_f(p)
=m e^{a\lambda}G(\gamma)\ne0.}
\tag{2.5}
\]

Nonvanishing follows from the real-zero property of \(G\), since \(\gamma\)
is nonreal. It does not require simplicity of the native zero or a uniform
lower bound on any native derivative.

## 3. New exact native construction: the original exterior has a stable input

Define

\[
a_N(t)=3e^{-t}\sum_{n\le e^t}\sqrt n
-2e^{-t/2}\lfloor e^t\rfloor,\qquad t\ge0,
\]

with zero extension, and

\[
A_N(p)=\mathcal La_N(p)=c_0(p)\zeta(p+1/2),\qquad
c_0(p)=\frac{p-1/2}{(p+1/2)(p+1)}.
\]

B03 proves \(0<a_N(t)\le(3/2)e^{-t/2}\). The new completed-kernel proof
establishes the actual causal convolution \(q_N=a_N*W_+\), with

\[
e^{\tau t}a_N,e^{\tau t}q_N\in L^1\cap L^2
\quad(0\le\tau<1/2).
\tag{3.1}
\]

The proof uses every integer edge in a zero-extension fractional Sobolev
estimate, the native logarithmic gamma multiplier, and the exact identity

\[
\begin{aligned}
Q_N=A_NJ&=A_N'+C_NA_N,\\
C_N(p)&=\frac2{p+1/2}+\frac1{p+1}
+\frac12\psi(p/2+1/4)-\frac12\log\pi.
\end{aligned}
\tag{3.2}
\]

Thus this is additional exact global native information. The two controlled
kernels are not merely local invariants shared by altered prime tails.

For \(T_du(t)=u(t-d)\), let \(f_+=T_af,c_+=T_ac\). Proper causal
convolution and the full-domain source identity give

\[
W_+*f_+=-c_++T_{2a}v,
\qquad q_N*f_++a_N*c_+=T_{2a}(a_N*v).
\]

The left side vanishes before \(2a\) by that identity. Therefore the actual
input

\[
\boxed{y_f(s)=(q_N*f_++a_N*c_+)(s+2a),\quad s\ge0}
\tag{3.3}
\]

satisfies

\[
\boxed{a_N*v=y_f,\qquad e^{\tau s}y_f\in L^2
\quad(0\le\tau<1/2).}
\tag{3.4}
\]

The finite advance, compact companion, all prime powers, and gamma correction
are preserved. The new proof covers every nullity on the same \(f\) and same
\(a\). Its first nonvanishing input jet at (2.5), the top jet among the
\(m\) adjoint tests, is

\[
\boxed{Y_f^{(m-1)}(\lambda)
=c_0(\lambda)e^{a\lambda}G(-i\lambda)\zeta^{(m)}(\rho)\ne0,}
\tag{3.5}
\]

and all lower jets vanish. The factor \(m\) in the residue cancels the
factorial ratio in this derivative; there is no extra \(m\) in (3.5).

## 4. New quantitative consequence: every large horizon sees the residue

Fix \(0\le\epsilon<\Re\lambda\), put \(\delta=\Re\lambda-\epsilon\),
and let \(\mathsf A_\epsilon\) be convolution with \(e^{-\epsilon t}a_N\).
It is bounded by \(M_\epsilon=3/[2(\epsilon+1/2)]\). Truncate only the
actual output:

\[
g_T=1_{[0,T]}e^{-\epsilon t}v(t),\qquad
e_T=e^{-\epsilon t}y_f-\mathsf A_\epsilon g_T.
\]

Both belong to \(L^2\), and causality makes \(e_T=0\) on \([0,T]\).
The \(m\) adjoint evaluation jets annihilate the full range; on the actual
input they are zero except for (3.5). Centering their polynomial tests at
\(T\) and minimizing the monic polynomial norm with Laguerre polynomials
gives the exact single-zero lower bound

\[
\boxed{\|e_T\|_2\ge
\frac{|Y_f^{(m-1)}(\lambda)|(2\delta)^{m-1/2}}{(m-1)!}
e^{\delta T}.}
\tag{4.1}
\]

The complete proof, its exact finite-pole Gram extension, and an independent
stable causal deflation proof are included in this report. They remove the
earlier polynomial penalty in \(T\), using already known lower-jet vanishing.
The triangle inequality in the defining expression for \(e_T\) implies

\[
\int_0^T e^{-2\epsilon s}|v(s)|^2ds
\ge C_{\rho,\epsilon}e^{2(\Re\rho-1/2-\epsilon)T}
\quad(T\ge T_{\rho,\epsilon}),
\tag{4.2}
\]

where \(C_{\rho,\epsilon}>0\). The zero, source, multiplicity, and damping
are fixed before the constants and threshold. No rightmost zero or uniform
constant over the native divisor is assumed.

Let \(\Delta=\sup_\rho|\Re\rho-1/2|\). Combining (4.2) with the imported
weighted \(L^2\) upper theorem only at its authorized rates \(\alpha>\Delta\)
proves

\[
\boxed{\lim_{T\to\infty}\frac1T\log\left(
1+\int_0^T e^{-2\epsilon s}|v(s)|^2ds\right)
=2(\Delta-\epsilon)_+,\qquad\epsilon\ge0.}
\tag{4.3}
\]

The upper limit in \(T\) is taken before \(\alpha\downarrow\Delta\). The
endpoint \(\epsilon=\Delta\) may have unbounded subexponential energy.
Equation (4.3) strengthens the abscissa theorem to an actual limit, and
excludes unusually quiet subsequences below that exponential rate. It is not
an independent proof that the rate is zero.

## 5. What the new native functional-equation coupling actually controls

The real even completed xi function implies \(J(i\omega)\) is purely
imaginary off its discrete zeros. On the actual undamped causal \(L^2\)
space, (3.1) therefore gives

\[
\mathsf A^*\mathsf Q+\mathsf Q^*\mathsf A=0,
\tag{5.1}
\]

where the kernels are \(a_N,q_N\). For the legal truncation
\(x_T=1_{[0,T]}v\), this yields the full future-flux identity

\[
\Re\int_0^T\overline{y_f(t)}(q_N*v)(t)dt
=-\Re\int_T^\infty
\overline{(a_N*x_T)(t)}(q_N*x_T)(t)dt.
\tag{5.2}
\]

The future term is retained and has no proved favorable sign. Directly
substituting \(v\) into (5.1) would assume its unproved global domain.
At positive damping, the coefficient is
\(\Re\{\overline{A_N(\epsilon+i\omega)}Q_N(\epsilon+i\omega)\}\),
not forced to vanish by the functional equation. Local PSD at \(a\) does not assign a
sign to an observation of increasing support.

For simple native zeros \(Q_N(\lambda)\ne0\). At a zero of arbitrary
multiplicity \(m\), the decaying native kernel
\(r_m(t)=(-t)^ma_N(t)\) has transfer

\[
R_m(\lambda)=A_N^{(m)}(\lambda)
=c_0(\lambda)\zeta^{(m)}(\rho)\ne0.
\]

These are explicit residue-sensitive filters. What is OPEN is a global bound
for \(q_N*v\) in the simple case, or \(r_m*v\) in the general case. Kernel
decay does not bound an unknown non-\(L^2\) input. The stable product-rule
identities for derivatives of \(Y_f=A_NV_f\) cancel the exposed residues
between their summands and provide no individual output estimate.

The complete explicit positive-kernel, even-divisor scattering control in
root Note 02 satisfies (3.1), (5.1), and a stable actual input while retaining
an off-axis growing output. Its apparently unitary scattering quotient has
right-half-plane poles, certified by the exact quartic value \(-135/4\).
It does not preserve the native integer/gamma data or contact; it falsifies
the proposed implication from the displayed abstract coupled identities.

## 6. One precise missing native coupling and the conditional contradiction

The following statement on the original source would suffice:

**OPEN Native quiet-subsequence lemma.** For the exact contact generator
furnished by the hypothetical off-line-zero construction,

\[
\boxed{\liminf_{T\to\infty}\frac1T
\log\left(1+\int_0^T|(W*f_0)(a+s)|^2ds\right)=0.}
\tag{NQ}
\]

Only one fixed original aperture and generator are involved. No estimate
uniform over apertures, nullities, or compact sources is required. A proof
constructing one such generated contact whenever an off-line zero exists
would also suffice. The lemma requires a genuinely native relation between
the supported null equation and the literal infinite prime/gamma completion.

**Conditional closing proof.** A hypothetical off-line zero has, by the
native reflection symmetry, a representative with \(\Re\rho>1/2\).
The PAPER contact construction supplies the state in Section 1. Equations
(2.5), (3.4), and (3.5) supply a nonzero adjoint input jet on the original
exterior. Equation (4.2) with \(\epsilon=0\) forces the left side of (NQ)
to be at least \(2(\Re\rho-1/2)>0\), contradicting (NQ). This treats every
finite multiplicity, both parity branches, and every nullity. Alternatively
(4.3) identifies the same limit as \(2\Delta\). Thus an independently
proved (NQ), together with the audited foundations and validation gates,
would close this route.

No proof of (NQ) has been found in this campaign. It is another precise
form of the remaining RH-strength upper information, not an additional
premise established by (4.3). The strong all-positive-damping exterior
\(L^2\) law would imply it. Its formulation is weaker as a generic norm
requirement, but the new exact exponent shows that, for this native
generated exterior, these closing targets enforce the same zero width.

The original cardinal-annihilation law remains OPEN as well. It would need
to annul the exact exterior pairing on a superlinear distinct set of simple
critical ordinates. None of the new filters or signed identities supplies
that annihilation, and no compactly supported exact global cardinal
representer has been reintroduced.

## 7. Why this campaign adds information without claiming closure

The new work constructs an exponentially decreasing actual input for the
unchanged contact exterior at every nullity; proves optimal finite-jet
leakage and an exact cumulative energy exponent; supplies an exact causal
polarized adapter with its full remainder; and derives the signed native
future-flux identity. These are new statements beyond renaming a range
condition. The local-observation classification proves that an entire class
of finite observations justified only by the unchanged local data must
cancel the native divisor. The exact-native negative logarithmic-generator
measure separately falsifies the proposed positive convolution-root repair.

The attempts stop at a definite mathematical obstruction: every presently
controlled channel either cancels the off-line pole or requires a domain or
sign for its actual output that has not been proved. No bound on that
uncanceled output has been inferred from a stable kernel, a positive
companion, finite-dimensional minimality, a changed-source budget, or a
single fixed-aperture PSD condition.

All new deductions are PAPER with internal review. There was no new formal
green result in this campaign, no source edit, and no claim promotion.
The 49 requirements, WP0-WP7, and D2 = Full continuous K3, both parities,
on \([1/512,\log16]\), are unchanged. **RH remains OPEN.**
