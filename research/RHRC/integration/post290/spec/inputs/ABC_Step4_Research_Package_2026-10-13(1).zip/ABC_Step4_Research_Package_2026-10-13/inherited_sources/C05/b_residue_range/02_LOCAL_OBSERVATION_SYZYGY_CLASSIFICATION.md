# C05 / round four — classification of locally justified stable exterior observations

**Status: NEW MATCHED IMPOSSIBILITY THEOREM / PAPER.** This theorem does not posit an alternative native xi function. It explicitly identifies which global integer and completed-functional-equation data its controls lose.

## 1. What is classified

The elementary residue-row audit says that a meromorphic vector with residue \(r_\lambda\) is invisible to an analytic observing row \(M\) exactly when \(M(\lambda)r_\lambda=0\). The result here is stronger: **the exact positive, power-consistent far-prime controls force every universally stable finite-channel observation into a complete analytic source-annihilator module.** With mild actual causal multiplier bounds, that condition is also sufficient.

Fix the hypothetical native contact interval \(I=[-a,a]\). Let
\[
f_0,f_1,\ldots,f_{N-1}\in\operatorname{Dom}T
\]
be actual compact \(L^2\) sources supported in \(I\), selected from unchanged local data; \(f_0\) is the canonical real-zero generator. Other sources may be null polynomials, actual companion images, or other genuine domain sources. Their additional domains must have been proved; this theorem supplies no new derivative tower.

Let
\[
D_j(p)=\int_I f_j(x)e^{-px}\,dx,\qquad
C_j(p)=\int_I (Tf_j)(x)e^{-px}\,dx.
\]
Both vectors \(D,C\) are entire. In the safe half-plane,
\[
X_j(p)=\int_a^\infty e^{-pt}(W_+*f_j)(t)\,dt
=D_j(p)J(p)-C_j(p).
\tag{1.1}
\]
The source domain and causal half convention exclude endpoint distributions; these are the same prerequisites used in B03's actual exterior formula. For shifted exteriors the whole vector is multiplied by \(e^{ap}\), a common nowhere-zero factor that changes no annihilator.

Let \(M(p)\) be a \(d\times N\) matrix holomorphic on \(\Re p>0\). It is selected once and is **unchanged** under all the far-prime modifications below. The common offset \(E(p)\), if present, is also unchanged and holomorphic there. The observation is
\[
Y(p)=M(p)X(p)+E(p).
\tag{1.2}
\]
It may represent an actual causal convolution observation. For necessity only the displayed analytic transfer and a claimed stable output are required.

We use a deliberately weak stability condition: the actual causal output has \(e^{-\varepsilon t}Y(t)\in H^{-k_\varepsilon}(\mathbb R)\) for every \(\varepsilon>0\), with some finite \(k_\varepsilon\). This implies holomorphy of its causal Laplace transform throughout \(\Re p>0\). Indeed choose a smaller fixed damping than \(\Re p\), pair the resulting distribution with the exponentially decreasing smooth test on its lower support, and differentiate under that pairing. No common Sobolev order or estimate as \(\varepsilon\downarrow0\) is needed.

## 2. Exact positive prime-base controls with a prescribed pole

Choose any
\[
\lambda=\delta+i\omega,\qquad 0<\delta<1/2,\quad \omega>0,
\qquad \alpha=1/2-\delta.
\]
Choose a prime cutoff \(P>e^{2a}\), larger than any prescribed finite prefix, and large enough that \(2P^{-\alpha}<1\). For \(\sigma=\pm1\), put
\[
w_p^{(\sigma)}=
\begin{cases}
1,&p\le P,\\
1+\sigma\,2p^{-\alpha}\cos(\omega\log p),&p>P,
\end{cases}
\qquad
\widetilde\Lambda_\sigma(p^k)=w_p^{(\sigma)}\log p.
\tag{2.1}
\]
All weights are positive. The same multiplier is used for every power of a given prime. Replace only the prime coefficients in \(W_+\), keeping its smooth completion and exact diagonal literally fixed.

Every changed delay exceeds \(2a\). Hence the entire compressed operator \(T\), its domain, the full \(H_a\), the source list \(f_j\), the compact transforms \(D,C\), and every matrix \(M\) constructed from those unchanged objects are identical. There is no re-minimization or transported witness.

The causal transfer difference, initially absolutely convergent sufficiently far right, is
\[
\Delta J_\sigma(p)=
-\sigma\sum_{q>P}\sum_{k\ge1}(\log q)q^{-k(p+1/2)-\alpha}
\left(q^{i\omega}+q^{-i\omega}\right),
\tag{2.2}
\]
where \(q\) in this display runs over prime bases.

**Lemma 2.1.** Equation (2.2) continues meromorphically to a neighborhood of \(\lambda\), and
\[
\boxed{\operatorname{Res}_{p=\lambda}\Delta J_\sigma(p)=-\sigma.}
\tag{2.3}
\]
The analogous conjugate pole is present. Additional singularities elsewhere are permitted.

**Proof.** Let
\[
L(s)=\sum_q(\log q)q^{-s}.
\]
For \(\Re s>1\),
\[
L(s)=-\frac{\zeta'}{\zeta}(s)
-\sum_q\sum_{k\ge2}(\log q)q^{-ks}.
\tag{2.4}
\]
The second term is holomorphic for \(\Re s>1/2\), by normal absolute convergence on compact sub-half-planes. Thus \(L(s)\) has at \(s=1\) a simple pole of residue \(+1\). The \(k=1\) part of (2.2) is
\[
-\sigma\bigl[
L(p+1/2+\alpha-i\omega)
+L(p+1/2+\alpha+i\omega)
\bigr]
\]
plus a finite entire prefix. At \(p=\lambda\), the first argument is \(1\); the second is \(1+2i\omega\), where zeta is nonzero by the unconditional zero-free line \(\Re s=1\). The second summand is therefore analytic near this point. This classical input was checked in the official NIST DLMF, Section 25.10(i), https://dlmf.nist.gov/25.10#i, which attributes it to Hadamard and de la Vallée Poussin; no RH or zero-free interior strip is assumed.

The \(k\ge2\) part of (2.2) is normally convergent near \(\lambda\). At \(\Re p=\delta\), its smallest absolute exponent in the prime base is
\[
2(\delta+1/2)+\alpha=3/2+\delta>1,
\]
with room for a neighborhood. The geometric sum over \(k\) preserves convergence. No higher prime-power channel can remove the stated pole. This proves (2.3). \(\square\)

This exact meromorphic calculation strengthens the earlier time-asymptotic control. It does not assign a completed functional equation or entire xi function to the modified tails.

## 3. Complete finite-channel necessity

**Theorem 3.1.** Suppose that, for every \(\lambda\) in the open half-strip of Section 2, the observation (1.2) is stable for **both** corresponding positive controls \(\sigma=\pm1\), with the same \(M,D,C,E\). Then
\[
\boxed{M(p)D(p)\equiv0\qquad(\Re p>0).}
\tag{3.1}
\]
Consequently its native transfer simplifies identically to
\[
Y(p)=-M(p)C(p)+E(p);
\tag{3.2}
\]
the complete native \(J\), not merely one residue, has disappeared.

**Proof.** Proper causal convolution and unchanged compression give
\[
X_\sigma-X_0=D\,\Delta J_\sigma.
\tag{3.3}
\]
The difference of the two stable observations is holomorphic on \(\Re p>0\). By (2.3), its residue at the chosen \(\lambda\) is
\[
-2M(\lambda)D(\lambda).
\]
It must vanish. This is true at every point of a nonempty open subset of the right half-plane. Every entry of \(MD\) is holomorphic, so the identity theorem gives (3.1) throughout that connected half-plane. Substitution into (1.1) proves (3.2). \(\square\)

The proof does not need to decide whether the original native exterior is stable or whether one particular modified sign is unstable. It uses the exact two-sign difference. Possible original poles at the chosen point cancel from that difference.

### The actual annihilator module

The canonical \(D_0(p)=G(-ip)\) has no zero on \(\Re p>0\), because \(G\) has only real zeros. Thus every scalar analytic row satisfying (3.1) has the unique form
\[
\boxed{
M(p)=\sum_{j=1}^{N-1}M_j(p)
\left(e_j^{\mathsf T}-\frac{D_j(p)}{D_0(p)}e_0^{\mathsf T}\right).
}
\tag{3.4}
\]
This is a free analytic source-annihilator module of rank \(N-1\). In particular the rank of any such observing matrix is at most \(N-1\) at every point.

For the canonical source and its companion \(c=-Tf_0\), \(D_c/D_0=-\mathfrak p\). The basis row (3.4) is exactly \((\mathfrak p,1)\), the blind B03 coupled row. Equation (3.4) shows that adding any finite number of further locally determined channels cannot repair that failure through observations whose stability is justified on all the same local controls.

## 4. Sufficiency with actual causal multiplier domains

Assume, in addition, that \(M\) is an actual causal distributional multiplier with
\[
\|M(\varepsilon+i\omega)\|
\le C_\varepsilon(1+\omega^2)^{k/2}
\tag{4.1}
\]
for some finite \(k\) and each fixed \(\varepsilon>0\), and that the offset \(E\) is stable in the stated sense, of order \(H^{-k_E(\varepsilon)}\). If \(MD=0\), then (3.2) is stable for every altered completion, in \(H^{-\max(k,k_E(\varepsilon))}\) after each positive damping. If the offset is itself in \(H^{-k}\), this simplifies to \(H^{-k}\).

Indeed each \(C_j\) is the transform of the same compact \(L^2\) source \(Tf_j\). Plancherel and (4.1) give
\[
\|e^{-\varepsilon t}\mathcal L^{-1}(MC)\|_{H^{-k}}
\le C_\varepsilon\sum_j\|e^{-\varepsilon x}Tf_j(x)\|_2.
\tag{4.2}
\]
The convolution is proper because the multiplier is causal and the source is compact. Equality with the actual observation holds first on a common safe half-plane and then as lower-supported distributions. Its pieces at negative times cancel as prescribed by the actual exterior identity; no boundary-defined substitute has been inserted.

Therefore, within this specified finite causal multiplier class, universal stability under the positive local-preserving tails is **equivalent** to source-channel annihilation. This is a classification theorem, not merely a check of one example.

## 5. No finite Laplace-derivative repair

A possible repair differentiates the observations in the Laplace parameter before combining them, hoping to recover the information removed by one row. The same controls classify that attempt.

Consider
\[
Y(p)=\sum_{k=0}^{K}M_k(p)X^{(k)}(p)+E(p),
\tag{5.1}
\]
with all \(M_k\) analytic and unchanged under the controls. Laplace differentiation corresponds to multiplication of the original exterior by powers of physical time; it is legitimate in the initial safe half-plane. It is **not** an assertion that extra derivatives of a compact null vector remain in its operator domain.

By Leibniz,
\[
\sum_{k=0}^{K}M_k(DJ)^{(k)}
=\sum_{\ell=0}^{K}S_\ell(p)J^{(\ell)}(p),
\]
\[
S_\ell(p)=\sum_{k=\ell}^{K}
\binom{k}{\ell}M_k(p)D^{(k-\ell)}(p).
\tag{5.2}
\]

**Theorem 5.1.** If (5.1) is stable for both controls at every chosen \(\lambda\), then
\[
\boxed{S_\ell\equiv0\quad(0\le\ell\le K).}
\tag{5.3}
\]
Thus every derivative of the native logarithmic derivative is canceled before stability.

**Proof.** The highest possible pole order in the two-sign difference is \(K+1\), with coefficient
\[
-2(-1)^K K!\,S_K(\lambda).
\]
Stability forces its vanishing for every \(\lambda\) in the open half-strip, so \(S_K\equiv0\). After deleting that identically zero term, the same argument proves \(S_{K-1}\equiv0\), and induction gives all of (5.3). This argument correctly handles derivatives of the analytic coefficients: once the highest coefficient is identically zero, none of its lower Taylor terms remain. \(\square\)

If the \(M_k\) have the causal multiplier bounds of Section 4, the surviving compact terms \(\sum M_kC^{(k)}\) are again stable: \(C^{(k)}\) is the transform of the compact \(L^2\) function \((-x)^kTf_j(x)\). No new source-domain theorem is needed for this statement.

## 6. Scope, native discriminator, and matched controls

The modified coefficients preserve the exact full contact, every selected local source, half-diagonal normalization, literal smooth completion, positivity and consistency over all powers of a prime, any prescribed finite prime prefix, and ordinary PNT leading behavior. Their exact divisor defect is
\[
(\widetilde\Lambda_\sigma*1)(n)-\log n
=\sigma\,2\sum_{\substack{p\mid n\\p>P}}
v_p(n)(\log p)p^{-\alpha}\cos(\omega\log p).
\tag{6.1}
\]
It is generally nonzero. They do not preserve the true native integer identity, the globally matched functional equation, or the native entire xi divisor. No single control is asserted to preserve the union of the far-prime and smooth-quartet hypotheses.

The theorem therefore says exactly this: a successful new stable observation must use a **global native property that these controls lose**, in a way that establishes stability for the native completion alone. It does not say that every native theorem is blind.

The new completed forward kernel from the companion note illustrates the distinction. Its transfer \(A_NJ\) is stable because the exact native identities give \(A_NJ=A_N'+C_NA_N\). Under the present controls it acquires \(A_N\Delta J_\sigma\), whose planted pole survives wherever \(A_N(\lambda)\ne0\); thus its stability is not a theorem of the preserved local data. At a *native* off-line zero, however, \(A_N(\lambda)=0\), and the existing controlled channel is again blind. Its actual-input adjoint jet detects the remaining range defect.

The smooth-quartet model remains a direct falsifier for inferring individual exterior stability from companion/Pick positivity. The all-orders Herglotz model, divergent jump compensator, and low-nullity collar have their separate previously established scopes; none supplies the missing native coefficient/completion coupling.

This result strengthens the residue-observability audit into a matched necessity-and-sufficiency theorem for a broad finite observation class, including finite Laplace jets. It leaves genuinely global native residue-sensitive estimates **OPEN**.
