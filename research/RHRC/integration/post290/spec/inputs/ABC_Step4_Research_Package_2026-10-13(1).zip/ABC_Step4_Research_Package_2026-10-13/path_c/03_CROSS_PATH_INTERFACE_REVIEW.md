# Independent Path C review of the new commutator and adaptive sieve

Date: 13 October 2026. **PAPER/source-interface review.** This is an internal independent derivation check of the displayed formulas, not a new review of all inherited contact foundations, external peer review, or a formal build.

## 1. Contact commutator: sign, domain, and gamma cancellation check

Reviewed root source: `cross_path/01_gamma_free_contact_commutator.md`.

For the convention

\[
q(u,v)=\iint W(x-y)\overline{u(x)}v(y)\,dx\,dy,
\]

the exact scalar factor is

\[
e^{\theta(x+y)}-\tfrac12e^{2\theta x}-\tfrac12e^{2\theta y}
=-e^{\theta(x+y)}[\cosh(\theta(x-y))-1].
\]

Thus the sign in the root's double-commutator identity is correct. For contact vectors the two polarized null terms vanish against the actual form-domain test vectors. This is a supported full-contact identity, not positivity extrapolated to a larger aperture.

All kernel vectors have some fixed positive fractional \(H^s\) regularity with \(s<1/2\). Same-interval compact smooth approximations converge in such an \(H^s\), which controls the logarithmic form norm. Smooth exponential multiplication on the fixed interval preserves that convergence. Correlations converge uniformly by the \(L^2\) translation estimate. The factor \(\cosh(\theta t)-1=O(t^2)\) kills the native diagonal and regularizes the \(1/|t|\) archimedean singularity; only a continuous density and finitely many prime atoms are paired with the limiting correlation. This supplies the required extension to the original finite-regularity targets, including nullity one and two.

At \(\theta=2\), the root's density and atom factors are exactly

\[
b_2(t)=\tfrac12(e^{2t}-1)
             (e^{t/2}-e^{-3t/2}-e^{-5t/2}),
\]

\[
\alpha_n=\frac{(n^2-1)^2}{2n^{5/2}}\Lambda(n).
\]

The quadratic identity therefore has a positive prime sum and a negative continuous integral, as displayed in the root note. The density changes sign where \(e^{3t}-e^t-1=0\). The endpoint correlation at \(2a\) is zero because it is a continuous \(L^2\) correlation whose supports overlap there only on a measure-zero set. There is no missing half-weight at that endpoint.

The root's fixed-gap remote-pulse control correctly preserves the local compressed form and every exponential commutator while changing the exterior rate. Its stated scope is essential: it does not preserve the full native integer/completed-zeta identities or the C05 \(A,Q\) relation. The control refutes a deduction from local data alone, not a native global closing theorem.

## 2. Adaptive sieve: the finite algebra and changing cutoff check

Reviewed Path A source: `path_a/04_PRIME_POWER_PRESERVING_ADAPTIVE_SIEVE.md`, with `path_a/02_ROUGH_CORE_AND_SQUAREFREE_SIGN_BUDGETS.md` for the strict divisor boundary and surviving signs.

The mask

\[
w_P(k)=1_{\omega(\gcd(k,P))\le1}
=\sum_{Q\mid P,\ Q\mid k}\mu(Q)(1-\omega(Q))
\]

is correct for squarefree \(P\), including the cases with zero or one selected prime. Its absolute coefficient budget
\((r-2)2^{r-1}+2\), \(r=\omega(P)\), is correct at \(r=0,1\) as well as \(r\ge2\). The bound by \(P(1+\log_2P)\) follows from \(2^r\le P\). Since the mask is one on every prime power, it leaves the actual von Mangoldt output unchanged; it is not a damping of that output.

For a fixed small divisor \(n\), the replacement

\[
Q\mid mn\quad\Longleftrightarrow\quad
\frac{Q}{\gcd(Q,n)}\mid m
\]

and the restricted integer drive

\[
U_q(s)=q^{-1/2}[(\log q)V(s-\log q)+U(s-\log q)]
\]

have the correct factors and arguments. The compensated cutoff

\[
Y_P=\frac{e^t}{BP(t)t^2}
\]

ensures \(nq\le e^t/(Bt^2)\) for every term in the small-divisor part. This is exactly what preserves the Gevrey exponent after the divisibility restriction. The resulting remainder bound has the required \(P^{-1/2}\) prefactor, coefficient budget, and exponent
\(c_B=\kappa_*\sqrt B-1/2>0\).

The strict long-divisor condition \(n>Y_P\) implies

\[
m<BP(t)e^dt^2,
\]

including when the cutoff passes an integer. Assigning equality to the small-divisor part is consistent. If \(Y_P<1\), that small part is empty. The concrete primorial choice is measurable and introduces no derivative term because all identities are pointwise finite sums. Derivative claims about the adaptive fields would require a separate jump analysis; the current note makes no such claim.

For the specified slowly growing modulus, the error is actually in unweighted \(L^2\) on the late tail, hence also in every positively damped \(L^2\) space. The bound on its initial finite interval is harmless after the stated initial cutoff.

The prime-power disappearance is consistent with \(Y_P/\sqrt X\to\infty\): the only squarefree divisor of a prime power that could survive is its base prime, and either that prime is below the cutoff or its cofactor is one, whose logarithm is zero. Both sign examples \(2q_-\) and \(2pq_+\) have the correct remaining coefficients \(-\log2\) and \(+\log2\). The primes \(p,q_+,q_-\) outside the selected palette exceed the cofactor scale as required, and their rough cores remain comparable to \(e^t\). The fixed-ratio PNT existence claim is uniform over the stated subexponential cofactor range because the relevant interval bases all tend to infinity.

No algebraic or source-cutoff error was found in the reviewed adaptive reduction. The result is a stable-error decomposition of the unchanged detector, and it leaves the complete surviving signed field without the required upper bound.

## 3. Which sources may be combined

Three objects remain distinct:

| Object | What is proved about it | What cannot be transferred silently |
|---|---|---|
| Canonical contact source \(f_0\) | Original support, actual null equation, real source zeros, finite Sobolev regularity | It is not A's Gevrey detector and has \(D_{f_0}(1/2)\ne0\) |
| Fixed arithmetic detector \(h\) | Gevrey integer-drive decay and double zero \(K(1/2)=K'(1/2)=0\) | It is not a contact null vector |
| Explicit convolution \(h*f_0\), or a supported polarized probe | Can be made a legal smooth, pole-neutral observation of the unchanged source after recording the source map and shifts | Smoothing does not preserve the original null equation or give a bounded inverse |

In particular, A's rapid-input estimate cannot simply be attached to \(f_0\): its elementary zero mode does not vanish, and its finite Sobolev regularity is not the fixed detector's Gevrey regularity.

There are legitimate adapters. Convolve the complete C source equation with the actual causal shift of \(h\), retaining all compact histories. Alternatively, explicitly construct \(h*f_0\). This convolution is compact and Gevrey because the Gevrey derivatives fall on \(h\), while \(f_0\in L^1\); it inherits the detector's elementary zeros. Its integer fields are the corresponding fixed-detector fields convolved with the compact \(f_0\), giving the required rapid tail with source-dependent constants. The resulting observation is **not** declared null. An appropriate causal shift must include its whole support. These constructions connect the arithmetic to the original contact, but do not transfer a global inverse norm through compact smoothing.

## 4. Why the stable errors do not create a norm-absorption estimate

The C source filter gives an actual strict contraction

\[
(I-\mathsf B_2)v=z_2-j_2,\qquad
\|\mathsf B_2\|\le e^{-2a}<1,\qquad j_2\in L^2.
\tag{4.1}
\]

The stable inverse is complete, including local-domain uniqueness. Its right side \(z_2\) is the full native continuum-minus-prime discrepancy; a bound on that forcing is still required.

For A's fixed detector, the exact sieve decomposition is

\[
F_h=S_{P,B}+r_{P,B},\qquad r_{P,B}\in L^2
\tag{4.2}
\]

on the late tail, with a finite-interval extension included when causal operators are used. The gamma-free kernel satisfies

\[
k_2*h_+=-F_{h,+}+d_h,\qquad d_h\in L^2,
\tag{4.3}
\]

where \(h_+\) is the chosen causal compact shift. Equation (4.3) is exact: \(K(1/2)=0\) removes the growing elementary tail after the full compact source has passed; the two decaying elementary convolutions and the \(n^{-2}\)-weighted prime measure are stable. Their initial compact histories are part of \(d_h\).

Convolving the complete C equation with \(h_+\) therefore replaces its gamma-free term by the masked arithmetic field convolved with \(f_+\), **plus proved stable terms**. The remaining term has the form

\[
S_{P,B,+}*f_+,
\tag{4.4}
\]

with the documented finite shifts. In the all-nullity vector equation it has the corresponding componentwise convolutions with \(f_{j,+}\). There is no established global bound on (4.4). Young's inequality bounds it by the norm of \(S_{P,B,+}\) if that norm is known; that is exactly the unproved signed arithmetic estimate.

The mask being zero or one does not yield a pointwise or norm contraction of \(F_h\). It acts inside the signed Möbius/divisor expansion and fixes the complete \(\Lambda\) output. More quantitatively, (4.2) gives for every horizon

\[
\bigl|\|S_{P,B}\|_{L^2(0,T)}-\|F_h\|_{L^2(0,T)}\bigr|
\le\|r_{P,B}\|_2.
\tag{4.5}
\]

Under a hypothetical visible growing native pole, the right side is fixed while \(\|F_h\|_{L^2(0,T)}\) grows exponentially. Therefore

\[
\frac{\|S_{P,B}\|_{L^2(0,T)}}{\|F_h\|_{L^2(0,T)}}\longrightarrow1.
\tag{4.6}
\]

The same statement holds at any damping below the pole displacement and for the correctly composed compact-source observation. Thus no attenuation constant below one follows from this masking identity. Such a bound would be new arithmetic information, not a consequence of the already proved stable error.

Likewise, at shift \(h=2\), the actual feedback output \(\mathsf B_2v\) is itself globally \(L^2\), since the supplied exterior theorem already gives \(e^{-2s}v\in L^2\). Hence the entire growing residue of \(v\) resides in the complete forcing \(z_2-j_2\). The contraction has not shrunk that forcing; it has isolated it.

Finally, compact smoothing by \(h_+\) has no bounded \(L^2\) inverse on arbitrary outputs: its Fourier multiplier decays at high frequency. One should keep the smoothed exact identity and its residue visibility, or prove a separate source-specific inverse estimate. Neither the scalar nor the weighted vector contraction supplies such an inverse for a different smoothing operator automatically.

## 5. Check of the subsequently written joint bridge

Also reviewed A's path_a/05_JOINT_SOURCE_BRIDGE_AND_CLOSING_ATTEMPT.md, equations (5), (9)–(16).

Its complete source equation and the shifts by \(d\) and \(L=2a\) are correct. The independently stable \(J_A\) retains the initial compact history. The noncommuting damping/filter term is exactly

\[
\mathsf H\mathsf B_2v-\mathsf B_2\mathsf Hv
=e^{-2a}\mathsf T_2[
  (h_+-e^{-2\cdot}h_+)*(e^{-2\cdot}v)].
\]

It is globally \(L^2\) by the supplied domain \(e^{-2s}v\in L^2\). Thus moving the compact filter through the feedback is legitimate only with this displayed correction, as done there. It produces a coercive prefix estimate for \(h_+*v\), with the still unknown complete signed residual on the right. A missing plus sign before its additive \(C_\epsilon\) was found and has been corrected in the reviewed working version of equation (13).

The additional all-positive-damping sensor equivalence for the fixed smooth detector is also supported. Its high-order local interpolation estimates \(z'\) from the small-scale averaged \(z\) and the known exponential envelope of \(z^{(j)}\). The moment conditions through order \(j-2\) yield the stated remainder \(\ell^{j-1}\sup|z^{(j)}|\). With \(\ell=e^{-ct}\), the scale is held fixed when taking the convolution derivative at the selected point \(t\); no derivative of the chosen scale is intended. Taking \(c=\epsilon/4\), \(\eta=\epsilon/8\), and \(c(j-1)>1/2\) makes both terms square integrable after the target damping. B's graph-domain inverse then applies.

This uses infinitely smooth original-detector output, the all-positive-damping premise, and its known high-derivative envelope. It is not a proof that a fixed-damping \(L^2\) sensor norm automatically controls its derivative, nor an extension to the original finite-regularity contact generator or to moving-cutoff arithmetic derivatives.

When the small-rough-core sector is also removed, A's total error is only proved in every **positive-damping** space. The residual norm comparison and failed-attenuation statement are correspondingly made at fixed \(\epsilon>0\). An undamped \(L^2\) claim is not needed or imported.

## 6. Review outcome

The root commutator, A's mask and compensated cutoff, and C's source-derived contraction are compatible on their stated sources. The combined identities retain every prime power, compact-history correction, and source change. They do not yet give the inequality needed for absorption: the surviving signed rough-core norm remains the complete uncontrolled forcing, and the proved errors are stable additions to it.

This conclusion does not rule out a genuinely new native estimate for that signed field. It identifies the exact additional information a closing argument must provide, after the new identities have done all the work they legitimately can.
