# B04.6 — The attempted actual native closure and its smallest unresolved lemma

**Status:** OPEN primary target; PAPER exact reductions, calculations and falsifications. No complete RH proof.

## Original target, no changed source

Preserve `r=1/4096`, `h=k_r*k_r`, `U=(tN)*h`, `F=M_mu*U=Pi*h`, and B03's actual `a_N*F=v`. The strict independent goal is

\[
\forall\epsilon>0:\quad e^{-\epsilon t}F(t)\in L^2(0,\infty)
\]

or the weaker sufficient closure membership `v_epsilon ∈ closure(Ran A_epsilon)` for all epsilon>0. Both imply the complete fixed-detector orbit subexponential estimate and then RH, conditional on the inherited PAPER single-detector proof. Neither was established in this round.

## The explicit approximation that was attempted

For large `X`, construct `G_X=F_{1,X}-B_X+F_{>=2}` from genuine finite primes, the explicit compact continuum cutoff pulse and the complete stable higher-power channel (proof note 03). This source-based approximant satisfies `G_X=F` on `0<=t<=T=log X-d`, but its definition does **not** use the unknown future values of F.

For `epsilon>0`, set `g_{X,epsilon}=e^{-epsilon t}G_X` and

\[
E_{X,\epsilon}=v_\epsilon-\mathsf A_\epsilon g_{X,\epsilon}.
\]

Then `E_{X,epsilon}=0` through horizon T. For `0<epsilon<1/2`, PNT yields only

\[
\boxed{\|E_{X,\epsilon}\|_2=o(X^{1/2-\epsilon}).}
\tag{KNOWN}
\]

This estimate is independent of assuming F has finite weighted energy, but it is too weak. It does not tend to zero, and it permits the exact native off-line leakage lower bound `c_{rho,epsilon}X^delta`, with `delta<1/2-epsilon`.

The alternative finite Euler inverse outputs also agree on each fixed horizon but are known to diverge in the global weighted norm. They cannot be used in place of the corrected prime-prefix approximation without retaining their escaped energy.

## A smaller, quantitative sufficient missing lemma

For **these explicit genuine approximants**, it would suffice to prove

\[
\boxed{
\forall\epsilon\in(0,1/2)\ \forall\eta>0\ \exists C_{\epsilon,\eta}<\infty:\quad
\|E_{X,\epsilon}\|_2\le C_{\epsilon,\eta}X^\eta
\text{ for all sufficiently large }X.}
\tag{OPEN-X}
\]

Unlike range closure, this demands no convergence of `E_X` to zero. It only requires subpower global leakage for this *specific* native approximant sequence. It is still a strong, presently unproved native statement.

**Proof that OPEN-X would imply RH.** If a right off-line zero `rho` exists, select `0<epsilon<Re rho-1/2` and `0<eta<delta=Re rho-1/2-epsilon`. For `X=e^{T+d}`, the sharp Laguerre theorem gives `||E_X||>=c e^{delta T}=c e^{-delta d}X^delta`. OPEN-X gives `||E_X||<=C X^eta`, a contradiction for large X. Native reflection handles left off-line zeros. All transforms, shifts, source identities and the multiple-zero jet are those of the original detector.

Thus OPEN-X is a concrete, testable global *error* inequality, not a rewritten norm assumption on F. But its mathematical content is still RH-strength in this setting: it is not licensed by the existing PNT remainder or finite-horizon agreement.

## Exact signed-pair alternative

On the identical fixed source, A02's signed residual is

\[
\mathcal R_\epsilon(T)=
[P_{+,\epsilon}(X)-C_{+,\epsilon}X^{1-2\epsilon}]
-[P_{-,\epsilon}(X)-C_{-,\epsilon}X^{1-2\epsilon}]
-[\mathcal B_\epsilon(T)-C_{\partial,\epsilon}X^{1-2\epsilon}],
\]

including the complete future boundary. It satisfies

\[
\mathcal R_\epsilon(T)=\|e^{-\epsilon t}F_1\|_{L^2(0,T)}^2-D_\epsilon(X).
\]

A separately proved uniform upper bound on `R_epsilon(T)` for every positive epsilon would close the proof. The sharper Laguerre lower bound shows that even a bound growing more slowly than `e^{eta T}` for every eta>0 would exclude off-line zeros. A02 currently supplies only `o(e^{(1-2epsilon)T})` up to the fixed d scale.

The arithmetic mechanism must control **the signed positive-minus-negative pair covariance and its correlated cutoff-edge energy**, not each absolute term separately.

## Exact falsification register

- **FALSE:** the prescribed local energy is globally nonincreasing. For the genuine detector its second derivative at zero is positive (B01).
- **FALSE:** native retarded impulse is a nonnegative measure (B01 fourth-derivative certificate).
- **FALSE:** universal continuum residual accretivity (B02 native negative-work probe).
- **FALSE:** finite Euler inverse outputs have uniform global weighted norms (B02).
- **FALSE as a generic principle:** weighted square-summable inverse coefficients plus rapidly decaying full output imply graph convergence of finite integer-source truncations (note 04).
- **BLOCKED:** positive forward kernel implies closed-range membership for the actual v. B03 gives an explicit adjoint defect under any hypothetical right zero.
- **BLOCKED:** an exactly bounded coupled contact observation controls native poles. Its observing row annihilates all pole residues (note 05).
- **BLOCKED:** ordinary PNT main-term cancellation supplies a subpower global residual. A02's remaining error scale has a strict exponent gap.

All are scoped; none is an RH counterexample. No negative result about every possible native analytic proof has been asserted.

## Exports and next mathematical information gain

**To A:** sharpen the adversarial target from `R_epsilon ≳ e^{2delta T}/T^{2m-2}` to `R_epsilon ≳ e^{2delta T}` under a hypothetical off-line zero; preserve A02's exact boundary loss and sign-changing correlation kernel. Testing OPEN-X against any proposed signed pair upper bound is immediate.

**To C:** the native forward multiplier's only closed-range obstruction is its Blaschke zero divisor; the contact-polynomial/causal comparison must pass a nonzero residue-rank test before using positivity. The full-contact polarized source is not a replacement for the fixed B detector or a null source. The delay/finite-history correction in note 05 is required.

**Highest-leverage next experiment/theorem:** derive a source-specific quantitative bound on the *complete* global error of the corrected prime-prefix approximants, combining exact native divisor identities with correlation cancellation beyond PNT. A falsification should first test the method on the same-input altered kernel, the `mu²` signed-control, native sign-changing prime-pair kernel and finite Euler divergence. This is a proposed next move, not evidence that OPEN-X holds.
