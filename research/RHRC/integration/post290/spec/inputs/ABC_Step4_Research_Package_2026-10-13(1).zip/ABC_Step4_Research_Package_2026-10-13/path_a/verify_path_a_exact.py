#!/usr/bin/env python3
"""Exact finite algebra controls for the Joint campaign Path A paper reductions.

No floating-point logarithms are used.  A rational linear combination of
logarithms is represented by its integer coefficients of log(prime).
Finite checks are controls, not proofs of the asymptotic propositions.
"""

from collections import Counter
from fractions import Fraction
from functools import lru_cache
from math import gcd
from pathlib import Path
import json


@lru_cache(None)
def factor(n):
    out = []
    p = 2
    while p * p <= n:
        e = 0
        while n % p == 0:
            n //= p
            e += 1
        if e:
            out.append((p, e))
        p = 3 if p == 2 else p + 2
    if n > 1:
        out.append((n, 1))
    return tuple(out)


@lru_cache(None)
def divisors(n):
    out = [1]
    for p, e in factor(n):
        before = list(out)
        for j in range(1, e + 1):
            out.extend(a * p**j for a in before)
    return tuple(sorted(out))


def mu(n):
    f = factor(n)
    return 0 if any(e > 1 for _, e in f) else (-1) ** len(f)


def omega(n):
    return len(factor(n))


def clean(c):
    return {p: e for p, e in sorted(c.items()) if e}


def add_log(c, n, scale=1):
    for p, e in factor(n):
        c[p] += scale * e


def lambda_log(n):
    f = factor(n)
    return {f[0][0]: 1} if len(f) == 1 else {}


def a_direct(k, y):
    c = Counter()
    for n in divisors(k):
        if n > y:
            add_log(c, k // n, mu(n))
    return clean(c)


def a_cofactor(k, y):
    c = Counter()
    for m in divisors(k):
        if m * y < k:
            add_log(c, m, mu(k // m))
    return clean(c)


def a_core(k, y):
    rad = 1
    for p, _ in factor(k):
        rad *= p
    repeated = k // rad
    c = Counter()
    for d in divisors(rad):
        if repeated * d * y < k:
            add_log(c, repeated * d, mu(rad) * mu(d))
    return clean(c)


def w_mask(k, pmod):
    return int(omega(gcd(k, pmod)) <= 1)


def mask_expansion(k, pmod):
    return sum(mu(q) * (1 - omega(q))
               for q in divisors(pmod) if k % q == 0)


def scale_dict(c, scale):
    return clean({p: v * scale for p, v in c.items()})


def threshold_grid(k):
    ys = {Fraction(1, 2), Fraction(3, 2), Fraction(k + 1)}
    for n in divisors(k):
        ys.update((Fraction(n) - Fraction(1, 3),
                   Fraction(n),
                   Fraction(n) + Fraction(1, 3)))
    return sorted(y for y in ys if y > 0)


def check_coefficients(limit):
    tested = 0
    for k in range(1, limit + 1):
        full = Counter()
        for n in divisors(k):
            add_log(full, k // n, mu(n))
        assert clean(full) == lambda_log(k), (k, full)
        for y in threshold_grid(k):
            actual = a_direct(k, y)
            assert actual == a_cofactor(k, y), (k, str(y), "cofactor")
            assert actual == a_core(k, y), (k, str(y), "core")
            tested += 1
            rad = 1
            for p, _ in factor(k):
                rad *= p
            if actual:
                assert Fraction(k, rad) < Fraction(k, 1) / y
                assert min(p for p, _ in factor(k)) < Fraction(k, 1) / y
            if y * y > k and len(factor(k)) == 1:
                assert actual == {}, (k, str(y), "prime_power")
    return tested


def check_complete_and_boundary(limit):
    truncated_cases = complete_cases = 0
    for k in range(1, limit + 1):
        for y in threshold_grid(k):
            r = Fraction(k, 1) / y
            actual = a_direct(k, y)
            for a in divisors(k):
                b = k // a
                if gcd(a, b) != 1:
                    continue
                if any(p < r for p, _ in factor(b)):
                    continue
                predicted = Counter()
                for m in divisors(a):
                    if m < r:
                        add_log(predicted, m, mu(b) * mu(a // m))
                assert actual == clean(predicted), (k, str(y), a, b)
                truncated_cases += 1
                if a < r:
                    assert actual == scale_dict(lambda_log(a), mu(b))
                    complete_cases += 1
    seam = {
        str(y): a_direct(42, y)
        for y in (Fraction(20, 3), Fraction(7), Fraction(22, 3))
    }
    assert seam["20/3"] == {}
    assert seam["7"] == {2: 1, 3: 1}
    assert seam["22/3"] == {2: 1, 3: 1}
    return truncated_cases, complete_cases, seam


def check_masks(limit, moduli):
    tested = 0
    budgets = {}
    for pmod in moduli:
        assert all(e == 1 for _, e in factor(pmod))
        r = omega(pmod)
        budget = sum(abs(mu(q) * (1 - omega(q))) for q in divisors(pmod))
        exact_budget = Fraction((r - 2) * 2**r, 2) + 2
        assert budget == exact_budget
        budgets[pmod] = budget
        for k in range(1, limit + 1):
            assert w_mask(k, pmod) == mask_expansion(k, pmod)
            if len(factor(k)) <= 1:
                assert w_mask(k, pmod) == 1
            tested += 1
        # The explicit cofactor-cost limitation needs no primality oracle:
        missing_prime = factor(pmod + 1)[0][0]
        assert (pmod + 1) % missing_prime == 0
        assert pmod % missing_prime != 0
        assert missing_prime <= pmod + 1
    return tested, budgets


def check_masked_small_drive(max_product, y, pmod):
    """Compare all product coefficients, inclusive small side, exactly."""
    direct = {}
    expanded = {k: Counter() for k in range(1, max_product + 1)}
    for k in range(1, max_product + 1):
        c = Counter()
        for n in divisors(k):
            if n <= y:
                add_log(c, k // n, w_mask(k, pmod) * mu(n))
        direct[k] = clean(c)

    for qcap in divisors(pmod):
        cq = mu(qcap) * (1 - omega(qcap))
        for n in range(1, min(max_product, y.numerator // y.denominator) + 1):
            q = qcap // gcd(qcap, n)
            assert 1 <= q <= pmod
            for m in range(q, max_product // n + 1, q):
                assert (m * n) % qcap == 0
                add_log(expanded[m * n], m, cq * mu(n))

    for k in range(1, max_product + 1):
        assert direct[k] == clean(expanded[k]), (max_product, str(y), pmod, k)
        total = Counter(direct[k])
        for p, v in a_direct(k, y).items():
            total[p] += w_mask(k, pmod) * v
        assert clean(total) == lambda_log(k)


def main():
    out = {
        "status": "PASS",
        "scope": "Exact finite algebra controls only; not an RH proof or an asymptotic norm test.",
        "log_representation": "integer coefficients of log(prime); no floating-point logarithms",
    }
    out["coefficient_threshold_cases"] = check_coefficients(2048)
    tr, co, seam = check_complete_and_boundary(256)
    out["rough_core_truncated_cases"] = tr
    out["rough_core_complete_cases"] = co
    out["boundary_counterexample_k42"] = seam
    moduli = [1, 2, 6, 30, 210, 2310]
    out["mask_cases"], out["mask_coefficient_budgets"] = check_masks(4096, moduli)

    grids = [Fraction(1, 2), Fraction(1), Fraction(3, 2),
             Fraction(8, 3), Fraction(3), Fraction(10, 3),
             Fraction(20, 3), Fraction(7), Fraction(22, 3),
             Fraction(23), Fraction(70)]
    count = 0
    for pmod in moduli:
        for y in grids:
            check_masked_small_drive(128, y, pmod)
            count += 128
    out["masked_restricted_drive_product_cases"] = count

    # Two actual squarefree coefficient examples, with a common R=10.
    # They test the identities, not existence in a late native source window.
    positive_k = 2 * 23 * 101
    negative_k = 2 * 503
    assert a_direct(positive_k, Fraction(positive_k, 10)) == {2: 1}
    assert a_direct(negative_k, Fraction(negative_k, 10)) == {2: -1}
    assert w_mask(positive_k, 30) == w_mask(negative_k, 30) == 1
    out["squarefree_examples"] = {
        "positive": {"k": positive_k, "Y": str(Fraction(positive_k, 10)),
                     "A_log_prime_coefficients": {2: 1}, "mask_modulus": 30},
        "negative": {"k": negative_k, "Y": str(Fraction(negative_k, 10)),
                     "A_log_prime_coefficients": {2: -1}, "mask_modulus": 30},
    }
    target = Path(__file__).with_name("PATH_A_EXACT_CONTROLS.json")
    target.write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
