# C05 / round four — exact finite-pole adjoint observability

**Status: NEW DERIVED / PAPER, conditional at specified hypothetical native zeros.** This extends the centered-jet improvement independently derived in the A-interface branch. It does not establish that any off-line zero exists and supplies no independent upper estimate.

## 1. An abstract causal theorem with the native variables retained

Let \(a_N\) be the exact B03 integer kernel and
\[
\mathsf A_\varepsilon g=(e^{-\varepsilon\cdot}a_N)*g,\qquad
\|\mathsf A_\varepsilon\|\le
M_\varepsilon:=\frac3{2(\varepsilon+1/2)}.
\]
Suppose the actual causal equation
\[
a_N*F=y
\tag{1.1}
\]
is proved as lower-supported distributions, with \(F\in L^2_{\rm loc}\) of some finite exponential order and \(y_\varepsilon=e^{-\varepsilon t}y\in L^2(0,\infty)\). No global domain for \(F_\varepsilon\) is assumed.

Take any **finite** set of distinct right native zero coordinates
\[
\lambda_j=\rho_j-1/2,\qquad
q_j=\lambda_j-\varepsilon,\qquad \Re q_j>0,
\]
with multiplicities \(m_j\). Suppose the actual input has the native zero jets
\[
Y^{(k)}(\lambda_j)=0\quad(0\le k<m_j-1),\qquad
Y^{(m_j-1)}(\lambda_j)=c_j\ne0.
\tag{1.2}
\]
This is exactly the pattern proved for the original contact input and for the two smooth A/B inputs in Section 5 below.

The functional
\[
\ell_{j,k}(w)=\int_0^\infty(-t)^k e^{-q_jt}w(t)\,dt
\quad(0\le k<m_j)
\tag{1.3}
\]
is continuous on \(L^2\), and it annihilates the range of \(\mathsf A_\varepsilon\). Indeed the transfer \(A_N(p)\) has a zero of order \(m_j\) at \(\lambda_j\); all derivatives of every range transform through order \(m_j-1\) vanish there. The input values are (1.2), with no factor or phase lost.

Define the actual finite-horizon truncation and leakage
\[
g_T=1_{[0,T]}F_\varepsilon,\qquad
e_T=y_\varepsilon-\mathsf A_\varepsilon g_T.
\tag{1.4}
\]
Both belong to \(L^2\), and exact causal equality gives \(e_T=0\) almost everywhere on \([0,T]\).

## 2. Centering all jets at the horizon

For \(0\le k<m_j\), the centered polynomial expands as
\[
(-(t-T))^k=\sum_{\ell=0}^k\binom{k}{\ell}T^{k-\ell}(-t)^\ell.
\]
Every lower input jet vanishes. Therefore
\[
\int_T^\infty (-(t-T))^k e^{-q_jt}e_T(t)\,dt
=
\begin{cases}
0,&k<m_j-1,\\
c_j,&k=m_j-1.
\end{cases}
\tag{2.1}
\]
Put \(w_T(s)=e_T(T+s)\). Its \(L^2(0,\infty)\) norm is \(\|e_T\|_2\), and (2.1) becomes
\[
\int_0^\infty(-s)^k e^{-q_js}w_T(s)\,ds
=d_{j,k}(T),
\qquad
d_{j,k}(T)=e^{q_jT}c_j\,1_{k=m_j-1}.
\tag{2.2}
\]
The large polynomial \(T^{m_j-1}\) appearing in the uncentered test has disappeared by using the entire exact zero-jet information.

## 3. Exact Gram bound for a finite native pole set

Use the conjugate-first Hilbert pairing and define
\[
\psi_{j,k}(s)=(-s)^k e^{-\overline{q_j}s}.
\]
These finitely many exponential polynomials are linearly independent. To see this, a finite combination vanishing almost everywhere vanishes as an entire exponential polynomial; applying successively the constant-coefficient operators that annihilate all but one exponential isolates each polynomial. Its coefficients must all be zero.

Their positive-definite Gram matrix is explicit:
\[
\boxed{
\Gamma_{(j,k),(\ell,n)}
=\langle\psi_{j,k},\psi_{\ell,n}\rangle
=\frac{(-1)^{k+n}(k+n)!}
{(q_j+\overline{q_\ell})^{k+n+1}}.
}
\tag{3.1}
\]
Every denominator has positive real part.

**Theorem 3.1.** Under (1.1)–(1.2),
\[
\boxed{\|e_T\|_2^2\ge d(T)^*\Gamma^{-1}d(T).}
\tag{3.2}
\]
This lower bound is the **exact minimum** of the squared norm among all \(L^2\) functions satisfying the finite jet constraints (2.2). It is not asserted to be attained by the actual native leakage.

**Proof.** Let \(\Psi z=\sum z_{j,k}\psi_{j,k}\). Then the vector of constraints on \(\Psi z\) is \(\Gamma z\). Set \(z_*=\Gamma^{-1}d\), so \(w_*=\Psi z_*\) satisfies (2.2). For any other satisfying \(w\), the difference \(w-w_*\) is orthogonal to the span of all \(\psi_{j,k}\), and hence to \(w_*\). Thus
\[
\|w\|_2^2=\|w_*\|_2^2+\|w-w_*\|_2^2
\ge z_*^*\Gamma z_*=d^*\Gamma^{-1}d.
\]
Taking \(w=w_T\) proves the claim. \(\square\)

The corresponding lower bound for the actual output prefix is
\[
\boxed{
\|F_\varepsilon\|_{L^2(0,T)}
\ge
\frac{\sqrt{d(T)^*\Gamma^{-1}d(T)}-\|y_\varepsilon\|_2}
{M_\varepsilon}.
}
\tag{3.3}
\]
One can replace the right side by its positive part. This follows only from the triangle inequality in (1.4); no unproved global output norm is used.

At \(T=0\), the same construction bounds the distance of the input from the closure of the full range. At positive \(T\), it quantifies the unavoidable defect beyond the exact matched horizon.

## 4. Single zero and the real conjugate pair

### 4.1. Arbitrary multiplicity, with no horizon polynomial loss

For a single zero, write \(\delta=\Re q>0\), \(m=n+1\). Orthogonalizing the top monomial against all lower monomials for the weight \(e^{-2\delta s}ds\) gives
\[
P_n(s)=\frac{n!}{(2\delta)^n}L_n(2\delta s),
\]
whose leading term is \((-s)^n\). The Laguerre identities, proved by repeated integration by parts from Rodrigues' formula, give
\[
\int_0^\infty e^{-2\delta s}|P_n(s)|^2ds
=\frac{(n!)^2}{(2\delta)^{2n+1}}.
\]
Consequently
\[
\boxed{
\|e_T\|_2
\ge
|c|\frac{(2\delta)^{m-1/2}}{(m-1)!}e^{\delta T}.
}
\tag{4.1}
\]
This is the single-zero specialization of (3.2), equivalently the formula for the top diagonal entry of \(\Gamma^{-1}\).

This independently confirms the A-interface centered-jet result. The earlier \(T^{-(m-1)}\) factor arose from using the uncentered top monomial alone. It was not an intrinsic repeated-zero cost.

### 4.2. A simple real-source conjugate pair

For a real native input, take conjugate simple zeros with
\[
q_1=\delta+i\omega,\quad q_2=\delta-i\omega,\quad
c_1=c,\quad c_2=\overline c,\quad \omega\ne0.
\]
Put
\[
a=\frac1{2\delta},\qquad b=\frac1{2\delta+2i\omega}.
\]
Then
\[
\Gamma=\begin{pmatrix}a&b\\\overline b&a\end{pmatrix},
\qquad
d=e^{\delta T}
\begin{pmatrix}ce^{i\omega T}\\\overline c e^{-i\omega T}\end{pmatrix},
\]
and the exact lower expression is
\[
\boxed{
d^*\Gamma^{-1}d
=\frac{e^{2\delta T}}{a^2-|b|^2}
\left(2a|c|^2-2\Re[b\,\overline c^{\,2}e^{-2i\omega T}]\right).
}
\tag{4.2}
\]
It is uniformly bounded below by
\[
\boxed{
\frac{4\delta\sqrt{\delta^2+\omega^2}}
{\sqrt{\delta^2+\omega^2}+\delta}
|c|^2e^{2\delta T}.
}
\tag{4.3}
\]
The constant is strictly greater than the single-simple-zero constant \(2\delta|c|^2\). The conjugate oscillations cannot erase the joint adjoint obstruction. No uniformity as \(\omega\to0\), over native zeros, or over damping is claimed.

## 5. Three actual source contracts

The common native forward kernel does not identify the inputs or their phases.

| Source | Actual right side of \(a_N*F=y\) | Highest input jet \(c_j\) at \(\lambda_j\) |
|---|---|---|
| B's original unchanged fixed detector \(h_B\), with bilateral transform \(K_B\) | \(y=R*B*((tN)*h_B)\); prime output \(F=\Pi*h_B\) is already causal | \(-c_0(\lambda_j)K_B(\lambda_j)\zeta^{(m_j)}(\rho_j)\) |
| A02 smooth polarized contact source \(h_b=\psi_b*\widetilde f_0\), width \(a+b\), delayed by \(c=a+b+1\) | \(y=R*B*T_c((tN)*h_b)\); \(F=T_c(\Pi*h_b)\) | \(-c_0(\lambda_j)e^{-c\lambda_j}K_b(\lambda_j)\zeta^{(m_j)}(\rho_j)\) |
| C's original exterior \(v(s)=(W*f_0)(a+s)\) | \(y=y_{f_0}\) explicitly constructed in Note 01; \(F=v\) | \(+c_0(\lambda_j)e^{a\lambda_j}G(-i\lambda_j)\zeta^{(m_j)}(\rho_j)\) |

Every coefficient is nonzero at every off-line native zero, by the corresponding source theorem. The original C input requires neither a polarized probe nor a smoothing or pole-neutral replacement. Its compact companion term contributes only to higher jets and does not change the last row.

The \(L^2\) domain of each actual input is proved separately: the first by B03, the second by A02's exact integer quadrature after its explicit delay, and the third by the new completed native forward kernel. None is inferred by transferring the norm of another source.

## 6. Consequences, falsification, and the remaining bound

Equation (4.1) and (3.3) give a fixed positive multiple of \(e^{(\Re\rho-1/2-\varepsilon)T}\) as an all-large-\(T\) lower bound on each correctly typed output prefix, for each specified hypothetical right zero. Applying A02's bounded higher-prime-power channel and exact future-boundary identity therefore removes the polynomial penalty from the cross-path signed-fluctuation lower bound as well.

Together with the inherited sharp exterior abscissa, this gives the exact cumulative energy exponent proved in the A-interface branch:
\[
\lim_{T\to\infty}\frac1T
\log\left(1+\int_0^T e^{-2\varepsilon s}|v(s)|^2ds\right)
=2(\Delta-\varepsilon)_+.
\]
This is an additional consequence, not an independently proved zero-width assertion.

The positive delayed-kernel control in the A-interface flux note realizes repeated forward zeros with exact leakage proportional to \(e^{\delta T}\), confirming the absence of a multiplicity power of \(T\). It has a nonnative multiplier and is not presented as native zeta data. The native positive-kernel unstable-inverse controls are also compatible with (3.2): positive forward kernels and small actual inputs do not invalidate their nonzero adjoint jets.

No infinite set of poles is summed here. A countable Gram limit would require a proved convergence or frame theorem and is not inferred from finite positive definiteness. No infinite negative index, unweighted generator-domain assertion, or global native inverse estimate follows.

The new theorem supplies the optimal finite-jet residue-observability lower bound available from these exact adjoint constraints. A genuinely native independent upper control of the original exterior or its exact finite-horizon leakage remains **OPEN**.
