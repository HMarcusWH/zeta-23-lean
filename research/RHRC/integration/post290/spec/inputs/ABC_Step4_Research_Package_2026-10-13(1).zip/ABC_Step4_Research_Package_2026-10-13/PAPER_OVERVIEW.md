# Joint research outcome

**Step 4 remains open. This campaign advances each of Paths A, B, and C and carries their combination through an exact original-source closing attempt. It does not establish the remaining signed upper bound.**

The most useful combined result is an explicit prime-only target. Under the project's inherited full-contact foundations, the original contact exterior is stable at a positive damping if and only if a particular centered prime response is stable at that same damping. The inverse and source-history issues in this statement are resolved on paper. The unresolved part is the global cancellation of that prime response.

This package records new mathematical deductions, their proofs, the inherited premises used, exact finite controls, internal cross-reviews, and the closing implications that were tested but not obtained. It is a continuation from **A03, B04, and C05**, not a new formalization or a claim to have independently reproved every earlier foundation. No repository or pull-request changes are part of this campaign.

## Status and reading guide

The word **PAPER** means a mathematical derivation recorded and internally checked here, with its dependencies stated. None of the new analytic or arithmetic theorems below has been compiled in Lean. Finite algebra controls are evidence that the formulas have been implemented consistently; they are not proofs of an infinite estimate, an analytic domain theorem, or RH.

For the current research conclusion, read this opening chapter. The remainder of the paper contains the complete new proof notes. The accompanying ZIP also contains the runnable standard-library controls, result receipts, selected unchanged source files, and a source manifest with hashes.

| Part | New content | Closing estimate still required |
|:--|:--|:--|
| A: arithmetic | Narrower covariance region; exact rough-core cancellation; stable small-core sector; adaptive prime-power-preserving mask | Complete signed large-rough-core norm |
| B: native analysis | One shifted sensor for every zero multiplicity; explicit causal graph inverse; exact gamma cancellation | Upper bound for the actual centered arithmetic forcing |
| C: contact source | Full-kernel defect rank and minimax growth; source-derived scalar and vector contractions | Quiet subsequence or all-positive-damping bound on the original-source prime discrepancy |
| A+B+C | Exact history-preserving convolution bridge and finite-horizon inequality | A bound on the surviving arithmetic term, beyond the already controlled errors |

## 1. The problem retained from the existing project

The existing program connects an off-critical-line zeta zero to a visible response, then to the native Weil/contact framework. The current paper frontier is a hypothetical full positive-semidefinite contact on a finite interval, with a nonzero nullspace. The project's contact classification and domain results produce a canonical compact source and an exterior response that detects every right-half-plane zero. They also produce a stable native input. What they do not yet supply is the independent upper estimate needed to contradict the exterior's positive growth.

Keep one such contact on \(I=[-a,a]\), and write

\[
H_a\ge0,\qquad E=\ker H_a,\qquad 1\le r=\dim E<\infty.
\]

The supplied paper source theorem gives a real source \(f_0\) of definite parity, supported in \(I\), whose Fourier transform \(G\) has only real simple zeros. The entire contact kernel is the polynomial module

\[
\widehat E=G\,\mathbb C[z]_{<r}.
\]

Set

\[
D(p)=G(-ip)=\int_{-a}^a f_0(u)e^{-pu}\,du,
\qquad v(s)=(W*f_0)(a+s),\quad s>0.
\]

Here \(W\) is the actual full native Weil distribution. Its causal half has the inherited diagonal convention and transform

\[
J(p)=\frac{\xi'}{\xi}(p+1/2).
\]

The compact companion \(c_0\), shifts \(f_+(t)=f_0(t-a)\), \(c_+(t)=c_0(t-a)\), and \(L=2a\) obey the exact causal equation

\[
W_+*f_+ +c_+=\tau_Lv.
\tag{O1}
\]

At a native zero \(\rho=1/2+\lambda\) of multiplicity \(m\) with \(\Re\lambda>0\), the original exterior has residue

\[
\operatorname{Res}_{p=\lambda}V(p)
=m e^{a\lambda}D(\lambda)\ne0.
\tag{O2}
\]

The nonvanishing follows from the real source zeros. The sharp inherited leakage theorem turns this residue, with all multiplicity jets retained, into an exponential energy lower bound on every sufficiently large horizon. Step 4 needs an independent upper law that contradicts it. Establishing another visibility or lower-growth statement alone cannot close that step.

The arithmetic branch has a different fixed source, the Gevrey detector \(h=k*k\), supported in \([-d,d]\), with \(d=1/2048\). Its transform \(K\) has the required double elementary zeros, and the detector remains nonzero at every relevant off-line zero. The field

\[
F(t)=\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}h(t-\log n)
\]

is the same fixed detector throughout the new arithmetic reductions. It is not identified with \(f_0\), and it is not declared a contact null vector. The exact convolution bridge below is what connects them.

## 2. The sharpest combined target: primes against the original contact source

Define

\[
\boxed{
\mathcal P_{f_0}(s)=
e^{(a+s)/2}D(1/2)
-\sum_{p\ \mathrm{prime}}\frac{\log p}{\sqrt p}
f_0(a+s-\log p),\qquad s>0.
}
\tag{O3}
\]

Every finite-time sum is locally finite, and the formula is interpreted in \(L^2_{\mathrm{loc}}\); no pointwise regularity of \(f_0\) is added. This is the actual prime response centered by its continuous main term.

The campaign proves the same-source equivalence

\[
\boxed{
e^{-\epsilon s}v(s)\in L^2(0,\infty)
\quad\Longleftrightarrow\quad
e^{-\epsilon s}\mathcal P_{f_0}(s)\in L^2(0,\infty),
\quad\epsilon>0.
}
\tag{O4}
\]

It also proves equivalence of the corresponding quiet-subsequence property. Thus a sufficient closing lemma is

\[
\boxed{
\liminf_{T\to\infty}\frac1T
\log\left(1+\int_0^T|\mathcal P_{f_0}(s)|^2\,ds\right)=0.
}
\tag{O5}
\]

Under the inherited contact/leakage foundations, (O5) contradicts the positive exterior growth forced at a hypothetical contact. Proving (O5), or a suitable positive-damping version, would therefore close this paper route to Step 4. **This campaign has not proved (O5).**

The new content in (O4) is the exact source-preserving reduction with a complete causal inverse and controlled remainders. It does not obtain an upper bound by defining a different output and assuming that output is stable.

### Why the gamma term and higher powers can be removed

The digamma recurrence gives the exact identity

\[
\begin{aligned}
J(p)-J(p+2)={}&
\frac{\zeta'}{\zeta}(p+1/2)
-\frac{\zeta'}{\zeta}(p+5/2)\\
&+\frac1{p-1/2}-\frac1{p+3/2}-\frac1{p+5/2}.
\end{aligned}
\tag{O6}
\]

Consequently the actual causal distribution becomes the explicit signed measure

\[
\begin{aligned}
k_2(dt):=(1-e^{-2t})W_+(dt)
={}&(e^{t/2}-e^{-3t/2}-e^{-5t/2})\,dt\\
&-\sum_{n\ge2}\Lambda(n)n^{-1/2}(1-n^{-2})\delta_{\log n}(dt).
\end{aligned}
\tag{O7}
\]

This removes the entire gamma tail and its diagonal regularization exactly. It retains all prime powers. The extra \(n^{-2}\)-weighted measure is unweighted finite variation; its convolution with the compact \(L^2\) source is stable. The two decaying elementary terms are stable too.

The higher prime powers can then be removed at every positive damping because

\[
\sum_p\sum_{k\ge2}(\log p)p^{-k(1/2+\epsilon)}<\infty
\qquad(\epsilon>0).
\tag{O8}
\]

Weighted Young's inequality controls their entire field, including its role in the full quadratic norm. No unweighted finite-variation claim is made for the square-prime part. This distinction matters: its undamped absolute measure would contain \(\sum_p(\log p)/p\).

## 3. Path C: a genuine contraction and a stronger full-kernel lower law

### A contraction constructed from the unchanged source

The canonical source has a paired Hadamard product

\[
D(p)=C p^\nu\prod_k(1+p^2/\gamma_k^2),\qquad\nu\in\{0,1\}.
\]

Definite parity removes the linear exponential factor. All \(\gamma_k\) are real. For every \(h>0\), comparison of distances to each imaginary-axis zero proves

\[
T_h(p):=\frac{D(p)}{D(p+h)}\in H^\infty(\mathbb C_+),
\qquad\|T_h\|_\infty\le1.
\tag{O9}
\]

Let \(\mathsf T_h\) be its bounded causal multiplier and \(\mathsf M_hu=e^{-h\cdot}u\). Tilting the complete equation (O1), applying the exact source-recovery multiplier \(e^{ah}T_h\), and subtracting gives

\[
z_h-j_h=(I-\mathsf B_h)v,
\qquad\mathsf B_h=e^{-ah}\mathsf T_h\mathsf M_h,
\qquad\|\mathsf B_h\|\le e^{-ah}<1.
\tag{O10}
\]

Here \(z_h\) is the advanced \((1-e^{-ht})W_+\) response of the original source, and \(j_h\) is the explicit advanced filtered compact companion. The proof establishes \(j_h\in L^2\). It never declares the tilted source to be a new null vector.

Write \(\|u\|_{\epsilon,T}^2=\int_0^T e^{-2\epsilon s}|u(s)|^2\,ds\). Causality makes the following bound valid for every \(\epsilon\ge0\) and every finite interval before any global exterior bound is known:

\[
(1-e^{-ah})\|v\|_{\epsilon,T}
\le\|z_h-j_h\|_{\epsilon,T}
\le(1+e^{-ah})\|v\|_{\epsilon,T}.
\tag{O11}
\]

Thus the feedback inverse is genuinely stable. A local uniqueness argument identifies its global solution with the original exterior whenever the forcing has the required global norm. At \(h=2\), (O7), (O8), and (O11) prove (O4).

The construction also covers the entire original contact kernel. On the legal derivative basis \(f_j=\partial^j f_0\), \(0\le j<r\), the translation matrix has entries

\[
C(-h)_{jk}=\binom jk(-h)^{j-k},\qquad k\le j.
\]

In component weights \(w_j=(a/2)^j/j!\), its generator has norm at most \(a/2\). The resulting full-vector feedback therefore has norm at most \(e^{-ah/2}<1\). Every component retains its own actual companion. Derivatives beyond the inherited domain limit are not used.

### The full kernel cannot choose away all unstable residues

For \(f\in E\), write \(F_f=G P_f\), \(\deg P_f<r\). At a native zero of multiplicity \(m\), the stable input automatically satisfies the lower \(m-1\) Hardy range jets; the last jet is proportional to \(P_f(-i\lambda)\). Thus the restricted source-to-range-defect map has exact rank

\[
\operatorname{rank}\mathcal D_\epsilon
=\min(r,N_\epsilon),
\tag{O12}
\]

where \(\epsilon>0\) and \(N_\epsilon\) counts distinct right zeros with displacement greater than \(\epsilon\). A repeated native zero imposes one source evaluation in this restricted map, even though the full Hardy range condition retains its multiplicity.

The full contact quadratic form also proves that no nonzero contact vector can cancel every right-zero evaluation. If it did, the reflected off-line terms would vanish pairwise. The remaining nonnegative critical-line sum would force its compact entire transform to vanish at every simple critical-line zero. The known distinct critical-zero count grows as \(T\log T\), whereas a nonzero entire function of finite exponential type has only \(O(T)\) zeros. This contradiction gives at least \(r\) distinct right zeros under the hypothetical contact assumptions.

For a precise uniform statement, define

\[
\Delta_r=\sup\{d\ge0:
\#\{\rho:\Re\rho>1/2+d\}\ge r\}.
\]

The campaign derives, for every \(\epsilon\ge0\),

\[
\boxed{
\lim_{T\to\infty}\frac1T\log\left(
1+\inf_{\substack{f\in E\\\|f\|_2=1}}
\int_0^T e^{-2\epsilon s}|v_f(s)|^2ds\right)
=2(\Delta_r-\epsilon)_+.
}
\tag{O13}
\]

The lower bound uses finitely many exact Laguerre jet inequalities and an invertible Vandermonde evaluation map. It is uniform even when the chosen unit null vector changes with the horizon. The upper bound uses the actual polynomial module to cancel at most \(r-1\) distinct poles, followed by the inherited operator-domain weighted spectral synthesis and an explicit same-source limit identification. It does not infer an \(H^2\) bound from meromorphic pole removal alone.

This is a sharper description of the growth forced by a hypothetical contact. Its matching upper rate does not force that rate to vanish and therefore does not supply the missing closing estimate.

## 4. Path B: one universal shifted sensor and an exact inverse domain

Keep the native completed integer kernel

\[
a_N(t)=3e^{-t}\sum_{n\le e^t}\sqrt n
-2e^{-t/2}\lfloor e^t\rfloor,
\]

\[
A(p)=c_0(p)\zeta(p+1/2),\qquad
c_0(p)=\frac{p-1/2}{(p+1/2)(p+1)}.
\]

For any one fixed \(h>1/2\), set \(r_h=e^{-ht}a_N\). Its transform \(A(p+h)\) is nonzero on the closed right half-plane because its zeta factor lies in the absolutely convergent Euler-product half-plane. Its derivative, including every integer jump and the atom at zero, has finite total variation.

For the explicit choice \(h=2\), let \(w=r_2*v\). The exact inverse is

\[
\boxed{
v=M_{5/2}*\left[w'+4w+\frac32 e^{-3t/2}\mathbf1_+*w\right],
\quad M_{5/2}=\sum_{n\ge1}\mu(n)n^{-5/2}\delta_{\log n}.
}
\tag{O14}
\]

The Möbius measure is absolutely summable. This gives a bounded causal isomorphism from weighted \(L^2\) to the weighted zero-trace \(H^1\) graph space, with horizon-independent constants. The derivative belongs to the output or falls on the filter; the rough contact source is not differentiated. The inverse is not a bounded raw \(L^2\)-to-\(L^2\) multiplier.

One chosen shift retains every right-zero residue at every finite multiplicity. This replaces the need for a multiplicity-dependent observation filter in this channel. Finite Möbius truncations converge in operator norm on the stated graph domain, but they do not establish that the unknown output belongs to that domain.

On the fixed infinitely smooth detector channel \(X=k_2*h_+\), with observation \(z=r_2*X\), the campaign supplies an additional interpolation theorem: all-positive-damping plain \(L^2\) stability of the sensor output is equivalent to that of the unsensed smooth channel. High-order derivative bounds and a shrinking-scale local mollifier recover the missing first derivative at each target damping. This result is explicitly restricted to the original smooth detector and is not applied to the finite-regularity contact source or the jumping adaptive arithmetic fields.

## 5. Path A: the signed arithmetic target is substantially narrower

### Localizing the complete covariance

The fixed detector's integer drive \(U\) obeys the inherited Gevrey bound

\[
|U(t)|\le C\exp(-\kappa e^{t/2}).
\]

In the exact finite-horizon gcd-ray expansion of the weighted energy, this implies

\[
|I_H(a,b)|\le C_\epsilon
\exp\left(-c\sqrt{\frac{\max(a,b)}{\min(a,b)}}\right).
\tag{O15}
\]

After the complete common-divisor sum is retained, every ray outside

\[
\frac{\max(a,b)}{\min(a,b)}
<C_0(1+\log\min(a,b))^2
\tag{O16}
\]

has a uniformly summable absolute contribution. All possible unbounded energy is therefore confined to a much narrower comparable-ratio region. No infinite limiting correlation is substituted for the finite-horizon identity. Near-diagonal absolute divergence remains, so this localization alone does not bound the signed sum.

### Exact complete-small-part cancellation

The localized coefficient is

\[
A_Y(k)=\sum_{\substack{n\mid k\\n>Y}}\mu(n)\log(k/n).
\]

If \(k=ab\), \((a,b)=1\), every prime of \(b\) is at least \(k/Y\), and \(a<k/Y\), then

\[
A_Y(ab)=\mu(b)\Lambda(a).
\tag{O17}
\]

Thus a fully included small part containing two distinct primes cancels exactly. The strict cutoff is essential: \(A_7(42)=\log6\), while the complete-small-part formula would incorrectly give zero at that seam if its strict hypothesis were dropped.

### A controlled small-rough-core sector

At cofactor scale \(L(t)=O(t^2\log t)\), separate each product into its full \(L\)-smooth part and its \(L\)-rough core \(b_L(k)\). An elementary Rankin count proves that the entire field with

\[
b_L(k)\le\exp(t/\log(t+2))
\tag{O18}
\]

belongs to every positively damped \(L^2\) space. The estimate uses absolute values and no Möbius mean or prime-distribution bound. At a fixed damping \(\epsilon\), a stronger cutoff \(b_L(k)\le e^{\theta t}\) is legal for any \(\theta<\min(1,2\epsilon)\). No endpoint claim is made at \(\theta=2\epsilon\).

### An adaptive mask that leaves the actual prime response unchanged

For squarefree \(P\), define

\[
w_P(k)=1_{\{\omega(\gcd(k,P))\le1\}}
=\sum_{Q\mid P,\ Q\mid k}\mu(Q)(1-\omega(Q)).
\tag{O19}
\]

This mask equals one on every prime power. Consequently it leaves the literal \(\Lambda\) response unchanged, while removing composite products with two selected prime factors from its divisor expansion.

Choose \(P(t)\) to be the largest initial primorial at most \(\log(t+2)\), and compensate the long-divisor cutoff by setting

\[
Y_P(t)=\frac{e^t}{B P(t)t^2}.
\]

One fixed sufficiently large \(B\) gives an exponentially small discarded field. The surviving cofactor range is \(m<O(t^2\log t)\). The finite divisibility expansion, its coefficient budget, and its losses in the Gevrey exponent are all explicit. The stepwise modulus is not differentiated, so no cutoff jumps are silently omitted.

Combining the mask with the controlled rough-core sector gives an exact decomposition

\[
\boxed{F=R_A+E_A,\qquad
E_A\in\bigcap_{\epsilon>0}L^2_\epsilon.}
\tag{O20}
\]

The residual \(R_A\) is supported on the complete masked, large-rough-core, short-cofactor field. The remaining A closing target is precisely
\(R_A\in\bigcap_{\epsilon>0}L^2_\epsilon\).

This reduction retains a substantial signed cancellation problem. Squarefree products \(2q\) and \(2pq\), with the rough primes above the cofactor scale, survive every stated removal and have exact coefficients \(-\log2\) and \(+\log2\). Ordinary fixed-ratio PNT proves that their separate magnitude budgets are at least constant multiples of \(e^{t/2}/t\) and \(e^{t/2}/(t\log t)\). These are not lower bounds for the complete signed output. They do show that a termwise absolute-value estimate cannot close its all-positive-damping target.

## 6. The actual A+B+C closing attempt

Let \(h_+(t)=h(t-d)\), so its full support is causal. The exact gamma-free measure satisfies

\[
k_2*h_+=b_h-\tau_dF,
\qquad b_h\in L^1\cap L^2.
\]

The detector's elementary zero kills the growing continuous tail; the compact initial history and decaying terms remain inside \(b_h\). Substitute (O20) and convolve the complete contact equation (O10). The result is the exact identity

\[
\boxed{
\tau_{2a}\,h_+*(I-\mathsf B_2)v
+f_+*\tau_dR_A=J_A,
\qquad J_A\in\bigcap_{\epsilon>0}L^2_\epsilon.
}
\tag{O21}
\]

The full definition of \(J_A\) in the proof note retains the source companion, its filtered history, the arithmetic stable error, and the compact initial terms. Moving the smoothing convolution through the feedback produces another explicit stable commutator; it is not set to zero.

For every positive damping and finite horizon, the resulting inequality has the form

\[
\begin{aligned}
&(1-e^{-2a})e^{-2a\epsilon}
\|h_+*v\|_{\epsilon,(T-2a)_+}\\
&\hspace{12mm}\le
\|f_+\|_{1,\epsilon}e^{-\epsilon d}
\|R_A\|_{\epsilon,(T-d)_+}+C_\epsilon.
\end{aligned}
\tag{O22}
\]

This is the completed joint attempt. It combines the actual arithmetic localization, mask, small-core estimate, native gamma cancellation, and source contraction. The left side still detects every right pole. Its missing right-side bound is exactly the surviving full signed arithmetic norm.

There is no backwards norm inversion of the compact Gevrey filter, and the convolved source is not declared null at a larger aperture. Pole visibility transfers through the explicit convolution because both source factors are nonzero at the relevant zeros.

## 7. Closing mechanisms tested and where they stop

**Absorption from the arithmetic mask.** The mask is zero or one inside the signed divisor expansion, but it does not contract the completed response. Equation (O20) gives

\[
\big|\|F\|_{\epsilon,T}-\|R_A\|_{\epsilon,T}\big|
\le\|E_A\|_{\epsilon,\infty}.
\]

If the actual native norm grows, the ratio of these two norms tends to one. A coefficient smaller than one does not follow from the mask. The strict factor in the contact feedback applies to its returned term, not to the entire forcing in (O22).

**Iteration of the new contraction.** The source filters satisfy \(\mathsf B_h\mathsf B_k=\mathsf B_{h+k}\). Their exact Neumann telescope gives the original exterior as its first forcing plus a convergent stable correction. At a safe shift \(h>1/2\), every returned term is independently controlled, but the first forcing still lacks the required upper bound. Its transform still has coefficient one on the unshifted \(J(p)\).

**Averaging several even shifts.** Every \((1-e^{-2mt})W_+\) response of a fixed source differs from the same centered prime-power response by an unweighted \(L^2\) remainder. A finite constant-coefficient combination retains that discrepancy with coefficient \(\sum_j\alpha_j\). Making the coefficient zero gives a stable combination but removes every native right-zero residue too. This is a limitation of that specified averaging mechanism, not of every possible vector or time-dependent construction.

**A gamma-free positivity argument.** A new exact supported contact commutator removes the gamma denominator from the quadratic form. The remaining continuous density changes sign, and the contact correlation need not be pointwise nonnegative. Independently, the actual native filtered defect \(r_2*k_2\) is negative just after zero, positive immediately before the first prime, and negative just after it. Its sign cannot supply a coefficientwise positive-kernel proof. Pointwise sign change is not asserted to settle every possible operator accretivity question.

**Choosing a different null vector at each horizon.** The uniform lower bound behind (O13) covers such choices. The full kernel can spend at most \(r-1\) polynomial roots canceling distinct right-zero residues, and a positive remaining displacement is forced under contact. Vector selection alone cannot supply a quiet exterior.

**Promoting local contact identities to a global tail estimate.** Every supported quadratic exponential-contact commutator considered here only uses prime shifts within the original contact aperture. A precisely scoped remote-pulse control preserves all those local identities while changing the exterior growth. It does not preserve the full native arithmetic or completed-zeta constraints and is not a counterexample to RH. It identifies the missing use of global native information in a proposed local-only deduction.

## 8. What is now concrete, and what remains research

The upper-law question is more explicit after this campaign. A proof may target the original-source prime discrepancy (O3) directly, the masked large-rough-core arithmetic residual (O20), or another genuinely new native estimate that bounds one of their exact observations. The source maps and inverse domains needed to transfer such an estimate have now been supplied for the stated constructions.

The completed tests give no reason to claim that the new forcing is small merely because the gamma tail, small divisors, or smooth products have been removed. The surviving signed term is large in each separate sign budget, and the existing exact identities preserve its potential unstable residues.

The decisive remaining lemma is (O5), or a sufficient all-positive-damping upper bound with the same fixed source and full mixed square. No such lemma is proved in this package. The current outcome is a narrower arithmetic problem, a source-preserving prime-only formulation, new complete inverse/feedback results, and a stronger all-kernel lower law. **Step 4 and RH remain open at this paper frontier.**

## Source authority and validation

The new paper continues the supplied A03 signed-arithmetic package, B04 proofs and range analysis, and C05 contact/exterior package. The selected source files copied into the ZIP remain unchanged and are hashed in the manifest. The repo state is used only as previously oriented context; there is no new formal build in this campaign.

Two primary external facts were checked directly for the new deductions: the digamma recurrence in NIST DLMF 5.5.2, and the simple-critical-zero proportion in Bui, Conrey, and Young, *More than 41% of the zeros of the zeta function are on the critical line*, Theorem 1.1, arXiv:1002.4127v2. Only a positive proportion of distinct simple critical zeros is needed; no current-record claim is made.

The exact controls cover strict divisor seams, mask and restricted-drive identities, squarefree sign coefficients, shifted rational inverses, full and finite-endpoint gamma cancellation, all-multiplicity factorials, source-product comparisons, the binomial matrix lift, weighted shift constants, and explicit sign falsifiers. They use integer or rational arithmetic and formal log-prime coefficients. Analytic and universal claims depend on the mathematical proofs, not on extrapolation from these finite checks.

Internal reviews checked the same-source distinction, all compact histories and causal advances, the finite Sobolev ceiling, the full mixed quadratic contribution, multiplicity, damping quantifiers, and local-versus-global inverse domains. A separate root review records the specific corrections made before this version was frozen.

### Primary source links

- A03: <https://drive.google.com/file/d/1rOzKqhrzDpceddpMRgUU0EIGe5SchNOL/view>
- B04: <https://drive.google.com/file/d/1ZxQuBjtEBSKOAWpUGFmFhSmXhBGfTvFS/view>
- C05: <https://drive.google.com/file/d/1Vg5dsSBQ3kum3LTfzTgX8E5WQ9B4wvw6/view>
- Digamma recurrence: <https://dlmf.nist.gov/5.5.E2>
- Simple critical zeros: <https://arxiv.org/pdf/1002.4127>

The following chapters contain the complete new proof notes. Their local equation numbers are retained; identify an equation by its chapter as well as its printed number.
