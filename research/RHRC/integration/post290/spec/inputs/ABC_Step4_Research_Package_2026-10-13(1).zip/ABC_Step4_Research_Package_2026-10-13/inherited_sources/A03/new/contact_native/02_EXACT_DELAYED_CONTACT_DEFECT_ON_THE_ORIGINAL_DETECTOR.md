# A03: the exact delayed contact defect on B's original detector

**Status: NEW DERIVED / PAPER composition.** The inputs are C04's actual native contact, support/cusp/domain theorems and B03's genuine causal positive-real source filter. This note proves an exact physical support statement and a source-preserving comparison with A02's complete signed fluctuation. It does not prove the remaining arithmetic upper bound and does not identify the dilating K2 source with the fixed detector.

## 1. Precise sources, realizations, and inherited premises

Assume the hypothetical native PSD full contact at \(I_a=[-a,a]\):

\[
H_a\ge0,\quad E=\ker H_a\ne0,\quad
\widehat E=G\mathbb C[z]_{\le r_c-1}.
\]

Let \(f_0\) be the actual canonical real definite-parity generator. Its essential support endpoints are \(\pm a\), and every zero of \(G=F_{f_0}\) is real. Use

\[
F_f(z)=\int f(x)e^{-izx}dx,
\quad \mathcal D_f(p)=F_f(-ip),
\quad J(p)=\frac{\xi'}{\xi}(1/2+p).
\]

The causal half \(W_+\) uses the exact half-diagonal convention and has transform \(J\) initially on \(\Re p>1/2\). The actual compression is \(T=P_IW_+P_I\). Set \(c=-Tf_0\). Both \(f_0,c\) have the inherited supported operator domains; the zero-extension endpoints and exterior local \(L^2\) theorem are retained.

B03 constructs, as an actual causal distribution, a positive-real source filter \(p_a\) with

\[
\mathcal Lp_a(p)=P_a(p),\qquad
\Re P_a(p)>0\quad(\Re p>0),\qquad
p_a*f_0=-c.
\tag{1.1}
\]

For each \(\epsilon>0\),

\[
|P_a(\epsilon+i\omega)|\le C_{a,\epsilon}(1+\omega^2).
\tag{1.2}
\]

The construction includes a representation \(p_a=(\partial_t+1)^4q_a\), with \(q_a\) continuous, causal, and of every positive exponential order. This prevents replacing an actual causal map by a boundary quotient.

C04 proves, on the same canonical source,

\[
\lim_{y\to\infty}\frac1y\log|J(y)-P_a(y)|=-2a.
\tag{1.3}
\]

Its proof retains the native completion, uses the signed contact cusp, and fixes an eventual sign. This is an inherited PAPER theorem, not a Lean premise.

## 2. A true causal defect with exact onset at the interval width

Define the actual lower-supported distribution

\[
\boxed{D_a=W_+-p_a.}
\tag{2.1}
\]

No quotient by \(G\) is used. On the safe half-plane,

\[
\mathcal LD_a(p)=J(p)-P_a(p).
\tag{2.2}
\]

The native interior equation and (1.1) give the full distribution identity

\[
\boxed{D_a*f_0=g_{f_0}^+,\qquad
g_{f_0}^+(t)=\mathbf1_{(a,\infty)}(t)(W*f_0)(t).}
\tag{2.3}
\]

To verify it: both causal convolutions vanish left of \(-a\); they equal \(-c\) on the interior; to the right of \(a\), \(p_a*f_0=-c=0\) and \(W_+*f_0=W*f_0\). The imported actual-domain identity makes these ordinary locally \(L^2\) pieces and rules out a suppressed endpoint delta. Equation (2.3) is the same original null-source exterior, with no smooth-source substitution.

**Theorem A03-CD.**

\[
\boxed{\inf\operatorname{supp}D_a=2a.}
\tag{2.4}
\]

In particular the source-root filter agrees with the entire literal native causal distribution on \((-\infty,2a)\), including its diagonal convention, archimedean distribution and prime-power atoms. The statement at the boundary \(2a\) is not discarded: any boundary distribution belongs to \(D_a\).

Here is a proof using only the already supplied signed Laplace support lemma. Choose an integer \(m\) sufficiently large, for example \(m\ge6\), and set

\[
r_m(t)=\frac{t^{m-1}e^{-t}}{(m-1)!}\mathbf1_{t\ge0},\qquad
z_a=r_m*D_a.
\]

The explicit native \(W_+\) has at most a finite-part \(1/t\) singularity at zero, discrete locally finite prime atoms, and exponential growth bounded after damping at any rate strictly larger than \(1/2\). Together with B03's four-derivative representation of \(p_a\), this makes \(z_a\) a continuous causal function with an integrable exponential damping. More explicitly, \(r_m*p_a=r_{m-4}*q_a\) distributionally, with all initial terms included; this is continuous for \(m\ge6\). A causal primitive of the native finite part is locally integrable, so its convolution with \(r_m\) is continuous, as is the locally finite sum of the smoothed prime atoms. The explicit prime weights and smooth completion supply exponential damping for this convolution. Its actual transform is

\[
\mathcal Lz_a(y)=\frac{J(y)-P_a(y)}{(y+1)^m},
\qquad
\lim_{y\to\infty}\frac1y\log|\mathcal Lz_a(y)|=-2a.
\]

For each fixed \(b<2a\), (1.3) gives \(\mathcal Lz_a(y)=O(e^{-by})\); the signed Laplace support lemma implies \(z_a=0\) on \([0,b)\). Therefore \(\inf\operatorname{supp}z_a\ge2a\). If its support started strictly later, its integrable exponential damping would give a strictly faster exponential transform bound, contradicting the exact limit. Thus its support starts at \(2a\).

Finally \(D_a=(\partial_t+1)^mz_a\) distributionally. Differentiation cannot create support earlier than \(z_a\), while convolution with causal \(r_m\) cannot create support earlier than \(D_a\). These two support inclusions give equality of the two lower support endpoints. This proves (2.4).

There is a second consistent support audit. C04's near-zero nonzero cusp implies that \(g_{f_0}^+\) has no initial gap after \(a\): otherwise its exact pairing with \(f_0\) would make the contact correlation vanish near zero. Together with (2.3), support saturation of \(f_0\), and the distributional Titchmarsh theorem, this again gives \(2a\). The preceding regularization proof does not need to import Titchmarsh separately.

## 3. Application to B's unchanged fixed detector

Now use B's original

\[
h=k_r*k_r\in C_c^\infty([-d,d]),\quad
r=1/4096,\quad d=1/2048,
\quad K(p)=\int h(t)e^{-pt}dt.
\]

It is **not** \(f_0*\widetilde f_0\), an A02 polarized probe, or the dilating K2 source. Keep the complete native prime measure \(\Pi\), including all prime powers.

Write the native causal completion as

\[
W_+=W_{{\rm sm},+}-\Pi,
\]

where the complete smooth/diagonal channel has transform

\[
j(p)=\frac1{p+1/2}+\frac1{p-1/2}
-\frac12\log\pi+\frac12\psi(p/2+1/4).
\]

The term called smooth here includes the prescribed distribution at the origin; no literal pointwise regularity is asserted for it before convolution. From (2.1), proper causal convolution gives exactly

\[
\boxed{F_B:=\Pi*h=s_{a,h}-D_a*h,
\qquad s_{a,h}=(W_{{\rm sm},+}-p_a)*h.}
\tag{3.1}
\]

This is a source-preserving arithmetic/contact adapter. It uses the same fixed detector on every term and performs no division by its transform or by the contact generator. The new unknown filtered defect starts no earlier than \(2a-d\). No assumption that this lower bound is positive is needed; negative-time contributions, if present, occupy a fixed compact interval.

For every \(\epsilon>0\),

\[
\boxed{e^{-\epsilon t}s_{a,h}(t)\in L^2(\mathbb R).}
\tag{3.2}
\]

For the source-root part, (1.2) and the rapid vertical-line Fourier decay of the fixed smooth compact \(h\) give

\[
\|e^{-\epsilon t}(p_a*h)\|_2^2
=\frac1{2\pi}\int_{\mathbb R}
|P_a(\epsilon+i\omega)K(\epsilon+i\omega)|^2d\omega<\infty.
\]

This is the actual lower-supported convolution: multiply its two factors by the same exponential damping, then use the Fourier representation supplied by B03's causal realization.

For the complete smooth channel, each elementary pole convolution has zero tail to the right of \(d\), by \(K(\pm1/2)=0\). These convolutions are supported in \([-d,d]\); they are not asserted to vanish globally. Their compact contributions remain in \(s_{a,h}\). To the right of \(d\), the exact archimedean expansion is

\[
(W_{{\rm sm},+}*h)(t)
=-\sum_{k\ge1}e^{-(2k+1/2)t}K(-2k-1/2).
\tag{3.3}
\]

The \(k=0\) term is also killed by \(K(-1/2)=0\); the full remaining series is retained. It converges normally on every \(t\ge d+\delta\) and is \(O(e^{-5t/2})\) on the far tail. Convolution of the origin distribution with \(h\) is smooth on compact intervals. Thus this channel is in every required weighted \(L^2\), proving (3.2).

## 4. Exact comparison with A02's signed fluctuation

Decompose \(F_B=F_1+F_{\ge2}\). A02's higher-power theorem gives

\[
e^{-\epsilon t}F_{\ge2}\in L^2(\mathbb R)
\quad(\epsilon>0).
\]

Set

\[
b_{a,h}=s_{a,h}-F_{\ge2},\qquad z_{a,h}=D_a*h.
\]

Then the exact original first-prime source satisfies

\[
F_1=b_{a,h}-z_{a,h},\qquad
C_{a,h,\epsilon}:=\|e^{-\epsilon t}b_{a,h}\|_{L^2(\mathbb R)}<\infty.
\tag{4.1}
\]

For the comparison with A02's leading-budget constants, restrict to \(0<\epsilon<1/2\), let \(X=e^{T+d}\), and retain its bounded diagonal \(D_\epsilon(X)\), complete future boundary, and complete signed fluctuation \(\mathcal R_\epsilon(T)\). Its exact identity and the triangle inequality now give

\[
\boxed{
\left|\sqrt{\mathcal R_\epsilon(T)+D_\epsilon(X)}
-\|\mathbf1_{[0,T]}e^{-\epsilon t}(D_a*h)(t)\|_2\right|
\le C_{a,h,\epsilon}.}
\tag{4.2}
\]

The quantity under the square root is exactly the nonnegative first-prime energy. Formula (4.2) does not replace the signed budget by an absolute prime majorant: the full positive and negative pair sums and their escaping future boundary are inside \(\mathcal R\). The higher powers contribute to the explicit stable term in (4.1).

The stable decomposition (4.1) and the corresponding norm comparison hold for every \(\epsilon>0\). Outside \((0,1/2)\), one may write their first norm directly as \(\|\mathbf1_{[0,T]}e^{-\epsilon t}F_1\|_2\), or separately define \(E_1-D_\epsilon\). The A02 asymptotic leading-constant definition of \(\mathcal R\) is not being extended beyond its proved damping range.

This makes the common missing physical response precise. It is the fixed-detector convolution of an actual canonical contact defect whose support begins at \(2a\). B03's leakage lower bound, if verified, therefore forces the same zero-dependent exponential prefix norm for this object up to a bounded additive norm. It supplies no upper estimate for that object.

The novelty is the exact support onset and the unchanged-source adapter (3.1)–(4.2). Mere equivalence of weighted norms is not being presented as an independently proved closing premise.

## 5. The closing law attempted, its stopping point, and matched falsification

An attempted sufficient lemma was:

> For the literal native \(D_a=W_+-p_a\) attached to the constructed full contact, \(e^{-\epsilon t}(D_a*h)(t)\) belongs to \(L^2\) for every positive \(\epsilon\), by positive-realness of \(P_a\), the exact delay \(2a\), the native prime/divisor identity and the initial one-sided cusp.

The calculations establish all the source identifications in this statement, but not its claimed estimate. Positive-realness controls \(p_a*h\); its proof contains no bound on the delayed difference \(W_+-p_a\). Delay imposes a zero prefix and multiplies a possible Laplace residue by a nonzero exponential factor. It does not remove the residue or bound the infinite tail.

The control of `01_LOCAL_CONTACT_AND_FINITE_JET_SIGNED_FLUCTUATION_CONTROL.md` is now exact in these coordinates. Its two modified prime systems have the same \(W_{{\rm sm},+}\), the same contact and \(p_a\), and hence the **same** stable term \(s_{a,h}\). They change only

\[
D_{a,\tau}=D_a-\tau\eta\Delta\Pi,
\qquad \operatorname{supp}\Delta\Pi\subset(2A,\infty).
\]

Each defect still starts at \(2a\), has the same large-y side and exact exponential comparison, and yields the same leading signed budget cancellation. At least one has the rigorously proved cofinal exponential fluctuation. With the arithmetic agent's slow-tail control, the same local preservation applies to an eventual single-model growing fluctuation; no finite central-jet continuation is asserted for that different slow tail.

The exact native \(N,\mu,U\) are the condition these controls lose. Replacing them by a generic Euler/divisor system does not repair the attempted proof. Conversely, the present calculation has not extracted a quantitative signed estimate from their literal values. This is the precise stopping point, rather than an appeal to an unspecified better prime theorem.

## 6. Domain, quantifier and authority firewall

- The contact is the full native PSD operator contact, not a finite canonical K2 state. No parity/depth transport from a reselected K2 ground is made.
- The fixed B detector stays fixed. The derivation neither dilates it nor substitutes a contact autocorrelation.
- The defect is initially a causal distribution, not assumed locally \(L^2\) at its onset. Smooth convolution is performed before the output norm is used.
- The exact boundary \(2a\), the finite interior source terms, and all origin/endpoint distributions are retained. Only the open interval before \(2a\) is asserted to have zero defect.
- The stable bounds are for each fixed contact and each fixed positive damping. No uniformity in aperture, nullity, generator normalization, or a vanishing damping is claimed.
- The negative prime-power contribution is accounted for in (4.1); the complete archimedean remainder is retained in (3.3).
- No global native cardinal identity is assigned to altered completions. No auxiliary positive-real measure is identified with the native zero divisor.

These are PAPER / DERIVED results. They do not produce a green formal theorem, invoke a new compiler authority, or change the 49 requirements, WP0–WP7, or D2 = Full K3. RH remains OPEN.
