# The exterior response has exact weighted L2 abscissa Delta

PRO C round two, 12 October 2026. Status: DERIVED / PAPER. No Lean result
and no RH closure. This is an additional theorem about the actual contact
source; it uses the native logarithmic archimedean symbol, absolute zero
sampling, and the same exterior response constructed in the companion BC
note. The smooth-quartet control retains all these hypotheses.

## 1. Statement

Let f be the real-zero real definite-parity null source at a full PSD
contact on I=[-a,a]. Let F be its negative-sign Fourier transform, let
g=W*f and v(s)=g(a+s) for s>=0. Put lambda_rho=rho-1/2=i gamma_rho,
with distinct zero coordinates grouped and multiplicities m_rho. Define

    Delta=sup_rho |Re lambda_rho|,
    sigma_2(v)=inf{c>=0: exp(-cs)v(s) belongs to L2(0,infinity)}.

Then

    sigma_2(v)=Delta.                                       (1.1)

More precisely, exp(-cs)v is in L2 for every c>Delta, and is not in L2
for every 0<=c<Delta. No claim is made at c=Delta, whether or not a pole
with real part Delta exists. This is a weighted L2 statement about an
almost-everywhere-defined exterior function, not a pointwise growth claim.

The proof adds two domain facts:

    integral_R log(2+|t|)^2 |F(t)|^2 dt < infinity,            (1.2)
    sum_rho m_rho log(2+|gamma_rho|)|F(gamma_rho)|^2
        < infinity.                                        (1.3)

The first is the full operator-domain regularity obtained from contact;
it does not upgrade f to H^epsilon for a positive epsilon.

## 2. Contact gives one full logarithmic operator norm

The archimedean Fourier multiplier in the native T1 form is

    A(t)=Re psi(1/4+it/2)-log pi.

The supplied T1 proof establishes 1+|A(t)| comparable with
1+log(2+|t|), up to harmless bounded-frequency modifications. For a
compactly supported L2 source, A(D)f belongs to H^(-eta)(R) for every
eta>0. Inside I the equation H_a f=0 identifies it with the negative
of the finite prime-shift and smooth pole contributions. Those are L2(I).

Outside I, the local delta part of the multiplier contributes nothing.
Its convolution kernel is the archimedean cross-boundary kernel, whose
only endpoint singularity is bounded by C/(s+u), with s,u>0. The Carleman
Schur estimate in the companion BC note bounds this operator from L2(I)
to L2 of each entire exterior half-line. At infinity the actual kernel
decays exponentially; alternatively the global Carleman bound already
controls the 1/(s+u) majorant. Thus A(D)f is L2 outside I as well.

The remaining possible difference is a distribution supported at the two
endpoints. It lies in H^(-eta) for 0<eta<1/2, so cannot contain a delta
or any derivative of delta. It is zero. Therefore A(D)f belongs to L2(R).
Plancherel and the logarithmic symbol comparison prove (1.2).

Exactly the same argument applies to any operator-domain vector of the
supported native form, with H_a f in L2 on the right side instead of zero.
Bounded smooth kernel perturbations do not change this conclusion.

## 3. One additional logarithmic weight in zero sampling

Let L(t)=log(2+|t|), and choose a smooth compact cutoff eta equal to one
on I. As in C's original sampling proof, for every large integer N,

    |F(z)|^2 <= C_N integral_R |F(t)|^2
                            (1+|Re z-t|)^(-N) dt,

uniformly for |Im z|<=1/2. The unconditional local zero count is

    sum_{rho: k<=Re gamma_rho<k+1} m_rho <= C log(2+|k|).

Multiplying the sampling estimate by L(Re gamma_rho), summing, and
grouping the zeros in unit intervals produces a kernel bounded by

    C sum_k log(2+|k|)^2 (1+|k-t|)^(-N)
        <= C' log(2+|t|)^2.

For the last step use
log(2+|k|)<=C[log(2+|t|)+log(2+|k-t|)] and take N>3; both the
unweighted and logarithm-squared discrete convolution tails converge.
Tonelli therefore proves

    sum m_rho L(Re gamma_rho)|F(gamma_rho)|^2
       <= C_I integral L(t)^2 |F(t)|^2 dt.                    (3.1)

Since the zero imaginary parts are bounded, replacing L(Re gamma) by
log(2+|gamma|) changes only a constant. Equations (1.2) and (3.1) prove
(1.3). No separation of individual zeros or simplicity assumption is used.

## 4. A direct Laplace sampling bound for the zero coordinates

Fix c>Delta and put

    L_rho=log(2+|Im lambda_rho|),
    w_rho=m_rho/L_rho,
    z_rho=c-conjugate(lambda_rho).

The z_rho lie in the right half-plane, in the fixed horizontal-width strip
c-Delta<=Re z<=c+Delta. Choose a disk radius r_0>0 smaller than
(c-Delta)/2. The weighted local count satisfies

    sup_z sum_{rho: |z-z_rho|<r_0} w_rho < infinity.           (4.1)

Indeed only a bounded number of unit height intervals meet a disk, their
total zero multiplicity is O(log(2+|Im z|)), and each denominator L_rho
there is comparable with that logarithm. Bounded-height exceptions are
finite and harmless. Clusters and multiple zeros are covered by the
multiplicity weights; no geometric separation is asserted.

For h in L2(0,infinity), let

    H_h(z)=integral_0^infinity h(s)exp(-zs)ds, Re z>0.

This is holomorphic. The disk mean-value inequality for |H_h|^2 gives

    |H_h(z_rho)|^2 <= (pi r_0^2)^(-1)
                          integral_{|z-z_rho|<r_0}|H_h(z)|^2 dA(z).

Multiply by w_rho, sum, and use (4.1). The resulting area integral lies
in one fixed strip 0<d_1<=Re z<=d_2<infinity. For each x>0, ordinary
Fourier Plancherel gives

    integral_R |H_h(x+iy)|^2 dy
       =2 pi integral_0^infinity |h(s)|^2 exp(-2xs) ds
       <=2 pi ||h||_2^2.

Integrating in x proves the bounded sampling inequality

    sum w_rho |H_h(z_rho)|^2 <= C_c ||h||_2^2.                (4.2)

This elementary disk proof supplies the needed Hardy-space sampling
estimate directly; it invokes no unverified global Suzuki-domain theorem.

## 5. Synthesis of the exterior response in weighted L2

For a finite zero set E define

    v_{E,c}(s)=sum_{rho in E} m_rho F(gamma_rho)
                   exp(a lambda_rho)exp((lambda_rho-c)s), s>=0.

Pair with h in L2 and use Cauchy-Schwarz together with (4.2). It follows
that

    ||v_{E,c}||_2^2 <= C_c sum_{rho in E}
          m_rho L_rho |F(gamma_rho)|^2 exp(2a Re lambda_rho).
                                                                    (5.1)

The exponential factor is bounded by exp(2a Delta), and (1.3) makes the
right side summable. Applying the same bound to differences of finite
sets proves unconditional L2 convergence to a function v_c.

For Re q>0, pairing with exp(-conjugate(q)s) is a bounded L2 functional.
Thus termwise Laplace transformation is legitimate in this L2 limit and

    L[v_c](q)=sum_rho m_rho F(gamma_rho)exp(a lambda_rho)
                          /(q+c-lambda_rho)
             =V(q+c).                                       (5.2)

The last identity is the meromorphic exterior formula independently
proved by the Volterra/contact factorization and by the exact native
Dirichlet calculation. Its series is absolutely and normally convergent
off its poles by the original unweighted sampling estimate.

To identify v_c with the actual exterior function without presupposing
its desired growth, choose c_0>max(c,1/2). The elementary native estimate
already proves exp(-c_0 s)v in L2. Both that function and
exp(-(c_0-c)s)v_c have the same Laplace transform V(q+c_0) for Re q>0.
Uniqueness of the L2 Laplace transform follows directly from Fourier
Plancherel after multiplying by exp(-epsilon s). Hence they agree, and

    v_c(s)=exp(-cs)v(s) almost everywhere.                    (5.3)

This proves the upper assertion in (1.1) for every c>Delta. It uses a
well-controlled infinite synthesis in a fixed weighted L2 space; it is
not a limit of weakly vanishing vectors with unbounded form norm.

## 6. Sharpness from exposed poles

Suppose exp(-cs)v belongs to L2 for some 0<=c<Delta. Its Laplace
transform is holomorphic in Re p>c, by Cauchy-Schwarz on every closed
sub-half-plane. But the exact meromorphic continuation has residues

    Res_{p=lambda_rho}V(p)
          =m_rho exp(a lambda_rho)F(gamma_rho).

Choose a right pole with Re lambda_rho>c. Such a pole exists by the
definition of Delta and reflection symmetry. Its coordinate is nonreal
in the gamma variable, so the real-zero source has F(gamma_rho)!=0.
The displayed residue is nonzero, contradicting holomorphy. This proves
the lower assertion and (1.1). Nothing in this proof decides the boundary
space at c=Delta.

## 7. Research meaning and falsification

The ordinary direct arithmetic estimate sigma>1/2 improves to the exact
spectral threshold c>Delta for this actual full-contact exterior source.
This adds a genuine operator-domain theorem, weighted zero-sampling
estimate, and convergent exterior synthesis. It also shows precisely why
the desired native subexponential bound remains the hard step: for this
real-zero source it would force Delta=0, whereas contact requires a
strictly negative off-line spectral contribution to balance its strictly
positive critical-line contribution.

C's positive-theta smooth-quartet model satisfies every hypothesis here.
The added kernel is bounded on finite intervals and does not change the
logarithmic symbol or local zero count. Its model contact therefore has
the same log-squared regularity and exact weighted L2 threshold, now at
least the inserted deviation delta. It falsifies replacing c>Delta by
all c>0 on the basis of these structural and domain results alone.

The theorem is an exact same-source export to B: the causal exterior
response, the correlation, the fixed local observation, and positive work
carry the same exponent (Delta, Delta, Delta, and 2 Delta respectively),
with distinct norms and the explicit filter from the companion note.
It supplies no native inequality forcing that exponent to vanish.
RH remains OPEN.

