# B04.7 — Formal authority, workflow harvest, history and Post-Green Research Pass

**Review timestamp:** 13 October 2026 after the user requested that interrupted B04 files be uploaded. All new universal mathematical results in B04 remain **PAPER**. Finite symbolic checks are finite checks. RH remains **OPEN**.

## Live repository observation versus archive history

The received cross-path synthesis records merged #288 at commit `bb7c9c9d54fa2d1f82ad5b682c31148539a8f78c` after #287, and a completed 16-workflow green #288 validation. Its mathematical significance is registration/rebinding of already compiled F04 and related source identities; the green receipts do not compile B04, A02 or C04 research arguments.

A **fresh read-only** GitHub connector check during this continuation found only one open PR in `HMarcusWH/zeta-23-lean`: [#290](https://github.com/HMarcusWH/zeta-23-lean/pull/290), draft, unmerged, latest observed head `a081ecd5bcd261c737450f8bc1a7cf74597804fd` at `2026-10-12T22:52:44Z`. The head was newer than the integrated paper's earlier #290 snapshot. Its 18 associated workflow runs were in transient states at that observation: 3 completed successfully, 6 in progress and 9 queued; none of those running or queued jobs may be claimed passed. No local Lean compilation was performed for B04.

#290's WP0–WP7 source checklist has implementation checkboxes but its validation checkboxes remain incomplete in the retrieved PR body. In particular `D2 = Full continuous K3, both parities, on [1/512,log16]` is an uncompleted independent engineering requirement, not made true by a draft PR or small finite grid.

## Workflow classes and factual dispositions

The earlier green #288 suite contains formal validity gates (Lean, exact claim bindings/axiom/no-placeholder checks), regression gates (post-268 44-check replay, earlier Q14 and RHRC research replays), and research-producing checks. The preserved research dispositions include `TRAJECTORY_RIGIDITY_UNRESOLVED`, composite parity-gap falsification on its stated panel, zero eligible exact inherited contacts in the recorded contact scout, and other scoped negatives. A successful replay preserves those results, not a new theorem.

The new #290 checks are independent current research and formal validation jobs in flight; three passing workflows observed included post-214 kernel dual geometry, post287 bounded signed-ray probe, and post-192 parity trajectory rigidity. Those results do not establish this round's native inverse estimate.

## What became formally true

No new B04 Lean declarations are submitted or compiled. The exact prior formal detector and F04 authority remains restricted to the declarations proved on its tested tree. The B04 Laguerre improvement, Hardy divisor characterization, source-based approximation, and domain falsifier are PAPER mathematics. The supplied symbolic checker records independent finite algebra replay, not a proof of RH.

## What changed mathematically versus B03 and A02

1. B03's multiple-zero leakage loses a polynomial only because it used the highest derivative alone. Retaining the complete lower-jet annihilation conditions and orthogonalizing with Laguerre removes that loss.
2. The exact original native forward multiplier admits a classical Blaschke-only closed-range characterization; no additional singular inner factor is the obstruction. This compresses the dependency graph but explicitly exposes the RH-equivalence of closure membership for the actual input.
3. The genuine first-prime cutoff can be corrected by an *explicit* continuum boundary pulse, using no unknown future F. Its remaining PNT error still has too large a global norm scale.
4. A changed-source exact integer-lattice control refutes the generic assertion that a rapidly decaying full output plus weighted ell² coefficients yields global convergence of finite integer truncations.
5. A02's all-nullity smooth polarized contact probes and C04's higher-nullity smoothed negative witnesses do not silently inherit an original detector null equation; all source shifts and interior residuals must remain.

## Upstream implications

The natural interfaces are the original fixed `h`, exact `M_mu`, `N`, `Pi_1`, `Pi_{>=2}`, `a_N`, `v`; the A02 cumulant `J` and future boundary; and the C contact residual. A reusable source/shift contract should distinguish full two-sided correlation from its retarded restriction and store the finite-history term. The old wrong sign and modulus-square temptations remain disallowed.

## Downstream implications and resurrected routes

The sharpened pure-exponential lower bound is a stricter falsifier for every future signed prime-pair upper estimate. Source-specific corrected cutoff approximants are worth reconsidering because their boundary pulse is now removed exactly; unlike the failed finite Euler norm route they come from the actual native primes and do not require using F as a definition. This resurrection does not eliminate the global error obstruction.

The source-specific range problem now has an exact zero-divisor test and a concrete sufficient subpower error inequality OPEN-X. This is a new usable proof cut, but it is not yet independent arithmetic or spectral control.

## Creative implication and falsification

An RH-relevant possibility is cancellation at the *next* scale: after the PNT deterministic prime-pair/boundary scale cancels, exact native divisor and theta compatibility might constrain the remaining signed error. To test its substance, demand the same bound on the unchanged original h and ordinary native coefficients, and try it on the native negative-work probe, far-prime tail surgeries, sign-changing pair kernel, altered positive-kernel same-input model and integer-truncation control.

The simplest falsifier is to find a construction preserving every premise of a proposed inequality but retaining a planted right pole. A technique that merely follows a bounded observation that has already annihilated the pole cannot close RH.

## Highest-leverage next moves

Mathematical information gain is highest from an independently proved global subpower error for B04's explicit corrected prime-prefix approximants, or a different genuinely native constraint that forces their residual to zero. Proving another equivalent range formula alone is insufficient. Any proposed formalization must state the exact source, operator-domain and epsilon quantifiers, enter the RHRC claim firewall, and pass the full theorem/axiom/CI gates before promotion.

## Claim firewall and preserved requirements

- `PROVED`: exact earlier Lean declarations only, on their stated tested trees.
- `PAPER/DERIVED`: all new infinite-dimensional B04 arguments.
- `CERTIFIED FINITE`: separately listed finite polynomial replays, no zero or CI authority.
- `FALSIFIED`: only scoped statements defeated by the matched controls.
- `OPEN`: original weighted `F` bound; actual input closed-range membership; OPEN-X global subpower error; A02 signed prime fluctuation upper estimate; relevant C native exterior bound; RH.

All 49 requirements and WP0–WP7 are preserved. D2 remains **Full continuous K3**, *both parities*, throughout `[1/512, log16]`. No repository edits, push, PR, merge or terminal-claim promotion were performed.
