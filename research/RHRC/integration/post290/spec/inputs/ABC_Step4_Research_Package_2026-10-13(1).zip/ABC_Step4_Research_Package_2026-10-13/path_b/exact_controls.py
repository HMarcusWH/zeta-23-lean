#!/usr/bin/env python3
"""Exact finite algebra controls for the new native shifted sensor.
No numerical zeta evaluations, no RH claim, and no proof of the global estimate.
All computations use integers and fractions in the standard library.
"""
from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path
import json, hashlib, math

def P(*coeffs):
    return tuple(F(x) for x in coeffs)
def trim(p):
    p=list(p)
    while len(p)>1 and p[-1]==0: p.pop()
    return tuple(p)
def padd(a,b):
    c=[F(0)]*max(len(a),len(b))
    for i,x in enumerate(a): c[i]+=x
    for i,x in enumerate(b): c[i]+=x
    return trim(c)
def pneg(a):return tuple(-x for x in a)
def psub(a,b):return padd(a,pneg(b))
def pmul(a,b):
    c=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return trim(c)
def pder(a):return trim(tuple(i*a[i] for i in range(1,len(a)))) if len(a)>1 else P(0)
class R:
    def __init__(self,n,d=P(1)):self.n,self.d=trim(n),trim(d)
    def __add__(self,b):
        if not isinstance(b,R):b=R(P(b))
        return R(padd(pmul(self.n,b.d),pmul(b.n,self.d)),pmul(self.d,b.d))
    __radd__=__add__
    def __neg__(self):return R(pneg(self.n),self.d)
    def __sub__(self,b):return self+-b
    def __mul__(self,b):
        if not isinstance(b,R):b=R(P(b))
        return R(pmul(self.n,b.n),pmul(self.d,b.d))
    __rmul__=__mul__
    def __truediv__(self,b):
        if not isinstance(b,R):b=R(P(b))
        return R(pmul(self.n,b.d),pmul(self.d,b.n))
    def zero(self):return all(v==0 for v in self.n)
    def equal(self,b):return (self-b).zero()
    def derivative(self):
        return R(psub(pmul(pder(self.n),self.d),pmul(self.n,pder(self.d))),pmul(self.d,self.d))
p=R(P(0,1))
def invlin(a):return R(P(1),P(a,1))
def c0shift(h):
    return (p+h-F(1,2))/((p+h+F(1,2))*(p+h+1))
checks={}
for h in [F(3,4),F(1),F(2),F(3),F(7,2)]:
    rat_inverse=p+h+2+F(3,2)*invlin(h-F(1,2))
    assert (c0shift(h)*rat_inverse).equal(R(P(1)))
checks["all_five_exact_shift_inverse_identities"]=True
integrated_inverse=R(P(1))-invlin(1)+3*invlin(F(1,2))
assert (integrated_inverse*c0shift(1)).equal(invlin(1))
checks["integrated_h1_left_inverse"]=True

# j includes an abstract gamma term; its exact shift-2 difference is -1/(p+1/2).
j_rational=invlin(-F(1,2))+invlin(F(1,2))
j_shift2_rational=invlin(F(3,2))+invlin(F(5,2))
gamma_shift_difference=-invlin(F(1,2))
actual=j_rational-j_shift2_rational+gamma_shift_difference
target=invlin(-F(1,2))-invlin(F(3,2))-invlin(F(5,2))
assert actual.equal(target)
checks["full_gamma_shift2_cancellation"]=True
for N in [1,2,3,5,8]:
    gamma_N=R(P(0));gamma_N_shift=R(P(0))
    for k in range(N):
        gamma_N=gamma_N-invlin(F(1,2)+2*k)
        gamma_N_shift=gamma_N_shift-invlin(F(5,2)+2*k)
    expected=-invlin(F(1,2))+invlin(F(1,2)+2*N)
    assert (gamma_N-gamma_N_shift).equal(expected)
checks["finite_gamma_cutoff_keeps_its_upper_endpoint"]=True
# Native first-prime prefix: the infinite extensions below coincide with the
# actual r_2 and Delta_2 for 0 < t < log 2, so causality gives the exact prefix.
r2_prefix=3*invlin(3)-2*invlin(F(5,2))
d2_prefix=invlin(-F(1,2))-invlin(F(3,2))-invlin(F(5,2))
k2_prefix=(F(4,21)*invlin(-F(1,2))+F(50,7)*invlin(3)
           -F(22,3)*invlin(F(5,2))
           +2*invlin(F(5,2))*invlin(F(5,2)))
assert (r2_prefix*d2_prefix).equal(k2_prefix)
assert F(4,21)+F(50,7)-F(22,3)==0
assert F(1,2)*F(4,21)-3*F(50,7)+2+F(5,2)*F(22,3)==-1
assert F(7,5)**2<2 and F(3,2)**2>2
# log 2 > 2/3 follows from 2*integral_0^(1/3) (1-u^2)^(-1) du > 2/3.
assert 75*F(7,5)+42*F(2,3)-122==11
assert 75*F(3,2)-122<0
checks["native_filtered_defect_changes_sign_before_and_at_first_prime"]=True
mutations={}
mutations["omitting_gamma_difference_rejected"]=not (j_rational-j_shift2_rational).equal(target)
mutations["wrong_gamma_sign_rejected"]=not (j_rational-j_shift2_rational-gamma_shift_difference).equal(target)
mutations["dropping_inverse_resolvent_rejected"]=not (c0shift(2)*(p+4)).equal(R(P(1)))

def factor(n):
    out={};q=2
    while q*q<=n:
        while n%q==0:out[q]=out.get(q,0)+1;n//=q
        q+=1
    if n>1:out[n]=out.get(n,0)+1
    return out
def divisors(n):
    out=[1]
    for q,k in factor(n).items():
        out=[v*q**j for v in out for j in range(k+1)]
    return sorted(out)
def mu(n):
    f=factor(n)
    return 0 if any(v>1 for v in f.values()) else (-1)**len(f)
def vm_log_basis(n):
    f=factor(n)
    return next(iter(f)) if len(f)==1 else None
def add_log(d,q,x):
    if q is not None:d[q]+=F(x)
# Coefficients are rational combinations of independent formal log-prime symbols.
for n in range(1,2001):
    assert sum(mu(d) for d in divisors(n))==(1 if n==1 else 0)
    coeff=defaultdict(F)
    direct=defaultdict(F)
    for d in divisors(n):
        q=vm_log_basis(d)
        add_log(coeff,q,d*d-1)
    for q,k in factor(n).items():
        add_log(direct,q,sum(q**(2*j)-1 for j in range(1,k+1)))
    assert dict(coeff)==dict(direct)
checks["mobius_inverse_and_weighted_divisor_coefficients_n_le_2000"]=True
mutations["absolute_mobius_inverse_rejected_at_prime2"]=(sum(abs(mu(d)) for d in divisors(2))!=0)
mutations["weighted_divisor_wrong_sign_rejected_at_prime2"]=(F(2**2-1)!=F(1,2**2)-1)

# Sparse symbolic polynomial ring for the covariant derivative hierarchy.
# Variables A, J0,J1,..., C0,C1,... with derivation D(A)=A*(J0-C0).
def var(n):return {((n,1),):F(1)}
def clean(x):return {m:c for m,c in x.items() if c}
def add(x,y):
    z=defaultdict(F);z.update(x)
    for m,c in y.items():z[m]+=c
    return clean(z)
def scale(x,c):return clean({m:v*c for m,v in x.items()})
def mul(x,y):
    z=defaultdict(F)
    for m,c in x.items():
        for n,d in y.items():
            e=defaultdict(int)
            for k,v in m+n:e[k]+=v
            z[tuple(sorted(e.items()))]+=c*d
    return clean(z)
def dv(n):
    if n=="A":return mul(var("A"),add(var("J0"),scale(var("C0"),-1)))
    return var(n[0]+str(int(n[1:])+1))
def deriv(x):
    z={}
    for mon,c in x.items():
        for name,power in mon:
            rest=dict(mon);rest[name]-=1
            if rest[name]==0:del rest[name]
            z=add(z,mul({tuple(sorted(rest.items())):c*power},dv(name)))
    return z
A=var("A");J=var("J0");C=var("C0")
lhs=A;bell={():F(1)}
for k in range(7):
    assert lhs==mul(A,bell)
    lhs=add(deriv(lhs),mul(C,lhs))
    bell=add(deriv(bell),mul(J,bell))
checks["covariant_completed_kernel_identity_orders_0_to_6"]=True

# Principal part bookkeeping at a zero: A=x^m*a0, V=res/x.
# (AV) has first nonzero degree m-1, while R_2*V has residue R_2(0)*res.
jet_checks=[]
for m in range(1,10):
    raw_factor=F(m,math.factorial(m))*math.factorial(m-1)
    assert raw_factor==1
    jet_checks.append({"multiplicity":m,"input_top_jet_factor":str(raw_factor),
                       "shifted_sensor_residue_order":1})
checks["multiplicity_factors_1_through_9"]=True

# A strict-prime endpoint test shows truncated inverse is only prefix-exact.
X=7;bad=[]
for n in range(1,41):
    residual=sum(mu(d) for d in divisors(n) if d<=X)-(1 if n==1 else 0)
    if residual:bad.append({"n":n,"coefficient_before_n_weight":residual})
assert all(x["n"]>X for x in bad) and bad[0]["n"]==10
checks["finite_mobius_inverse_prefix_exact_but_not_global_exact"]=True

assert all(checks.values()) and all(mutations.values())
result={
"status":"EXACT_FINITE_ALGEBRA_CONTROLS_PASS",
"scope":"Finite symbolic/rational controls only; not a proof of analytic domains, actual output bound, or RH.",
"checks":checks,"mutation_falsifiers":mutations,
"multiplicity_checks":jet_checks,"truncated_inverse_first_residuals":bad,
"native_sign_control":{
  "interval":"0 < t < log 2",
  "kappa2":"(4/21) exp(t/2) + (50/7) exp(-3t) + (2t-22/3) exp(-5t/2)",
  "initial_right_derivative":"-1",
  "scaled_left_limit_at_log2":"84 sqrt(2) kappa2(log2-) = 75 sqrt(2) + 42 log(2) - 122 > 11",
  "scaled_right_limit_at_log2":"84 sqrt(2) kappa2(log2+) = 75 sqrt(2) - 21 log(2) - 122 < -19/2"
},
"new_source_identity":"(1-exp(-2t))*W_+ = exp(t/2)-exp(-3t/2)-exp(-5t/2)-sum Lambda(n)n^(-1/2)(1-n^(-2))delta_log(n)",
"open":"Independent H1 or quiet-subsequence upper bound for r_2*v on the original contact."
}
here=Path(__file__).resolve().parent
result["script_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(here/"exact_controls.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"status":result["status"],"checks":len(checks),"mutations":len(mutations)}))

