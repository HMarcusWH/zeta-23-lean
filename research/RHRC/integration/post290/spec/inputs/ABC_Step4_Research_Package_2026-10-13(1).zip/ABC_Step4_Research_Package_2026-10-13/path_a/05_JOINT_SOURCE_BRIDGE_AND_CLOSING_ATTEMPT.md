# Joint campaign Path A continuation: the exact A+B+C source bridge and closing attempt

Date: 13 October 2026. Status: **PAPER / DERIVED, not formalized. Step 4 remains open.**

This note combines the new arithmetic mask and smooth-sector estimate with B's shifted native sensor and C's source-derived contraction. It proves an exact finite-horizon inequality on the actual sources. The inequality still contains one signed arithmetic term without a proved upper bound. Replacing that term by the already controlled arithmetic sectors is the unsupported closing implication.

## 1. One fixed arithmetic residual

Keep the original detector \(h\), \(d=1/2048\), and choose the single \(B\) and the primorial step function \(P(t)\) of Note 04. Set

\[
L_P(t)=BP(t)e^dt^2,\qquad
Z(t)=\exp(t/\log(t+2)).
\]

Let \(S_{P,B}\) be the complete masked long-divisor sum in Note 04. Split its product coefficients according to the full \(L_P(t)\)-rough core:

\[
\begin{split}
R_A(t)
&=\sum_{\substack{k\le e^{t+d}\\b_{L_P(t)}(k)>Z(t)}}
\frac{w_{P(t)}(k)A_{Y_P(t)}(k)}{\sqrt k}
h(t-\log k),\\
E_A(t)&=F(t)-R_A(t).
\end{split}
\tag{1}
\]

Use (1) above a sufficiently large fixed \(T_0\); set \(R_A=0\) before \(T_0\). The bounded initial piece is absorbed into \(E_A\). Notes 03–04 prove

\[
\boxed{\forall\epsilon>0:\quad E_A\in L^2_\epsilon,}
\qquad
\|u\|_{\epsilon,T}
:=\left(\int_0^T e^{-2\epsilon t}|u(t)|^2dt\right)^{1/2}.
\tag{2}
\]

This uses the compatibility \(L_P(t)=O(t^2\log(t+2))\). The small-rough-core part is only proved to lie in every positively damped space; it has not been proved undamped \(L^2\).

Equation \(F=R_A+E_A\) is exact. Every mixed cofactor term belonging to \(R_A\) remains in its squared norm. The all-positive-damping closing target is now exactly

\[
\boxed{\forall\epsilon>0:\quad \sup_T\|R_A\|_{\epsilon,T}<\infty.}
\tag{3}
\]

## 2. The same fixed detector sees the complete gamma-free forcing

Write \(h_+(t)=h(t-d)\), supported in \([0,2d]\), and let \(\tau_b\) denote causal delay by \(b\). Then

\[
F_+:=\Pi*h_+=\tau_dF.
\]

The independent B and C calculations agree on the exact native causal measure

\[
\Delta_2=(1-e^{-2t})W_+
=E_2-\Pi+\Pi_2,
\tag{4}
\]

where

\[
E_2(dt)=(e^{t/2}-e^{-3t/2}-e^{-5t/2})\,dt,\qquad
\Pi_2=\sum_{n\ge2}\Lambda(n)n^{-5/2}\delta_{\log n}.
\]

All three continuous terms are causal, and the entire prime-power measure is retained. The equality follows on the initial convergence half-plane from

\[
\tfrac12\{\psi(p/2+1/4)-\psi(p/2+5/4)\}
=-\frac1{p+1/2},
\]

which cancels precisely the \(1/(p+1/2)\) rational term in \(J(p)-J(p+2)\). Thus there is no omitted gamma or diagonal remainder.

The compact detector's transform satisfies \(K(1/2)=0\). Consequently \(E_2*h_+\) has only compact initial history and two decaying exponential tails. Also

\[
|(\Pi_2*h_+)(t)|\le C_h(1+t)e^{-3t/2}
\]

for large \(t\), by the elementary inequality \(\Lambda(n)\le\log n\) and the support restriction \(e^{t-2d}\le n\le e^t\). Therefore the actual causal function

\[
b_h:=E_2*h_++\Pi_2*h_+
\]

belongs to \(L^1\cap L^2\), with a positive exponential margin. The exact full-history identity is

\[
\boxed{
\Delta_2*h_+=b_h-F_+
=b_h-\tau_dE_A-\tau_dR_A.
}
\tag{5}
\]

It follows, for every fixed \(\epsilon>0\), that

\[
\boxed{
\left|
\|\Delta_2*h_+\|_{\epsilon,T}
-e^{-\epsilon d}\|R_A\|_{\epsilon,(T-d)_+}
\right|\le C_\epsilon
\quad\text{for every }T.
}
\tag{6}
\]

This is a true same-detector comparison for the complete centered prime forcing. It does not require a backwards inverse of a compact convolution.

The replacement of prime weights by \(1-n^{-2}\) changes the fixed-detector output by the independently stable term \(\Pi_2*h_+\). It cleans up the native completion but does not improve the unknown exponential growth rate.

## 3. Convolving C's original contact equation, without declaring a new null vector

Import C's actual canonical contact source \(f_0\), aperture \(a>0\), companion \(c_0\), and right exterior \(v\). Put

\[
L=2a,\quad f_+(t)=f_0(t-a),\quad c_+(t)=c_0(t-a).
\]

Both compact sources are supported in \([0,L]\). C's new theorem provides

\[
D(p)=\int_{-a}^a f_0(x)e^{-px}\,dx,\quad
T_2(p)=D(p)/D(p+2),\quad \|T_2\|_{H^\infty(\mathbb C_+)}\le1.
\]

Let \(\mathsf T_2\) be its actual bounded causal operator, \(\mathsf M_2v=e^{-2t}v\), and

\[
\mathsf S_2=e^{2a}\mathsf T_2,\qquad
\mathsf B_2=e^{-2a}\mathsf T_2\mathsf M_2,\qquad q=e^{-2a}<1.
\]

The exact original-source identity, including its complete history, is

\[
\Delta_2*f_++c_+-\mathsf S_2\mathsf M_2c_+
=\tau_L(I-\mathsf B_2)v.
\tag{7}
\]

Causality and the \(H^\infty\) bound give, for every positive damping and every finite horizon,

\[
(1-q)\|u\|_{\epsilon,T}
\le\|(I-\mathsf B_2)u\|_{\epsilon,T}
\le(1+q)\|u\|_{\epsilon,T}.
\tag{8}
\]

Convolve (7) with the fixed \(h_+\), use (5), and use commutativity of proper causal convolution. This yields the exact equation

\[
\boxed{
\tau_L\,h_+*(I-\mathsf B_2)v
+f_+*\tau_dR_A
=J_A,
}
\tag{9}
\]

where

\[
J_A=f_+*(b_h-\tau_dE_A)
+h_+*c_+-h_+*\mathsf S_2\mathsf M_2c_+.
\tag{10}
\]

Every term of \(J_A\) is independently in every \(L^2_\epsilon\), \(\epsilon>0\): the compact functions are \(L^1\), \(E_A\) has (2), and \(\mathsf S_2\mathsf M_2c_+\) is a proved globally \(L^2\) output. All compact initial contributions remain in (10).

Young's inequality on prefixes therefore gives, with
\(a_\epsilon=\|e^{-\epsilon t}f_+(t)\|_1<\infty\),

\[
\boxed{
e^{-\epsilon L}
\|h_+*(I-\mathsf B_2)v\|_{\epsilon,(T-L)_+}
\le a_\epsilon e^{-\epsilon d}
\|R_A\|_{\epsilon,(T-d)_+}+C_\epsilon.
}
\tag{11}
\]

No smoothed source has been declared a null vector at a new aperture. Equation (9) is a convolution of the existing exact contact equation. The original \(f_0,c_0,v\), the original \(h\), and their shifts are explicit.

## 4. A legal contracted inequality for the smoothed actual exterior

One can move the compact filter through the feedback at the price of another independently stable term. The safe shifted half-plane/source regularity used by B and C gives
\(\mathsf M_2v\in L^2\) unconditionally under their supplied contact foundations. In detail, \(J(2+i\xi)\) has logarithmic growth, while the compact \(f_0\) has some positive fractional Sobolev regularity; the companion is \(L^2\). Their original transform identity therefore lies in \(L^2\) on that safe line. No critical-strip zero-free input is used.

Let \(\mathsf H u=h_+*u\). Then

\[
\begin{split}
\mathsf H\mathsf B_2v-\mathsf B_2\mathsf Hv
&=e^{-2a}\mathsf T_2
\left[(h_+-\mathsf M_2h_+)*\mathsf M_2v\right]\\
&=:j_{\mathrm{comm}}.
\end{split}
\tag{12}
\]

The right side is a proved \(L^2\) function, hence is in every positive-damping space. This is the full commutator; it is not set to zero. Thus

\[
\mathsf H(I-\mathsf B_2)v
=(I-\mathsf B_2)\mathsf Hv-j_{\mathrm{comm}}.
\]

Substitution in (9) and use of (8) gives the explicit combined estimate

\[
\boxed{
(1-e^{-2a})e^{-\epsilon L}
\|h_+*v\|_{\epsilon,(T-L)_+}
\le
a_\epsilon e^{-\epsilon d}
\|R_A\|_{\epsilon,(T-d)_+}
+C_\epsilon.
}
\tag{13}
\]

This is a genuine finite-horizon A+B+C closing inequality: the stable lattice cancellation, the arithmetic mask, the small-core estimate, the exact gamma-free distribution, and the source contraction are all included. Its unknown right-hand term is the complete signed arithmetic residual (1).

There is no assertion of a bounded backwards \(L^2\) inverse for \(h_+\), and (13) is not a norm estimate on unsmoothed \(v\). The smoothed actual exterior still retains every right-half-plane zero pole, since the native \(K(\lambda)\) is nonzero there and C's canonical \(D(\lambda)\) is also nonzero. This pole statement uses the actual convolution; it does not assert new contact positivity at aperture \(a+d\).

## 5. What B's stable sensor adds on the fixed smooth detector

B's independently checked native sensor is

\[
r_2(t)=e^{-2t}a_N(t),\qquad
R_2(p)=A(p+2).
\]

It has no zero in \(\Re p\ge0\), is in \(L^1\cap L^2\), and has a finite-measure derivative. Its exact inverse on the causal graph domain is

\[
X=M_{5/2}*
\left[z'+4z+\tfrac32 e^{-3t/2}\mathbf1_+*z\right],
\quad z=r_2*X,\quad
M_{5/2}=\sum_{n\ge1}\mu(n)n^{-5/2}\delta_{\log n}.
\tag{14}
\]

The measure \(M_{5/2}\) has finite variation. At a fixed damping, the inverse needs \(z'\) as well as \(z\).

For the particular smooth original-detector field \(X=\Delta_2*h_+\), the all-positive-damping frontier can also be expressed using only the plain \(L^2\) sensor output:

\[
\boxed{
X\in\bigcap_{\epsilon>0}L^2_\epsilon
\quad\Longleftrightarrow\quad
r_2*X\in\bigcap_{\epsilon>0}L^2_\epsilon.
}
\tag{15}
\]

Here is the additional regularity argument, so that (15) does not silently replace B's graph theorem. The native compact smoothing gives, for every integer \(j\ge0\),

\[
|X^{(j)}(t)|\le C_j(1+t)e^{t/2}.
\]

The same estimate holds for \(z^{(j)}=r_2*X^{(j)}\). The causal \(X\) is infinitely smooth and flat at zero because \(h_+\) is infinitely smooth and flat at the endpoints of its compact support. Derivatives fall on this smooth \(X\), rather than on the moving arithmetic cutoff.

Suppose \(z\in L^2_\eta\) for every \(\eta>0\). Fix a target \(\epsilon>0\), set \(c=\epsilon/4\), \(\eta=\epsilon/8\), and choose an integer \(j\ge2\) with \(c(j-1)>1/2\). Choose a compact smooth kernel \(\phi\), supported in \([-1,1]\), with integral one and moments of orders \(1,\ldots,j-2\) zero. Such a kernel follows by solving the finite positive-definite moment system for a polynomial times a positive smooth bump.

For each selected \(t\ge2\), set \(\ell=e^{-ct}\) and hold this scale fixed while taking the convolution derivative in the independent evaluation variable. No derivative of a moving scale is intended. Taylor's theorem and that fixed-scale convolution differentiation give

\[
|z'(t)|
\le C_j\left[
\ell^{-3/2}\|z\|_{L^2(t-1,t+1)}
+\ell^{j-1}\sup_{|s-t|\le1}|z^{(j)}(s)|
\right].
\tag{16}
\]

The first term is \(O_{\epsilon,j}(e^{(\eta+3c/2)t})
=O_{\epsilon,j}(e^{\epsilon t/2})\), because
\(\|z\|_{L^2(t-1,t+1)}
\le e^{\eta(t+1)}\|z\|_\eta\).
The second term decays exponentially up to a polynomial, by the choice of \(j\). Thus \(z'\in L^2_\epsilon\). Formula (14) then gives \(X\in L^2_\epsilon\), proving the nontrivial implication in (15). The forward implication is Young's inequality.

This argument is restricted to the unchanged infinitely smooth detector field. It does not apply to the unsmoothed finite-regularity contact generator without further work, and it does not apply to derivatives of the adaptive arithmetic fields, which may have cutoff jumps.

At every hypothetical right zero \(\lambda\), \(R_2(\lambda)\ne0\), so the sensor retains the nonzero pole coefficient of \(X\). It therefore provides an explicit native observation with the stated graph inverse, and an exact equivalent all-damping target on this smooth source. It does not estimate that target.

## 6. The explicit attempted absorption and its failure

The desired next inequality would have to control

\[
\|R_A\|_{\epsilon,T}
\]

independently of the unknown growing native field. The new estimates control the discarded small inverse, the entire small-rough-core sector, and the separated gcd rays. They do not control the remaining masked large-rough-core field.

The zero-one property \(0\le w_P\le1\) does not imply a contractive estimate for a signed sum. In fact the exact source adapter rules out obtaining an attenuation factor merely from this projection. For a fixed \(\epsilon>0\), (2) implies

\[
\big|\|F\|_{\epsilon,T}-\|R_A\|_{\epsilon,T}\big|
\le \|E_A\|_{\epsilon,\infty}.
\tag{17}
\]

If the actual native norm diverges, then

\[
\frac{\|R_A\|_{\epsilon,T}}{\|F\|_{\epsilon,T}}\longrightarrow1.
\tag{18}
\]

Thus, on any such growing output, an estimate
\(\|R_A\|_{\epsilon,T}\le q_0\|F\|_{\epsilon,T}+C_\epsilon\)
with \(q_0<1\) and fixed \(C_\epsilon\) is false. This is a precise conditional norm statement, not an assertion that RH has a counterexample.

In particular, the inherited actual-input lower bound for a hypothetical zero \(\rho\) with \(\lambda=\rho-1/2\), \(\Re\lambda>0\), transfers without any change of horizon quantifier. For every \(0<\epsilon<\Re\lambda\), it gives constants \(c_{\rho,\epsilon}>0\) and \(T_{\rho,\epsilon}\) such that

\[
\|R_A\|_{\epsilon,T}^2
\ge c_{\rho,\epsilon}e^{2(\Re\lambda-\epsilon)T}
\qquad(T\ge T_{\rho,\epsilon}).
\tag{18a}
\]

This follows directly from (17) and the same-source bound on \(F\). The constants can depend on the zero and its multiplicity. No largest off-line real part, simple-zero assumption, or horizon subsequence is introduced.

C's factor \(e^{-2a}<1\) controls its feedback term. It does not multiply the complete arithmetic forcing by a corresponding factor. Substituting (13) back into a rearranged source identity therefore gives an estimate containing the same unknown norm again, with no proved coefficient below one. The exact missing implication is:

\[
\boxed{
\begin{gathered}
\text{bounded masked-small-divisor error}
\\
+\ \text{bounded small-rough-core field}
\\
+\ \text{stable source contraction and sensor}
\\[2pt]
\not\Longrightarrow_{\text{proved here}}
\sup_T\|R_A\|_{\epsilon,T}<\infty.
\end{gathered}}
\tag{19}
\]

Attempting to supply (19) by taking absolute values also fails as a method: Note 02 proves surviving squarefree positive and negative budgets at exponential rate \(1/2\), even after this mask and rough-core removal. Their complete signed cancellation, including mixed cofactor correlations, remains the required arithmetic input.

No cofinal sign theorem for a dilating A source has been substituted for this fixed-source bound. No finite calculation is used to establish (3).

## Cross-review and source record

- B continuation, path_b/01_SHIFTED_NATIVE_SENSOR_AND_GAMMA_FREE_DEFECT.md: Sections 3–6 were checked against the derivative, jump, inverse, residue, and digamma calculations. The truncation bound now explicitly uses integer cutoffs after review.
- C continuation, path_c/02_SOURCE_TILT_CONTRACTION_AND_GAMMA_FREE_FORCING.md: Sections 1–4 supply the source multiplier, original-source equation, and prefix coercivity. The \(h=2\) digamma cancellation and the factors \(D(1/2),D(-3/2),D(-5/2)\) were independently checked.
- A Notes 01–04 supply only the specific bounds and identities stated there. The contact foundations remain inherited paper assumptions/results; none was promoted to Lean authority.
- Equations (5), (9), (12)–(13), the smooth-source adapter (15), and the failed-attenuation test (17)–(18) are derived in this joint campaign.
