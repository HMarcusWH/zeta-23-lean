# A03 arithmetic: native composite support after exact localization

**Status: PAPER / DERIVED.** This note adds a genuinely native arithmetic
description of the short-cofactor sum in Note03. It proves that all of its
active prime-power coefficients vanish, while positive and negative
composite coefficients both occur inside every sufficiently late fixed
source window. Thus the exact native Möbius signs remain essential after
the new localization. The result is not an upper norm bound, and RH
remains OPEN.

## 1. Exact source, cutoff and proposed closing statement

Use the unchanged original detector `h=k_r*k_r`, `r=1/4096`,
`d=1/2048`, and the quantitative constants from Note03. Fix one `B>0`
large enough that `kappa sqrt(B)>1/2`. Put

\[
 X(t)=e^{t+d},\qquad Y(t)=\frac{e^t}{Bt^2},
\]

and define the finite exact native sum

\[
 \mathcal L_B(t)=
 \sum_{2\le m<B e^d t^2}\frac{\log m}{\sqrt m}
 \sum_{\substack{n>Y(t)\\nm\le X(t)}}
 \frac{\mu(n)}{\sqrt n}h(t-\log(mn)).
 \tag{1.1}
\]

For all sufficiently large `t`, Note03 proves

\[
 F(t)=\mathcal L_B(t)+r_B(t),\qquad
 |r_B(t)|\le C_Bt^{-1}e^{-c_Bt},\quad c_B>0.
 \tag{1.2}
\]

The major candidate closing law, stated before the additional test, is

\[
 \boxed{\forall\epsilon>0:\quad
 \int_{T_0}^{\infty}e^{-2\epsilon t}|\mathcal L_B(t)|^2\,dt<\infty.}
 \tag{CL}
\]

Here `T0` is any sufficiently large fixed threshold on which (1.2) holds.
The exact native coefficients, sharp inner threshold, unchanged detector,
and *all* small-cofactor cross terms are part of the statement. By (1.2)
and the inherited B03 actual-input obstruction, (CL) would exclude every
off-line native zero; no assumption of it is made. The attempted extra
step was to obtain a favorable arithmetic sign from the now very short
cofactor range and the exact identity `mu*1=delta1`. The following
native calculation falsifies that sign shortcut.

## 2. Exact product coefficients and complete prime-power disappearance

For any `X>=2`, any `Y>1`, and every positive integer `k<=X`, let

\[
 A_Y(k)=\sum_{\substack{n\mid k\\n>Y}}
                    \mu(n)\log(k/n).
 \tag{2.1}
\]

The `n=k` term is always zero, regardless of the value of `mu(k)`.
Regrouping the finite sum (1.1) therefore gives exactly

\[
 \boxed{\mathcal L_B(t)=
 \sum_{2\le k\le X(t)}\frac{A_{Y(t)}(k)}{\sqrt k}
                                  h(t-\log k).}
 \tag{2.2}
\]

There is no limiting interchange and no new source. The full divisor
identity is

\[
 \Lambda(k)=\sum_{n\mid k}\mu(n)\log(k/n)
           = A_Y(k)+\sum_{\substack{n\mid k\\n\le Y}}
                               \mu(n)\log(k/n).
 \tag{2.3}
\]

Suppose now that `Y>sqrt(X)`. Then

\[
 \boxed{A_Y(p^j)=0\quad\text{for every prime power }p^j\le X.}
 \tag{2.4}
\]

For `j=1`, the only possible term above `Y` is `n=p`, which has
`log(k/n)=0`. For `j>=2`, a nonzero Möbius coefficient on a divisor of
`p^j` can only occur at `n=1` or `n=p`. Both are at most `Y`, because
`p<=sqrt(X)<Y`. This covers repeated powers without discarding them.

Since `Y(t)/sqrt(X(t))=e^{(t-d)/2}/(Bt^2)` tends to infinity, (2.4)
applies eventually to the actual localized sum. Therefore every
nonzero product coefficient in (2.2) is supported on integers with at
least two distinct prime divisors. Nevertheless (1.2) recovers the full
native von Mangoldt output, up to the separately controlled small term.

This apparently unusual support change is exact. The small-divisor
part contains every prime-power coefficient of the original output,
but its composite coefficients cancel those terms after this precise
same-source smoothing. It is false to turn the filtered small remainder
into a coefficientwise error bound. In particular, deleting prime powers
from the original explicit formula would be an entirely different and
invalid operation.

## 3. Exact signs on native composite families

Two elementary native formulas control the new sign test.

**Large-prime family.** If `Y>sqrt(X)`, `q>Y` is prime and
`k=qm<=X`, then `m<X/Y<Y<q`; hence `q` does not divide `m`. Every
divisor of `k` greater than `Y` must contain `q`, because the other
divisors are at most `m`. Conversely each `qd`, `d|m`, exceeds `Y`.
The genuine Möbius signs give

\[
 \begin{split}
 A_Y(qm)
 &=\sum_{d\mid m}\mu(qd)\log(m/d)\\
 &=-\sum_{d\mid m}\mu(d)\log(m/d)
 =-\Lambda(m)\le0.
 \end{split}\tag{3.1}
\]

The equality `mu(qd)=-mu(d)` is valid also when `d` is not squarefree:
both sides then vanish. For example, `m=2` gives `A_Y(2q)=-log2`.

**Repeated-small-prime family.** Let distinct primes `p,q` satisfy

\[
 p\le Y,\quad q\le Y,\quad pq>Y,\quad p^2q\le X.
 \tag{3.2}
\]

The only squarefree divisors of `p^2q` are `1,p,q,pq`. Only `pq` is
above the cutoff, so

\[
 \boxed{A_Y(p^2q)=\log p>0.}\tag{3.3}
\]

The repeated prime in the product is load-bearing. These formulas use
the actual native squarefree signs and exact divisor relation; no
modified-prime or magnitude model is needed.

## 4. Both signs occur in every sufficiently late active source window

Let `J=(u_-,u_+)` be any nonempty fixed open interval with closure in
`(-d,d)` on which `h` is nonzero and has a fixed sign. At least one such
interval exists because `h` is continuous and nonzero. For every
sufficiently large `t`, there are native integers `k_+(t),k_-(t)` such
that

\[
 t-\log k_\pm(t)\in J,\qquad
 A_{Y(t)}(k_+(t))>0,\qquad A_{Y(t)}(k_-(t))<0.
 \tag{4.1}
\]

Here is the full existence argument. Ordinary PNT supplies a prime

\[
 q_-\in
 \left(\frac{e^{t-u_+}}2,\frac{e^{t-u_-}}2\right).
\]

The endpoints have a fixed ratio greater than one and tend to infinity,
so the interval contains a prime for all large `t`. Eventually
`q_->Y(t)` and `2q_-<=X(t)`. With `k_-=2q_-`, (3.1) gives
`A_Y(k_-)=-log2`.

For the positive coefficient, first choose a prime

\[
 2\sqrt B\,t<p<3\sqrt B\,t.
\]

PNT again permits this for every large `t`. Then choose a prime

\[
 q_+\in
 \left(\frac{e^{t-u_+}}{p^2},
       \frac{e^{t-u_-}}{p^2}\right).
\]

These endpoints also have a fixed ratio, and their lower endpoint tends
to infinity uniformly for the selected range of `p`. PNT therefore
supplies `q_+` for every large `t`, with no uniform short-interval
theorem beyond fixed-ratio PNT being invoked. Since `d=1/2048`,

\[
 \frac{q_+}{Y(t)}
 <\frac{Bt^2e^{-u_-}}{p^2}<\frac{e^d}4<1,
\]

while

\[
 \frac{pq_+}{Y(t)}
 >\frac{Bt^2e^{-u_+}}p
 >\frac{\sqrt B\,e^{-d}}3t>1
\]

eventually. Also `p<Y(t)`, `q_+>p`, and
`p^2q_+<=e^{t-u_-}<X(t)`. Thus all conditions (3.2) hold.
For `k_+=p^2q_+`, (3.3) gives `A_Y(k_+)=log p>0`, and both chosen
products land in the same prescribed sign interval of `h`.

Consequently the actual summands
`A_Y(k) h(t-log k)/sqrt(k)` in (2.2) have both signs at every
sufficiently large aperture. This is a native falsification of any
entrywise sign law proposed for the shortened arithmetic. It does not
show that their *complete sum* has either sign, nor does it falsify (CL).

## 5. Full signed window energy and the remaining quantitative gap

For clarity, the exact quadratic form associated with the shortened
sum can be written without losing any cross term. Fix a large `T0` and
`T>T0`. Extend each active summand by zero when its inequalities fail.
With `X(t),Y(t)` as above, define

\[
 \begin{split}
 J^{B,T}_{mn,\ell k}
 =\int_{T_0}^T &e^{-2\epsilon t}
 h(t-\log(mn))h(t-\log(\ell k))\\
 &\times1_{n>Y(t)}1_{k>Y(t)}\,dt.
 \end{split}\tag{5.1}
\]

Because `h` is compactly supported, only products at most `e^{T+d}`
contribute. Thus the following sums are finite and exactly equal:

\[
 \int_{T_0}^T e^{-2\epsilon t}|\mathcal L_B(t)|^2dt
 =\sum_{m,\ell\ge2}\frac{\log m\log\ell}{\sqrt{m\ell}}
   \sum_{n,k\ge1}\frac{\mu(n)\mu(k)}{\sqrt{nk}}
                  J^{B,T}_{mn,\ell k}.
 \tag{5.2}
\]

An active pair has `m,ell<B e^d T^2` and
`|log(mn/(ell k))|<=2d`. Each sharp long-divisor indicator remains
inside the integral because its threshold depends on `t`. This is a
native signed correlation over large integers with rational cofactor
ratios; it is not a sum of independent one-cofactor budgets. The full
Gram form is nonnegative by its definition, but this positivity supplies
no upper estimate. Nor does the identity `mu*1=delta1` separately
annihilate its two divisor thresholds.

One can quantify exactly what the present unconditional input gives.
Suppose the established native estimate used in Note01 is

\[
 |\theta(x)-x|\le Cx(\log x)^{B_0}e^{-c_0\sqrt{\log x}}.
\]

Then that note proves
`|F1(t)|<=C_h e^(t/2)t^B0 exp(-c0 sqrt(t))`. The remaining prime
powers are uniformly bounded pointwise: for squares, Chebyshev's
`theta(x)<=Cx` bounds

\[
 \sum_{e^{(t-d)/2}\le p\le e^{(t+d)/2}}\frac{\log p}{p}=O_d(1);
\]

for all exponents `j>=3`, the entire absolute sum

\[
 \sum_p\sum_{j\ge3}\frac{\log p}{p^{j/2}}
 \le\sum_p\frac{\log p\,p^{-3/2}}{1-p^{-1/2}}<\infty
\]

is available. These bounds use boundedness of `h` and imply
`F_{>=2}(t)=O_h(1)`. Hence (1.2) yields the actual native estimate

\[
 \boxed{|\mathcal L_B(t)|
 \le C_{h,B}\left(1+e^{t/2}t^{B_0}e^{-c_0\sqrt t}\right).}
 \tag{5.3}
\]

For `0<epsilon<1/2`, its full energy consequence is only

\[
 \boxed{\int_{T_0}^T e^{-2\epsilon t}|\mathcal L_B(t)|^2dt
 \le C_{\epsilon,h,B}
 \left(1+e^{(1-2\epsilon)T}T^{2B_0}e^{-2c_0\sqrt T}\right).}
 \tag{5.4}
\]

For `epsilon>=1/2` the same estimate does give a finite infinite
integral. The small dampings are exactly the unresolved case. At an
off-line zero `rho` with `Re rho>1/2+epsilon`, the audited dual-leakage
theorem forces a lower exponent `2Re rho-1-2epsilon`. The unconditional
upper exponent remains larger by `2(1-Re rho)>0`. Thus all the native
divisor identities used above coexist with the hypothetical leakage;
there is no contradiction from (5.4).

The inherited actual-input `mu^2` falsifier remains a further hard check:
it obeys the same cutoff and source-localization bound, but the short
sum grows like `P_r(i/2)^2 e^(t/2)/zeta(2)`. Its magnitude does not
control the genuine signed square (5.2). The new native theorem is
stronger than merely invoking that altered-sign model: actual Möbius
coefficients already give both local product signs as proved above.

## 6. Export and validation

**New arithmetic result.** All long-divisor prime-power coefficients
vanish, and positive and negative composite coefficients occur in every
sufficiently late active fixed-source window. This describes exactly
where the unchanged output resides after the quantitative localization.
It narrows the candidate closing law to a genuinely signed composite
correlation; it supplies no unproved correlation estimate.

**To B and C.** The same localized function carries B's native leakage
and, through the independently audited contact adapter, C's delayed
defect. Neither a support delay nor a small cofactor count changes the
native opposite-sign conclusion. Any successful upper law must control
the complete correlation (5.2), including products with repeated prime
factors, while using the exact original source and all completion terms.

The finite checker tests the exact support and divisor-sign formulas on
bounded native integers, including the neighboring active products
`19^2*277=99997` and `2*49999=99998`. It does not evaluate the actual
detector at those points, infer an eventual asymptotic from this sample,
or assert that the sample chooses the source-dependent admissible `B`.
The universal window assertion above is PAPER, proved from ordinary
PNT and exact divisibility. No new Lean declaration has been made.
