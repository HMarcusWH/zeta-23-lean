# Joint campaign Path A paper results: complete small-divisor cancellation and native rough-core signs

Date: 13 October 2026. Status: **PAPER / DERIVED, not formalized.**

This note proves exact finite identities for the actual shortened arithmetic. It also gives a precise limitation on a termwise absolute-value estimate: native positive and negative coefficient budgets are both exponentially large, even among squarefree products that survive the adaptive sieve.

## 1. Exact squarefree-core identity

For \(k\ge1\), \(Y>0\), and \(R=k/Y\), let

\[
A_Y(k)=\sum_{\substack{n\mid k\\n>Y}}\mu(n)\log(k/n).
\tag{1}
\]

Write \(r=\operatorname{rad}(k)\), \(q=k/r\). Any nonzero Möbius divisor \(n\) divides \(r\), so write \(n=r/d\), \(d\mid r\). Then

\[
\mu(r/d)=\mu(r)\mu(d),\qquad k/n=qd,\qquad n>Y\iff qd<R.
\]

Consequently

\[
\boxed{
A_Y(k)=\mu(r)\sum_{\substack{d\mid r\\qd<R}}
\mu(d)\log(qd).
}
\tag{2}
\]

The strict inequality is part of the identity. In particular a nonzero coefficient requires \(k/\operatorname{rad}(k)<R\). It also requires that \(k\) have a prime divisor below \(R\): when \(q>1\), this follows from a prime divisor of \(q<R\); when \(q=1\), the \(d=1\) term is zero, so a contributing \(d>1\) contains such a prime.

## 2. A complete-small-divisor cancellation theorem

Suppose \(k=ab\), \((a,b)=1\), and every prime factor of \(b\) is at least \(R=k/Y\). A divisor \(m\mid k\) with \(m<R\) cannot contain any prime of \(b\), and hence divides \(a\). Reindexing \(m=k/n\) yields

\[
\boxed{
A_Y(k)=\mu(b)
\sum_{\substack{m\mid a\\m<R}}\mu(a/m)\log m.
}
\tag{3}
\]

This remains valid when \(b\) is not squarefree: its Möbius factor is then zero, as is every eligible \(\mu(k/m)\).

If also \(a<R\), every divisor of \(a\) is included. The exact identity \(\mu*\log=\Lambda\) gives

\[
\boxed{A_Y(ab)=\mu(b)\Lambda(a).}
\tag{4}
\]

Thus an entirely included small part with at least two distinct prime factors cancels exactly. A prime-power small part leaves the sign of the actual rough core. If \(a=1\), the coefficient is zero.

One useful canonical choice is to let \(a\) be the complete prime-power part of \(k\) made from primes below \(R\), and \(b\) the remaining part. Another is the full \(L\)-smooth part with \(L\ge R\). Formula (3) is valid in either case; formula (4) requires the additional strict condition \(a<R\).

### Why the boundary condition cannot be removed

Take \(k=42\), \(a=6\), \(b=7\), \(Y=7\), so \(R=6=a\). The allowed squarefree divisors above \(Y\) are \(14,21,42\), and

\[
A_7(42)=\log3+\log2=\log6.
\]

Yet \(\mu(7)\Lambda(6)=0\). The divisor \(m=6\), corresponding to \(n=7=Y\), is excluded by the strict long-divisor cutoff. If \(Y\) is decreased slightly below \(7\), that term enters and cancels \(\log6\). This explicit seam shows why complete-divisor cancellation cannot be asserted on the cutoff boundary.

## 3. Both signs on squarefree integers in every late detector window

Use the original detector support \([-d,d]\). Let \(P(t)\equiv1\) for the original A03 localization, or let \(P(t)\) be the primorial choice of Note 04. In either case put

\[
x=e^t,\qquad
Y=\frac{x}{BP(t)t^2},\qquad
L=BP(t)e^dt^2.
\tag{5}
\]

The argument below also works for any squarefree \(P(t)\) with \(\log P(t)=o(t)\). Then \(L=e^{o(t)}\), \(L\to\infty\), and \(x/L^2\to\infty\).

Fix a nonempty open interval \(J=(u_-,u_+)\) with closure inside \((-d,d)\), on which \(h\) has one nonzero sign. By shrinking it if necessary, assume \(|h(u)|\ge h_J>0\) throughout \(J\). Products in its active window satisfy

\[
xe^{-u_+}<k<xe^{-u_-},\qquad
BP(t)t^2e^{-u_+}<R=k/Y<L.
\tag{6}
\]

In particular \(R>2\) eventually.

### Negative coefficient

Fixed-ratio PNT gives a prime

\[
q_-\in(xe^{-u_+}/2,\;xe^{-u_-}/2)
\]

for every sufficiently large \(t\). Set \(k_-=2q_-\). The rough prime \(q_-\) is greater than \(L\), while \(2<R\). Formula (4), with \(a=2\), \(b=q_-\), gives

\[
\boxed{A_Y(k_-)=-\log2.}
\tag{7}
\]

### Positive coefficient on another squarefree product

Choose a prime \(p\in[2L,4L]\), and then choose a prime

\[
q_+\in(xe^{-u_+}/(2p),\;xe^{-u_-}/(2p)).
\]

These prime choices exist for every sufficiently large \(t\). The second application of PNT is uniform over the selected \(p\) range: its interval has a fixed ratio, its lower endpoint is bounded below by a fixed multiple of \(x/L\to\infty\), and \(\log(x/p)\sim t\). It is not an invocation of a shrinking relative interval.

Eventually \(q_+>4L\), so \(2,p,q_+\) are distinct. With \(k_+=2pq_+\), the factorization \(a=2\), \(b=pq_+\) meets all hypotheses of (4). Hence

\[
\boxed{A_Y(k_+)=+\log2.}
\tag{8}
\]

Both examples are squarefree. This strengthens the inherited A03 positive family involving a repeated small prime.

For the adaptive mask, \(p,q_+,q_->P(t)\), so none of those primes divides \(P(t)\). At most the prime \(2\) is selected. Consequently \(w_{P(t)}(k_-)=w_{P(t)}(k_+)=1\), and neither sign is removed by that mask. Their full \(L\)-rough cores equal \(k_\pm/2\), so they also survive every small-core cutoff \(b_L(k)\le e^{\theta t}\) with fixed \(\theta<1\).

## 4. A quantitative obstruction to termwise absolute values

Define the two actual coefficient budgets in the fixed source window:

\[
\begin{split}
\mathcal M_+(t)
&=\sum_{\substack{t-\log k\in J\\A_Y(k)>0}}
\frac{A_Y(k)}{\sqrt k}|h(t-\log k)|\,w_P(k),\\
\mathcal M_-(t)
&=\sum_{\substack{t-\log k\in J\\A_Y(k)<0}}
\frac{-A_Y(k)}{\sqrt k}|h(t-\log k)|\,w_P(k).
\end{split}
\tag{9}
\]

For the original sum use \(w_P\equiv1\). If \(h\) is negative on \(J\), the roles of these two budgets as positive or negative summands of the field are simply interchanged.

PNT gives at least \(c_Jx/t\) primes \(q_-\) in the first interval. Each corresponding term has magnitude at least a fixed positive constant times \(x^{-1/2}\). Therefore

\[
\boxed{\mathcal M_-(t)\ge c\,e^{t/2}/t.}
\tag{10}
\]

There are at least \(cL/\log L\) primes \(p\in[2L,4L]\). For each such \(p\), the \(q_+\) interval contains at least \(c_Jx/(Lt)\) primes, uniformly for all sufficiently large \(t\). Each resulting \(k=2pq_+\) is counted once: it has exactly one prime factor in \([2L,4L]\), because \(q_+>4L\). Hence at least \(c_Jx/(t\log L)\) distinct products yield the positive coefficient in (8), and

\[
\boxed{\mathcal M_+(t)\ge c\,e^{t/2}/(t\log L(t)).}
\tag{11}
\]

For the original cutoff, or the concrete adaptive cutoff \(P(t)\le\log(t+2)\), \(\log L(t)\asymp\log t\). Both budgets therefore have exponential rate \(1/2\), up to the displayed logarithmic factors.

These are lower bounds on the sums of magnitudes in the native shortened arithmetic. They imply that its termwise absolute-value majorant cannot belong to every positively damped \(L^2\) space: it fails for every \(0<\epsilon<1/2\). They do **not** give a lower bound on the absolute value of the complete signed field, and do not falsify the desired signed \(L^2\) estimate.

The result is a specified limitation of a specified estimate. The phrase “parity of the rough core,” if used descriptively, refers only to the exact signs \(\mu(q)=-1\) and \(\mu(pq)=+1\) in these formulas. No general no-go theorem for sieve methods is asserted.

## 5. What remains after the exact cancellation

Formula (3) leaves either an incomplete small-divisor boundary or a complete small prime-power factor multiplied by the genuine rough-core Möbius sign. The examples and magnitude bounds above show that both signs remain quantitatively significant after the adaptive mask and the separately proved smooth-sector removal.

The missing input is an upper bound for their complete signed, smoothed superposition, including correlations between different short cofactors. The finite identity does not turn those signs into independent random variables, and it does not justify discarding mixed terms.

## Source record

- A03 new/arithmetic/05_native_composite_support_and_signed_window_obstruction.md, Sections 1–4: exact \(A_Y(k)\), prime-power disappearance, and the inherited sign test using a repeated prime.
- The identities (2)–(4), the squarefree positive family, the source-window magnitude bounds, and their compatibility with the new sieve are derived here.
- The only prime-distribution fact used in Sections 3–4 is the ordinary fixed-ratio consequence of PNT already used by the inherited A03 note. Sections 1–2 are finite elementary identities.
