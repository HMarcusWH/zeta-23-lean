# A03: the exact native drive reduces the remaining inverse to log-squared cofactors

**Status: PAPER / DERIVED.** This result was developed jointly by the root
researcher and the arithmetic branch, using and independently checking the
recovered original fixed-detector construction. It is not a Lean theorem.
No repository source has been changed. It does not prove the remaining
signed arithmetic upper bound.

## 1. Exact source authority and the prospective closing step

The actual fixed source uses

\[
 c_j=\frac{r}{j(j+1)},\quad
 q_r=*_{j\ge1}\frac{1_{[-c_j,c_j]}}{2c_j},\quad
 k_r=q_r''-\tfrac14q_r,\quad h=k_r*k_r,
 \quad r=1/4096.
 \tag{1.1}
\]

These are **not** the dyadic widths of C's different contact probe. The
recovered original source is
`source_recovery/c20a78ef1eae_01_single_universal_detector.md`, Sections1
and3. It proves the Fourier and derivative estimates

\[
 |P_r(z)|\le2e^{r|\Im z|}e^{-c\sqrt{r|z|}},
 \qquad
 \|q_r^{(j)}\|_\infty\le
 \frac{4(2j+1)!}{\pi c^{2j+2}r^{j+1}},
 \quad c=\tfrac12\log2.
 \tag{1.2}
\]

Thus this exact source is Gevrey of order2. The prospective arithmetic
mechanism is to exploit the *quantitative* native lattice cancellation in

\[
 U(t)=\sum_{m\ge1}\frac{\log m}{\sqrt m}h(t-\log m),
 \quad F=M_\mu*U,
\]

before taking a norm or estimating genuine Möbius signs. The objective is
to remove a large part of the inverse independently, leaving an exact
source-specific signed sum substantially shorter in one arithmetic
variable. It is not an attempt to uniformly bound finite Euler inverses.

## 2. Gevrey estimates survive the exact logarithmic change of variable

Equation (1.2), fixed differentiation, and compact convolution imply

\[
 \|h^{(j)}\|_\infty\le A H^j(j!)^2\quad(j\ge0)
 \tag{2.1}
\]

for some finite constants `A,H>0` depending only on the unchanged source.
For example `(2j+1)!/(j!)^2` has at most exponential growth times a
polynomial in `j`, which is absorbed by increasing `H`; the finite two
derivatives in `k_r` are handled in the same way.

Define two fixed compact functions, extended by zero outside their
support in `[e^{-d},e^d]`:

\[
 a(y)=y^{-1/2}h(-\log y),\qquad b(y)=(\log y)a(y).
 \tag{2.2}
\]

They too satisfy `L1` derivative bounds `A_1 H_1^j(j!)^2`. Here is an
elementary proof that does not assume a generic composition theorem.
With `D` denoting differentiation of `h`'s argument,

\[
 \partial_y^j[y^{-1/2}h(-\log y)]
 =y^{-j-1/2}Q_j(D)h(-\log y),
 \quad Q_j(D)=\prod_{\ell=0}^{j-1}(-D-\ell-1/2).
 \tag{2.3}
\]

If `Q_j(D)=sum_k q_{j,k}D^k`, put
`A_j=sum_k |q_{j,k}|H^k(k!)^2`. The product recurrence gives

\[
 A_{j+1}\le[H(j+1)^2+j+1/2]A_j
          \le(H+1)(j+1)^2 A_j.
\]

Hence `A_j<=(H+1)^j(j!)^2`. The bounded support of `y` absorbs the
factor `y^{-j-1/2}` into another exponential constant. Multiplication by
`log y` uses Leibniz's rule and the analytic derivative bounds for that
function on a compact interval bounded away from0, giving the same
Gevrey order for `b`. Smooth flatness at the support endpoints makes the
zero extensions legitimate, without endpoint distributions.

Consequently, for the Fourier convention
`widehat a(xi)=int a(y)exp(-2pi i xi y)dy`, repeated integration by parts
and choosing `j` proportional to `sqrt(|xi|)` give constants `A_2,k>0`
such that

\[
 |\widehat a(\xi)|+|\widehat b(\xi)|
 \le A_2e^{-k\sqrt{|\xi|}}.\tag{2.4}
\]

Explicitly, the integration-by-parts bound is
`A_1 H_1^j(j!)^2/(2pi|xi|)^j`; use `j!<=j^j` and
`j=floor(sqrt(pi|xi|/(2H_1)))` for sufficiently large frequency.
The remaining bounded interval is covered by increasing `A_2`.

## 3. A quantitative double-exponential bound for the actual integer input

For fixed `t`, extend

\[
 g_t(x)=(\log x)x^{-1/2}h(t-\log x)\quad(x>0)
\]

by zero for `x<=0`. It is smooth with compact positive support. Scaling
`x=e^t y` gives

\[
 g_t(e^t y)=e^{-t/2}[t a(y)+b(y)],
 \quad
 \widehat g_t(\ell)=e^{t/2}
       [t\widehat a(\ell e^t)+\widehat b(\ell e^t)].
 \tag{3.1}
\]

The zero Fourier mode is exactly

\[
 \widehat g_t(0)=e^{t/2}[tK(1/2)+K'(1/2)]=0.\tag{3.2}
\]

Poisson summation is valid for each of these compact smooth functions.
Using (2.4) on its nonzero frequencies gives

\[
 |U(t)|\le C(1+t)e^{t/2}
                 \sum_{\ell\ge1}e^{-k e^{t/2}\sqrt\ell}.
 \tag{3.3}
\]

For `Q>=1`, comparison with the integral of `exp(-Q sqrt(x))` gives
`sum_{ell>=1} exp(-Q sqrt(ell))<=5 exp(-Q)`. Absorbing the remaining
polynomial/exponential prefactor into half of this much faster exponent,
and increasing the constant on a fixed initial interval, proves:

### Theorem A3-G2

For the exact native input there exist source-dependent constants `C,kappa>0`
such that

\[
 \boxed{|U(t)|\le C\exp(-\kappa e^{t/2})\qquad(t\ge0).}\tag{3.4}
\]

`U` vanishes before `t0=log2-d>0`. No numerical value of `kappa` is
asserted here. It is obtained from finite constants in the preceding
Gevrey estimates, not from RH or any unknown zero-free region. This is a
quantitative strengthening of the inherited all-orders exponential decay.

## 4. Exact removal of all smaller Möbius divisors

Fix `B>0` and, for `t>0`, let

\[
 Y_B(t)=\frac{e^t}{Bt^2},\qquad
 F_{\mathrm{small},B}(t)
 =\sum_{n\le Y_B(t)}\frac{\mu(n)}{\sqrt n}U(t-\log n).
 \tag{4.1}
\]

When `Y_B(t)<1` the sum is zero. For large `t`, each included argument
satisfies `e^{(t-log n)/2}>=sqrt(B)t`. By (3.4) and the elementary
bound `sum_{n<=Y}n^{-1/2}<=2 sqrt(Y)`,

\[
 \boxed{|F_{\mathrm{small},B}(t)|
 \le\frac{2C}{\sqrt B\,t}
       \exp\{-(\kappa\sqrt B-1/2)t\}.}\tag{4.2}
\]

All arithmetic signs remain genuine; only this discarded portion has
been bounded using `|mu|<=1`. If `kappa sqrt(B)>1/2`, this part decays
exponentially and belongs to every positively damped `L2` space. For any
prescribed `A>0`, choosing a larger fixed `B` makes it `O(exp(-At))`.
The choice of `B` may depend on the requested decay rate. A single fixed
`B` is not claimed to provide every possible rate.

Alternatively, with cutoff `Y_eta(t)=e^t/t^{2+eta}`, any fixed `eta>0`
gives

\[
 |F_{\mathrm{small},\eta}(t)|
 \le C e^{t/2}t^{-1-\eta/2}
               e^{-\kappa t^{1+\eta/2}}
 =O_A(e^{-At})\quad\text{for every fixed }A>0.
 \tag{4.3}
\]

The logarithmic cutoff is time-dependent. These are exact pointwise
finite sums and bounds; no interchange with an infinite norm or a
finite-Euler-product limit has been used.

## 5. The surviving arithmetic has only log-squared cofactors

The remaining part is exactly

\[
 F_{\mathrm{long},B}(t)
 =\sum_{n>Y_B(t)}\frac{\mu(n)}{\sqrt n}U(t-\log n).
\]

Expand the *actual* integer input before taking any limit. Because `h`
is supported in `[-d,d]`, every active product satisfies `nm<=e^{t+d}`.
Since `n>Y_B(t)`, its cofactor obeys `m<B e^d t^2`. Consequently

\[
 \boxed{
 F(t)=
 \sum_{2\le m<B e^d t^2}\frac{\log m}{\sqrt m}
 \sum_{\substack{n>e^t/(Bt^2)\\ nm\le e^{t+d}}}
 \frac{\mu(n)}{\sqrt n}h(t-\log m-\log n)
 +F_{\mathrm{small},B}(t).
 }\tag{5.1}
\]

Both sums are finite. The inner lower cutoff is load-bearing. It cannot
be removed independently for each `m`: doing so restores large terms
whose collective cancellation was precisely used to prove (4.2).
The equality includes *all* prime powers automatically, through
`mu*log=Lambda`; no first-prime approximation has replaced this divisor
sum. Source, Fourier convention, support, and native signs are unchanged.

For any single fixed `B` with `kappa sqrt(B)>1/2`, bounding the weighted
norm of the displayed bilinear sum would bound the actual output, since
the discarded remainder is independently in every required weighted
space. What has been gained is a short, explicit cofactor range
`m=O((log x)^2)` at `x=e^t`; no estimate for its remaining genuine signed
Möbius correlations has yet been proved.

If the A02/B03 dual composition holds, its conditional exponential lower
bound transfers to this bilinear sum by the weighted triangle inequality.
Thus an actual off-line zero's forced energy cannot reside in the part
already removed in (4.2). This is a valid consequence about the exact
arithmetic source, not a substitution of a contact or dilating K2 source.

## 6. Hard check: the localization does not cancel a coherent inverse pole

A particularly tempting next step would be to assert that the short
cofactor range or the rapid input automatically destroys an off-line
Möbius mode. The exact calculation goes in the opposite direction.

Suppose, conditionally, that a native zero has coordinate `lambda=rho-1/2`
and multiplicity `m>=1`. Write the principal part of `1/zeta(p+1/2)` at
`lambda` as

\[
 \sum_{j=1}^m\frac{A_j}{(p-\lambda)^j},
 \qquad A_m=\frac{m!}{\zeta^{(m)}(\rho)}.
\]

Its elementary inverse-Laplace mode is

\[
 v_\lambda(t)=1_{t\ge0}e^{\lambda t}
             \sum_{j=1}^m\frac{A_jt^{j-1}}{(j-1)!}.
 \tag{6.1}
\]

This is a diagnostic mode calculation; it is **not** an assertion that
the atomic native Möbius measure has a pointwise decomposition into
(6.1) plus a bounded remainder. For the actual rapid `U`, its transform
is entire and

\[
 \widehat U(p)=-\zeta'(p+1/2)K(p),
\]

by identity continuation from the safe half-plane. Thus

\[
 \widehat U^{(k)}(\lambda)=0\ (k<m-1),\qquad
 \widehat U^{(m-1)}(\lambda)
 =-\zeta^{(m)}(\rho)K(\lambda).
 \tag{6.2}
\]

Convolving (6.1) with `U`, and replacing the upper limit by infinity
using (3.4), gives a finite polynomial whose coefficients are the
derivatives in (6.2). Every nonconstant coefficient vanishes, while the
constant equals

\[
 \frac{A_m}{(m-1)!}\widehat U^{(m-1)}(\lambda)
 =-mK(\lambda).
\]

Therefore

\[
 (v_\lambda*U)(t)=-mK(\lambda)e^{\lambda t}
                   +O_A(e^{-At})\quad\text{for every fixed }A>0.
 \tag{6.3}
\]

There is no missing factorial. Universal off-line visibility makes this
coefficient nonzero.

The very same cutoff as (5.1) restricts the convolution's source variable
to `0<=s<min(t,log(Bt^2))`; eventually `log(Bt^2)<t`, which is the tail
used here. Its omitted tail is bounded by the double-exponential
decay in (3.4). For any fixed `B` satisfying `kappa sqrt(B)>1/2`, and any
fixed native right-strip coordinate `0<Re lambda<1/2`, choose
`kappa1<kappa` with `kappa1 sqrt(B)>1/2`. The omitted mode tail is at most
a fixed polynomial in `t` times

\[
 e^{\Re\lambda t-\kappa_1\sqrt B\,t},
\]

and therefore decreases exponentially. With `B` enlarged, it decreases
at any prescribed fixed rate. Thus the short-cofactor restriction
retains, rather than annihilates, the exact surviving residue
`-mK(lambda)`.

This falsifies the proposed *automatic mode cancellation* mechanism.
The remaining successful theorem must use a new law of the actual
atomic Möbius signs to exclude the coherent mode in the first place.
The rapid input and source-dependent short range do not do that alone.

## 7. Research disposition

New native information: Gevrey2 quantitative Poisson cancellation makes
all inverse indices below `x/(B(log x)^2)` a separately controlled
remainder. The original all-orders decay alone gave no such uniform
log-squared cutoff. The remaining sum (5.1) is an exact native bilinear
object with only `O((log x)^2)` possible cofactors and no changed source.

Attempted closing argument: exploit that short range to eliminate a
hypothetical off-line inverse mode through the same zero-neutral
arithmetic input. Exact calculation (6.1)--(6.3) shows the mode survives
with the required native residue; that step fails rigorously. Absolute
values, generic positive kernels, or a finite-Euler norm are not a
repair. An independent bound for the signed short-cofactor sum remains
OPEN. No generic request for a prime error estimate replaces its exact
definition. No formal post-green promotion is applicable.
