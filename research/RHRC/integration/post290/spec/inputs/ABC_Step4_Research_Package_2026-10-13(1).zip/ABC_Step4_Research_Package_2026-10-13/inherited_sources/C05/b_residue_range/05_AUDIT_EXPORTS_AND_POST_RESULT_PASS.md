# C05 / round four — B integration, internal review, exports, and post-result pass

**Branch:** `/root/round4_b_residue_range`.
**Status:** new infinite-domain conclusions are DERIVED / PAPER. Exact finite algebra has its own receipt. No Lean compilation, repository source edit, push, PR, merge, or claim promotion occurred in this branch. **RH remains OPEN.**

## 1. Focused input coverage and source authority

The current cross-path analysis and full A+B quantitative dual-leakage proof were read before original work. The complete ten mathematical proof notes of B03 were then read, at their actual source bodies:

| B03 directory | Complete mathematical notes read | Main audited boundary |
|---|---|---|
| `proofs/root` | `01_NATIVE_POSITIVE_FORWARD_KERNEL_AND_RANGE_DEFECT.md`; `02_SAME_INPUT_POSITIVE_KERNEL_CONTROL.md` | Actual causal integer convolution and specific input; positivity does not give inverse membership |
| `proofs/contact` | `01_X2_DELTA_AUDIT_AND_FINITE_REGULARITY.md`; `02_COMPANION_POLE_NEUTRALITY_AND_STRATUM_OBSTRUCTION.md`; `03_COUPLED_CAUSAL_COMPANION_CONTROL_AND_BLINDNESS.md` | Finite source derivatives, low-nullity rank, exact coupled residue cancellation |
| `proofs/coupled` | `01_FULL_COMPLETION_CAUSAL_SEMIGROUP.md`; `02_CONTACT_COUPLED_ENERGY_AND_EXTERIOR_PORT.md`; `03_NATIVE_BOUNDARY_GENERATOR_DOMAIN.md` | Internal evolution parameter differs from physical exterior time; actual boundary generator domain is restrictive |
| `proofs/authority` | `01_QUANTITATIVE_CONTACT_ASYMPTOTIC_AND_COMPACT_UNIQUENESS.md`; `02_COMPACT_POSITIVE_TOWER_FLAT_CONTROL.md` | Exponential compact comparison has a valid domain, while native logarithmic derivative is outside every exact finite compact quotient class |

The B03 root overview, complete post-green pass, root/contact/authority independent review notes, authority delta-coverage note, authority post-green pass, and final export ledger were also read in full. The earlier B2 exact-contact/far-prime proof was read at `imports/B_ROUND2/bc_null_state/02_EXACT_CONTACT_AND_NATIVE_TAIL_RESIDUAL.md`. This is a focused audit of the supplied new proofs and their necessary historical argument, not an assertion that every nested historical certificate was independently replayed.

The A branch separately read the complete A02 mathematical package. In this branch, its four new full proofs were independently read: the explicit all-nullity causal exterior map, optimal centered-jet leakage, exact cumulative horizon exponent, and renormalized native jump-flux failure. The A02 prime-pair budget source was also read directly to check the later zero-damping extension. Its exact source is B's unchanged detector, not A's dilating K2 vector.

The authority branch handles the fresh live repository declarations, tested objects, axiom panels and CI; the B03 snapshot is historical. The native full contact, polynomial classification, maximal domain, causal companion and absolute native sampling remain their stated PAPER imports. Nothing about new paper contact sources is inferred from current finite-state compiler interfaces.

Two official primary-reference checks were made for classical analytical inputs: NIST DLMF 25.10(i), `https://dlmf.nist.gov/25.10#i`, for the unconditional zero-free line \(\Re s=1\), and DLMF 5.11.2, `https://dlmf.nist.gov/5.11#E2`, for the fixed-sector digamma expansion. The proofs use only the precise consequences stated in Notes 01 and 02, not a stronger zero-free region or an unquantified variable-order asymptotic.

## 2. Source transformations reconciled

Put \(\lambda=\rho-1/2\), \(\gamma=-i\lambda\), and \(c_0(p)=(p-1/2)/[(p+1/2)(p+1)]\). The Fourier convention is \(F_f(z)=\int f(x)e^{-izx}dx\). The table records the actual coefficient of the highest nonzero input jet, rather than moving a residue between different sources.

| Source/output | Actual causal adjustment | Highest input jet at multiplicity \(m\) |
|---|---|---|
| B03 original fixed prime output \(F_B\) | none; already causal | \(-c_0(\lambda)K_B(\lambda)\zeta^{(m)}(\rho)\) |
| A02 polarized prime output \(F_b\) | common delay \(c=a+b+1\) | \(-c_0(\lambda)e^{-c\lambda}K_b(\lambda)\zeta^{(m)}(\rho)\) |
| Original C exterior \(v(s)=(W*f_0)(a+s)\) | original right-boundary origin; compact sources shifted by \(a\), their combined input advanced by \(2a\) | \(+c_0(\lambda)e^{a\lambda}G(-i\lambda)\zeta^{(m)}(\rho)\) |

Every coefficient is nonzero under its own stated off-line visibility proof. No extra \(m\) or factorial appears in these \((m-1)\)-st input derivatives. The simple pole of the corresponding output retains its multiplicity factor, as detailed in Note 03.

The direct C input theorem uses the original finite-regularity null generator. It works for \(r=1,2\) as well as higher nullities. It does not create a smooth pole-neutral null vector, contradict the low-nullity positive constrained collar, or move a witness into a smaller legal finite carrier. The A02 source is instead smooth and polarized; its causal adapter is a separate useful map whose transfer is nonzero on every off-line residue.

## 3. New mathematical output of this branch

| Note | New theorem or complete failed construction | What it makes possible |
|---|---|---|
| 01 | The exact completed forward kernel \(q_N=a_N*W_+\) lies in exponentially weighted \(L^1\cap L^2\) for every strict decay rate below \(1/2\); weighted fractional Sobolev regularity of the exact integer staircase is proved | Constructs an actual stable input for the **unchanged original C exterior** in every nullity, using the complete integer, gamma and elementary-pole identities |
| 01 | The full native FE gives \(\mathsf A^*\mathsf Q+\mathsf Q^*\mathsf A=0\) on actual causal \(L^2\) | An exact global bounded-operator relation; its signed nature and input domain are explicit |
| 02 | Positive prime-base controls with consistent weights at all powers plant a prescribed exact complex pole while leaving all local sources unchanged | Classifies all universally stable finite local observations as a complete analytic source-annihilator module; finite Laplace jets cannot repair that class |
| 03 | A complete finite pole/jet Gram theorem gives the exact least possible leakage norm \(d^*\Gamma^{-1}d\) | Combines genuinely different visible zeros and all their lower vanishing jets; yields the optimal single-zero constant and stronger conjugate-pair estimate |
| 04 | Explicit stable native kernels are nonzero on every specified off-line residue; the actual finite-horizon FE flux retains its full future pairing | Identifies the exact distinction between a bounded filter and an unproved bound on its actual exterior output; rules out dropping the future or damping terms |

The original contact input is now a concrete function,
\[
y_f(s)=[q_N*T_af_0+a_N*T_a(-Tf_0)](s+2a),
\]
whose pre-origin part cancels by the actual contact identity. It satisfies
\[
a_N*v=y_f,
\qquad e^{\tau s}y_f\in L^2(0,\infty)
\quad(0\le\tau<1/2).
\]
This is stronger domain information than the prior general cardinal/range statement. It does not solve the inverse problem, because multiplication by \(A_N\) removes the native zero pole before the stable input is obtained.

The single-zero leakage bound, for \(\delta=\Re\lambda-\epsilon>0\), is
\[
\|e_T\|_2\ge
\frac{|c_{\lambda,m}|(2\delta)^{m-1/2}}{(m-1)!}
e^{\delta T}.
\]
It holds for every horizon and has no multiplicity-dependent power of \(T\). The A branch's monic Laguerre proof and the authority branch's stable causal zero-deflation proof independently confirm that no polynomial horizon loss is necessary. These are internal corroborations, not external peer review.

## 4. Independent mathematical reviews and finite validation

The completed native kernel proof was independently read by both other branches. Their checks covered the actual integer jump spacing cutoff, fractional zero-extension norm, logarithmic multiplier and causal approximation, exact gamma and rational constants, source advance, companion sign and highest input jet. The requested explicit support-preserving approximation and weighted \(L^1\) corollary have been incorporated.

The authority branch independently checked the entire syzygy proof: positive and power-consistent weights, exact planted residue \(-\sigma\), two-sign difference, identity theorem and finite-jet induction. It requested one scope clarification for a separately stable offset of different Sobolev order; the sufficiency statement now uses \(H^{-\max(k,k_E(\epsilon))}\). Its inverse-Gram and conjugate-pair audit passed without correction, including all three source phases and multiplicity constants. Its Note 04 audit also passed the two stable-filter residues, derivative-input cancellation, finite-horizon future pairing and shifted-line Fourier factor; the requested almost-everywhere and Fourier-normalization clarifications have been incorporated.

This branch independently reviewed A's four new proofs. The compact causal adapter, both parities, elementary double zeros, support intervals, local silence, source shift and full gamma remainder are consistent. Its centered Laguerre norm agrees with the independently computed Gram inverse. The actual horizon-limit proof fixes one visible zero at a time for the lower bound and one damping above the spectral abscissa for the upper bound; it does not require an attained rightmost zero or uniform constants. The jump renormalization cancels every late diagonal contribution exactly, while the moving-probe estimate retains only the \(e^{t/2}\) scale. A minor LaTeX delimiter typo in the horizon note was reported, corrected and rechecked; it was not a mathematical gap.

The authority branch's complete stable zero-deflation proof, including its weighted-\(L^2\) addendum for the original C input, was read and checked. The future-tail representation has sign \((-1)^k\), the moment cancellation is exact, and the addendum's norm factor is \((\Re\lambda+\tau)^{-k}\). It does not assert that the growing deflation kernel is a bounded filter on arbitrary inputs.

Both new root controls were read completely. The native failure of arbitrary positive convolution roots has a valid signed logarithmic-generator measure, negative on \((\log2,\log3)\); the compactness and Laplace uniqueness argument proves precisely the claimed obstruction without assuming RH. The exact positive FE/scattering control has the stated causal derivative boundary term, positive envelope, stable completed kernel and genuine quartet. Its necessary quartic inequality is violated by \(-135/4\), and numerator cancellation is excluded by the simple roots of \(X\). Both controls pass at their stated scopes.

`verify_round4_b_algebra.py` completed **60 exact finite checks** in SymPy 1.14.0. They cover the rational completion identity, actual input jets for multiplicities 1 through 7, finite Gram inverse constants, conjugate-pair algebra, derivative-observation grouping, and source-shift exponents. The JSON receipt identifies the script hash and every check. It does **not** certify infinite sums, Sobolev domains, causal distribution continuity, zero-free lines, or RH. No local Lean build was performed.

## 5. One precise native coupling still missing

For the actual input constructed above, the smallest current range target is
\[
\boxed{
\forall\epsilon>0:\qquad
e^{-\epsilon\cdot}y_f\in
\overline{\operatorname{Ran}\mathsf A_\epsilon},
\qquad
\mathsf A_\epsilon g=(e^{-\epsilon\cdot}a_N)*g.
}
\tag{OPEN-C05}
\]
It is **OPEN**, not an imported hypothesis. At a hypothetical native zero with \(\Re\lambda>\epsilon\), the proved adjoint functional evaluates to
\[
c_0(\lambda)e^{a\lambda}G(-i\lambda)\zeta^{(m)}(\rho)\ne0,
\]
so it annihilates the closed range but not this input. An independently proved (OPEN-C05) would therefore contradict that zero, at the original source and every nullity.

An all-positive-damping bound for the original exterior, a suitable residue-sensitive output estimate from Note 04, or a vanishing exponential horizon rate are alternative sufficient expressions of the unresolved native control. Their equivalences or implications do not supply additional independent premises.

The new exact global integer/completion identity proves stability only after the zero-bearing forward factor. The local syzygy classification proves that local-only observations stable on all the controls remove the entire native logarithmic derivative. The signed global FE pair admits the explicit unstable positive-kernel control. The natural positive native jump form loses the residue when renormalized, while its unrenormalized diagonal diverges. None of these can furnish (OPEN-C05) as currently proved.

## 6. Full post-result research pass

### What became formally true

Nothing new became Lean-PROVED in this branch. The new analytic theorems are PAPER; the finite symbolic receipt checks only the listed identities. The separate live compiler audit is evidence about its actual tested tree and declarations, not about these sources.

### What changed

The unchanged C exterior now has a directly constructed native stable forward input. The exact global completion supplies a bounded lossless pair, which was actively tested as a possible recovery mechanism and falsified at its abstract scope. The finite-pole leakage is quantitatively sharp, and the stable local observation class has a proved annihilator classification.

### Upstream implications

The exact \(N*\Pi=tN\) identity, rational elementary factors, true archimedean half and maximal source domain are load-bearing. Finite regularity suffices for the original input construction; no Gevrey null source, pole-neutral null vector, changed aperture, unrestricted derivative, or transported detector depth is required. The phase \(e^{a\lambda}\) and companion sign must remain attached to the original exterior.

### Downstream implications

Every hypothetical visible right zero forces pure exponential every-large-horizon growth of the unchanged exterior. Any proposed approximation to the actual forward input must pass the full finite jet Gram obstruction, not merely agree on each initial interval. Combining multiple zeros increases the exact lower constraint where its Gram matrix is well conditioned; no infinite frame or infinite-index consequence is inferred.

### Resurrected routes

A source-specific global range or approximation theorem can now work directly with \(f_0\) in all nullities. The smooth polarized route remains an independent exact adapter to the prime/Möbius output. No route below terminal K2, no compact native logarithmic quotient, and no generic positive inverse or positive convolution semigroup is revived.

### New RH-relevant information

Stable residue-sensitive native filters exist explicitly, but their action on the actual exterior is the missing estimate. The global FE controls only the signed full pairing of two stable operators on admissible inputs; its actual finite-horizon use produces an uncontrolled future flux. This makes a would-be new native boundary-flux theorem precise enough to falsify at its transfer and domain.

### Falsification checks

Positive power-consistent far-prime controls preserve all finite local sources and plant arbitrary exact poles, but lose the genuine divisor/FE data. The positive-theta quartet preserves native atoms and loses its exact smooth completion. The all-orders Herglotz control does not meet the new integer-completion hypothesis. The divergent native jump compensator and low-nullity collar remain separate exact obstructions. The delayed positive-kernel and the stronger positive FE/scattering model preserve their specifically stated forward data while retaining unstable inverse modes. No one model is assigned the union of all native assumptions.

### Highest-leverage remaining task and explicit exports

**To A:** use the finite Gram theorem for the unchanged B detector, with its negative input coefficient and original support. The complete signed prime remainder inherits a pure exponential lower scale without multiplicity loss. The zero-damping diagonal is \(\|h\|^2\sum_{p\le e^{T+d}}(\log p)^2/p\sim\frac12\|h\|^2T^2\) by ordinary PNT; an off-line exponential lower bound dominates it. The exact future boundary term remains part of the identity.

**To B:** the source-independent completed kernel \(q_N\) supplies an actual stable input for C's original exterior. The exact finite-family Gram matrix and full source-jet table can be used in native inverse-domain or approximation arguments. The global lossless operator identity is available only on its actual \(L^2\) input domain; it has a matched unstable inverse model.

**To C/root:** require a proof of the particular native coupling (OPEN-C05), or a genuinely new controlled observation whose transfer remains nonzero on the specified residue. The local-only finite observation class is now classified, rather than merely tested on one row. The full flux identity records the remaining future term explicitly.

All 49 requirements, WP0–WP7, both parities, and **D2 = Full continuous K3 on \([1/512,\log16]\)** are unchanged. No formal acceptance gate is declared discharged. **RH remains OPEN.**
