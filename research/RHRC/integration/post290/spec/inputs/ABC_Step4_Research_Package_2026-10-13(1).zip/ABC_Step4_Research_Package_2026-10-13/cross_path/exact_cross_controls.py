#!/usr/bin/env python3
"""Exact rational and Laurent-polynomial controls for the joint paper.

No numerical zero sampling and no inference of a global arithmetic bound.
Run with the Python standard library only.
"""
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import json


def clean(p):
    return {k: Q(v) for k, v in p.items() if v}


def add(*ps):
    out = {}
    for p in ps:
        for k, v in p.items():
            out[k] = out.get(k, Q(0)) + v
    return clean(out)


def scale(p, c):
    return clean({k: c*v for k, v in p.items()})


def mul(p, q):
    out = {}
    for i, x in p.items():
        for j, y in q.items():
            out[i+j] = out.get(i+j, Q(0)) + x*y
    return clean(out)


checks = {}
mutations = {}
# X = exp(t/2).  The positive-time native density is
# (X - X^-3 - X^-5)/(1-X^-4).
den = {0: Q(1), -4: Q(-1)}
native_num = {1: Q(1), -3: Q(-1), -5: Q(-1)}
raw_num = add(mul({1: Q(1), -1: Q(1)}, den), {-1: Q(-1)})
assert raw_num == native_num
checks['native_density_common_denominator'] = True

cosh_minus_one = {4: Q(1, 2), -4: Q(1, 2), 0: Q(-1)}
b2 = {5: Q(1, 2), 1: Q(-1), -1: Q(-1, 2),
      -3: Q(1, 2), -5: Q(1, 2)}
assert mul(cosh_minus_one, native_num) == mul(b2, den)
assert mul({4: Q(1, 2), 0: Q(-1, 2)}, native_num) == b2
checks['contact_gamma_free_density_and_factor'] = True
mutations['wrong_commutator_sign_rejected'] = (
    mul(cosh_minus_one, native_num) != mul(scale(b2, -1), den))
bad_b2 = dict(b2)
del bad_b2[-5]
mutations['missing_last_archimedean_endpoint_rejected'] = (
    mul(cosh_minus_one, native_num) != mul(bad_b2, den))

for m in range(1, 17):
    geom = {-4*j: Q(1) for j in range(m)}
    expected = {1: Q(1), -(4*m-1): Q(-1), -(4*m+1): Q(-1)}
    expected = add(expected, {-(4*j+1): Q(-1) for j in range(1, m)})
    assert mul(native_num, geom) == expected
    assert mul(den, geom) == {0: Q(1), -4*m: Q(-1)}
checks['even_shift_endpoints_m_1_through_16'] = True

# H=[[1,-1],[-1,1]] is PSD with null vector (1,1).
# This exact control detects the factor two and sign in the quadratic identity.
for a in [Q(1, 3), Q(1), Q(7, 2)]:
    for b in [Q(1, 2), Q(2), Q(9, 2)]:
        direct = (a-b)**2
        commutator = 2*a*b*((a/b+b/a)/2-1)
        assert direct == commutator
checks['finite_psd_contact_double_commutator'] = True
mutations['missing_reflected_pair_factor_two_rejected'] = (
    (Q(1)-Q(2))**2 != Q(1)*Q(2)*((Q(1,2)+Q(2))/2-1))

# g=1_[0,1]-1_[1,2] has C_g(1)=-1, although its autocorrelation is
# positive definite. The corresponding finite Toeplitz determinants are n+1.
previous, current = Q(1), Q(2)
for n in range(2, 20):
    previous, current = current, 2*current-previous
    assert current == n+1 > 0
checks['positive_definite_correlation_can_be_negative'] = True

# The unique positive b2 sign change is x^3-x-1=0, x=exp(t)>1.
def plastic_polynomial(x):
    return x**3-x-1
assert plastic_polynomial(Q(13,10)) < 0
assert plastic_polynomial(Q(4,3)) > 0
# Its derivative 3x^2-1 is positive for x>=1.
assert 3*Q(1)**2-1 > 0
checks['density_sign_threshold_rational_bracket'] = True

# The original +/- prime atom pair coefficient is retained exactly.
for n in range(2, 101):
    # Multiply alpha_n by sqrt(n)/Lambda(n), avoiding irrational logs.
    lhs = (Q(n*n)+Q(1,n*n))/2-1
    rhs = Q((n*n-1)**2, 2*n*n)
    assert lhs == rhs
checks['prime_atom_coefficients_n_2_through_100'] = True

# Any finite constant-coefficient even-shift combination has native pole
# residue proportional to the coefficient sum. Distinct shift tails have
# no native right pole; this formal check only tracks the exact coefficient.
coefficients = [Q(1), Q(-3,2), Q(1,2)]
assert sum(coefficients) == 0
checks['balanced_shift_combination_has_zero_native_residue'] = True

assert all(checks.values()) and all(mutations.values())
here = Path(__file__).resolve().parent
result = {
    'status': 'EXACT_CROSS_CONTROLS_PASS',
    'scope': 'Finite algebra controls. Analytic and universal claims require the paper proofs. No Step 4 upper estimate is established.',
    'checks': checks,
    'mutation_falsifiers': mutations,
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(here/'EXACT_CROSS_CONTROLS.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'status': result['status'], 'checks': len(checks), 'mutations': len(mutations)}))
