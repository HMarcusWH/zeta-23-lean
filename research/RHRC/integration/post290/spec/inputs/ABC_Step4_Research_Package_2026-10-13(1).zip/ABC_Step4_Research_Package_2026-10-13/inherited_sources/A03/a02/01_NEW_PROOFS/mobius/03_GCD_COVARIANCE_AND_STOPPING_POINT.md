# A2: exact gcd grouping of the Möbius covariance and the failed remainder bound

Date: 12 October 2026. Status: new PAPER/DERIVED algebra and bounds, with an OPEN closing remainder.

## 1. The precise proposed arithmetic step

For B's exact rapidly decreasing \(U\), put \(u=e^{-\epsilon t}U\), \(\sigma=1/2+\epsilon\), \(t_0=\log2-d>0\). The attempted closing statement is

\[
\sup_{T>0}\int_0^T
\left|\sum_{n\le e^{T-t_0}}\mu(n)n^{-\sigma}
u(t-\log n)\right|^2dt<\infty
\quad\text{for every }\epsilon>0.
\tag{A}
\]

This is the already specified source-specific target. The new attempt groups the genuine Möbius covariance by common divisors before taking any infinite limit. Its purpose is to test whether the exact squarefree divisor geometry, beyond coefficient magnitudes, yields a positive arithmetic domination.

## 2. Finite-horizon gcd identity

Every summand at a fixed horizon is finite. Set \(n=da,m=db\), with \((a,b)=1\). The exact squarefree identity is

\[
\mu(da)\mu(db)=
\begin{cases}
\mu(a)\mu(b)\mu(d)^2,&(d,ab)=1,\\
0,&(d,ab)>1,
\end{cases}
\tag{1}
\]

where both sides vanish whenever \(a\) or \(b\) is nonsquarefree. Therefore

\[
\boxed{
\begin{aligned}
E_\epsilon(T)
={}&\sum_{(a,b)=1}\frac{\mu(a)\mu(b)}{(ab)^\sigma}
\sum_{\substack{d\ge1\\(d,ab)=1}}
\frac{\mu(d)^2}{d^{2\sigma}}\\
&\qquad\cdot
\int_0^{T-\log d}u(s-\log a)\overline{u(s-\log b)}ds .
\end{aligned}}
\tag{2}
\]

An integral whose upper endpoint is nonpositive is zero, and causality makes every remaining sum finite: \(d\max(a,b)\le e^{T-t_0}\). The change of variable is \(s=t-\log d\). The originally lower interval \([-\log d,0)\) contributes zero because \(u\) begins at \(t_0>0\). Thus no boundary term is lost.

For real \(U\), the displayed products are real after swapping \(a,b\), but their separate signs are retained. Equation (2) does not replace \(\mu(a)\mu(b)\) by a magnitude.

## 3. What this grouping does control

### The diagonal

The primitive ratio \(a=b=1\) gives

\[
0\le E_{\epsilon,\mathrm{diag}}(T)
\le \|u\|_2^2
\sum_{d\ge1}\frac{\mu(d)^2}{d^{2\sigma}}
=
\frac{\zeta(2\sigma)}{\zeta(4\sigma)}\|u\|_2^2<\infty.
\tag{3}
\]

### Each fixed reduced rational ray

For each fixed coprime pair \(a,b\), Cauchy–Schwarz bounds the absolute inner integral by \(\|u\|_2^2\). The positive \(d\) sum has finite value

\[
C_\sigma(ab)=
\prod_{p\nmid ab}(1+p^{-2\sigma})
=\frac{\zeta(2\sigma)}{\zeta(4\sigma)}
\prod_{p\mid ab}(1+p^{-2\sigma})^{-1}.
\tag{4}
\]

Hence that entire ratio ray is bounded uniformly in \(T\). Dominated convergence in this one \(d\) sum gives its exact limit

\[
\frac{\mu(a)\mu(b)}{(ab)^\sigma}C_\sigma(ab)
R_u(\log(a/b)),
\qquad R_u(v)=\int_{\mathbb R}u(s) \overline{u(s+v)}ds.
\tag{5}
\]

The fixed-ray limit is justified. Summing it over all rational rays is a new operation and is not justified by this argument.

### Polynomially separated rays

Since \(U\) decreases faster than every exponential and begins at \(t_0>0\), for every \(N>0\) there is \(C_N\) such that the absolute truncated correlation in (2) is at most

\[
C_Ne^{-N|\log(a/b)|}.
\tag{6}
\]

For example, if \(a\ge b\), shift by \(\log a\) and use the rapid bound on the factor with the extra shift \(\log(a/b)\), integrating the remaining exponentially weighted source absolutely.

For every fixed \(\eta>0\), all terms in (2) with \(a\ge b^{1+\eta}\) are absolutely and uniformly summable. Indeed they are bounded by a constant times

\[
\sum_{b\ge1}b^{-\sigma+N}
\sum_{a\ge b^{1+\eta}}a^{-\sigma-N},
\]

and for \(N+\sigma>1\) the outer exponent is

\[
1+\eta-\sigma(2+\eta)-\eta N.
\]

Choosing \(N\) large makes this less than \(-1\). The symmetric region is identical. This bound includes the full positive \(d\) sum (4).

These are unconditional bounds on actual pieces of the native covariance. For every fixed \(\eta>0\), the only region left uncontrolled is \(b\le a<b^{1+\eta}\), together with its transpose. This is comparability on a logarithmic scale, not a proved fixed upper bound for \(a/b\). No single rational ray, finite collection of rays, or polynomially separated sector can produce divergence.

### The absolute sum of the native rational-ray limits really diverges

The failure of absolute summation can be proved directly for the actual \(U\); it does not need an inference from a different prime expansion. For every \(0<\epsilon\le1/2\),

\[
\boxed{\sum_{(a,b)=1}
\frac{|\mu(a)\mu(b)|}{(ab)^\sigma}
C_\sigma(ab)\,|R_u(\log(a/b))|=\infty.}
\tag{6a}
\]

**Proof.** The actual \(u\) is real, nonzero and in \(L^2\), so translation continuity gives \(R_u(0)=\|u\|_2^2>0\) and \(R_u(v)\ge c_u>0\) for \(|v|\le v_0\). Fix \(0<\eta<1\) with \(\log(1+\eta)<v_0\). The number of ordered pairs of coprime squarefree integers \(a,b\in[X,(1+\eta)X]\) is

\[
\kappa\eta^2X^2+o(X^2),\qquad
\kappa=\prod_p(1-3p^{-2}+2p^{-3})>0.
\tag{6b}
\]

For completeness, restrict first to primes \(p\le Q\). Modulo \(p^2\), the allowed valuation pairs are \((0,0),(1,0),(0,1)\). They occupy
\((p^2-p)^2+2(p-1)(p^2-p)=p^4-3p^2+2p\) residue pairs. The Chinese remainder theorem therefore gives the finite-prime density \(\prod_{p\le Q}(1-3p^{-2}+2p^{-3})\). Failure at a prime \(p>Q\) requires \(p^2\mid a\), \(p^2\mid b\), or \(p\mid a,b\). Counting multiples bounds the total exceptional pairs by
\[
O\!\left(X^2\sum_{p>Q}p^{-2}+X^{3/2}+X\log X\right).
\]
Here square-divisor errors use \(p\le\sqrt{(1+\eta)X}\), and common-prime errors use \(p\le(1+\eta)X\). Let \(X\to\infty\), then \(Q\to\infty\). This proves (6b), and the positive product converges because its deviations from one are summable.

For these pairs, \(C_\sigma(ab)\ge1\), \(|\mu(a)\mu(b)|=1\), and the correlation is at least \(c_u\). The contribution of this one shell is consequently at least a positive constant times
\[
X^{2-2\sigma}=X^{1-2\epsilon}.
\]
Choose disjoint shells \(X=2^j\). For \(0<\epsilon<1/2\), their individual lower bounds grow; at \(\epsilon=1/2\), they are bounded below by a fixed positive constant. In either case the series diverges. This argument concerns the absolute ray series. It does not assign a sign to \(\mu(a)\mu(b)\) or to their complete signed sum.

The corresponding absolute finite-horizon ray budget is unbounded as well. For any finite collection of these pairs, each ray converges by the already justified dominated limit (5). First make that collection's absolute limiting sum arbitrarily large, then take \(T\) large enough for those finitely many convergences. No infinite exchange of limits is used.

## 4. Exact divisor collapse and what remains

The native input itself is \(U=\mathcal D_{\log}*h\). Expanding its locally finite integer translates before the horizon produces exactly

\[
M*U=\mathcal D_{\mu*\log}*h=\mathcal D_\Lambda*h.
\tag{7}
\]

This is the full use of the alternating native divisors in the current grouping. It is stronger than squarefree magnitude information; the comparison with \(\mu^2\) loses (7).

Note01 then bounds the complete \(p^k,\ k\ge2\), channel. The surviving covariance is Note02's exact signed first-prime kernel, supported only on

\[
1<q/p<e^{2d}.
\]

The positive squarefree common-divisor factor (4) has not become a domination theorem for those distinct first-prime correlations. The factors \(\mu(a)\mu(b)\), and the overlaps belonging to the actual \(U\), are exactly what recombine to that prime-only residual.

In particular the independent ray bounds cannot be summed by Tonelli after taking absolute values: the native proof (6a) shows their absolute divergence directly. Separately, Note02 proves that the positive and negative native prime-pair budgets each have a positive \(X^{1-2\epsilon}\) main term when \(0<\epsilon<1/2\). The two expansions have different indices; divergence in one has not been used as a substitute proof for the other. The missing cancellation resides in the collective near-ratio region and its horizon boundary, not in an omitted estimate on one gcd factor.

## 5. Exact test of a stronger covariance premise

A possible but invalid shortcut would be:

> The positive factor \(C_\sigma(ab)\), finite diagonal, and positive-definite source covariance make the cumulative off-diagonal contribution nonpositive or uniformly bounded in magnitude.

The matrix is positive semidefinite only as a complete Gram matrix; its individual entries are not sign-definite. Note02 uses the exact source moments to prove sign-changing \(R_\epsilon\), and ordinary PNT to realize both signs with native prime pairs at arbitrarily large scales. Their two absolute parts diverge at the explicit native rate. This is a native falsification of the required sign/magnitude inference, without modifying any prime.

The weaker complete signed bound, including its nonnegative boundary loss, survives that test. The leading arithmetic cancellation has been proved in Note02; the quantitative residual has not.

## 6. Why the additional B/C state does not finish this estimate

The canonical contact generator and its positive auxiliary invariant provide a second compact-source observation of the centered first-prime distribution. Note01 proves a stable remainder after mutually filtering B's forcing and C's exterior residual. The cancellation is source-preserving and retains the native completion.

It does not supply an independent bound for either term: at every hypothetical off-line pole, the two filtered residues cancel with opposite signs. C's positive Herglotz function likewise becomes positive after canceling those native residues. Combining these two cancellations does not yield a second inequality on the native covariance in (2).

The inherited same-contact far-prime controls and smooth-quartet control preserve different halves of the native data. Our adapter distinguishes both defects explicitly. No one of those models is asserted to preserve the exact integer divisor law and exact native smooth completion simultaneously.

## 7. Stopping point and concrete export

Established: exact native finite-horizon gcd grouping, bounded diagonal and rational rays, absolute control of polynomially separated ratios, direct absolute divergence of the collective rational-ray series for \(0<\epsilon\le1/2\), exact native collapse to the first-prime Gram after the bounded power channel, and the proved leading boundary cancellation of that Gram.

Unproved: a uniform upper bound on the signed remainder \(\mathcal E_\epsilon(T)\) of Note02 (14), for every positive damping. That is the source-specific arithmetic information still needed. The branch supplies a narrower and fully normalized residual; it does not claim the already known RH-strength equivalence as a new theorem.

