# The native logarithmic derivative has no finite-type entire denominator

Date: 2026-10-12. **DERIVED / PAPER from classical complex analysis and an unconditional primary zero-density theorem.** No RH assumption, no Lean claim, and no native full-contact hypothesis are used.

## 1. Primary density input and the distinct-count audit

H. M. Bui, Brian Conrey and Matthew P. Young, *More than 41% of the zeros of the zeta function are on the critical line*, Acta Arithmetica 150 (2011), 35–64, Theorem 1.1, explicitly proves

\[
 \liminf_{T\to\infty}\frac{N_0^*(T)}{N(T)}\ge0.4058.
\]

Their `N_0^*(T)` counts **simple critical-line zeros**, whereas `N(T)` counts all nontrivial zeros with positive ordinate below T, with their usual multiplicities. The theorem therefore supplies genuinely distinct critical ordinates. We do not replace a multiplicity count by a distinct count.

The first page and definition were checked both in the authors' arXiv version and in the published article:

- https://arxiv.org/pdf/1002.4127 , version 2, 11 March 2011, p.1.
- https://aimath.org/~kaur/publications/69.pdf , published p.35, Theorem 1.1.
- DOI: https://doi.org/10.4064/aa150-1-3 .

Together with the Riemann–von Mangoldt formula

\[
 N(T)=\frac{T}{2\pi}\log\frac{T}{2\pi e}+O(\log T),
\]

this implies `N_0^*(T) >= c T log T` for all sufficiently large T and some fixed `c>0`. A primary research source displaying this exact formula is J. B. Conrey, *More than two fifths of the zeros of the Riemann zeta function are on the critical line*, J. reine angew. Math. 399 (1989), 1–26, equation (8), published p.3. Its original article also already proves a sufficient positive simple-critical proportion. Formula (8) and the simple-zero definition were visually checked:

- https://maths.dur.ac.uk/users/herbert.gangl/morethan2_5.PDF .

The specific 0.4058 proportion is not needed for the argument, and is not described here as a current record. Any established positive simple-critical proportion suffices.

## 2. An elementary zero-count lemma

**Lemma.** If G is a nonzero entire function of finite exponential type, its number of zeros in `|z|<=T`, counted with multiplicity, is `O(T)`.

**Proof.** Choose `z0` with `G(z0) != 0`, and put `g(w)=G(z0+w)`. There exist finite constants C, tau with `|g(w)| <= C exp(tau |w|)` (increasing tau and C if necessary). Jensen's formula on a disk of radius `R` gives

\[
 \sum_{|w_k|<R}\log\frac R{|w_k|}
  =\frac1{2\pi}\int_0^{2\pi}\log|g(Re^{i\theta})|d\theta
     -\log|g(0)|
  \le \log C+\tau R-\log|g(0)|.
\]

Take `R=2(T+|z0|+1)`; if needed choose an arbitrarily nearby larger radius avoiding boundary zeros. Every zero of G in `|z|<=T` gives a zero of g of modulus at most `T+|z0|`, contributing at least `log 2`. Hence the count is O(T). QED.

In particular this applies to every nonzero Fourier transform of an L2 function supported in a finite interval. Such a function is L1 there, and its transform satisfies the stronger bound `|G(z)| <= ||f||_1 exp(a |Im z|)` after centering its support in `[-a,a]`.

## 3. No-global-quotient theorem

Set `Xi(z)=xi(1/2+iz)`.

**Theorem.** There do not exist a nonzero entire finite-exponential-type G, an entire H, and a nonzero constant c such that

\[
 \frac{H(z)}{G(z)}=c\frac{\Xi'(z)}{\Xi(z)}
\]

as meromorphic functions on the plane, or even on a nonempty open set where both sides are holomorphic.

**Proof.** Equality on an open set gives the entire identity

\[
 H(z)\Xi(z)=cG(z)\Xi'(z)
\]

by the identity theorem. At every simple positive real native ordinate gamma, `Xi(gamma)=0` and `Xi'(gamma) != 0`; therefore `G(gamma)=0`. Section 1 supplies at least `c0 T log T` such distinct zeros below T. Section 2 bounds the number of G's zeros there by O(T). This is impossible. QED.

The numerator H need not have finite type or any growth bound: entire continuation and the denominator's finite type already contradict the native pole density. The same proof permits adding an entire term to the native logarithmic derivative, since that does not remove its simple critical poles.

The conclusion is unchanged by any nonzero fixed factors of i, by using `-Xi'/Xi`, or by moving to the s coordinate. At nontrivial zeros the completion factor in xi is nonzero, so a simple zeta zero gives a simple Xi zero. No uniform lower bound on the nonzero derivatives is required.

## 4. Consequence for the compact companion route

The contact invariant has the exact decomposition

\[
 \mathfrak m_a(z)=i\frac{F_h(z)}{G(z)}
       =\frac{S_G(z)}{G(z)G^\#(z)}-\frac{\Xi'(z)}{\Xi(z)}.
\]

The compact-pair uniqueness theorem legitimately identifies two compact L2 pairs that agree with a common comparison to the required `2a` exponential accuracy. This does **not** license taking the native logarithmic derivative itself as an exact second compact pair. The theorem above proves that such an exact representation is unconditionally impossible, including in a world where RH is true: its already known real poles are too dense.

Consequently the following proposed closing construction is falsified as stated:

> Represent the exact native logarithmic derivative by a second compact Fourier pair of finite support; apply compact-pair uniqueness to identify it with the positive contact invariant.

A noncompact source, an entire denominator of infinite exponential type, or a genuinely different native compatibility map would be required for that direction. No such map is constructed by this note.

The native correction is therefore necessary. It cancels the numerous native poles that a compact quotient cannot carry. The theorem does not eliminate that correction, turn its measure into the native zero measure, or prove a local range law. Under a hypothetical contact, the nonzero compact generator vanishes at at most O(T) of the simple critical ordinates below T; the remaining order `T log T` ordinates necessarily have nonzero generator evaluation and corresponding nonzero exterior cardinal pairing. Proving an independent native annihilation law on a superlinear set would contradict this fact and close the route, but this note supplies no such independent law.

## 5. Matched controls and post-result implications

A sparse real pole set, such as the dyadic X3 divisor or a fixed-spacing trigonometric divisor, has no superlinear pole count; these controls do not contradict the theorem. Compactly supported distributions still have finite-type transforms and therefore do not repair the dense-pole obstruction, although they can affect the distinct compact-pair uniqueness theorem at its boundary.

For an actual finite-type denominator, removing only finitely many native poles, or O(T) of them up to height T, leaves the contradiction unchanged. An allowed correction must remove a superlinear set. The exact project residual does precisely that at a formal meromorphic level; the challenge is to constrain its native realization, not to discard it.

**C export:** an exact native second compact-pair construction is unavailable, so compact-pair uniqueness must be used with its actual residual and an independently justified comparison class.

**B export:** any native global Weyl/Suzuki realization carrying all simple critical poles must have spectral complexity beyond a finite-support Fourier denominator. A local positive quotient cannot by itself identify the native global realization.

**A export:** no change to the finite prime-prefix or fixed-K2 sign problem. The obstruction applies to exact global representations, not to finite-horizon arithmetic recovery.

This is an independent restriction on a possible proof construction, not an RH proof. **RH remains OPEN.**
