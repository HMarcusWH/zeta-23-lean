# Constraint campaign: slow refinement through the native arithmetic and finite carrier

Date: 13 October 2026. Status: **PAPER / DERIVED; not formalized. Step 4 remains open at the explicit inequality in Section 5.**

This note combines the original detector's positive refinement with the actual integer-lattice drive, the native prime-power-preserving mask, the controlled rough-core sector, and the prescribed quartic finite bridge. The scale parameter is frozen throughout each entire finite history. Its deterioration in the Poisson constant is explicitly paid for; the fixed-source logarithm-squared cofactor estimate is not imported with fictitious scale-independent constants.

## 1. The integer drive has a quantitative scale cost

For \(0<s\le r_*\), define, using the actual \(h_s\),

\[
V_s(u)=\sum_{n\ge1}n^{-1/2}h_s(u-\log n),
\qquad
U_s(u)=\sum_{n\ge1}(\log n)n^{-1/2}h_s(u-\log n).
\tag{1}
\]

**Lemma 1.** There are constants \(C,\kappa>0\), independent of \(s\) and \(u\), such that

\[
\boxed{
|V_s(u)|+|U_s(u)|
\le Cs^{-6}\exp\big(-\kappa\sqrt{s}\,e^{u/2}\big)
\qquad(u\ge0).
}
\tag{2}
\]

The exponent \(6\) in the prefactor is a convenient bound, not an optimized constant. The factor \(\sqrt{s}\) inside the exponential is essential.

**Proof.** The original derivative estimate and scaling imply

\[
\|h_s^{(m)}\|_1\le Cs^{-4}(A/s)^m(m!)^2,
\quad m\ge0,
\tag{3}
\]

with constants independent of \(s\). Indeed
\(h_s=(\partial^2-1/4)^2b_s\), and the finitely shifted factorials from four derivatives are absorbed in \(A^m\).
Set

\[
a_s(y)=y^{-1/2}h_s(-\log y),\qquad
b_s^\flat(y)=(\log y)a_s(y),
\]

extended by zero outside their compact support in \(y>0\). To check the composition cost directly, for \(x=-\log y\),

\[
\partial_y^m a_s(y)
=(-1)^m y^{-m-1/2}
\prod_{j=0}^{m-1}(\partial_x+j+1/2)h_s(x).
\tag{4}
\]

The coefficient of \(\partial_x^k\) in this product is bounded by
\(\binom mk m^{m-k}\). On the support \(|x|\le2s\le2r_*\), the extra power of \(y\) costs only a fixed exponential in \(m\). Since
\(m^{m-k}(k!)^2\le e^m(m!)^2\), (3) gives

\[
\|a_s^{(m)}\|_1+\|(b_s^\flat)^{(m)}\|_1
\le Cs^{-4}(A'/s)^m(m!)^2.
\tag{5}
\]

For the second term use \(b_s^\flat=-x h_s(x)\) before applying (4); differentiation introduces at most one additional factor \(m\), absorbable in the fixed exponential. Repeated Fourier integration by parts and the choice \(m\asymp\sqrt{s|\xi|}\) now prove

\[
|\widehat a_s(\xi)|+|\widehat b_s^\flat(\xi)|
\le Cs^{-4}e^{-c\sqrt{s|\xi|}}.
\tag{6}
\]

Both zero Fourier modes vanish exactly:
\(\int a_s=H_s(1/2)=0\) and \(\int b_s^\flat=H_s'(1/2)=0\).
Poisson summation at mesh \(e^{-u}\) therefore bounds (1) by

\[
Cs^{-4}(1+u)e^{u/2}
\big(1+(se^u)^{-1}\big)e^{-c'\sqrt{s}e^{u/2}}.
\tag{7}
\]

For example, the elementary sum used here is
\(\sum_{k\ge1}e^{-c\sqrt{zk}}
\le C(1+z^{-1})e^{-c'\sqrt z}\).
Writing \(z=\sqrt{s}e^{u/2}\), separating \(z\le1\) from \(z\ge1\), and reducing \(c'\) absorbs the remaining factors into \(Cs^{-6}\). This proves (2). QED.

## 2. The mask and cofactor cutoff are still exact for every frozen scale

Fix one \(B_0\ge1\) so that \(c_0:=\kappa\sqrt{B_0}-1/2>0\), and put

\[
B_s=B_0/s.
\tag{8}
\]

For the running time \(u\ge1\), let \(P(u)\) be the largest initial primorial at most \(\log(u+2)\), with the empty primorial equal to one. Define

\[
Y_s(u)=\frac{e^u}{B_sP(u)u^2},\qquad
X_s(u)=e^{u+2s},\qquad
L_s(u)=B_sP(u)e^{2s}u^2,
\tag{9}
\]

\[
w_{P}(k)=1_{\{\omega(\gcd(k,P))\le1\}},\qquad
A_Y(k)=\sum_{\substack{n\mid k\\n>Y}}\mu(n)\log(k/n).
\tag{10}
\]

The previously proved mask identity, including its coefficient budget, is

\[
w_P(k)=\sum_{Q\mid\gcd(k,P)}\mu(Q)(1-\omega(Q)),
\quad
\mathcal A(P)\le P(1+\log_2P)
\quad(P\ge2).
\]

It fixes every prime power, so the exact native decomposition is

\[
F_s(u)=S_s(u)+r_s(u),
\quad
S_s(u)=\sum_{k\le X_s(u)}
\frac{w_{P(u)}(k)A_{Y_s(u)}(k)}{\sqrt k}
h_s(u-\log k).
\tag{11}
\]

The long-divisor condition in (10) implies the strict cofactor range
\(m<L_s(u)\). This is derived from the original support and strict threshold; it is not a second truncation.

The restricted integer drive still has the exact identity

\[
U_{s,q}(v)=q^{-1/2}
\left[(\log q)V_s(v-\log q)+U_s(v-\log q)\right].
\tag{12}
\]

For \(Q\mid P(u)\), \(n\le Y_s(u)\), set \(q=Q/\gcd(Q,n)\). Then
\(nq\le e^u/(B_su^2)\). Inserting (2) into exactly the original compensated-cutoff proof gives

\[
\boxed{
|r_s(u)|\le
\frac{Cs^{-6}\mathcal A(P(u))(1+\log P(u))}
{\sqrt{B_sP(u)}\,u}
e^{-c_0u}.
}
\tag{13}
\]

The critical exponent is now
\(\kappa\sqrt{sB_s}-1/2=c_0\), uniformly in the scale. In particular, after adding the finite initial history,

\[
\boxed{\|r_s\|_{\eta,[0,\infty)}\le C_\eta s^{-6}}
\quad(\eta>0).
\tag{14}
\]

On \([0,1]\), only finitely many native products can occur and \(\|h_s\|_\infty=O(s^{-5})\); this supplies the asserted initial-history cost. One may define the long part to be zero there and retain the actual \(F_s\) in \(r_s\).

Thus a scale of order \(1/T\) expands the late-horizon cofactor budget to order \(T^3\log T\). Keeping \(B_s\) fixed as \(s\to0\) would not prove (13).

## 3. A slow scale preserves the controlled rough-core sector on the full prefix

For an integer \(k\), let \(a_L(k)\) be its complete prime-power part with prime factors at most \(L\), and let \(b_L(k)=k/a_L(k)\). Define the fixed cutoff

\[
Z(u)=\exp\!\left(\frac{u}{\log(u+2)}\right).
\]

Split the complete long-divisor field (11) as

\[
S_s=D_s+R_s,
\tag{15}
\]

where \(D_s\) retains exactly the products with
\(b_{L_s(u)}(k)\le Z(u)\), and \(R_s\) retains the complementary products. Each includes its full mask and divisor coefficient. No quadratic mixed term is dropped by this pointwise decomposition.

The elementary Rankin counting proof from the prior campaign, with its source dependence exposed, gives for \(0<\delta<1/2\)

\[
\begin{split}
|D_s(u)|\le {}&C_\delta s^{-5}L_s(u)\log(eL_s(u))\\
&\times\exp\left[
\delta u+(1/2-\delta)\log Z(u)
+C_\delta L_s(u)^{1/2-\delta}
\right].
\end{split}
\tag{16}
\]

For clarity the counting input is only
\(\Psi(v,L)\le v^{1/2+\delta}
\exp(C_\delta L^{1/2-\delta})\),
obtained by a finite Euler product bounded above by a sum over all integers. The coefficient bound is
\(|A_Y(k)|\le L\log(eL)\), and the source bound is
\(\|h_s\|_\infty\le Cs^{-5}\).

Now fix a damping \(\eta>0\), and fix

\[
b=\min(1/2,\eta),\qquad
\delta=\min(1/4,\eta/2).
\tag{17}
\]

At an outer horizon \(T\), choose the original detector's dyadic descendant

\[
\boxed{
s=s_\eta(T)=r\,2^{-\lceil b\log_2(T+2)\rceil}.
}
\tag{18}
\]

Thus \(r(T+2)^{-b}/2\le s\le r(T+2)^{-b}\). **This one value of \(s\) is frozen for every running time \(u\in[0,T+2r]\).** The running modulus \(P(u)\) and divisor threshold retain the definitions in (9); no derivative of these stepwise quantities is taken.

**Theorem 3.** With these choices there is \(C_\eta\), independent of \(T\), such that for all sufficiently large \(T\)

\[
\boxed{
\|D_{s_\eta(T)}\|_{\eta,[0,T+2r]}
+\|r_{s_\eta(T)}\|_{\eta,[0,T+2r]}
\le\exp(C_\eta T^{3/4}).
}
\tag{19}
\]

**Proof.** The second norm has only a polynomial horizon cost by (14) and (18). For the first, throughout the prefix,
\(L_s(u)\le C_r(T+2)^b u^2\log(u+2)\).
The prefactor in (16) is polynomial in \(T\). Split the integration at \(u=T^{3/4}\).

On \(1\le u\le T^{3/4}\), the linear terms in the exponent of (16) are \(O_\eta(T^{3/4})\). Its Euler-product term is at most a constant times

\[
T^{b(1/2-\delta)+(3/4)(1-2\delta)}
(\log(T+2))^{1/2-\delta}.
\]

The power of \(T\) is strictly less than \(3/4\): for \(\eta\le1/2\) it is
\(3/4-\eta/4-\eta^2/2\), and for \(\eta\ge1/2\) it is \(1/2\). This part of the norm is therefore bounded by the right side of (19), with a changed constant.

On \(T^{3/4}\le u\le T+2r\),

\[
\frac{L_s(u)^{1/2-\delta}}{u}
\le C_r T^{b(1/2-\delta)-(3/2)\delta}
(\log(T+2))^{1/2-\delta}\longrightarrow0.
\]

Also \(\log Z(u)/u\to0\), uniformly in this part of the interval. Because \(\delta<\eta\), multiplication by \(e^{-\eta u}\) leaves at most
\(\operatorname{poly}_\eta(T)e^{-(\eta-\delta)u/2}\) for all sufficiently large \(T\). Its norm is harmless. The initial interval is polynomially bounded as in Section 2. QED.

This proof is why the scale in (18) depends on the requested damping. Using \(s\asymp T^{-1}\) inside the same absolute Rankin estimate would require \(\delta>1/6\) before its late-horizon Euler-product exponent becomes sublinear. Such a fixed refinement rate cannot be inserted into this particular argument for every positive damping. No prohibition on a stronger counting or cancellation estimate is claimed.

## 4. Steps 1–3 remain attached to this scale choice

The source scale in (18) has \(b\le1/2<1\). The positive finite-carrier construction in
`../source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md` retains nonnegativity of the even precursor, the original plus/minus lobe coefficient and reflection parity, the exact pole moments, and the collars at the prescribed cutoff \(K(L)=\lceil L^4\rceil\). The finite source approximates the original translated detector in the stated norm; its repaired transform is not asserted to keep the original cosine/sine factor or its entire zero pattern exactly. Its full form error is bounded by

\[
C(1+L)L^{13/2}s^{-2}
\exp\!\left(\frac L2-c\sqrt{\frac{s(K(L)-3)}L}\right).
\tag{20}
\]

At \(s\asymp L^{-b}\), the negative term has order
\(L^{(3-b)/2}\), which dominates the form cost \(e^{L/2}\). All prefactors are polynomial. Along a signed coarse witness time, Note 01 provides a refined time within \(2r\), so \(L=T+O_r(1)\), and its raw exponential depth loses only \(s^5\), again polynomially. The same original lobe sign and reflection phase, with that approximation record, are therefore available in the legal finite carrier.

The negative-threshold construction in
`../contact_provenance/01_DEEP_POLE_NEUTRAL_STATE_WITH_SPECTRAL_GAP.md`
retains that detector record while choosing a deep threshold with a positive shifted predecessor. Its inverse bound is
\(6K_d^2/D\), with the threshold and pole-constraint multipliers retained. Since \(K_d\le K(L)=O(L^4)\) and \(D\ge e^{\beta' L}\) on the retained deep sequence, this bound is \(O(L^8e^{-\beta' L})\).

These facts supply an exponentially small predecessor inverse and a specific source history. They do not estimate the right side of that inverse's actual source equation. The contact provenance note retains that Schur forcing explicitly.

## 5. One explicit native closing inequality

Apply the exact damped prefix inequality (13) of Note 01, with the frozen descendant (18), and then the exact decomposition
\(F_s=R_s+D_s+r_s\). By (8) of Note 01 and (19),

\[
\boxed{
\begin{split}
\|F_r\|_{\eta,[0,T]}
\le e^{v_0r^2\eta^2}\Big[
\|R_{s_\eta(T)}\|_{\eta,[0,T+2r]}
+e^{C_\eta T^{3/4}}
\Big].
\end{split}
}
\tag{21}
\]

This is an inequality for the **original fixed** \(F_r\). Every refined source is accompanied by its exact source reconstruction, and the full terminal anticipation is present. The remainder in (21) is proved, with its scale dependence; the residual on the right is not yet bounded.

A sufficient closing input is the following all-horizon assertion:

\[
\boxed{
\forall\eta>0:\quad
\limsup_{T\to\infty}\frac1T
\log\!\left(
1+\|R_{s_\eta(T)}\|_{\eta,[0,T+2r]}
\right)=0.
}
\tag{22}
\]

**If (22) were proved independently**, (21) would make
\(\|F_r\|_{\eta,[0,T]}=e^{o(T)}\) for every \(\eta>0\).
For a requested final damping \(\epsilon>0\), use \(\eta=\epsilon/2\). Summing over unit intervals gives

\[
\begin{split}
\int_0^\infty e^{-2\epsilon u}|F_r(u)|^2du
&\le\sum_{j\ge0}e^{-2(\epsilon-\eta)j}
\|F_r\|_{\eta,[0,j+1]}^2<\infty.
\end{split}
\tag{23}
\]

The exact gamma tail then gives the same all-positive-damping property for the original \(C_r\). Its universal nonzero residues and the native Laplace-pole argument would exclude every off-line zero. Thus (22), together with the proved adapters, would actually close the original chain. It is not supplied by a cofinal positive sequence or by changing the source separately at each running time.

There is an equivalent source-specific prime-pair form of the same remaining task. Let
\(\mathcal O_{s,\eta}(T)\) be exactly the signed off-diagonal energy from Note 02. Its pairs obey \(|\log(m/n)|\le4s\). At \(s=s_\eta(T)\), the diagonal costs at most
\(C_\eta T^{9b}\). Equations (17) of Note 02 and (19) here show that (22) is equivalent to

\[
\boxed{
\forall\eta>0:\quad
\limsup_{T\to\infty}\frac1T
\log\left(1+\max\{0,
\mathcal O_{s_\eta(T),\eta}(T+2r)\}\right)=0.
}
\tag{24}
\]

This equivalence uses triangle inequalities for entire fields already bounded in norm. It does not remove the mixed terms between cofactors or infer positivity of the off-diagonal part. The ratio window is now explicitly \(1+O(T^{-b})\), with the original pole-killed squared-energy kernel, original positive precursor, and quartic carrier all recorded.

## 6. The exact unsupported implication after the combined attempt

We attempted to derive (22)/(24) by applying the complete positive dyadic variance identity to the actual source and taking finer scales until prime windows separated. Note 02 proves that this scale martingale is not uniformly integrable even at the first native prime. The scaled diagonal atom limit is therefore insufficient to justify the missing uniformity. At the finite slow scale used here, the diagonal is controlled and the signed off-diagonal term remains.

The exponentially small predecessor inverse from Section 4 also does not independently supply (22): its Schur completion contains the norm of the actual detector forcing, so that forcing must still be estimated. Retaining depth prevents a loss of information but does not, by itself, bound the arithmetic input of the equation.

Accordingly the unsupported implication is specific:

> The exact detector phase, positive refinement, controlled diagonal, deep finite witness and small shifted predecessor inverse together force a subexponential upper bound on the full signed quantity in (24).

No such bound has been derived in this campaign. The contributions of this note are the uniform scale-dependent Poisson estimate, the paid-for moving cofactor budget, the full-prefix small-core bound at the slow descendant scale, and the concrete original-source closing inequality (21). They combine Steps 1–3 constraints with the arithmetic target without asserting that the remaining cancellation follows from them.

## Source record

- Notes 01–02 in this campaign: actual detector, exact refinement, finite histories, phase/depth, squared kernel and diagonal.
- Prior campaign `path_a/03_SMOOTH_SECTOR_BOUND.md`: elementary Rankin proof and full-field rough-core split.
- Prior campaign `path_a/04_PRIME_POWER_PRESERVING_ADAPTIVE_SIEVE.md`: exact native mask, restricted integer drive, strict cutoff, and finite identities.
- Current `source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md`: uniform Gevrey positive endpoint construction and quartic carrier.
- Current `contact_provenance/01_DEEP_POLE_NEUTRAL_STATE_WITH_SPECTRAL_GAP.md`: retained detector record, deep threshold and \(6K_d^2/D\) inverse.
- The unconditional scale uniformity, full-prefix discarded-sector estimate, and original-source inequality (21) are proved in this note. Assertions (22) and (24) remain explicitly **OPEN**; only their equivalence and their sufficient closing implication are proved. No outside arithmetic theorem or mean Möbius cancellation is used.
