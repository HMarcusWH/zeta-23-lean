# Joint campaign Path A paper result: independent control of the smooth-product sector

Date: 13 October 2026. Status: **PAPER / DERIVED, not formalized.**

The short cofactor range permits an unconditional estimate that is stronger than a generic divisor-count estimate. It removes products with a sufficiently small rough core using absolute values alone. It does not estimate the remaining long rough cores.

## 1. Unchanged source and exact coefficients

Use the original detector \(h\), supported in \([-d,d]\), \(d=1/2048\), and put \(x=e^t\). Fix one sufficiently large \(B>0\) as in A03, with

\[
Y(t)=\frac{x}{Bt^2},\qquad
X(t)=xe^d,\qquad L(t)=Be^dt^2.
\]

The inherited exact localization is

\[
F(t)=S_B(t)+r_B(t),\qquad
S_B(t)=\sum_{k\le X(t)}\frac{A_{Y(t)}(k)}{\sqrt k}
h(t-\log k),
\tag{1}
\]

where

\[
A_Y(k)=\sum_{\substack{n\mid k\\n>Y}}\mu(n)\log(k/n)
=\sum_{\substack{m\mid k\\m<k/Y}}\mu(k/m)\log m,
\tag{2}
\]

and \(r_B\) decays exponentially. Any active \(k\) is at least \(xe^{-d}\), and \(k/Y\le L(t)\). Therefore

\[
|A_{Y(t)}(k)|\le \sum_{1\le m<L(t)}\log m
\le L(t)\log(eL(t)).
\tag{3}
\]

This bound uses the actual short cofactor threshold; no large divisor function is required.

For each integer \(k\), let \(a_L(k)\) be its full prime-power part composed of primes at most \(L\). Let \(b_L(k)=k/a_L(k)\). Thus \(a_L\) is \(L\)-smooth, \(b_L\) has every prime factor greater than \(L\), and the two parts are coprime.

## 2. A counting bound with no prime-distribution input

Let

\[
\Psi(v,L)=\#\{a\le v:\text{ every prime divisor of }a\text{ is at most }L\}.
\]

For \(1/2<s<1\), Rankin's elementary inequality gives

\[
\Psi(v,L)\le v^s P_s(L),\qquad
P_s(L):=\prod_{p\le L}(1-p^{-s})^{-1}.
\tag{4}
\]

Indeed \(1_{a\le v}\le(v/a)^s\), and the sum over all \(L\)-smooth \(a\) factorizes into this finite Euler product. Moreover,

\[
\begin{split}
\log P_s(L)
&=\sum_{p\le L}-\log(1-p^{-s})\\
&\le \frac{1}{1-2^{-s}}\sum_{p\le L}p^{-s}\\
&\le C_s\sum_{2\le n\le L}n^{-s}
\le C'_s L^{1-s}.
\end{split}
\tag{5}
\]

This deliberately weak estimate needs neither PNT nor cancellation of any Möbius sum.

The number of \(k\le X\) with \(b_L(k)\le Z\) is at most

\[
\sum_{b\le Z}\Psi(X/b,L)
\le X^s P_s(L)\sum_{b\le Z}b^{-s}
\le C_sX^s Z^{1-s}\exp(C'_sL^{1-s}).
\tag{6}
\]

We dropped the roughness and coprimality requirements on \(b\), which is legitimate for this upper bound.

## 3. The field contributed by small rough cores

Define the complete sector

\[
S_{B,\le Z}(t)=
\sum_{\substack{k\le X(t)\\b_{L(t)}(k)\le Z(t)}}
\frac{A_{Y(t)}(k)}{\sqrt k}h(t-\log k).
\tag{7}
\]

Combining (3), (6), the support lower bound on \(k\), and boundedness of \(h\), with \(s=1/2+\delta\), \(0<\delta<1/2\), gives

\[
\boxed{
|S_{B,\le Z}(t)|
\le C_{\delta,B,h}\,t^2\log(et)\,
\exp\left[
\delta t+(1/2-\delta)\log Z(t)
+C_{\delta,B}t^{1-2\delta}
\right].
}
\tag{8}
\]

Increasing the fixed constant covers a bounded initial interval. All quantities inside the sector are the native ones.

### Fixed damping and a power-sized core cutoff

Take \(Z(t)=e^{\theta t}\), \(0\le\theta<1\). The linear exponent in (8) is

\[
\delta+(1/2-\delta)\theta
=\theta/2+\delta(1-\theta).
\]

If \(\epsilon>\theta/2\), choose \(0<\delta<1/2\) sufficiently small that this is less than \(\epsilon\). Since \(t^{1-2\delta}=o(t)\), (8) then proves

\[
\boxed{
\int_{T_0}^\infty e^{-2\epsilon t}
|S_{B,\le e^{\theta t}}(t)|^2\,dt<\infty
\qquad(\theta<\min(1,2\epsilon)).
}
\tag{9}
\]

The strict inequality is essential. No endpoint claim at \(\theta=2\epsilon\) is made.

### One core cutoff valid for every positive damping

If \(\log Z(t)=o(t)\), then for every \(\eta>0\), (8), choosing \(\delta<\eta\), implies a bound \(O_\eta(e^{\eta t})\). Consequently

\[
\boxed{
\forall\epsilon>0:\quad
\int_{T_0}^\infty e^{-2\epsilon t}
|S_{B,\le Z}(t)|^2\,dt<\infty.
}
\tag{10}
\]

For a concrete single choice, take \(Z(t)=\exp(t/\log(t+2))\). This source partition is fixed once and for all; it is not chosen separately for each \(\epsilon\).

## 4. What may now be removed from the closing target

Let \(S_{B,>Z}=S_B-S_{B,\le Z}\). For the single subexponential cutoff above, the sought all-positive-damping property for \(S_B\) is equivalent to that for \(S_{B,>Z}\). This follows from (10) and the triangle inequality in each weighted \(L^2\) space.

This operation does not silently discard quadratic mixed terms. The pointwise decomposition is exact, and the removed entire function already has a proved norm bound. The residual field retains all of its own cofactor, integer, and product cross terms.

For a particular \(\epsilon\), (9) permits the stronger reduction to \(b_L(k)>e^{\theta t}\) for any fixed \(\theta<2\epsilon\). This partition depends on \(\epsilon\), but the detector and the original cofactor cutoff \(B\) do not.

The surviving field still contains products \(2q\) and \(2pq\), with \(p\) just above the cofactor scale and \(q\) exponentially large. Their rough cores are comparable to \(e^t\). The bound does not touch their opposing native signs.

## 5. Compatibility with the adaptive sieve

The proof remains valid whenever the cofactor upper bound satisfies

\[
L(t)=t^{2+o(1)}
\]

up to fixed constants, because \(L(t)^{1/2-\delta}=t^{1-2\delta+o(1)}=o(t)\). In particular it applies to the prime-power-preserving adaptive sieve in Note 04 with its concrete \(L(t)=O(t^2\log(t+2))\). Multiplying the summands by a weight in \([0,1]\) only decreases the absolute bound.

It is not asserted for an arbitrary larger subexponential cofactor cutoff: the estimate on the finite Euler product must still be checked. The logarithm-squared scale is exactly the critical one for this elementary argument at the native \(k^{-1/2}\) weight.

## Source record

- A03 new/arithmetic/03_native_gevrey_drive_and_log_squared_cofactors.md, Sections 4–5: exact native cofactor localization and stable discarded field.
- A03 new/arithmetic/05_native_composite_support_and_signed_window_obstruction.md, Sections 1–2: exact product coefficients.
- The counting argument, sector estimate, quantifiers, and adaptive-sieve compatibility are derived in this campaign.
