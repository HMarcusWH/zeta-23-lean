# Constraint campaign: the fixed original precursor directly controls projected forcing

Date: 13 October 2026. Status: **PAPER / DERIVED; not formalized.**

This final combination retains the original detector \(k_s=(\partial^2-1/4)q_s\) at one fixed scale. Moving the pole-killing operator onto a pole-neutral test gives a direct source-specific bridge to the Schur forcing. The arithmetic input then has a double pole zero and the original positive Gevrey precursor. A tiny auxiliary detector is unnecessary for this direct bridge; if such a detector is used, keeping the original \(q_s\) convolution prevents its small scale from damaging the arithmetic constants.

## 1. An exact fixed-source field, obtained from the original detector

Fix the actual original scale \(s=r_*=1/4096\), or any other once-fixed scale \(0<s\le r_*\) in the constructed family. Write

\[
P=\partial^2-1/4,\qquad
k_s=Pq_s,\qquad
F_{k_s}=\Pi*k_s,
\quad
\Pi=\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}\delta_{\log n}.
\]

Define the derived kernel and native field

\[
\boxed{
j_s=P^2q_s,\qquad X_s=\Pi*j_s=P F_{k_s}.
}
\tag{1}
\]

These are identities on the actual smooth native source. In particular

\[
\boxed{h_s=q_s*j_s,\qquad F_{h_s}=q_s*X_s.}
\tag{2}
\]

The original A field is thus an explicitly known positive smoothing of (1). Equation (2) is not used backwards as an unbounded deconvolution estimate.

The bilateral transform of the new arithmetic kernel is

\[
J_s(p)=(p^2-1/4)^2Q_s(p).
\tag{3}
\]

It has exact double zeros at \(p=\pm1/2\), is nonzero at every native off-line \(\lambda=\rho-1/2\), and retains the original positive precursor \(q_s\). The kernel \(j_s\) itself need not be nonnegative and is not asserted to equal the autocorrelation \(k_s*k_s\). Its use is authorized by the exact differential relation (1), not by an identification of distinct sources.

## 2. The direct projected bridge has no scale or boundary loss

Let \(I\) be the actual compact source interval, and let \(S\) be any closed subspace of pole-neutral \(L^2\) functions supported in \(I\). This includes the exact predecessor carrier of the new contact state.

The compact-inverse theorem proved in the root and source-transport notes says that each \(\phi\in S\) has a unique compactly supported \(g\in H^2(\mathbb R)\), supported in the same \(I\), such that

\[
Pg=\phi,\qquad \|g\|_2\le4\|\phi\|_2.
\tag{4}
\]

Explicitly \(g(x)=-\int e^{-|x-y|/2}\phi(y)dy\). Both pole moments of \(\phi\) make this function vanish outside \(I\); consequently \(g\) and \(g'\) vanish at the endpoints. For the original smooth prime field, integration by parts gives

\[
\langle F_{k_s},\phi\rangle_I
=\langle P F_{k_s},g\rangle_I
=\langle X_s,g\rangle_I.
\]

Taking the supremum over unit tests proves

\[
\boxed{\|\Pi_S F_{k_s}\|_2\le4\|X_s\|_{L^2(I)}.}
\tag{5}
\]

Translations and reflection commute with \(P\) and preserve pole neutrality, so (5) applies to every translated/reflected field appearing in the two-lobe source, on its exact corresponding interval. This is a test-space estimate; it does not claim a bounded inverse of convolution by \(k_s\) on arbitrary output functions. There is no omitted initial history or artificial extension at the right endpoint.

## 3. The actual two-lobe Schur forcing

Retain the actual original source

\[
f_{a,\sigma}(x)=\frac{k_s(x-a)+\sigma k_s(x+a)}{\sqrt{2n_s}},
\quad n_s=\|k_s\|_2^2,\quad \sigma\in\{+1,-1\},
\]

and its unit-collared aperture \(L=2a+2s+2\). Let \(p\) be its legal finite approximation with the same lobe coefficient, reflection parity, exact pole moments, and recorded norm error. Let \(\eta_{\rm sp}\) be the selected negative-threshold shift, and write the actual Schur forcing as

\[
b=\Pi_S(H+\eta_{\rm sp}I)p.
\]

The contact provenance proof gives exactly

\[
b-\eta_{\rm sp}\Pi_Sp
=\Pi_S(A_{\rm arch}p-\mathcal T_\Lambda p).
\tag{6}
\]

The elementary pole operator is absent because the trial is exactly pole-neutral. The original prime action retains all four terms:

\[
\mathcal T_\Lambda f_{a,\sigma}(x)
=\frac{F_{k_s}(x-a)+F_{k_s}(a-x)
+\sigma F_{k_s}(x+a)+\sigma F_{k_s}(-x-a)}{\sqrt{2n_s}}.
\tag{7}
\]

For the physical interval of length \(L\), all positive arguments in (7) lie in \([0,L]\), and the native fields vanish on the remaining negative arguments. Applying (4) to each test in (7) yields

\[
\boxed{
\|\Pi_S\mathcal T_\Lambda f_{a,\sigma}\|_2
\le8\sqrt{\frac2{n_s}}\,\|X_s\|_{L^2(0,L)}.
}
\tag{8}
\]

The phase \(\sigma\) remains in the exact equation (7). The norm upper bound (8) is allowed to use the triangle inequality; no phase-dependent lower bound is inferred from it.

Let \(\mathcal E_L\) be the genuine projected form error from the finite bridge. The contact note proves

\[
\mathcal E_L\le C_Q(1+L)e^{L/2}
\sqrt{1+(2\pi(K_\eta-1)/L)^2}\,\|p-f_{a,\sigma}\|_{H^1}.
\tag{9}
\]

At the fixed original scale and quartic cutoff this tends to zero with a stretched-exponential margin. With the fixed-source Archimedean bound \(C_s\), (6)–(9) give

\[
\boxed{
\|b-\eta_{\rm sp}\Pi_Sp\|_2
\le C_s+8\sqrt{\frac2{n_s}}\,\|X_s\|_{L^2(0,L)}
+\mathcal E_L.
}
\tag{10}
\]

The known shift term is not declared zero. This is the exact input appropriate to the constrained Schur equation, not an unrestricted ground equation.

## 4. The arithmetic mask and controlled sector apply directly

The original source derivatives give

\[
\|j_s^{(m)}\|_1\le Cs^{-4}(A/s)^m(m!)^2,
\qquad \|j_s\|_\infty\le Cs^{-5}.
\tag{11}
\]

The proof of Lemma 1 in Note 03 uses only these bounds, compact support, and the two equations \(J_s(1/2)=J_s'(1/2)=0\). It therefore applies to \(j_s\), with the same form of bound

\[
|N*j_s(u)|+|((\log n)N)*j_s(u)|
\le Cs^{-6}e^{-\kappa\sqrt{s}e^{u/2}}.
\tag{12}
\]

Here \(N=\sum_{n\ge1}n^{-1/2}\delta_{\log n}\), and the second notation means the locally finite integer-lattice sum weighted by \(\log n\). Since \(s\) is fixed, choose one \(B_s=B_0/s\) once and for all. The exact adaptive mask and strict long-divisor threshold then give

\[
\boxed{X_s=R_s^{\sharp}+D_s^{\sharp}+r_s^{\sharp}
=R_s^{\sharp}+E_s^{\sharp},
\qquad
\forall\epsilon>0:\ \|E_s^{\sharp}\|_{\epsilon,[0,\infty)}
\le C_{\epsilon,s}<\infty.}
\tag{13}
\]

To make the residual completely explicit, use the same increasing primorial \(P(u)\) and the same fixed subexponential rough-core cutoff \(Z(u)\) as Note 03. For one fixed width budget \(d\ge s\), put

\[
Y(u)=\frac{e^u}{B_sP(u)u^2},\quad
X(u)=e^{u+d},\quad L_c(u)=B_sP(u)e^d u^2.
\]

For \(u\ge1\), define

\[
\boxed{
R_s^{\sharp}(u)=
\sum_{\substack{k\le X(u)\\b_{L_c(u)}(k)>Z(u)}}
\frac{w_{P(u)}(k)A_{Y(u)}(k)}{\sqrt k}
j_s(u-\log k),
}
\tag{14}
\]

and set it to zero on the earlier interval. Here \(D_s^{\sharp}\) is exactly the complementary small-rough-core sector of the long-divisor field, \(r_s^{\sharp}\) is the complete discarded short-divisor field, and \(E_s^{\sharp}=D_s^{\sharp}+r_s^{\sharp}\). The complete initial native history is retained in \(r_s^{\sharp}\). The cofactor range is \(m<L_c(u)=O_s(u^2\log(u+2))\). Equation (13) follows from the uniform integer-drive error and the fixed-scale Rankin sector bound, with no mean Möbius estimate. The residual (14) keeps its entire signed product coefficient and all of its quadratic cross terms.

Combining (10) and (13), for every \(\epsilon>0\), gives the explicit projected arithmetic inequality

\[
\boxed{
\begin{split}
\|b-\eta_{\rm sp}\Pi_Sp\|_2
\le {}&C_s+\mathcal E_L\\
&+8\sqrt{\frac2{n_s}}e^{\epsilon L}
\left[\|R_s^{\sharp}\|_{\epsilon,[0,L]}+C_{\epsilon,s}\right].
\end{split}
}
\tag{15}
\]

There is one fixed original \(q_s\), one fixed arithmetic kernel \(j_s\), one fixed compensated cofactor constant, and the exact original finite source history in (15).

The same compact duality applies directly to the original unit trial \(f_{a,\sigma}\), which is itself pole-neutral. Consequently the actual original witness also satisfies

\[
\boxed{
|\mathcal Q(f_{a,\sigma})|
\le C_s+8\sqrt{\frac2{n_s}}e^{\epsilon L}
\left[\|R_s^{\sharp}\|_{\epsilon,[0,L]}+C_{\epsilon,s}\right].
}
\tag{15a}
\]

This is the direct original-phase closing inequality. It does not require replacing the witness by a selected ground or claiming a sign for a Schur diagonal.

## 5. Keeping the original smoothing also makes optional probes uniform

For completeness, the fine-probe route has no unavoidable deterioration in its arithmetic constant if its actual measured source is retained. For \(0<\delta\le s\), let \(b_\delta=q_\delta*q_\delta\), and define

\[
j_{s,\delta}=j_s*b_\delta=P^2(q_s*b_\delta),
\qquad X_{s,\delta}=\Pi*j_{s,\delta}=b_\delta*X_s.
\tag{16}
\]

This is exactly the measured field \(F_{h_\delta}*q_s\) used in the source-transport probe construction. Positivity and mass one of \(b_\delta\) imply

\[
\|j_{s,\delta}^{(m)}\|_1\le\|j_s^{(m)}\|_1,
\qquad \|j_{s,\delta}\|_\infty\le\|j_s\|_\infty,
\tag{17}
\]

uniformly as \(\delta\downarrow0\). Its support is contained in \([-3s,3s]\), and its transform is
\((p^2-1/4)^2Q_s(p)Q_\delta(p)^2\), with the same exact double pole zeros. Hence (12) and the entire arithmetic decomposition (13) hold uniformly in the probe scale, with \(s\), not \(\delta\), controlling the Gevrey constant.

Choose the common width budget \(d=3s\) in (14), and use it for every \(0\le\delta\le s\), where the case \(\delta=0\) means \(j_{s,0}=j_s\). Write the resulting decomposition as

\[
X_{s,\delta}=R_{s,\delta}^{\sharp}+E_{s,\delta}^{\sharp},
\quad
\sup_{0\le\delta\le s}
\|E_{s,\delta}^{\sharp}\|_\epsilon\le C_{\epsilon,s}.
\tag{18}
\]

The time-dependent mask and rough-core threshold do not commute with convolution. Their exact discrepancy is nevertheless already controlled, because (16) and (18) give

\[
\boxed{
R_{s,\delta}^{\sharp}-b_\delta*R_{s,0}^{\sharp}
=b_\delta*E_{s,0}^{\sharp}-E_{s,\delta}^{\sharp}.
}
\tag{19}
\]

Thus weighted Young's inequality, with the exact mass
\(\int e^{-\epsilon u}b_\delta(u)du=Q_\delta(\epsilon)^2\), proves

\[
\|R_{s,\delta}^{\sharp}-b_\delta*R_{s,0}^{\sharp}\|_\epsilon
\le\big[Q_\delta(\epsilon)^2+1\big]C_{\epsilon,s}.
\tag{20}
\]

This is uniform in \(\delta\le s\). The initial supports lie strictly to the right of \(2\delta\), so no negative-time history is lost. On a prefix the corresponding bound is

\[
\|R_{s,\delta}^{\sharp}\|_{\epsilon,[0,T]}
\le Q_\delta(\epsilon)^2
\|R_{s,0}^{\sharp}\|_{\epsilon,[0,T+2\delta]}
+\big[Q_\delta(\epsilon)^2+1\big]C_{\epsilon,s}.
\tag{21}
\]

Consequently it would be incorrect to impose a cofactor budget \(O(L^4\log L)\) merely because an auxiliary \(\delta\) is of order \(L^{-2}\). That loss occurs if the original \(q_s\) convolution is removed before the arithmetic estimate. The actual mixed measurement (16) keeps a fixed-source \(O_s(u^2\log u)\) cofactor budget. The direct projection theorem (5) is simpler still and requires no probe.

## 6. What would close, and what remains unproved

A sufficient fixed-source input is now

\[
\boxed{
\forall\epsilon>0:\quad
\|R_s^{\sharp}\|_{\epsilon,[0,\infty)}<\infty.
}
\tag{22}
\]

This is **OPEN**. If it were established independently, take one of the actual original deep phase sequences, with \(\mathcal Q(f_{a,\sigma})\le-e^{\beta L}\), and choose \(0<\epsilon<\beta\). Equation (15a) would then contradict its exponential depth. Equivalently, (13) would give the same all-positive-damping property for \(X_s\), and the exact relation \(F_{h_s}=q_s*X_s\) would give it for the original detector field; the original universal visibility and Laplace-pole argument would exclude every off-line zero. The same bound would make the unshifted part of the actual Schur forcing in (15) subexponential, with its original detector, phase, pole moments and finite approximation retained.

The unconditional absolute estimate available from the retained source is only

\[
|X_s(u)|\le C_s(1+u)e^{u/2},\qquad
\|X_s\|_{L^2(0,L)}\le C_s(1+L)e^{L/2}.
\tag{23}
\]

Indeed active integers satisfy \(e^{u-s}\le n\le e^{u+s}\); count them, use \(\Lambda(n)\le\log n\), and use the fixed bound on \(j_s\). This is a genuine upper bound on the actual source, but its exponent does not contradict an original deep rate \(\beta<1/2\). Combining it with the proved predecessor inverse of size \(\operatorname{poly}(L)e^{-\beta L}\) gives at best a quadratic-response upper bound of order \(\operatorname{poly}(L)e^{(1-\beta)L}\), before retaining the known shift and signed diagonal. That estimate also does not oppose depth \(e^{\beta L}\). Positivity of \(q_s\) leaves \(P^2q_s\) signed; the exact squared-kernel sign calculation in Note 02 explains why the positive precursor cannot simply be inserted as a positive arithmetic energy.

An upper bound on the positive response term alone does not establish the sign of the Schur complement: the diagonal part and the known shift in (6) remain. Thus (15) is not declared to contradict the deep threshold merely because its predecessor inverse is small. The closing implication through (22) uses the original native correlation via (2), and needs the independent full signed arithmetic bound.

The final improvement is concrete. The previous distinction \(F_{h_s}=k_s*F_{k_s}\) no longer requires an unjustified inverse of \(k_s\) for projected forcing. Pole neutrality supplies a compact test-space inverse of the elementary operator \(P\), and its resulting field has exactly the double-zero integer drive required by Path A. The retained positive original precursor also makes any fine-probe arithmetic constants uniform. What is still missing is cancellation of the full signed residual (14), not a source adapter or a fine-probe scale budget.

## Source record and status

- Root `01_TWO_SIDED_PHASE_AND_POLE_NEUTRAL_SOURCE.md`, Theorem K: compact pole-neutral inverse of \(P\).
- Current `../source_transport/04_DIRECT_POLE_NEUTRAL_FORCING_BRIDGE.md`, Sections 1–4: the interval, compact-inverse, original witness, and source-reconstruction estimates underlying (5) and (15a).
- Contact provenance `02_ACTUAL_DETECTOR_FORCING_IN_THE_SCHUR_IDENTITY.md`: exact actual forcing, four prime translates, Archimedean term, known shift, and finite approximation error.
- Note 03 in this branch, Lemma 1, and prior Path A mask/core proofs: integer drive and stable arithmetic decomposition.
- Equations (1)–(21), including (15a), and the elementary estimate (23), with their stated hypotheses, are proved adapters and bounds. Equation (22) is explicitly **OPEN**. No RH conclusion is claimed.
