"""Verify every listed payload byte and reject unexpected payload files."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
expected=manifest['files']
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST_SHA256.json' and '__pycache__' not in p.parts}
if actual != set(expected):
    raise SystemExit(f'File-set mismatch: missing={set(expected)-actual}; extra={actual-set(expected)}')
for rel,rec in expected.items():
    data=(ROOT/rel).read_bytes()
    if len(data)!=rec['bytes'] or hashlib.sha256(data).hexdigest()!=rec['sha256']:
        raise SystemExit('Hash mismatch: '+rel)
print(f'PASS: {len(expected)} exact payload files. Integrity only; RH remains OPEN.')
