# 3. Constructing the least-cost correction under the full native jet constraints

**Status: PAPER deduction.** B04 already proved the no-polynomial-loss Laguerre leakage lower bound. That lower bound is not claimed as new here. This section adds an explicit minimum-norm constructor for arbitrary finite collections of jets, preserves their cross-phases, and applies the bound to every stable future completion that keeps an exact original prefix.

## 3.1 Complete source jets

Fix $\epsilon>0$ and retain $X$, $y_{\triangle}$, and $A_{\triangle}$. Work in

$$H_\epsilon=L^2([0,\infty),e^{-2\epsilon t}\,dt).$$

Let $z\in H_\epsilon$ agree with the actual locally defined $X$ on $[0,T]$. This includes, but is not restricted to, the zero extension of the original prefix. Define

$$r=y_{\triangle}-a_{\triangle}*z.$$

Causality gives $r=0$ almost everywhere on $[0,T]$. At each hypothetical right zero $\lambda_i=\rho_i-1/2$ of multiplicity $m_i$, with $\Re\lambda_i>\epsilon$, bounded Laplace evaluation gives

$$
\int_T^\infty(-t)^j e^{-\lambda_i t}r(t)\,dt
=b_{i,j}:=\widehat y_{\triangle}^{(j)}(\lambda_i),
\qquad0\le j<m_i. \tag{3.1}
$$

The native data are

$$b_{i,j}=0\ (j<m_i-1),\qquad
b_{i,m_i-1}=-c_{3/2}(\lambda_i)J_s(\lambda_i)\zeta^{(m_i)}(\rho_i)\ne0.$$

All complex phases remain. No uniform lower bound on $\zeta^{(m_i)}(\rho_i)$ is assumed.

## 3.2 Solve the finite moment problem exactly

Let $F$ be any finite list of distinct $\lambda_i$ with their indicated jets. Put

$$w_{i,j}(t)=(-t)^j e^{-\lambda_i t}1_{t\ge T}.$$

The finite Hermitian Gram matrix is

$$
\begin{split}
G_{(i,j),(\ell,k)}(T)
&=\int_T^\infty w_{i,j}(t)\overline{w_{\ell,k}(t)}e^{2\epsilon t}\,dt\\
&=(-1)^{j+k}\int_T^\infty t^{j+k}
 e^{-(\lambda_i+\overline{\lambda_\ell}-2\epsilon)t}\,dt.
\end{split} \tag{3.2}
$$

Every entry is explicit. For $h=j+k$ and $a=\lambda_i+\overline{\lambda_\ell}-2\epsilon$,

$$\int_T^\infty t^h e^{-at}\,dt
=e^{-aT}\sum_{r=0}^{h}\frac{h!}{(h-r)!}\frac{T^{h-r}}{a^{r+1}}.$$

The exponential-polynomial functions are linearly independent on an interval. Hence $G(T)$ is strictly positive definite. The unique least-norm tail satisfying this finite set of requirements is

$$
\boxed{
 r_F^*(t)=e^{2\epsilon t}\sum_{(i,j)\in F}
 [G(T)^{-1}b]_{i,j}\,\overline{w_{i,j}(t)},
\qquad
\|r_F^*\|_\epsilon^2=b^*G(T)^{-1}b.
} \tag{3.3}
$$

To prove this, substitute the expression into (3.1), which gives $G G^{-1}b=b$. Every other admissible tail differs by a vector orthogonal to all the Riesz kernels, so Pythagoras proves minimality. This is a construction, not only a lower estimate.

If the list is closed under complex conjugation and its data have native conjugate symmetry, uniqueness implies $r_F^*$ is real. A minimizer using only one member of a nonreal conjugate pair is generally complex. Its cost is a valid lower bound for real tails, but it is not the sharp paired real-source problem.

**Feasibility boundary.** Equation (3.3) solves only the finite moment constraints. It need not be realizable as $y_{\triangle}-a_{\triangle}*z$ for a stable native output continuation, and need not satisfy unlisted native jets. It is a rigorous lower relaxation of that problem. Its existence cannot be promoted into native inverse solvability.

## 3.3 B04's sharp single-zero cost, now with an explicit minimizer

Let $\lambda=\beta+i\gamma$, $d=\beta-\epsilon>0$, $m\ge1$, $n=m-1$, and $c=b_{m-1}$. Define the monic Laguerre polynomial

$$Q_n(u)=\frac{(-1)^n n!}{(2d)^n}L_n(2du),\qquad
K_n=\int_0^\infty e^{-2du}Q_n(u)^2du
=\frac{(n!)^2}{(2d)^{2n+1}}.$$

The finite single-zero problem has the minimizer

$$r^*(t)=\frac{(-1)^n c e^{2dT}}{K_n}
 e^{(2\epsilon-\overline\lambda)t}Q_n(t-T)1_{t\ge T}.$$

Orthogonality to all lower powers gives every lower jet zero, while the top jet is exactly $c$. Its norm is

$$
\boxed{
\|r^*\|_\epsilon^2
=\frac{(2d)^{2m-1}}{((m-1)!)^2}|c|^2e^{2dT}.
} \tag{3.4}
$$

For the actual real problem, include the conjugate zero in (3.3). In either case every stable $z$ agreeing with $X$ on $[0,T]$ obeys the lower bound (3.4). Redesigning the tail cannot improve this bound to a subexponential cost while keeping those exact native conditions, under the hypothetical zero.

Applying the same bound to $z=1_{[0,T]}X$ and using $\|a_{\triangle}*z\|_\epsilon\le q\|z\|_\epsilon$ gives

$$
\|X\|_{\epsilon,[0,T]}
\ge \frac{|c|(2d)^{m-1/2}}{q(m-1)!}e^{dT}
-\frac{\|y_{\triangle}\|_\epsilon}{q}. \tag{3.5}
$$

Thus the lower obstruction holds at every sufficiently large horizon, not only at a favorable original two-lobe phase. This is the B04 full-jet argument applied to the unchanged new fixed source; no greatest-displacement zero is needed.

## 3.4 The exact residual of the constructed iteration

For $T=0$, (3.3) is the squared norm of the projection of $y_{\triangle}$ onto the finite native adjoint-jet space. B04's full range characterization implies that these finite spaces span densely the entire adjoint kernel. Therefore the residual of Section 2 satisfies

$$
\boxed{
\|e_\infty\|^2
=\sup_{F\text{ finite native right jets}}b_F^*G_F(0)^{-1}b_F.
} \tag{3.6}
$$

The damping is included in (3.2); the two Hilbert-space conventions are related by multiplication by $e^{-\epsilon t}$. Formula (3.6) preserves the cross terms between zeros, multiplicities, and the original source values. It does not replace this Hermitian Gram matrix by complex-symmetric spectral residue data.

Equations (2.5) and (3.6) provide a primal construction and its exact dual obstruction. They do not establish that the supremum is zero. The finite Gram controls in the code use synthetic rational zero coordinates solely to test algebra; they are not assertions of native zeros.
