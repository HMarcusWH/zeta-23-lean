# B04.2 — The exact closed-range obstruction is the native zero divisor

**Status:** PAPER functional-analysis deduction under the B03 exact kernel and classical Hardy factorization. No independent native range membership is claimed. The conclusion is a precise characterization of the obstruction, not a shortcut around it.

## Original operator and transform convention

For `epsilon>0`, let `H=L²(0,infty)`. The unitary (up to normalization) Laplace/Paley–Wiener map identifies H with the Hardy space `H²(C_+)` by

\[
\mathscr Lg(z)=\int_0^\infty e^{-zt}g(t)\,dt,\qquad \Re z>0.
\]

For the native positive forward kernel `a_N` of B03,

\[
A(p)=\mathscr L a_N(p)
=\frac{p-1/2}{(p+1/2)(p+1)}\zeta(p+1/2)
\]

with the apparent `p=1/2` singularity removable. The actual damped convolution `A_epsilon g=(e^{-epsilon .}a_N)*g` becomes multiplication by

\[
\mathcal A_\epsilon(z)=A(z+\epsilon).
\]

Because `0<a_N(t)<= (3/2)e^{-t/2}`, `mathcal A_epsilon in H^infty(C_+)`. It is not the zero function, and is analytic across every *finite* point of the boundary `Re z=0` (the zeta pole cancels; epsilon>0 keeps the other denominator singularities outside a boundary neighborhood).

The only zeros in `Re z>0` are the points

\[
z=\rho-\tfrac12-\epsilon
\]

where `rho` is a nontrivial zeta zero with `Re rho>1/2+epsilon`; multiplicities agree. No elementary positive-real zero survives the cancellation at `p=1/2`.

## Why the inner factor is only a Blaschke product

Canonical inner–outer factorization for a nonzero `H^infty(C_+)` multiplier yields a Blaschke factor `B_epsilon`, a singular inner factor supported on the boundary/infinity, and an outer factor.

A nonzero singular inner boundary measure would obstruct analytic continuation across points in its support. The explicit zeta formula analytically continues through each finite point of `Re z=0`, so no such finite-boundary singular measure occurs. An inner delay factor `exp(-cz)` with `c>0` is also impossible: the original kernel has `a_N(t)=1+O(t)` for `t↓0` and hence `A(p)=p^{-1}+O(p^{-2})` on the positive real axis as `p→infty`. Its exponential mean type is zero. Thus the singular inner part is constant.

**Conclusion (closed-range formula):**

\[
\boxed{\overline{\operatorname{Ran} \mathsf A_\epsilon}
\quad\stackrel{\mathscr L}{\longleftrightarrow}\quad
B_\epsilon H^2(\mathbb C_+).}
\tag{B04-RANGE}
\]

The zeros of `B_epsilon` are precisely the native right off-line zeta zeros farther than epsilon from the critical line, including multiplicity. Under the Paley–Wiener identification, a vector `w∈H` belongs to that closed range iff, for every such `rho` of multiplicity `m`, its Laplace transform satisfies

\[
\frac{d^j}{dz^j}(\mathscr Lw)(z)\bigg|_{z=\rho-1/2-\epsilon}=0,
\qquad j=0,\ldots,m-1.
\]

The necessity is direct. For sufficiency, all Blaschke zeros with their multiplicities divide the inner factor of `mathscr Lw`, so `mathscr Lw/B_epsilon ∈H²`. This statement uses the absence of singular inner factors just proved; it would not hold for a general bounded causal kernel with an unexamined singular inner divisor.

## The actual input lies outside the range in the hypothetical non-RH case

B03's input has the exact transform

\[
V(p)=-\frac{b(p)}{p+1}\zeta'(p+1/2)K(p),\quad
b(p)=\frac{p-1/2}{p+1/2}.
\]

At a native zero `rho` of multiplicity `m`, its derivatives of order `0,...,m-2` vanish, but

\[
V^{(m-1)}(\rho-1/2)
=-\frac{b(\lambda)K(\lambda)}{\lambda+1}\zeta^{(m)}(\rho)\ne0.
\]

Therefore `v_epsilon` fails exactly the final required jet at every hypothetical right zero, agreeing with the B03 adjoint-distance bound.

For fixed epsilon, this gives a full conditional equivalence:

\[
\boxed{
 v_\epsilon\in\overline{\operatorname{Ran}\mathsf A_\epsilon}
\iff
\zeta(s)\ne0\quad(\Re s>1/2+\epsilon).
}
\tag{B04-FIREWALL}
\]

The direction from right to left uses the zero-free right-half-plane to make `B_epsilon=1`; it does not require a stable bounded inverse. The direction from left to right uses the source-specific final derivative nonvanishing. These are *equivalent mathematical claims*, not independent evidence that the actual right half-plane is zero-free.

## Failed attempted proof and exact residual

One tempting construction approximates `v_epsilon` by `A_epsilon g_T` where `g_T` is an actual-output finite truncation. Causal equality ensures the residual is supported beyond T, but the sharp Laguerre estimate in note 01 proves that under a hypothetical off-line zero,

\[
\|v_\epsilon-\mathsf A_\epsilon g_T\|_2
\ge c_{\rho,\epsilon} e^{(\Re\rho-1/2-\epsilon)T}.
\]

No limit of these residuals is proved to approach zero. Any approximate-range argument must construct its approximants without assuming the unknown global output belongs to L², and must control their **complete global residual** independently of that output. That is the missing theorem.

The zero divisor fully accounts for the closed-range obstruction: there is no additional singular Hardy factor to remove. This is useful dependency compression, but it also proves that a clever abstract density assertion with no genuine native information would simply disguise RH.

## Domain checks and falsification

The Laplace transforms start as ordinary integrals on their stated Hardy half-plane. `a_N` is an integrable causal kernel. `v_epsilon ∈ L²` is inherited from B03. Evaluation of finitely many Hardy derivatives at an interior point is bounded, since `t^j e^{-\sigma t} ∈L²` for `sigma>0`. No differentiation of a global undamped Suzuki orbit is used. The same-input positive-kernel perturbation from B03 shows that positivity, an exponential envelope, and agreement on a finite causal prefix alone cannot force the closed-range property; it does not contradict the exact native divisor characterization above because it changes the global multiplier.
