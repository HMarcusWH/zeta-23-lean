#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
pandoc RH_Constructive_Continuation_Paper.md --standalone --from=markdown+tex_math_dollars --include-in-header=paper_header.tex --pdf-engine=xelatex -o RH_Constructive_Continuation_Paper.pdf
