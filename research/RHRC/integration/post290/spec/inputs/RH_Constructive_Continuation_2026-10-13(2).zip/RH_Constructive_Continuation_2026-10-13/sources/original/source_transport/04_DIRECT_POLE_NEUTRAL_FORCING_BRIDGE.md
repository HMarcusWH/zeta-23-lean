# The direct original-source bridge, and a quantitative smoothing adapter

Date: 13 October 2026. Status: **new paper proof; the native signed residual estimate is still required for Step 4.**

The exact pole moments give a simpler bridge than finite-band deconvolution. They transfer the actual finite forcing to a double-pole arithmetic source built from the original positive precursor \(q_s\), with norm constant four and no boundary loss. A separate positive-kernel calculation quantifies how smoothed measurements recover this same forcing; it is useful but is not needed for the direct bridge.

## 1. The original single-detector field and its derivative

Retain the original real even sinc-product probability density \(q_s\), its fixed scale \(s\), and

\[
P=\partial_x^2-\frac14,\qquad k_s=Pq_s,\qquad
\Pi=\sum_{n\ge2}\Lambda(n)n^{-1/2}\delta_{\log n}.
\tag{1.1}
\]

Set

\[
F_s=\Pi*k_s,\qquad
X_s=PF_s=\Pi*j_s,\qquad
j_s=P^2q_s .
\tag{1.2}
\]

These are smooth, locally finite native prime sums. No prime weight has changed. The source \(j_s\) retains the original fixed precursor and has bilateral Laplace transform

\[
D_{j_s}(p)=(p^2-1/4)^2Q_s(p).
\tag{1.3}
\]

Thus its two elementary pole zeros are double; all its other transform zeros lie on the imaginary axis. Its support is \([-s,s]\), and its derivative bounds are exactly those of the original fixed Gevrey source after four derivatives. In particular the integer-drive cancellations needed by the arithmetic branch apply to this source. It need not be an autocorrelation in order for those linear cancellations or the native divisor identities to hold.

## 2. Compact inverse and the projection theorem

Let \(I=[A,B]\) be any finite interval. Let

\[
\mathcal N_I=\left\{\phi\in L^2(I):
\int_I\phi(x)e^{x/2}\,dx=
\int_I\phi(x)e^{-x/2}\,dx=0\right\},
\tag{2.1}
\]

with functions extended by zero outside \(I\). The compact inverse theorem gives, for every \(\phi\in\mathcal N_I\),

\[
g=P^{-1}\phi=-e^{-|\cdot|/2}*\phi,\qquad
\operatorname{supp}g\subset I,\qquad
g\in H^2(\mathbb R),\qquad
\|g\|_2\le4\|\phi\|_2.
\tag{2.2}
\]

Both \(g\) and \(g'\) have zero endpoint traces. The norm bound is the real Fourier multiplier bound
\((\xi^2+1/4)^{-1}\le4\).

For any smooth field \(F\) near \(I\), compact distributional integration by parts therefore gives

\[
\boxed{\quad
\langle F,\phi\rangle_I
=\langle PF,g\rangle_I .
\quad}
\tag{2.3}
\]

This identity has no exterior term. It uses the exact pole moments of the test, not endpoint vanishing of the nonlocal field.

Let \(\mathcal S\) be any closed subspace of \(\mathcal N_I\), including the actual finite pole-neutral predecessor or canonical carrier. Taking the supremum over unit tests in (2.3) proves

\[
\boxed{\quad
\|\Pi_{\mathcal S}(F_s|_I)\|_2
\le4\|X_s\|_{L^2(I)} .
\quad}
\tag{2.4}
\]

The estimate is independent of cutoff, dimension, phase, and the number of endpoint jets. It applies even to the full codimension-two space \(\mathcal N_I\). Translations and reflections commute with \(P\); translating or reflecting the source simply translates or reflects the observation interval in (2.4).

This is not an assertion that \(P^{-1}\) is a stable causal inverse on every positively damped space. It is a compact inverse on the exact pole-neutral test space. That distinction is why the two moment constraints remove the otherwise noncompact homogeneous terms.

## 3. The actual two-lobe forcing, with all four terms

For the original unit detector

\[
f(x)=\frac{k_s(x-a)+\sigma k_s(x+a)}{\sqrt{2n_s}},
\qquad n_s=\|k_s\|_2^2,
\tag{3.1}
\]

the symmetric prime action in the native Weil operator is

\[
\mathcal T_\Lambda f(x)
=\frac1{\sqrt{2n_s}}\left[
F_s(x-a)+F_s(a-x)+\sigma F_s(x+a)+\sigma F_s(-x-a)
\right].
\tag{3.2}
\]

The same original phase appears in each term. For a unit-collared interval of length \(L=2a+2s+2\), the positive arguments required in these four fields are at most \(L\). When \(s<\log2\), the native field vanishes at negative arguments and on \([0,\log2-s)\).

Let \(C_s^{\rm arch}\) be the fixed-source full-line archimedean bound from the source-forcing note. The two elementary pole channels vanish exactly. Equations (2.3)–(2.4), applied to all four terms, give

\[
\left\|\Pi_{\mathcal S}(W*f+\eta f)-\eta\Pi_{\mathcal S}f\right\|_2
\le C_s^{\rm arch}+
\frac{16}{\sqrt{2n_s}}\|X_s\|_{L^2(0,L)}.
\tag{3.3}
\]

The known spectral shift is displayed rather than absorbed into a discrepancy constant. For the actual finite approximation \(p\), the previously proved projected error
\(\|\Pi_{\mathcal S}W*(p-f)\|_2+\eta\|p-f\|_2\) is added exactly as in the contact-provenance note. Its quartic-cutoff Gevrey budget makes it negligible on the retained fixed-source sequence.

The same duality can be applied directly to the original unit test \(f\), without a finite projection. Consequently

\[
|\mathfrak q(f,f)|
\le C_s^{\rm arch}+
\frac{16}{\sqrt{2n_s}}\|X_s\|_{L^2(0,L)}.
\tag{3.4}
\]

Thus a suitably subexponential estimate for this actual arithmetic field would directly oppose the exponentially negative original witnesses. Equation (3.4) contains a missing estimate, not a supplied upper bound on its right side.

The small predecessor inverse from the deep-threshold construction remains valid, but (3.3) alone does not determine the sign of the complete Schur complement. The shift, shell diagonal and constrained residual must still be retained if that route is used.

## 4. Returning to the original squared detector

The original arithmetic source is \(h_s=k_s*k_s\). Since derivatives commute with compact convolution,

\[
h_s=q_s*j_s,\qquad
F_{h_s}=\Pi*h_s=q_s*X_s.
\tag{4.1}
\]

This is an exact source reconstruction by the original positive probability density. In particular, for \(\epsilon>0\),

\[
\|F_{h_s}\|_{\epsilon,[0,T]}
\le e^{\epsilon s}\|X_s\|_{\epsilon,[-s,T+s]}.
\tag{4.2}
\]

The anticipation and initial interval are explicit. For the small original scale, the negative initial part is zero by the native support.

An independently proved all-positive-damping bound for \(X_s\) would therefore give the same property for the original \(F_{h_s}\). Its exact gamma-tail dictionary then returns the original correlation \(C_s\), whose right-half-plane residues are nonzero. This closes through the original detector and the original pole argument, without any source substitution or a claimed sign theorem for a generic Schur matrix.

More quantitatively, suppose for every \(\epsilon>0\) one proved
\(\|X_s\|_{\epsilon,[0,T]}=e^{o(T)}\). For a given exponentially deep original witness rate \(\beta>0\), choose \(\epsilon<\beta\). Then
\(\|X_s\|_{L^2(0,L)}\le e^{\epsilon L+o(L)}\), and (3.4) contradicts that witness. Alternatively, use half the desired final damping and sum unit intervals to obtain global \(L^2\) at every positive damping before applying (4.2).

These are sufficient implications only. The arithmetic branch still has to bound the complete signed residual for \(j_s\).

## 5. A positive compact approximate inverse with polynomial norm

The direct bridge already establishes the needed source interface. The following independent calculation answers whether physical smoothing can recover this original forcing without an exponential inverse norm.

Let

\[
b_\delta=q_\delta*q_\delta,\qquad
\mathcal B_\delta u=b_\delta*u,\qquad
\mathcal J_{\delta,M}=\sum_{j=0}^{M-1}(I-\mathcal B_\delta)^j,
\quad M\ge1.
\tag{5.1}
\]

Because \(q_\delta\) is real and even,
\(\widehat b_\delta(\xi)=P_\delta(\xi)^2\in[0,1]\) for real \(\xi\).
Hence Plancherel gives

\[
\|\mathcal J_{\delta,M}\|_{L^2\to L^2}\le M,\qquad
\|(I-\mathcal B_\delta)^M\|_{L^2\to L^2}\le1,
\tag{5.2}
\]

and the algebraic identity is exact:

\[
I-\mathcal J_{\delta,M}\mathcal B_\delta
=(I-\mathcal B_\delta)^M .
\tag{5.3}
\]

The convolution distribution of \(\mathcal J_{\delta,M}\) is supported in
\([-2(M-1)\delta,2(M-1)\delta]\). The residual distribution has support in \([-2M\delta,2M\delta]\).

Thus on \(I=[0,L]\), writing \(w=2M\delta\),

\[
\|X_s\|_{L^2(I)}
\le M\|b_\delta*X_s\|_{L^2([-w,L+w])}
 +\|(I-\mathcal B_\delta)^MX_s\|_{L^2(I)}.
\tag{5.4}
\]

The first norm may use the slightly smaller collar \(2(M-1)\delta\); the larger one displayed is convenient. To justify its local operator bound, truncate the measured field to that larger interval and extend it by zero. On \(I\) the convolution is unchanged, and the global norm bound (5.2) applies.

At a fixed positive damping \(\epsilon\), conjugation changes the multiplier of \(I-\mathcal B_\delta\) by at most
\(e^{2\epsilon\delta}-1\), because \(b_\delta\) is a probability kernel with support radius \(2\delta\). Thus

\[
\|\mathcal J_{\delta,M}\|_{L^2_\epsilon\to L^2_\epsilon}
\le M e^{2\epsilon\delta(M-1)}\le M e^{\epsilon w}.
\tag{5.5}
\]

The corresponding local version of (5.4) holds with this factor and the displayed weighted observation interval. No exponential total-variation bound for the alternating convolution expansion is substituted for its much smaller \(L^2\) operator norm.

## 6. Exact truncation and the effective frequency scale

All estimates in this section are for the original fixed smooth source. Set

\[
U=L+w+s,\qquad
\Pi_U=\sum_{\log n\le U}\Lambda(n)n^{-1/2}\delta_{\log n},
\qquad X_{s,U}=\Pi_U*j_s.
\tag{6.1}
\]

For \(t\in[-w,L+w]\), the compact support of \(j_s\) implies
\(X_{s,U}(t)=X_s(t)\). Consequently the residual in (5.4) agrees on \(I\) with \((I-\mathcal B_\delta)^MX_{s,U}\). The truncated field is a genuinely compact smooth function on the real line, so the following global Fourier argument is legitimate.

The elementary mass bound is

\[
\|\Pi_U\|_{\rm TV}
\le 2(1+U)e^{U/2}.
\tag{6.2}
\]

The Gevrey estimate for the actual source, including its four derivatives, gives constants \(C_s,c>0\), with \(c\) independent of \(s\), such that for \(\Omega\ge1\),

\[
\|X_{s,U}\|_2\le C_s(1+U)e^{U/2},
\tag{6.3}
\]

\[
\|\mathbf1_{|\xi|>\Omega}\widehat X_{s,U}\|_{2,\rm Pl}
\le C_s(1+U)e^{U/2}e^{-c\sqrt{s\Omega}}.
\tag{6.4}
\]

Here the Fourier norm includes the Plancherel normalization. To see (6.4) directly, use
\(\widehat j_s(\xi)=(\xi^2+1/4)^2P_s(\xi)\) and bound the squared tail by a constant times

\[
\|\Pi_U\|_{\rm TV}^2
\int_\Omega^\infty(1+\xi)^8e^{-2c_*\sqrt{s\xi}}\,d\xi.
\tag{6.5}
\]

Substitution \(v=\sqrt{s\xi}\) leaves a fixed polynomial in \(v\) times \(e^{-2c_*v}\), with a fixed power of \(s^{-1}\). Absorbing that polynomial into a smaller exponential proves (6.4). Since \(s\) is fixed, this introduces no hidden horizon dependence.

If \(\delta\Omega=\theta<\pi/2\), then on \(|\xi|\le\Omega\),
\(1-P_\delta(\xi)^2\le\sin^2\theta\). Splitting the residual into the two frequency ranges gives

\[
\|(I-\mathcal B_\delta)^MX_s\|_{L^2(I)}
\le C_s(1+U)e^{U/2}
\left[(\sin^2\theta)^M+e^{-c\sqrt{s\Omega}}\right].
\tag{6.6}
\]

Fix \(0<\theta\le1/2\) and a desired error rate \(\eta>0\). Choose constants \(\mu,A>0\) satisfying

\[
\mu\log\frac1{\sin^2\theta}>\frac12+2\eta,
\qquad c\sqrt A>\frac12+2\eta.
\tag{6.7}
\]

Take

\[
M=\lceil\mu L\rceil,\quad
\Omega=\frac{A L^2}{s},\quad
\delta=\frac{\theta s}{A L^2},\quad
w=2M\delta=O_s(L^{-1}).
\tag{6.8}
\]

Then \(U=L+s+O_s(L^{-1})\), and (6.6) is at most
\(C_{s,\eta}e^{-\eta L}\) for large \(L\). Equations (5.4)–(5.5) prove the quantitative recovery

\[
\boxed{\;
\|X_s\|_{\epsilon,[0,L]}
\le M e^{\epsilon w}
\|b_\delta*X_s\|_{\epsilon,[-w,L+w]}
+C_{s,\eta}e^{-\eta L},
\quad \epsilon\ge0.
\;}
\tag{6.9}
\]

For \(\epsilon>0\), the unweighted residual bound is also an upper bound for its norm on \([0,L]\). This supplies the required weighted version without a fictitious positive Fourier symbol on a shifted line.

Combining (2.4) and the unweighted case gives the corresponding finite-projection recovery with leading coefficient \(4M\). This argument improves the needed probe scale from the nominal band scale \(L^{-3}\) to the effective original-source scale \(s/L^2\), with a polynomial inverse norm and a shrinking observation collar. It uses the original Gevrey source; it does not declare that an arbitrary selected finite ground has those bounds.

## 7. The measured arithmetic kernel retains the original precursor

The measured field in (6.9) is exactly

\[
b_\delta*X_s
=\Pi*j_{s,\delta}=F_{h_\delta}*q_s,\qquad
j_{s,\delta}=P^2(q_s*b_\delta).
\tag{7.1}
\]

The original positive \(q_s\) must remain in this identity. Since \(b_\delta\) is a positive probability kernel,

\[
\|j_{s,\delta}^{(j)}\|_1
\le\|j_s^{(j)}\|_1,\qquad
\operatorname{supp}j_{s,\delta}\subset[-s-2\delta,s+2\delta].
\tag{7.2}
\]

Both elementary transform zeros remain double. Consequently the fixed-\(s\) Gevrey, integer-drive, compensated-mask and controlled-sector constants can be uniform as \(\delta\to0\). Bounding \(F_{h_\delta}\) separately would throw away precisely this useful retained source information.

The arithmetic branch supplies that uniform mixed-source reduction, and also applies it directly at \(\delta=0\) to \(X_s\). The latter is the simplest closing target for (2.4), (3.3) and (3.4).

## 8. Final closing attempt and the remaining signed estimate

The exact direct bridge removes the single-pole obstruction in the actual projected forcing by moving \(P\) onto the field and using the compact inverse on the legal test. It retains the original positive precursor, fixed scale, native prime weights, all four source phases, and actual finite observation interval. The uniform mixed-source arithmetic reduction then controls its integer-drive error and one rough-core sector with the original scale constants.

The complete signed residual of \(\Pi*P^2q_s\) is still not bounded by those facts. The original phase and positivity of \(q_s\) do not turn \(P^2q_s\) into a nonnegative kernel, and the exact mask decomposition retains its signed cross terms. No independent lower bound for the full selected Schur energy is inferred from the norm transfer.

The positive approximate inverse does not manufacture the missing arithmetic estimate either. Using a much coarser sensor while preserving the same elementary residual proof would require controlling its multiplier throughout the effective band or increasing the number of compact convolution steps. Such an increase also enlarges the observation collar; a subexponential algebraic inverse cost alone is not enough if it moves the required history beyond the original horizon. No unproved uniform lower bound across the coarser sensor's real Fourier zeros is used here.

A sufficient closing input is now particularly direct: an all-positive-damping subexponential prefix bound for the full signed residual of the **fixed original source \(j_s=P^2q_s\)**, with the controlled sectors and finite histories retained. The arithmetic companion states that residual explicitly. Equations (3.4) and (4.1)–(4.2) show how such a bound would oppose the original witness and close through its original correlation. The bound itself has not been proved.

### Dependencies and independent review

- The root note supplies the compact inverse theorem and the two-sided original detector witnesses.
- The source-forcing note in contact_provenance supplies the exact four translated/reflected native prime fields, archimedean bound, spectral shift and finite approximation error.
- detector_arithmetic/04_FIXED_ORIGINAL_PRECURSOR_AND_PROJECTED_FORCING.md supplies the uniform arithmetic reduction for \(P^2q_s\) and its positive probability smoothings.
- Notes 01–03 in this directory supply the original fixed source, optional high-jet construction and independent finite-band boundary theorem.

The compact-duality/projection theorem was independently checked by the root and contact branches. The positive compact approximate inverse, exact truncation, effective-band estimate and weighted local norm bounds are proved in Sections 5–6 above. All are paper arguments, not newly compiled claims.
