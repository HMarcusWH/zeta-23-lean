# Constraint campaign: native birth, squared energy, and the scale limit

Date: 13 October 2026. Status: **PAPER / DERIVED; not formalized.**

This note uses the actual \(q_r\), \(k_r\), \(h_r\), prime weights, and dyadic refinement of Note 01. It proves a precise limitation of one proposed closing argument: positive refinement does not supply a uniformly integrable scale martingale. That failure already occurs at the first native prime and does not require any hypothetical off-line zero. It does not rule out a different arithmetic estimate or a finite, quantitatively chosen refinement.

## 1. The positive primitive is retained exactly

Let

\[
\Pi=\sum_{n\ge1}\frac{\Lambda(n)}{\sqrt n}\delta_{\log n},
\qquad G_r=\Pi*b_r,\qquad b_r=q_r*q_r\ge0.
\]

The underlying field is nonnegative and

\[
\boxed{F_r=(\partial^2-1/4)^2G_r.}
\tag{1}
\]

No positivity of \(F_r\) follows from (1). The two exact pole moments are part of this derivative operation. If \(g_r(t)=e^{-t/2}G_r(t)\), then

\[
e^{-t/2}F_r(t)=\partial^2(\partial+1)^2g_r(t).
\tag{2}
\]

This is an exact conjugation identity, not an upper bound on those derivatives.

## 2. The dyadic chain is a martingale with the complete history

Fix the original \(r\le r_*\), a real damping \(\epsilon\), and a finite observation time \(t\). Put \(r_j=r/2^j\). Let \(U_j\), \(j\ge0\), be independent with laws
\(\sigma^\epsilon_{r_j,r_{j+1}}\) from Note 01. Write

\[
S_0=0,\qquad S_j=\sum_{i<j}U_i,
\qquad
\mathcal M_j=
\frac{e^{-\epsilon(t-S_j)}F_{r_j}(t-S_j)}{Q_{r_j}(\epsilon)^2}.
\tag{3}
\]

Every \(\mathcal M_j\) is bounded for that fixed \(j\): its time argument lies in a fixed compact interval, and the native sum is locally finite. Equation (4) of Note 01, with the tilted probability, gives

\[
\boxed{
\mathbb E(\mathcal M_{j+1}\mid U_0,\ldots,U_{j-1})
=\mathcal M_j.
}
\tag{4}
\]

Thus this is a genuine real martingale, with constant mean
\(e^{-\epsilon t}F_r(t)/Q_r(\epsilon)^2\). Its conditional variance is exactly the positive variance in Note 01. There is no assumption of a globally finite norm in (4).

Because \(|U_j|\le r_j\), the full history converges absolutely and

\[
|S_\infty-S_j|\le2r_j.
\tag{5}
\]

The probability law of \(S_\infty\) is explicitly

\[
\boxed{
\frac{e^{-\epsilon u}b_r(u)}{Q_r(\epsilon)^2}\,du.
}
\tag{6}
\]

To prove (6), first take \(\epsilon=0\). For each original width, the sum of the independent binary signs reconstructs one uniform variable on that width. The two copies in \(\sigma\) therefore reconstruct \(q_r*q_r\). For general damping the product of the finite tilting factors is
\(e^{-\epsilon S_j}Q_{r_j}(\epsilon)^2/Q_r(\epsilon)^2\).
The compact convergence \(S_j\to S_\infty\), \(Q_{r_j}(\epsilon)\to1\), proves (6) by integration against any continuous function. The density is smooth and in particular has no atoms.

## 3. The actual first prime disproves uniform integrability of this chain

The set \(\{\log n:n\ge2\}\) is locally finite. By (6), with probability one,
\(t-S_\infty\) is not in this set. Its distance from this set is then positive. By (5), once \(r_j\) is sufficiently small, no point \(\log n\) can lie within \(2r_j\) of \(t-S_j\). The support of \(h_{r_j}\) gives

\[
\boxed{\mathcal M_j=0\text{ eventually, almost surely.}}
\tag{7}
\]

Now choose a time \(t\) at which \(F_r(t)\ne0\). Such a time is supplied by the actual first-prime window: since
\(4r_*<\log(3/2)\), on \([\log2-2r,\log2+2r]\) the only possible nonzero native coefficient is that of \(2\). Hence

\[
F_r(t)=\frac{\log2}{\sqrt2}h_r(t-\log2)
\quad\text{on this window},
\tag{8}
\]

and \(h_r\) is not identically zero. Therefore (3) has a nonzero constant mean, whereas (7) says that its almost-sure limit is zero.

It follows that

\[
\boxed{
\{\mathcal M_j\}\text{ is not uniformly integrable},
\qquad
\sup_j\mathbb E|\mathcal M_j|^2=\infty.
}
\tag{9}
\]

For the second assertion no convergence theorem beyond an elementary truncation is needed. A uniform second-moment bound would give
\(\mathbb E[|\mathcal M_j|1_{|\mathcal M_j|>K}]\le C/K\).
On \(|\mathcal M_j|\le K\), bounded convergence using (7), followed by \(K\to\infty\), would force the means to tend to zero, a contradiction. The second moments are nondecreasing by (4), so they actually tend to infinity.

The same construction with \(G_{r_j}\) in place of \(F_{r_j}\) gives a nonnegative martingale with limit zero and positive mean whenever \(G_r(t)>0\). Thus restoring the positive precursor does not repair this particular scale-limit argument. The failure is concentration on shrinking native atom windows, not a claim that any RH-violating mode exists.

For the complete spectral field, at times beyond all shifted support boundaries, the gamma tail must also be transported. The exact combination \(-C_{r_j}-A_{r_j}=F_{r_j}\) has precisely the behavior above. Omitting \(A\), or setting the bilateral history to zero, would change the martingale being tested.

## 4. Exact finite-horizon squared energy and its signed kernel

For \(\epsilon>0\), write

\[
\mathcal E_{s,\epsilon}(T)
=\int_0^T e^{-2\epsilon u}|F_s(u)|^2du.
\]

Expanding the locally finite native sum gives the exact finite identity

\[
\mathcal E_{s,\epsilon}(T)
=\sum_{m,n\le e^{T+2s}}
\frac{\Lambda(m)\Lambda(n)}{\sqrt{mn}}
I_{s,\epsilon,T}(m,n),
\tag{10}
\]

\[
I_{s,\epsilon,T}(m,n)
=\int_0^T e^{-2\epsilon u}
h_s(u-\log m)h_s(u-\log n)du.
\]

Only pairs with \(|\log(m/n)|\le4s\) can contribute. All their cross terms remain in (10).

On a full translate window the covariance kernel is

\[
\mathcal K_{s,\epsilon}(v)
=\int_{\mathbb R}e^{-2\epsilon u}
h_s(u+v/2)h_s(u-v/2)du.
\tag{11}
\]

It is real, even, supported in \([-4s,4s]\), and
\(\mathcal K_{s,\epsilon}(0)>0\). Its bilateral Laplace transform is

\[
\int e^{-pv}\mathcal K_{s,\epsilon}(v)dv
=H_s(\epsilon+p)H_s(\epsilon-p).
\tag{12}
\]

This follows from the change of variables \(x=u+v/2\), \(y=u-v/2\), whose Jacobian has absolute value one. In particular the transform vanishes at the real point \(p=1/2-\epsilon\). A nonzero nonnegative compact kernel could not have this property. Therefore

\[
\boxed{\mathcal K_{s,\epsilon}\text{ takes both positive and negative values.}}
\tag{13}
\]

This conclusion follows from the actual pole-killed source, despite positivity of its precursor. It is consistent with positive semidefiniteness of the full Gram matrix and does not assert that the matrix has a negative quadratic form.

More explicitly, set

\[
\mathcal B_{s,\epsilon}(v)=\int e^{-2\epsilon u}
b_s(u+v/2)b_s(u-v/2)du\ge0.
\]

The complete derivative structure of the squared energy is

\[
\boxed{
\mathcal K_{s,\epsilon}
=\big[\partial^2-(\epsilon+1/2)^2\big]^2
\big[\partial^2-(\epsilon-1/2)^2\big]^2
\mathcal B_{s,\epsilon}.
}
\tag{14}
\]

Indeed the transform polynomial factors as
\(((p+\epsilon)^2-1/4)((p-\epsilon)^2-1/4)
=(p^2-(\epsilon+1/2)^2)(p^2-(\epsilon-1/2)^2)\), before squaring. Equation (14) retains the two original pole factors through the entire residual-energy calculation.

## 5. The diagonal is controlled, uniformly over every horizon

Let

\[
J_{s,\epsilon}=\int e^{-2\epsilon u}|h_s(u)|^2du.
\]

Scaling the exact derivative formula gives

\[
h_s(sv)=s^{-5}
\left[b_1^{(4)}(v)-\frac{s^2}{2}b_1''(v)
+\frac{s^4}{16}b_1(v)\right].
\tag{15}
\]

Consequently \(J_{s,\epsilon}\le C_\epsilon s^{-9}\) for \(0<s\le r_*\). The diagonal part \(D_{s,\epsilon}(T)\) of (10) satisfies

\[
\boxed{
0\le D_{s,\epsilon}(T)
\le J_{s,\epsilon}\sum_{n\ge2}
\frac{\Lambda(n)^2}{n^{1+2\epsilon}}
\le C'_\epsilon s^{-9}.
}
\tag{16}
\]

The series is finite from \(\Lambda(n)\le\log n\). This bound needs no information about pairs of primes.

If \(\mathcal O_{s,\epsilon}(T)\) denotes exactly the off-diagonal sum in (10), then

\[
\mathcal E_{s,\epsilon}(T)
=D_{s,\epsilon}(T)+\mathcal O_{s,\epsilon}(T).
\tag{17}
\]

For polynomially shrinking \(s(T)\), (16) is only a polynomial horizon cost. A subexponential upper bound on the positive part of the **complete signed** \(\mathcal O_{s(T),\epsilon}(T)\) would therefore give a subexponential bound on this refined native energy. Neither (13) nor positivity of the full square supplies that upper bound.

## 6. The atom-separation limit is exact, and cannot be exchanged for free

Fix \(T>0\) which is not a point \(\log n\) with \(\Lambda(n)\ne0\). For all sufficiently small \(s\), the finitely many prime-power windows meeting \([0,T]\) are disjoint and are entirely inside or outside that interval. Thus

\[
\mathcal E_{s,\epsilon}(T)
=J_{s,\epsilon}\sum_{\log n<T}
\frac{\Lambda(n)^2}{n^{1+2\epsilon}}.
\tag{18}
\]

Since the bracket in (15) converges in \(L^2([-2,2])\),

\[
\boxed{
\lim_{s\downarrow0}s^9\mathcal E_{s,\epsilon}(T)
=\|b_1^{(4)}\|_2^2
\sum_{\log n<T}\frac{\Lambda(n)^2}{n^{1+2\epsilon}}.
}
\tag{19}
\]

In particular the iterated limit obtained by then sending \(T\to\infty\) is finite for every \(\epsilon>0\). Formula (19) is a finite-horizon atom calculation; it is not a bound uniform in \(T\) before refinement.

The reverse limit is precisely sensitive to the spectral question. If there is a native zero with \(\Re\lambda>\epsilon\), then for every fixed \(s>0\), universal visibility and the meromorphic Laplace-pole argument exclude \(F_s\in L^2_\epsilon\). Indeed such membership would make its Laplace transform holomorphic on \(\Re p>\epsilon\), by Cauchy–Schwarz, while the complete explicit formula has the nonzero pole coefficient \(H_s(\lambda)\); the gamma tail is harmless on this half-plane. Hence in that hypothetical case

\[
\lim_{s\downarrow0}\lim_{T\to\infty}
s^9\mathcal E_{s,\epsilon}(T)=\infty,
\]

whereas (19) gives a finite value in the other order. This is a conditional demonstration of the missing uniformity, not evidence that such a zero exists.

A simple sufficient spacing condition makes the scale cost visible. Among all integers \(n\le e^{T+1}\), consecutive logarithms are separated by at least a constant times \(e^{-T}\). Choosing \(s\ll e^{-T}\), together with the distance from the terminal endpoint, ensures disjointness. The derivative norm cost is then \(s^{-9}\). This sufficient atom-separation method does not deliver a subexponential bound for the original fixed detector. No theorem that every possible method requires this scale is claimed.

## Scope of the failed closing implication

The following inference is false for the actual native source:

> Positive refinement and nonnegative scale variances imply a uniformly integrable or uniformly square-integrable family of finer detector observations.

Equations (3)–(9) disprove that inference on the first-prime window. What remains possible is a direct, quantitatively weighted estimate at a finite scale chosen from the original detector history. Note 03 pursues exactly that option, with the scale cost carried into both the integer-lattice arithmetic and the finite bridge.

## Source record

- Note 01 in this campaign: exact positive refinement, tilted measures, compact support, original detector normalization.
- Master v2.9 universal-detector proof and `04_cross_detector_and_analytic_continuation_tests.md`: actual first-prime window, full support, and native explicit formula.
- Prior A03 / Path B native pole argument: weighted membership would remove a visible right pole.
- The martingale, non-uniform-integrability proof, signed squared-kernel factorization, uniform diagonal bound, and exact atom-scale limit are derived here.
