# B04.1 — Sharp native A02–B03 leakage without a multiplicity polynomial

**Status:** PAPER DERIVED from the supplied A02 prime-pair/boundary identity and B03 native positive-forward proof. The Laguerre refinement below is an independently written consequence of the full order-`m` zero conditions. This is not a new Lean result and proves no RH-excluding upper bound.

## Shared original detector and exact premisses

Fix `r=1/4096`, `d=2r`, `h=k_r*k_r`; let `K(p)=∫h(t)e^{-pt}dt` and `F=(Pi*h)=(M_mu*U)` with `U=(tN)*h`. Throughout `Pi` is the complete *genuine* von-Mangoldt prime-power distribution, with no modification of coefficients.

For `epsilon>0`, B03 constructs `a_N=R*B*N`, `v=R*B*U` and `A_epsilon g=(e^{-epsilon .}a_N)*g` on `L²(R_+)`. It establishes `v_epsilon=e^{-epsilon .}v in L²`, `||A_epsilon||<=M_epsilon=3/[2(epsilon+1/2)]` and the causal identity `a_N*F=v` on every finite horizon.

Assume a nontrivial native zero `rho` of multiplicity `m>=1` with `Re rho>1/2`. Fix `0<epsilon<Re(rho-1/2)`, and put `lambda=rho-1/2`, `delta=Re lambda-epsilon>0`, `q=lambda-epsilon`, `n=m-1`.

On the right Laplace half-plane, `A_epsilon(z)=A(z+epsilon)` has a zero of order `m` at `z=q`, while `V_epsilon(z)=V(z+epsilon)` vanishes to order exactly `m-1`. Thus for the bounded derivative functionals

`ell_j(w) = ∫_0^infty (-t)^j exp(-qt) w(t) dt` (`0<=j<=n`),

`ell_j(A_epsilon g)=0` for all `g∈L²` and `j<=n`; `ell_j(v_epsilon)=0` for `j<n`, whereas

`ell_n(v_epsilon)=c_{lambda,m}=-[b(lambda) K(lambda)/(lambda+1)] zeta^(m)(rho) ≠0`, with `b(p)=(p-1/2)/(p+1/2)`.

No factorial appears in `c_{lambda,m}`: differentiating `zeta'` `m-1` times produces `zeta^(m)`.

For each `T>=0`, define the *actual-output* finite horizon witness `g_T=1_[0,T] e^{-epsilon t}F(t)` (always an L² vector because F is smooth on compact horizons) and the exact global error `e_T=v_epsilon-A_epsilon g_T`. By causality `e_T=0` a.e. on `[0,T]`. Consequently

`ell_j(e_T)=0` (`j<n`), `ell_n(e_T)=c_{lambda,m}`.

These lower derivative constraints are essential; retaining only the `n`-th condition gives B03's weaker `e^{delta T}/T^n` bound.

## Sharp Laguerre projection and proof

For `n>=0`, let `L_n(x)` be the usual Laguerre polynomial normalized by `L_n(0)=1`. Write the monic polynomial

`Q_n(y)=(-1)^n n!/(2 delta)^n * L_n(2 delta y)`.

Then `Q_n(y)=y^n+(lower powers)` and

`∫_0^infty e^{-2 delta y} Q_n(y) y^j dy =0`, `0<=j<n`,

`∫_0^infty e^{-2 delta y} Q_n(y)^2dy = (n!)²/(2 delta)^{2n+1}`.

Since `(-t)^n-(-1)^n Q_n(t-T)` is a polynomial of degree at most `n-1`, the vanishing `ell_j(e_T)=0` for all lower `j` allows exact replacement inside `ell_n`:

`c_{lambda,m}=(-1)^n ∫_T^infty exp(-qt) Q_n(t-T) e_T(t)dt`.

Weighted Cauchy–Schwarz gives

`|c_{lambda,m}| <= ||e_T||_2 e^{-delta T} n!/(2delta)^(n+1/2)`.

Therefore, **for every T>=0**, under the hypothetical native zero,

\[
\boxed{\|e_T\|_2\ge
\frac{|c_{\lambda,m}|(2\delta)^{m-1/2}}{(m-1)!}\,e^{\delta T}.}
\tag{B04-SHARP}
\]

This estimate is pure exponential. It has no `T^{-(m-1)}` polynomial loss. It is not a uniform-in-rho or uniform-in-epsilon estimate.

Using `||e_T||<=||v_epsilon||+M_epsilon||g_T||`, we obtain the quantitative output prefix bound

\[
\|e^{-\epsilon t}F\|_{L^2(0,T)}\ge
\frac{|c_{\lambda,m}|(2\delta)^{m-1/2}}{M_\epsilon(m-1)!}e^{\delta T}-\frac{\|v_\epsilon\|_2}{M_\epsilon}.
\]

This is a conditional adversarial lower bound on the *actual unchanged output*, not a hypothetical bound on finite Euler outputs.

## Composition with A02's signed prime-pair identity

Write `F=F_1+F_{>=2}` as A02 does, retaining every prime power. A02 proves `H_epsilon=||e^{-epsilon t}F_{>=2}||_{L²(0,infty)}<infty` and the exact identity, for `0<epsilon<1/2`, `X=e^{T+d}`, `beta=1-2epsilon`,

\[
\mathcal R_\epsilon(T)=\|e^{-\epsilon t}F_1\|_{L^2(0,T)}^2-D_\epsilon(X),
\qquad 0\le D_\epsilon(X)\le D_\epsilon^*<\infty.
\]

Here `R_epsilon` includes *all three* differences of the positive-pair, negative-pair and future-boundary budgets, and the leading constants satisfy `C_+-C_-=C_partial`. Dropping the future boundary term invalidates the identity.

The triangle inequality, `H_epsilon<infty`, and the preceding prefix estimate give constants `c_0,T_0>0` depending on `rho,epsilon` such that

\[
\boxed{\mathcal R_\epsilon(T)\ge c_0e^{2\delta T}\qquad(T\ge T_0).}
\tag{B04-PAIR}
\]

This strengthens the integrator's `e^{2delta T}/T^{2m-2}` conclusion. It is a logically conditional consequence of A02/B03 PAPER premises; it is not the opposite independent upper bound.

A02's unconditional ordinary-PNT estimate `R_epsilon(T)=o(X^beta)` is compatible with this lower bound, because `2delta=2Re(rho)-1-2epsilon < 1-2epsilon=beta` for every nontrivial zero `Re rho<1`. A proof of `R_epsilon(T)=O(e^{eta T})` for arbitrarily small `eta>0`, **independent of RH**, would be decisive; that inequality remains OPEN.

## Adversarial scope

At `m=1`, the bound is `sqrt(2delta)|c|e^{delta T}`. At `m=2`, the permitted replacement is `Q_1(y)=y-1/(2delta)`. The proof works for any finite multiplicity, without requiring greatest-displacement attainment. It applies to the exact input `v_epsilon`, not a source-altered or positive-kernel-perturbed input. `T` is the same positive-time horizon as A02's `X=e^{T+d}`. The crucial data are **the complete vanishing derivative jet**, not merely existence of the highest-order adjoint obstruction.

The symbolic finite Laguerre check in `checks/verify_laguerre_and_causal_jet.py` replays the polynomial algebra for several n/delta; it cannot certify native off-line zeros or the paper source identities.
