"""Exact rational outward enclosures for the new native completion.

No floating-point result is used in an assertion. This certifies two bounded
facts, not RH: a mass upper bound, and failure of the naive inverse iteration
at one native frequency. Elementary series and an explicit Euler--Maclaurin
remainder are included. Python integers fail closed (there is no NaN path).
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from math import factorial, isqrt, comb, prod
from pathlib import Path
import json
import sympy as sp

S = 10**50

def ceildiv(a: int, b: int) -> int:
    if b <= 0:
        raise ValueError('positive divisor required')
    return -((-a)//b)

@dataclass(frozen=True)
class I:
    lo: int
    hi: int
    def __post_init__(self):
        if self.lo > self.hi:
            raise ValueError('inverted interval')
    @staticmethod
    def exact(x=0) -> 'I':
        if isinstance(x, I):
            return x
        x=F(x)
        return I((x.numerator*S)//x.denominator,
                 ceildiv(x.numerator*S,x.denominator))
    def __add__(self, other):
        b=I.exact(other); return I(self.lo+b.lo,self.hi+b.hi)
    __radd__=__add__
    def __neg__(self): return I(-self.hi,-self.lo)
    def __sub__(self, other): return self+-I.exact(other)
    def __rsub__(self, other): return I.exact(other)+-self
    def __mul__(self, other):
        b=I.exact(other)
        v=[self.lo*b.lo,self.lo*b.hi,self.hi*b.lo,self.hi*b.hi]
        return I(min(v)//S,ceildiv(max(v),S))
    __rmul__=__mul__
    def inv(self):
        if self.lo <= 0 <= self.hi:
            raise ZeroDivisionError('interval includes zero')
        if self.hi < 0: return -((-self).inv())
        return I((S*S)//self.hi,ceildiv(S*S,self.lo))
    def __truediv__(self, other):return self*I.exact(other).inv()
    def __rtruediv__(self, other):return I.exact(other)*self.inv()
    def __pow__(self, n:int):
        if n<0:return self.inv()**(-n)
        r=I.exact(1); b=self
        while n:
            if n&1:r=r*b
            b=b*b; n//=2
        return r
    def widen(self, e:F):
        if e<0:raise ValueError('negative error')
        u=ceildiv(e.numerator*S,e.denominator)
        return I(self.lo-u,self.hi+u)
    def record(self):
        return {'lower_numerator':str(self.lo),'upper_numerator':str(self.hi),
                'denominator':str(S),'decimal_display_only':[self.lo/S,self.hi/S]}

def sqrt_int(n:int)->I:
    k=isqrt(n*S*S)
    return I(k,k if k*k==n*S*S else k+1)

def log_small(x:I)->I:
    # x in [1,2]; atanh argument in [0,1/3] < 1/2.
    assert x.lo>=S and x.hi<=2*S
    z=(x-1)/(x+1); z2=z*z; power=z; ans=I.exact(0)
    K=120
    for k in range(K):
        ans=ans+2*power/F(2*k+1);power=power*z2
    # Uniform absolute geometric remainder, valid for |z| <= 1/2.
    err=F(2,1)*F(1,2)**(2*K+1)/F(2*K+1)/F(3,4)
    return ans.widen(err)

LOG2=log_small(I.exact(2))
def log_int(n:int)->I:
    if n<1:raise ValueError('positive integer required')
    e=n.bit_length()-1
    return e*LOG2+log_small(I.exact(F(n,2**e)))

def atan_recip(n:int)->I:
    x=I.exact(F(1,n));x2=x*x;p=x;ans=I.exact(0);K=100
    for k in range(K):
        ans=ans+((-1)**k)*p/F(2*k+1);p=p*x2
    return ans.widen(F(1,n)**(2*K+1)/F(2*K+1))
PI=16*atan_recip(5)-4*atan_recip(239)
assert PI.lo > 3*S

def trig(x:I)->tuple[I,I]:
    # Deterministic range reduction, using an enclosing pi interval.
    mid=(x.lo+x.hi)//2
    k=(mid+PI.lo)//(2*PI.lo)
    z=x-2*k*PI
    assert max(abs(z.lo),abs(z.hi))<4*S
    z2=z*z;cs=I.exact(1);sn=z;tc=I.exact(1);ts=z
    for k in range(1,40):
        tc=-tc*z2/F((2*k-1)*(2*k));cs=cs+tc
        ts=-ts*z2/F((2*k)*(2*k+1));sn=sn+ts
    cs=cs.widen(F(4**80,factorial(80)))
    sn=sn.widen(F(4**81,factorial(81)))
    return cs,sn

def exp_small(x:I)->I:
    assert max(abs(x.lo),abs(x.hi)) <= S
    ans=I.exact(1);term=I.exact(1)
    for k in range(1,61):term=term*x/F(k);ans=ans+term
    return ans.widen(F(3,factorial(61)))

@dataclass(frozen=True)
class C:
    re:I
    im:I
    @staticmethod
    def exact(re=0,im=0):return C(I.exact(re),I.exact(im))
    def __add__(self,o):
        if not isinstance(o,C):o=C.exact(o)
        return C(self.re+o.re,self.im+o.im)
    __radd__=__add__
    def __neg__(self):return C(-self.re,-self.im)
    def __sub__(self,o):return self+-o if isinstance(o,C) else self+C.exact(-o)
    def __rsub__(self,o):return -self+o
    def __mul__(self,o):
        if not isinstance(o,C):o=C.exact(o)
        return C(self.re*o.re-self.im*o.im,self.re*o.im+self.im*o.re)
    __rmul__=__mul__
    def conj(self):return C(self.re,-self.im)
    def abs2(self):return self.re**2+self.im**2
    def inv(self):
        den=self.abs2()
        if den.lo<=0:raise ZeroDivisionError('unresolved complex denominator')
        return C(self.re/den,-self.im/den)
    def __truediv__(self,o):
        if not isinstance(o,C):o=C.exact(o)
        return self*o.inv()
    def widen(self,e):return C(self.re.widen(e),self.im.widen(e))
    def record(self):return {'real':self.re.record(),'imag':self.im.record()}

def zeta_em_at_12(epsilon:F)->tuple[C,F]:
    """zeta(1/2+epsilon+12i), epsilon 0 or 1/100.

    N=64, eight Bernoulli terms. A rational upper bound for the
    periodic-Bernoulli integral is included in the returned rectangle.
    """
    assert 0<=epsilon<=F(1,100)
    sigma=F(1,2)+epsilon;z=C.exact(sigma,12);N=64;M=8
    def term(n):
        ln=log_int(n);co,si=trig(12*ln)
        modulus=sqrt_int(n).inv()*exp_small(-epsilon*ln)
        return C(modulus*co,-modulus*si)
    ans=C.exact()
    for n in range(1,N):ans=ans+term(n)
    tn=term(N)
    ans=ans+N*tn/(z-1)+tn/2
    poch=C.exact(1)
    for k in range(1,2*M):
        poch=poch*(z+(k-1))
        if k%2:
            m=(k+1)//2
            b=F(sp.bernoulli(2*m))/factorial(2*m)
            ans=ans+poch*tn*F(b,1)*F(1,N**k)
    # |s+j| <= 13+j, zeta(16)<2, pi>3, sigma>=1/2.
    rem=F(4,6**(2*M))*prod(range(13,13+2*M))*F(8,N**(2*M))/F(31,2)
    return ans.widen(rem),rem

def main():
    # Positive Euler-transformed eta series; each finite difference in [0,1].
    M=14; eta=I.exact(0)
    for k in range(M):
        d=I.exact(0)
        for j in range(k+1):d=d+(-1)**j*comb(k,j)*sqrt_int(j+1).inv()
        eta=eta+d/F(2**(k+1))
    eta=I(eta.lo,eta.hi+ceildiv(S,2**M))
    assert eta.hi*200<121*S
    assert 707**2<2*500**2
    q=F(605,621)
    assert q==F(2,3)*F(121,200)/F(207,500) and q<1
    rows=[]
    for eps in [F(0),F(1,100)]:
        z,rem=zeta_em_at_12(eps)
        p=C.exact(eps,12)
        a=((p-F(1,2))/((p+F(1,2))*(p+F(3,2))))*z
        bad=(1-a).abs2()
        assert a.re.hi*100 < -4*S
        assert bad.lo*100>109*S
        rows.append({'epsilon':str(eps),'frequency':'12','zeta':z.record(),
                     'A_triangle':a.record(),'abs2_I_minus_A':bad.record(),
                     'em_absolute_error_bound':str(rem)})
    # Fail-closed guard: a denominator whose interval contains zero is rejected.
    rejected=False
    try:I(-1,1).inv()
    except ZeroDivisionError:rejected=True
    assert rejected
    out={'status':'PASS','arithmetic':'integer-outward-fixed-point intervals',
         'precision_decimal_places':50,'eta_half_enclosure':eta.record(),
         'operator_norm_rational_upper_bound':str(q),
         'resolvent_I_minus_A_norm_upper_bound':str(1/(1-q)),
         'native_inverse_iteration_falsifiers':rows,
         'zero_denominator_rejected':rejected,
         'scope':'Finite constant and two native frequency enclosures only. Not RH, not a Lean receipt.'}
    path=Path(__file__).resolve().parents[1]/'evidence'/'native_completion_certificate.json'
    path.write_text(json.dumps(out,indent=2))
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
