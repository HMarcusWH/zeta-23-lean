# RH constructive continuation — 13 October 2026

**Research status: Step 4 OPEN.** This is a paper proof-discovery campaign from the fixed original detector, not an RH proof, a new Lean result, or an external peer-review receipt.

Read `RH_Constructive_Continuation_Paper.pdf` or its editable Markdown counterpart. Five proof notes supply the full arguments. The selected inherited source files are copied unchanged and individually hashed in `evidence/SOURCE_REGISTER.json`.

## Constructed objects

A positive native floor kernel with mass strictly below one; a faster same-source input; a definite adjoint-based residual iteration; exact minimum-cost finite native-jet corrections; a prime–composite mixed-energy expression with an additional summable near-gap sector. A native frequency certificate refutes the naive inverse iteration without making an assertion about an off-line zero.

## Reproduce the finite evidence

Use Python 3.10 or later, install `requirements.txt`, then run:

```sh
python run_checks.py
python verify_manifest.py
```

The native constant/frequency suite uses integer-outward rational intervals and an explicit Euler–Maclaurin remainder. The other suite checks 3,047 finite algebraic/support assertions. The actual continuum Landweber iteration has not been numerically executed. Neither suite proves the open residual limit or the far coprime cancellation estimate.

## Scope and authority

No repository mutation, PR merge, new local Lean build, or external independent review occurred. `evidence/REPOSITORY_OBSERVATION.json` records a pinned, partial live CI refresh and the invalidation warning attached to earlier whole-cover receipts. The paper does not rely on those numerical covers. All previous PAPER foundations remain inherited assumptions of the corresponding arguments.

## Build the PDF

The source is `RH_Constructive_Continuation_Paper.md`, with `paper_header.tex`. A standard Pandoc/XeLaTeX build is described in `build_pdf.sh`. Font files are not distributed.
