# Self-review and scoped evidence harvest

This is a self-review by the authoring assistant, not an independent external review or a parallel-agent review.

## Mathematical checks

1. The positive completion keeps the exact integer measure and source. The positivity interval is sharp only inside the displayed one-parameter family. Its mass identity follows from an integrable envelope and analytic continuation from the absolutely convergent half-plane.
2. The rational mass bound refers to the forward operator. Invertibility of its complement is not invertibility of the native forward operator. The actual native-frequency certificate demonstrates failure of the naive inverse iteration.
3. The adjoint iteration is defined on ordinary L2 after positive damping. Its adjoint is explicitly noncausal. Its residual converges to the adjoint-kernel projection; a zero limit is not asserted. The approximate outputs need not stay bounded.
4. Native multiplicity m gives vanishing derivatives below m−1 and a nonzero derivative exactly at m−1. No extra factorial enters that derivative. The Laguerre normalization was checked exactly. The no-polynomial-loss lower bound is inherited from B04, not newly claimed.
5. The finite-jet minimizer is a moment relaxation, not a solved infinite native extension. Its Hermitian Gram matrix retains conjugations. A paired list gives a real minimizer. A one-zero complex relaxation supplies a lower bound only for the real problem.
6. The original long-divisor coefficient is kept inside each time integral. The prime-power coefficient vanishing is restricted to sufficiently late active windows. It is not pointwise vanishing of the field at prime times.
7. Positive damping is essential to higher-power summability. The same error E−H is used for all damping parameters, with parameter-dependent norms.
8. The near-gap absolute estimate counts all nearby integers and uses the actual short-cofactor budget. All remaining separated interactions stay in Gamma. Neither coprimality nor disjoint coefficient indices imply orthogonal output functions.
9. Every-large-horizon lower leakage, not just subsequence sign oscillation, is used for the quiet-subsequence closing criterion. Constants and subsequences may depend on damping. Reflection is invoked only after excluding all right zeros.
10. The complete modulation of both source and measure leaves energy invariant. Twisting only one side changes the mathematical input.

## Finite controls and corrections

Both finite suites pass. An initial symbolic conjugation assertion in the synthetic paired-Gram check required simplification of an exactly zero difference; the repaired assertion checks that difference explicitly. This was a test-expression normalization issue, not new mathematical evidence. The interval suite rejects denominators enclosing zero and uses no NaN acceptance path. Decimal displays are not interval endpoints with authority; integer numerators and denominators are stored.

## Post-validation implications

The positive-completion result resurrects a native small-norm forward construction with an explicit source contract. It does not resurrect inverse stability: the zero divisor is unchanged. The phase-preserving mixed-energy construction supplies a genuine independently bounded sector and an exact angle/non-saturation target. Both routes now have concrete objects to test, but the stationary residual and separated coprime interaction remain unexcluded.

## Claim boundary

New formal theorem authority: none. New paper constructions and finite controls: recorded. Actual native output subexponential bound: not proved. Full PR #290 acceptance: not audited here. RH: OPEN.
