# 5. Phase preservation and the attempted final closures

**Status: PAPER algebra and scope audit.** This records which construction requirements were met and where the attempted closing inferences failed.

## 5.1 Coherent phase averaging does not diagonalize the original energy

One tempting construction is to average vertical phases of the prime coefficients and keep only a diagonal arithmetic term. Test it before using it.

For real $\tau$, let

$$\Pi_\tau=\sum_n\Lambda(n)n^{-1/2}e^{-i\tau\log n}\delta_{\log n},
\qquad j_{s,\tau}(u)=e^{-i\tau u}j_s(u).$$

If the original source is transported coherently with the prime phases, then

$$
\boxed{\Pi_\tau*j_{s,\tau}(t)=e^{-i\tau t}X(t).} \tag{5.1}
$$

The coefficient phase and the source phase cancel internally at each summand. Every prefix energy is unchanged. In the expanded square, all relative phases introduced by the twist cancel as well: this averaging cannot remove the coprime mixed interaction of Section 4.

The differential source law is also transported exactly:

$$P_\tau=(\partial+i\tau)^2-1/4,\qquad
P_\tau^2(e^{-i\tau t}q_s)=e^{-i\tau t}P^2q_s.$$

Using $P$ instead of $P_\tau$ would change the pole-neutrality requirements. Keeping $j_s$ fixed while twisting only the arithmetic coefficients likewise creates a different source problem. Neither operation is an estimate on the unchanged original field.

This is a scoped falsification of a phase-averaging shortcut, not a claim that no phase-dependent arithmetic estimate is possible.

## 5.2 What has actually been constructed

The following objects are supplied with formulas and proofs in this package:

* The whole one-parameter completion family, its exact positivity interval, and the endpoint native floor kernel.
* A rational strict-contraction bound and a bounded inverse of the complement $I-\mathsf A_\epsilon$.
* The unchanged-source input, with its double-pole cancellations and faster exponential tail.
* A native adjoint-based output-approximation sequence, a proved descent law, and its exact limiting residual.
* The least-cost tail matching any finite collection of original zero jets, including the full Hermitian cross-phase matrix.
* A mixed prime--composite energy formula and an independently controlled near-gap strip.

The construction does not replace the original $q_s$, alter prime weights, choose a hypothetical zeta zero numerically, identify a selected ground with the detector, or assume $X\in H_\epsilon$.

## 5.3 The failed final inferences, stated precisely

**Contraction applied to the wrong operator.** A strict bound for $\mathsf A$ proves invertibility of $I-\mathsf A$, not of $\mathsf A$. The actual-frequency certificate in Section 2 defeats the naive inverse iteration. The bounded complementary response has an exact native zero factor and loses the Step 1 pole.

**Finite moment feasibility mistaken for a controlled native future.** Every finite jet problem has a unique least-norm solution. Under a right zero its required norm grows exponentially with the matched prefix length. That solution is only a relaxation of full native range feasibility. No global cost bound follows from having solved all its finite linear equations.

**Monotone residual mistaken for zero residual.** The valid iteration has a decreasing error norm and a strong limit. Its invariant component is exactly the native adjoint-kernel projection. The residual does not disappear merely because each step is mathematically well defined and decreases the controllable component.

**Disjoint coefficients mistaken for orthogonal outputs.** The native first-prime field and the late residual have no common coefficient index. Their translates overlap densely on logarithmic time. The near-gap estimate removes a genuine sector; it does not determine the sign or size of the remaining separated coprime interaction.

**Positive precursor mistaken for a positive differentiated source.** The source is still $P^2q_s$, not $q_s$. No positivity statement has been inserted into a signed energy by changing that source.

## 5.4 Two exact remaining contracts

There are now two concrete alternatives, neither established here.

The range construction closes if its actual limiting residual is zero for every positive damping in a sequence tending to zero. An explicit sufficient native estimate is the non-summable relative-progress law (2.7).

The original-detector arithmetic construction closes if the separated coprime interaction has the quiet-subsequence property (4.13). The all-horizon jet lower bound then yields the contradiction directly. This route uses the compact-potential source adapter and does not require a new continuous-contact existence theorem or an extra finite-ground sign assumption.

They are alternative analytic targets, not a claim that both must be proved. They have not become logically easy because the constructions are explicit.

## 5.5 What is new relative to the sources inspected

The old $b=1$ native kernel, its Hardy zero-divisor characterization, and B04's sharp Laguerre lower bound are inherited. The current contribution is the $b$-family positivity proof with the sharp endpoint $b=3/2$, the explicit strict mass bound, the faster same-source driving formula, the native inverse-iteration falsifier, the definite adjoint iteration with its retained defect, the finite-jet minimum-cost constructor, and the prime--composite/coprime interaction reduction with its critical-width strip bound.

The finite linear-algebra tools themselves are standard. No priority claim over all mathematical literature is made. These are derived applications and new combinations relative to the inspected project frontier.

**Current result:** supporting constructions and bounds have been supplied; neither remaining native exclusion has been proved. Step 4 and RH remain OPEN in this package.
