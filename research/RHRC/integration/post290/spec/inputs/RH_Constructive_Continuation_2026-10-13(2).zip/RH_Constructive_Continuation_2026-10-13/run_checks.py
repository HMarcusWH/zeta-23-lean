"""Replay the two finite suites; no network or Lean build is required."""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
for name in ['native_completion_certificate.py','exact_construction_checks.py']:
    completed=subprocess.run([sys.executable,str(ROOT/'checks'/name)],cwd=ROOT,check=True,text=True,capture_output=True)
    (ROOT/'evidence'/(name.removesuffix('.py')+'_replay_stdout.txt')).write_text(completed.stdout)
    print(name+': PASS')
print('Finite controls passed. Infinite bounds depend on the written proofs; RH remains OPEN.')
