# A single compact smooth detector with universal off-line visibility

**Research status:** new paper derivation in this pass; not a Lean declaration and not a claim of historical priority. It replaces neither the existing canonical bump bank nor its proof authority. It supplies a different explicit family.

## 1. Conventions and construction

Use `Ff(z) = integral f(x) exp(i z x) dx`. Let `r>0`, put

\[
 c_j=\frac{r}{j(j+1)},\qquad
 b_j(x)=\frac{\mathbf 1_{[-c_j,c_j]}(x)}{2c_j},\qquad j\ge1.
\]

The widths telescope: `sum c_j=r` and `sum_{j>N} c_j=r/(N+1)`.
Define the entire product

\[
 P_r(z)=\prod_{j=1}^{\infty}\operatorname{sinc}(c_jz),
 \qquad \operatorname{sinc}z=\sin z/z,\quad\operatorname{sinc}0=1.
\]

**Theorem 1.** There is a nonnegative real even `q_r` in `C_c^infinity(R)` with integral one, support contained in `[-r,r]`, and Fourier transform `P_r`. For every nonreal `z`, `P_r(z)` is nonzero. The pole-killed source

\[
 k_r=q_r''-\tfrac14q_r
\]

is real even and smooth with compact support, and

\[
 \widehat k_r(z)=-(z^2+\tfrac14)P_r(z).
\]

In particular, for **every** nontrivial off-line zeta zero `rho`,

\[
 \widehat k_r\!\left(\frac{\rho-1/2}{i}\right)
 =\rho(\rho-1)P_r\!\left(\frac{\rho-1/2}{i}\right)\ne0.
\]

The same fixed `r` works for all such zeros. This is not a uniform lower bound on the transform, a universal observation time, or a claim that this source is one member of the repository's existing bump bank.

### Proof of existence and smoothness

Let `X_j` be independent uniform random variables on `[-c_j,c_j]`. Their sum converges absolutely, since `sum |X_j|<=r`. Its probability law `mu_r` is real, symmetric and supported in `[-r,r]`. Alternatively, the finite convolution laws converge weakly by the uniform tail bound `r/(N+1)`; this gives the same measure without a probabilistic interpretation.

On every compact complex set, the tails of the product converge normally: `sinc(c_j z)=1+O(c_j^2 |z|^2)` and `sum c_j^2<infinity`. Integration against the compactly supported limiting measure identifies its transform with `P_r` on the whole complex plane.

For any complex `w`,

\[
 |\operatorname{sinc}w|\le e^{|\Im w|}
 \min\{1,1/|w|\}.
\]

Let `R=r|z|` and `N=floor(sqrt(R)/2)`. If `N>=1`, then for `j<=N`,
`j(j+1)<=2N^2<=R/2`, so each of these `N` factors contributes an additional factor at most `1/2`. Thus, with `c=(log 2)/2`,

\[
 |P_r(z)|\le 2e^{r|\Im z|}e^{-c\sqrt{r|z|}}.                 \tag{1}
\]

The same bound holds when `N=0` because its right side is at least one times the usual exponential bound. On the real line, every polynomial times `P_r` is integrable. Fourier inversion therefore gives a smooth density `q_r` for `mu_r`, with

\[
 \|q_r^{(j)}\|_\infty
 \le \frac{4(2j+1)!}{\pi c^{2j+2}r^{j+1}}.                  \tag{2}
\]

It is a Gevrey-order-two bound. Positivity, mass, symmetry and compact support follow from the measure construction. As a globally smooth compactly supported function, all endpoint derivatives vanish; integration by parts yields the pole-killing multiplier with no boundary terms.

### Proof of nonvanishing

The zeros of each sinc factor are real. At a fixed nonreal `z`, no factor vanishes, and the convergent tail satisfies `sum |sinc(c_j z)-1|<infinity`. The infinite-product nonvanishing criterion, or the normally convergent logarithmic tail, shows that the product is nonzero. The two nonreal zeros introduced by the differential operator are exactly `+i/2` and `-i/2`; these correspond to `rho=0,1`, not to a nontrivial zeta zero. QED.

## 2. Explicit visibility cost, not just a nonvanishing assertion

Let `R=|z|>0`, `y=|Im z|>0` and `N=ceil(2 sqrt(rR))`. Then

\[
 |P_r(z)|\ge
 \left(\frac yR\right)^N
 \exp\left(-\frac{r^2R^2}{6N^3}\right)>0.                  \tag{3}
\]

For the first `N` factors, the identity
`|sin(u+iv)|^2=sin(u)^2+sinh(v)^2` gives `|sinc(c_jz)|>=y/R`.
For `j>N`, `|c_jz|<=1/4` and the power series gives
`|sinc(c_jz)-1|<=(c_jR)^2/4`. Since these errors are at most `1/64`,
`1-e>=exp(-2e)` applies. Finally
`sum_{j>N} 1/[j^2(j+1)^2] <= 1/(3N^3)`.
This proves (3). It deliberately deteriorates when `y` is small; it does not promise uniform detectability margins near the critical line.

For computation on `|z|_1<=R_1`, if `N>=2 sqrt(rR_1)` and
`S=r^2R_1^2/(12N^3)<1`, the relative product-tail error is at most
`exp(S)-1 <= S/(1-S)`. The accompanying executable combines this bound with rational complex Taylor balls; it does not replace an infinite product by an unqualified finite truncation.

## 3. Consequence for the complete detector correlation

Put `h=k_r*k_r` and retain the exact filtered correlation

\[
 C_r(t)=\sum_{\rho}m_\rho\widehat k_r(\gamma_\rho)^2
               e^{(\rho-1/2)t},\qquad
 \gamma_\rho=(\rho-1/2)/i.
\]

The squared filter is absolutely summable by (1), the zero-strip bound and the unconditional `O(T log T)` zero count. The exposed-pole argument in the supplied baseline proves that its exponential type is the supremum of the displacements of its visible zeros. Theorem 1 makes every off-line zero visible. Therefore

\[
 \boxed{\limsup_{t\to\infty}
 \frac{\log(1+|C_r(t)|)}t
 =\Delta:=\sup_\rho|\Re\rho-1/2|.}                         \tag{4}
\]

This holds for **each fixed** `r>0`; a limiting detector bank is no longer needed for this route. If `Delta=0`, real zeros potentially annihilated by the filter do not affect (4). The lower-bound argument uses a visible zero within any requested tolerance of the supremum, not attainment of a rightmost zero.

This is a sharpening of the detector interface, not exclusion of the detected mode. The independent subexponential estimate for `C_r` is not proved here.

## 4. Full support, used in the nonanalyticity check

The support of `mu_r` reaches both endpoints. To see this, fix epsilon, put the tail below epsilon/4, and require finitely many head variables to lie sufficiently close to their right endpoints; that event has positive probability. Thus
`lim_{y->infinity} y^{-1} log P_r(iy)=r`.
Multiplication by `y^2-1/4` does not change this indicator, so `k_r` has support reaching both endpoints too. Since

\[
 \widehat{(k_r*k_r)}(iy)=(y^2-1/4)^2P_r(iy)^2,
\]

the autocorrelation reaches `+/-2r`; it cannot vanish throughout any interior neighborhood of those support endpoints. No positivity of `k_r` is assumed.

## Evidence status

The construction and its universal quantifiers are analytic paper proofs. The finite product evaluations are exact rational-ball checks with explicit infinite tails. No Lean source was added. No uniform time bound and no RH conclusion have been obtained.
