# 4. Use two exact arithmetic representations before taking the square

**Status: PAPER deduction under the original-detector package's stable-error decomposition.** This section retains the actual long-divisor coefficients and the original fixed source. It supplies an independent bound for an additional interaction sector. The remaining separated, coprime, prime--composite interaction is not bounded here.

## 4.1 The inherited exact decomposition

Use the same $j_s$ and $X=\Pi*j_s$. The previous campaign supplies

$$X=R+E,\qquad E\in H_\epsilon\quad\text{for every }\epsilon>0. \tag{4.1}$$

Here $R=R_s^\sharp$ is not a free residual. For $t\ge1$ it is exactly

$$
R(t)=\sum_n\frac{B_n(t)}{\sqrt n}j_s(t-\log n),
$$

$$B_n(t)=1_{\{n\le e^{t+d},\ b_{L_c(t)}(n)>Z(t)\}}
 w_{P(t)}(n)A_{Y(t)}(n), \tag{4.2}$$

and $R=0$ on the earlier interval. All symbols have their frozen original meanings:

$$A_Y(n)=\sum_{a\mid n,\ a>Y}\mu(a)\log(n/a),\qquad
w_P(n)=1_{\{\omega(\gcd(n,P))\le1\}},$$

$$Y(t)=\frac{e^t}{B_sP(t)t^2},\quad
L_c(t)=B_sP(t)e^dt^2,\quad
P(t)\le\log(t+2).$$

$P(t)$ is the original increasing initial primorial and $b_{L_c}$ is the original rough-core map. $Z(t)=\exp(t/\log(t+2))$. In particular the time-dependent coefficient in (4.2) stays inside every integral below. No derivative of that coefficient is taken.

## 4.2 The residual has no prime-power coefficient on a sufficiently late active window

There is $T_0$ such that for $t\ge T_0$,

$$Y(t)\ge e^{(t+s)/2}\quad\text{and}\quad Y(t)\ge1.$$

This follows from the exponential numerator and the fixed polylogarithmic denominator. If $j_s(t-\log n)\ne0$, then $n\le e^{t+s}$. For a prime power $n=p^k$ with $k\ge2$, every squarefree divisor is $1$ or $p\le\sqrt n\le Y(t)$, so $A_{Y(t)}(n)=0$. For $k=1$, the only possible remaining divisor is $p$ itself, whose coefficient is $\mu(p)\log1=0$. Thus

$$
\boxed{B_{p^k}(t)=0\quad\text{whenever }t\ge T_0
\text{ and }j_s(t-\log(p^k))\ne0.} \tag{4.3}
$$

This is coefficient support, not pointwise vanishing of $R$ near a prime. Nearby composite translates can overlap that same time window.

## 4.3 Remove higher powers as a complete controlled field

Write

$$X_1(t)=\sum_{p\text{ prime}}\frac{\log p}{\sqrt p}j_s(t-\log p),
\qquad H=X-X_1.$$

The entire higher-power field belongs to $H_\epsilon$, because weighted Young's inequality gives

$$
\|H\|_\epsilon
\le\|e^{-\epsilon u}j_s(u)\|_{L^2(\mathbb R)}
\sum_p\sum_{k\ge2}(\log p)p^{-k(1/2+\epsilon)}<\infty. \tag{4.4}
$$

This argument requires positive damping. It does not assert an undamped finite-variation estimate. Combining (4.1) and (4.4),

$$X_1=R+Z,\qquad Z=E-H\in H_\epsilon\quad(\epsilon>0).$$

For $\mathcal E_\epsilon(T)=\|X_1\|_{\epsilon,[0,T]}^2$, the exact mixed identity is

$$
\left|\mathcal E_\epsilon(T)-\Re\langle X_1,R\rangle_{\epsilon,[0,T]}\right|
\le \|E-H\|_\epsilon\sqrt{\mathcal E_\epsilon(T)}. \tag{4.5}
$$

This is why it is useful not to square the divisor representation immediately. The native first-prime field and the long-divisor field have genuinely different coefficient supports, while their complete output discrepancy is controlled.

## 4.4 Every late mixed pair is coprime

Expanding the finite-horizon mixed pairing gives terms

$$
\frac{\log p}{\sqrt{pn}}
\int_{T_0}^{T} e^{-2\epsilon t}B_n(t)
 j_s(t-\log p)j_s(t-\log n)\,dt. \tag{4.6}
$$

By (4.3), $n$ is not a prime power. Overlap requires

$$|\log(n/p)|\le2s.$$

Since $e^{2s}<2$, a distinct multiple of the prime $p$ cannot lie in this interval. Therefore every nonzero late mixed term has

$$
\boxed{n\text{ non-prime-power},\quad n\ne p,\quad (p,n)=1.} \tag{4.7}
$$

This is not an assumed independence of primes and composites. It is an exact support restriction on their mixed energy. The whole finite initial segment $[0,T_0]$ contributes a fixed finite constant.

## 4.5 A stronger coefficient bound uses the actual short cofactor budget

On an active source window, set $m=n/a$ in (4.2). The strict condition $a>Y(t)$ gives

$$m<n/Y(t)\le L_c(t).$$

Consequently, without any Möbius cancellation,

$$
|A_{Y(t)}(n)|
\le\sum_{m<L_c(t)}\log m
\le C_s(1+t)^3
\le C'_s(1+\log n)^3. \tag{4.8}
$$

The first bound uses $L_c(t)=O_s(t^2\log(t+2))$ and $\log^2(t+2)=O(1+t)$. It is important to use this actual cofactor constraint, rather than replacing it by an arbitrary divisor-count bound. The mask and rough-core indicator have absolute value at most one.

## 4.6 A critical-width interaction strip is independently summable

Fix $0<\epsilon<1/2$ and define

$$H_\epsilon(p)=\frac{p^{2\epsilon}}{(1+\log p)^6}.$$

**Theorem 2.** The total absolute contribution of all mixed terms (4.6) with

$$0<|n-p|\le H_\epsilon(p)$$

is finite over the full half-line, uniformly in the terminal horizon $T$.

**Proof.** Let $M_s=\|j_s\|_\infty$. On an active overlap, $t\in[\log p-s,\log p+s]$ and $n/p\in[e^{-2s},e^{2s}]$. Formula (4.8) bounds the absolute integral of one term by

$$C_{s,\epsilon}(1+\log p)^4p^{-1-2\epsilon}.$$

There are at most $2H_\epsilon(p)+1$ admissible integers $n$. Summing even over all integers $p\ge2$ rather than just primes bounds the total by a constant times

$$
\sum_{p\ge2}\frac1{p(1+\log p)^2}
+\sum_{p\ge2}(1+\log p)^4p^{-1-2\epsilon},
$$

both convergent. This is an independent arithmetic upper bound; it assumes neither the target norm of $X$ nor an off-line zero. $\square$

The sixth logarithmic power is a convenient sufficient choice, not an optimality claim. The endpoint without a logarithmic loss is not inferred from this estimate.

## 4.7 The remaining exact interaction

Let $\Gamma_\epsilon(T)$ be the complete real sum (4.6) after restricting to

$$
 p\text{ prime},\quad n\text{ non-prime-power},\quad(p,n)=1,
 \quad |\log(n/p)|\le2s,
 \quad |n-p|>H_\epsilon(p), \tag{4.9}
$$

with every original mask, rough-core condition, strict cutoff, coefficient and phase-bearing source factor retained. It is a finite, source-defined number at each finite $T$.

Equations (4.5) and Theorem 2 prove

$$
\boxed{
|\mathcal E_\epsilon(T)-\Gamma_\epsilon(T)|
\le C_0+C_1\sqrt{\mathcal E_\epsilon(T)}.
} \tag{4.10}
$$

In particular, for suitable fixed $C$,

$$\mathcal E_\epsilon(T)\le2\Gamma_\epsilon(T)_++C,
\qquad \Gamma_\epsilon(T)_+\le2\mathcal E_\epsilon(T)+C. \tag{4.11}$$

Here $x_+=\max(x,0)$. One uses $C_1\sqrt E\le(E+C_1^2)/2$; no sign is assigned separately to the terms in the mixed sum.

## 4.8 The stepwise closing implication is explicit

Suppose a native zero has $\Re\rho-1/2=\beta>\epsilon$. Apply the original source values to the full-jet lower bound (3.5), then subtract the bounded higher-power field in (4.4). This gives constants $c>0,T_1$ such that

$$\mathcal E_\epsilon(T)\ge c e^{2(\beta-\epsilon)T}\qquad(T\ge T_1).$$

Equation (4.10) therefore gives

$$\Gamma_\epsilon(T)>0\text{ eventually},\qquad
\liminf_{T\to\infty}\frac{\log(1+\Gamma_\epsilon(T)_+)}T
\ge2(\beta-\epsilon)>0. \tag{4.12}$$

A sufficient remaining estimate is thus

$$
\boxed{
\liminf_{T\to\infty}\frac{\log(1+\Gamma_\epsilon(T)_+)}T=0
\quad\text{for every }\epsilon\in\{1/3,1/4,1/5,\ldots\}.
} \tag{4.13}
$$

No common subsequence or uniform constants in $\epsilon$ are needed. Any right zero would violate (4.13) for a sufficiently small listed damping. Reflection then treats the left side. The use of an arbitrarily late quiet subsequence is justified by the every-large-horizon lower bound; it would not be justified by only an unspecified subsequence of deep negative trials.

**Equation (4.13) is OPEN.** The new construction does not prove cancellation in the separated coprime sector (4.9). It has removed the coefficient diagonal, all higher prime powers as a controlled field, and the displayed near-gap strip from the remaining estimate.

## 4.9 A quantitative compatibility demand, not an automatic contradiction

Under a hypothetical right zero, $\|X_1\|_{\epsilon,[0,T]}$ grows exponentially and $\|X_1-R\|_\epsilon$ remains bounded. Hence the normalized real inner product of these two different-support outputs satisfies

$$
\frac{\Re\langle X_1,R\rangle_{\epsilon,[0,T]}}
{\|X_1\|_{\epsilon,[0,T]}\|R\|_{\epsilon,[0,T]}}
=1-O(e^{-2(\beta-\epsilon)T}). \tag{4.14}
$$

This follows from $\|X_1-R\|^2=(a-b)^2+2ab(1-\cos\theta)$. It is an exact quantitative restriction on an admissible counterexample: the two arithmetic representations must become extremely aligned despite disjoint coefficient supports. Dense logarithmic translates are not orthogonal, so disjoint supports alone do not contradict (4.14). An independent non-saturation estimate for these actual coefficients could be useful; none is claimed here.


## 4.10 A source-specific angle condition would suffice

The two-output geometry also gives an exact alternative to estimating the whole interaction sum. At horizons where both norms are nonzero, set

$$c_T=\frac{\Re\langle X_1,R\rangle_{\epsilon,[0,T]}}
{\|X_1\|_{\epsilon,[0,T]}\|R\|_{\epsilon,[0,T]}}.$$

Suppose that along an unbounded sequence of horizons one could prove, on these actual arithmetic outputs,

$$c_T\le1-\delta_T,\qquad 0<\delta_T\le1,
\qquad\frac{\log(1/\delta_T)}{T}\longrightarrow0. \tag{4.15}$$

Writing $a=\|X_1\|$, $b=\|R\|$, completing the square gives

$$
\|Z\|_\epsilon^2\ge a^2+b^2-2(1-\delta_T)ab
=[b-(1-\delta_T)a]^2+(2\delta_T-\delta_T^2)a^2.
$$

Thus $\mathcal E_\epsilon(T)\le\|Z\|_\epsilon^2/(2\delta_T-\delta_T^2)$ on that sequence, contradicting (4.12) whenever a right zero lies beyond $\epsilon$. A polynomial lower bound for the actual angular separation would be sufficient. A horizon with $R=0$ is handled directly by $X_1=Z$.

Condition (4.15) is OPEN. Positivity of a Gram determinant proves only $|c_T|\le1$, which is not a quantitative separation. Coefficient disjointness does not supply (4.15) because the translated source functions are not orthogonal. The condition identifies the exact non-saturation property a phase-preserving construction would have to establish; it is not evidence that the property holds.
