# Joint campaign Path A paper result: a prime-power-preserving adaptive sieve on the original detector

Date: 13 October 2026. Status: **PAPER / DERIVED, not formalized.**

This is an exact native arithmetic reduction. A growing finite set of small primes can be used to remove every product containing two of those primes, including products at the moving divisor-cutoff boundary. The source remains the original fixed \(h\). The price is multiplication of the cofactor cutoff by the sieve modulus. The construction does not close the remaining signed estimate.

## 1. Fixed source and two rapid integer-lattice inputs

Use the original real compact detector \(h=k_r*k_r\), with \(r=1/4096\), \(d=1/2048\), and source widths \(r/[j(j+1)]\). Its bilateral Laplace transform \(K\) has

\[
K(1/2)=K'(1/2)=0.
\tag{1}
\]

Define the locally finite fields

\[
V(s)=\sum_{j\ge1}j^{-1/2}h(s-\log j),\qquad
U(s)=\sum_{j\ge1}(\log j)j^{-1/2}h(s-\log j).
\tag{2}
\]

The A03 quantitative Poisson argument applies to both fields and gives constants \(C,\kappa_*>0\), depending only on \(h\), with

\[
|V(s)|+|U(s)|\le C\exp(-\kappa_* e^{s/2})
\qquad(s\ge0).
\tag{3}
\]

For completeness, write \(a(y)=y^{-1/2}h(-\log y)\) and \(b(y)=(\log y)a(y)\). The original Gevrey estimates give
\(|\widehat a(\xi)|+|\widehat b(\xi)|\le C e^{-c\sqrt{|\xi|}}\).
The zero Fourier modes of the scaled sums for \(V\) and \(U\) are respectively
\(e^{s/2}K(1/2)\) and \(e^{s/2}[sK(1/2)+K'(1/2)]\), both zero. The nonzero modes are bounded as in A03, and reducing the positive exponent constant handles the prefactors and a fixed initial interval. Thus (3) uses no new prime input. Its \(\kappa_*\) may be smaller than a constant previously displayed only for \(U\).

Choose one fixed \(B>0\) such that

\[
c_B:=\kappa_*\sqrt B-\tfrac12>0.
\tag{4}
\]

This choice is made once. It is independent of \(t\), the damping \(\epsilon\), and the sieve modulus below.

## 2. An exact mask that fixes all prime powers

Let \(P\ge1\) be squarefree and let \(\omega(q)\) be the number of distinct prime factors of \(q\). Define

\[
w_P(k)=1_{\{\omega(\gcd(k,P))\le1\}}.
\tag{5}
\]

Thus \(w_P\) is a nonnegative zero-one mask. It equals one on every prime power and on \(1\). It has the exact divisibility expansion

\[
\boxed{
w_P(k)=\sum_{\substack{Q\mid P\\Q\mid k}}c_Q,
\qquad c_Q=\mu(Q)(1-\omega(Q)).
}
\tag{6}
\]

To verify this, let \(j=\omega(\gcd(k,P))\). The right side is
\(\sum_{\ell=0}^j\binom j\ell(-1)^\ell(1-\ell)\).
It is one for \(j=0,1\), and zero for \(j\ge2\), by the binomial identity and its derivative. This is the desired mask, including all endpoint cases.

If \(r=\omega(P)\), its coefficient budget is

\[
\mathcal A(P):=\sum_{Q\mid P}|c_Q|
\le (1+r)2^r
\le P(1+\log_2 P)
\quad(P\ge2),
\tag{7}
\]

and \(\mathcal A(1)=1\). The exact value is \((r-2)2^{r-1}+2\), with the expression also giving one when \(r=0\) or \(1\).

Because the native von Mangoldt function vanishes away from prime powers,

\[
F(t)=\sum_{k\ge1}\frac{\Lambda(k)}{\sqrt k}h(t-\log k)
=\sum_{k\ge1}\frac{w_P(k)\Lambda(k)}{\sqrt k}h(t-\log k).
\tag{8}
\]

The detector has not been changed, translated, or adapted. Equation (8) is an arithmetic identity at each \(t\).

## 3. Uniform control of the restricted integer drive

For each integer \(q\ge1\), define

\[
U_q(s)=\sum_{\substack{m\ge1\\q\mid m}}
\frac{\log m}{\sqrt m}h(s-\log m).
\]

Reindexing \(m=qj\) gives the exact equality

\[
\boxed{
U_q(s)=q^{-1/2}
\left[(\log q)V(s-\log q)+U(s-\log q)\right].
}
\tag{9}
\]

When \(s-\log q\ge0\), (3) yields

\[
|U_q(s)|\le
Cq^{-1/2}(1+\log q)
\exp\left(-\kappa_*\frac{e^{s/2}}{\sqrt q}\right).
\tag{10}
\]

This scaling factor \(q^{-1/2}\) and the loss \(\sqrt q\) in the exponent are both retained. The estimate is not claimed with constants uniform in \(q\) after deleting that loss.

## 4. Time-varying modulus and the compensated cutoff

At each time \(t\), choose a squarefree integer \(P=P(t)\), and put

\[
x=e^t,\quad X=xe^d,\quad
Y_P(t)=\frac{x}{BP(t)t^2},\quad
L_P(t)=BP(t)e^dt^2.
\tag{11}
\]

Expand the native divisor identity in (8), before taking any limit:

\[
F(t)=
\sum_{m,n\ge1}\frac{\mu(n)\log m}{\sqrt{mn}}
w_{P(t)}(mn)h(t-\log(mn)).
\tag{12}
\]

The sum is finite because \(mn\le X\) on the support of \(h\). Split it at \(n=Y_P(t)\), with equality assigned to the small-divisor part. Define the exact remaining field

\[
\boxed{
\begin{split}
S_{P,B}(t)=
\sum_{2\le m<L_P(t)}\frac{\log m}{\sqrt m}
\sum_{\substack{n>Y_P(t)\\mn\le X(t)}}
\frac{\mu(n)}{\sqrt n}
w_{P(t)}(mn)h(t-\log(mn)).
\end{split}
}
\tag{13}
\]

The bound \(m<L_P(t)\) follows from the strict inequality \(n>Y_P(t)\); it is not a new truncation.

Let \(r_{P,B}(t)=F(t)-S_{P,B}(t)\). Insert (6) into the small-divisor part. For fixed \(Q\mid P\) and \(n\le Y_P\), the condition \(Q\mid mn\) is equivalent to

\[
q_{Q,n}:=\frac{Q}{\gcd(Q,n)}\mid m,\qquad 1\le q_{Q,n}\le P.
\]

The inner \(m\) sum is exactly \(U_{q_{Q,n}}(t-\log n)\). Since

\[
nq_{Q,n}\le Y_P P=\frac{x}{Bt^2},
\]

its argument in (9) is at least \(\log(Bt^2)\). For all \(t\) with \(Bt^2\ge1\), the bound (10) therefore applies and gives

\[
\begin{split}
|r_{P,B}(t)|
&\le C\sum_{Q\mid P}|c_Q|
\sum_{n\le Y_P}
\frac{1+\log q_{Q,n}}{\sqrt{nq_{Q,n}}}
e^{-\kappa_*\sqrt{x/(nq_{Q,n})}}\\
&\le 2C\,\mathcal A(P)(1+\log P)\sqrt{Y_P}
e^{-\kappa_*\sqrt B\,t}.
\end{split}
\]

If \(Y_P<1\), the small sum is empty and its bound is automatic. Otherwise the elementary estimate
\(\sum_{n\le Y_P}n^{-1/2}\le2\sqrt{Y_P}\) applies. Thus in all cases

\[
\boxed{
|r_{P,B}(t)|
\le
\frac{2C\,\mathcal A(P)(1+\log P)}{\sqrt{BP}\,t}
e^{-c_Bt}.
}
\tag{14}
\]

The same constants \(C,\kappa_*,B,c_B\) work for every modulus value. Dependence on the time-varying modulus is explicit in (14).

## 5. A concrete nearly logarithm-squared choice

Let \(P_j\) be the product of the first \(j\) primes, with \(P_0=1\). Choose

\[
P(t)=\max\{P_j:P_j\le\log(t+2)\}.
\tag{15}
\]

This is a well-defined measurable step function, tends to infinity, and satisfies \(P(t)\le\log(t+2)\). Every fixed prime eventually belongs to \(P(t)\). Consequently the mask eventually removes any product containing any specified pair of distinct fixed primes.

From (7) and (14),

\[
|r_{P,B}(t)|
\le C_{B,h}
\frac{\sqrt{\log(t+2)}
[1+\log\log(t+2)]^2}{t}
e^{-c_Bt}
\tag{16}
\]

for a sufficiently large fixed initial threshold. In particular this one remainder belongs to every positively damped \(L^2\) space. The cofactor range is

\[
m<O(t^2\log(t+2)).
\tag{17}
\]

Because \(Y_P(t)/\sqrt{X(t)}\to\infty\), the inherited prime-power disappearance in the product coefficient also applies eventually. Thus the new long-divisor field is supported on composite products having **at most one prime from the increasing selected palette**.

Changes in \(P(t)\) create no missing derivative or endpoint term in this proof: (8), (12), and (14) are pointwise finite identities and inequalities. No differentiation of \(P(t)\), \(Y_P(t)\), or the mask is performed. The two resulting fields can have jumps that cancel in their sum \(F\). A separate claim about derivatives of either adaptive field would have to keep those jumps.

The fixed original \(S_B\), the new \(S_{P,B}\), and \(F\) differ by fields already proved to lie in every positively damped \(L^2\) space. Their all-positive-damping target is therefore equivalent by the triangle inequality. This is a proved adapter, not an assumption that a bound transfers between unrelated sources.

More generally, any choice with \(\log P(t)=o(t)\) has a subexponential coefficient loss in (14), and hence the same stable-error conclusion. Its cofactor range becomes \(O(P(t)t^2)\). The particularly small choice (15) also preserves the smooth-sector estimate of Note 03; a much larger \(P(t)\) requires that counting estimate to be rechecked.

## 6. A precise limitation of this cutoff mechanism

The sieve modulus occurs in the cofactor cost \(L_P=Be^dt^2P\). This construction cannot select every prime at most that resulting cofactor scale. Indeed for sufficiently large \(t\), \(L_P\ge P+1\). Any prime divisor \(p\) of \(P+1\) satisfies

\[
p\le P+1\le L_P,\qquad p\nmid P.
\tag{18}
\]

Thus at least one prime below the expanded cofactor scale is always unselected. This is a precise statement about this modulus-and-cutoff mechanism. It is not a theorem prohibiting all sieves or all possible arithmetic estimates.

There is a stronger direct check on the actual remaining signs. With the choice (15), let \(J=(u_-,u_+)\) be a fixed interval in \((-d,d)\) where \(h\) is nonzero with fixed sign. For every sufficiently large \(t\), fixed-ratio PNT supplies:

- a prime \(q_-\) with \(2q_-\in(e^{t-u_+},e^{t-u_-})\);
- a prime \(p\in[2L_P(t),4L_P(t)]\), and a prime \(q_+\) with \(2pq_+\) in the same product interval.

Here \(q_+>p>L_P\ge P\) eventually, uniformly over the chosen \(p\) range. Both products have at most the prime \(2\) in the selected palette, so both masks are one. The exact squarefree calculation of Note 02 gives

\[
A_{Y_P(t)}(2q_-)=-\log2,\qquad
A_{Y_P(t)}(2pq_+)=+\log2.
\tag{19}
\]

Both opposite signs therefore survive this increasingly selective native sieve. Their rough cores are comparable to \(e^t\), so they also survive the independently controlled small-core sector of Note 03.

This does not disprove the desired complete signed upper estimate. It identifies why the projection by itself does not supply it.

## 7. Exact stopping point

For the single fixed detector and the single fixed \(B\) of (4), the following remains unproved:

\[
\forall\epsilon>0:\qquad
\int_{T_0}^\infty e^{-2\epsilon t}
|S_{P,B}(t)|^2\,dt<\infty.
\tag{20}
\]

The native products, their mask, all cofactor cross terms, and the time-dependent strict long-divisor threshold are part of (20). One may additionally remove the proved small-rough-core sector of Note 03. Neither the nonnegative mask nor the finite-divisor identity estimates the remaining signed sum. The new result is a narrower exact arithmetic target, not Step 4 closure.

## Source record and validation scope

- A03 new/arithmetic/03_native_gevrey_drive_and_log_squared_cofactors.md, Sections 1–5: fixed source, quantitative Poisson estimate, original localization.
- A03 new/arithmetic/05_native_composite_support_and_signed_window_obstruction.md, Sections 1–2: product coefficients and prime-power disappearance.
- Note 02 in this campaign: complete-small-divisor identity and squarefree opposing signs.
- The mask, uniform restricted-drive estimate, compensated time-varying cutoff, and cutoff limitation are derived here.
- The companion exact-arithmetic script checks the mask/divisor identities and both sides of cutoff seams on finitely many integers. Those checks validate the algebraic implementation; the universal claims are established by the proofs above.
