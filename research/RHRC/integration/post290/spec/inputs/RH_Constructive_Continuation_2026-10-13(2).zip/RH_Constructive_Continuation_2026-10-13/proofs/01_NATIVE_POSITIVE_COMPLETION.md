# 1. Constructing a positive native completion with norm below one

**Status: PAPER deduction.** The construction changes the rational completion of the native integer operator, not the original detector, the integer lattice, the von Mangoldt coefficients, or the zeta zero divisor. No RH assumption is used in this section. The numerical constant is supported by the exact rational enclosure in the package.

## 1.1 Frozen source

Retain the previous campaign's fixed scale $s=1/4096$, compact even Gevrey probability density $q_s$, and

$$
P=\partial_t^2-\tfrac14,\qquad k_s=Pq_s,\qquad j_s=P^2q_s.
$$

Write

$$
J_s(p)=\int_{\mathbb R}e^{-pt}j_s(t)\,dt
       =(p^2-\tfrac14)^2Q_s(p).
$$

The source has the two double elementary zeros and is nonzero at every off-line native zero coordinate $\lambda=\rho-1/2$. These source facts, the compact test-space inverse of $P$, and the original two-lobe forcing identity are inherited PAPER premises from the original-detector package, not results re-formalized here.

The actual measures and fields are

$$
N=\sum_{n\ge1}n^{-1/2}\delta_{\log n},\qquad
\Pi=\sum_{n\ge2}\Lambda(n)n^{-1/2}\delta_{\log n},
$$

$$
X=\Pi*j_s,\qquad U=((\log n)N)*j_s.
$$

All these convolutions are locally finite. Because $s<\log2$, both $X$ and $U$ vanish before $\log2-s>0$. The $n=1$ term of $U$ is zero. The native divisor identity $1*\Lambda=\log$ gives

$$N*X=U. \tag{1.1}$$

The prior fixed-source integer-drive proof supplies constants $C_s,\kappa_s>0$ such that, for sufficiently large $t$,

$$|U(t)|\le C_s\exp(-\kappa_s e^{t/2}). \tag{1.2}$$

We use (1.2) only as an inherited analytic bound on this exact source. Consequently $\widehat U$ is entire, and the identity initially obtained for $\Re p>1/2$ continues as

$$\widehat U(p)=-J_s(p)\zeta'(p+1/2). \tag{1.3}$$

The double zero of $J_s$ cancels the double pole of $\zeta'$ at $p=1/2$.

## 1.2 Solve a one-parameter completion requirement

For $b>1/2$, put $\alpha=b-1/2$ and choose

$$
c_b(p)=\frac{p-1/2}{(p+1/2)(p+b)}
=-\frac1\alpha\frac1{p+1/2}
 +\frac{\alpha+1}{\alpha}\frac1{p+b}.
$$

Its causal kernel is

$$c_b(t)=\frac{-e^{-t/2}+(\alpha+1)e^{-bt}}\alpha\,1_{t\ge0}.$$

The zero at $p=1/2$ cancels the elementary zeta pole. The two denominator poles are strictly on the left. Define $a_b=c_b*N$ locally, and let $x=e^t$, $n=\lfloor x\rfloor$. Direct summation gives the exact, native formula

$$
a_b(t)=\frac{x^{-1/2}}\alpha
\left[(\alpha+1)x^{-\alpha}\sum_{k=1}^{n}k^\alpha-n\right]. \tag{1.4}
$$

This formula involves every integer up to the true floor, not selected primes or altered coefficients.

**Theorem 1 (sharp positivity interval in this family).** For $1/2<b\le3/2$,

$$0<a_b(t)\le\frac{\alpha+1}{2\alpha}e^{-t/2}\quad(t\ge0). \tag{1.5}$$

For each $b>3/2$, the kernel is negative on a nonempty subinterval before the first prime, $0<t<\log2$.

**Proof.** For $0<\alpha\le1$, induction and the concave Bernoulli inequality prove

$$
\sum_{k=1}^{n}k^\alpha\ge\frac{n(n+1)^\alpha}{\alpha+1}.
$$

Indeed, the induction step reduces to

$$\left(1+\frac1{n+1}\right)^\alpha\le1+\frac\alpha{n+1}.$$

Since $n\le x<n+1$, substitution in (1.4) gives strict positivity. The composite trapezoidal inequality for the concave function $u^\alpha$ gives

$$\sum_{k=1}^{n}k^\alpha\le\frac{n^{\alpha+1}}{\alpha+1}+\frac12n^\alpha.$$

Thus the bracket in (1.4) is at most

$$n[(n/x)^\alpha-1]+\tfrac12(\alpha+1)(n/x)^\alpha
\le\tfrac12(\alpha+1),$$

which proves (1.5).

For $\alpha>1$, use $n=1$ in (1.4). Its sign is the sign of $(\alpha+1)x^{-\alpha}-1$. Since $\alpha+1<2^\alpha$, the zero $x=(\alpha+1)^{1/\alpha}$ lies strictly between $1$ and $2$, and the kernel is negative to its right before $2$. This is sharpness only within the displayed family, not a claim of optimality over all possible completions. $\square$

## 1.3 The endpoint is an elementary floor kernel

At $b=3/2$, the power sum is exact:

$$
\boxed{a_{\triangle}(t)=e^{-3t/2}\lfloor e^t\rfloor
\bigl(\lfloor e^t\rfloor+1-e^t\bigr),\quad t\ge0.} \tag{1.6}
$$

Its left limit is zero at each positive integer threshold; the right jump is $n^{-1/2}$ at $t=\log n$. These point conventions do not affect the $L^1$ convolution operator. In particular,

$$0\le a_{\triangle}(t)\le e^{-t/2},\qquad a_{\triangle}(0+)=1.$$

The Laplace transform, first obtained in the absolutely convergent half-plane and then continued using this envelope, is

$$
\boxed{A_{\triangle}(p)=
\frac{p-1/2}{(p+1/2)(p+3/2)}\zeta(p+1/2).} \tag{1.7}
$$

The apparent singularity at $p=1/2$ is removable and is not a zero.

The total mass is

$$q_{\triangle}=\int_0^\infty a_{\triangle}(t)\,dt
=-\frac23\zeta(1/2). \tag{1.8}$$

It is strictly less than one. Here is a rational certificate, rather than a decimal assertion. Let $\eta(1/2)=\sum_{n\ge1}(-1)^{n-1}/\sqrt n$. Its positive Euler transform is

$$\eta(1/2)=\sum_{k\ge0}2^{-k-1}\sum_{j=0}^k(-1)^j\binom{k}{j}(j+1)^{-1/2}.$$

The inner differences belong to $[0,1]$: use the integral for $(j+1)^{-1/2}$ and the nonnegative factor $(1-e^{-u})^k$. The tail after $14$ terms is at most $2^{-14}$. Rational square-root enclosures give

$$0.6048974044190445<\eta(1/2)<0.6049584395752946<\frac{121}{200}.$$

The full rational endpoints, not the printed decimals, are in the certificate. Since $\sqrt2>707/500$ and $\zeta(1/2)=\eta(1/2)/(1-\sqrt2)$,

$$
\boxed{0<q_{\triangle}<\frac{605}{621}<1.} \tag{1.9}
$$

For $\epsilon\ge0$, let $\mathsf A_\epsilon$ be convolution on ordinary $L^2(0,\infty)$ by $a_{\triangle,\epsilon}(t)=e^{-\epsilon t}a_{\triangle}(t)$. Young's inequality gives

$$\|\mathsf A_\epsilon\|\le q_{\triangle}<605/621.$$

In fact its norm equals the integral of the positive kernel, by testing increasingly long nearly constant inputs. We only need the upper bound.

Thus the native operator $I-\mathsf A_\epsilon$ has the genuine Neumann inverse

$$\|(I-\mathsf A_\epsilon)^{-1}\|\le621/16. \tag{1.10}$$

This is an inverse of $I-\mathsf A_\epsilon$, not an inverse of $\mathsf A_\epsilon$.

Within the positive family of Theorem 1 the mass is exactly $-\zeta(1/2)/b$. It decreases with $b$, so $b=3/2$ simultaneously minimizes this mass and maximizes the tail exponent in (1.12) within that family. This limited optimization does not assert optimality over all possible native completions.

## 1.4 The original input has a faster tail

Set $y_b=c_b*U$. Then the exact causal equation is

$$a_b*X=y_b. \tag{1.11}$$

Since $J_s(-1/2)=0$ and $\zeta'(0)$ is finite, (1.3) gives

$$\int_0^\infty e^{u/2}U(u)\,du=0.$$

Therefore, with $\alpha=b-1/2$,

$$
\begin{split}
y_b(t)={}&\frac{\alpha+1}{\alpha}\widehat U(-b)e^{-bt}\\
&+\frac1\alpha e^{-t/2}\int_t^\infty e^{u/2}U(u)\,du
-\frac{\alpha+1}{\alpha}e^{-bt}\int_t^\infty e^{bu}U(u)\,du.
\end{split} \tag{1.12}
$$

The last two terms decay faster than every exponential, using (1.2). In particular

$$y_{\triangle}(t)=2\widehat U(-3/2)e^{-3t/2}+\text{super-exponentially decaying remainder},$$

and $e^{\tau t}y_{\triangle}\in L^2$ for every $\tau<3/2$. This is an actual upper bound on the unchanged-source input. It is not an upper bound on $X$.

## 1.5 Exact relation to B04 and retained visibility

The old B04 multiplier used $b=1$. The new one satisfies

$$A_{\triangle}(p)=\frac{p+1}{p+3/2}A_1(p). \tag{1.13}$$

This left factor is bounded and causally invertible on every nonnegatively damped $L^2$ space; its inverse is $1+\tfrac12/(p+1)$, of norm at most $3/2$. The old and new range conditions are therefore equivalent after applying the same factor to the input. In particular no zero-divisor obstruction has been removed.

At a hypothetical native zero $\rho$, let $\lambda=\rho-1/2$ and let $m$ be its multiplicity. For $\Re\lambda>0$,

$$\widehat y_{\triangle}(p)=-c_{3/2}(p)J_s(p)\zeta'(p+1/2),$$

$$\widehat y_{\triangle}^{(j)}(\lambda)=0\ (j<m-1),\qquad
\widehat y_{\triangle}^{(m-1)}(\lambda)
=-c_{3/2}(\lambda)J_s(\lambda)\zeta^{(m)}(\rho)\ne0. \tag{1.14}$$

There is no missing factorial in (1.14). Meanwhile

$$\operatorname{Res}_{p=\lambda}\widehat X(p)=-mJ_s(\lambda). \tag{1.15}$$

Thus the same source remains visible in Step 1, complete in the Step 2 paper sense, and attached to the exact Step 3 compact-potential bridge. The new positive contraction is useful native operator structure. It is not Step 4 closure, because its zeros still annihilate the unstable part when it acts forward.
