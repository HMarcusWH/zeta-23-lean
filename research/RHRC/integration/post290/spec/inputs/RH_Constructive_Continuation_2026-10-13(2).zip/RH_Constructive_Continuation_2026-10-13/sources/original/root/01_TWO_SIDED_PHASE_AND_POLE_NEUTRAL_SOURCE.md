# Retaining the original phase, scale, and pole-neutral source

Date: 13 October 2026. Status: **new paper derivation, with the inherited detector and explicit-formula foundations stated below. No RH conclusion.**

This note responds to the loss of source information between the original two-translate detector and later selected grounds. It strengthens the original detector conclusion before any minimization. It also gives the exact compact inverse of the pole-killing operator. Neither construction changes the native prime weights.

## 1. The fixed source and its full provenance

Fix the original scale \(r=1/4096\). Let

\[
c_j=\frac{r}{j(j+1)},\qquad
q_r=*_{j\ge1}\frac{\mathbf 1_{[-c_j,c_j]}}{2c_j},
\qquad k_r=(\partial_x^2-1/4)q_r.
\tag{P1}
\]

The inherited universal-detector theorem proves that \(q_r\) is a real, even, nonnegative, smooth probability density with full support \([-r,r]\), and

\[
\widehat k_r(z)=-(z^2+1/4)P_r(z),\qquad
P_r(z)=\prod_{j\ge1}\operatorname{sinc}(c_jz).
\tag{P2}
\]

All zeros of \(P_r\) are real. The only nonreal zeros of \(\widehat k_r\) are \(\pm i/2\), each simple. Both exponential moments of \(k_r\) vanish. The exact Fourier convention is \(\widehat f(z)=\int f(x)e^{izx}\,dx\).

Set \(h_r=k_r*k_r\), and retain the actual native correlation

\[
C_r(t)=\sum_\rho m_\rho\widehat k_r(\gamma_\rho)^2e^{\lambda_\rho t},
\qquad \lambda_\rho=\rho-1/2,\quad \gamma_\rho=\lambda_\rho/i.
\tag{P3}
\]

The coefficient is a complex square. The reflection symmetries make \(C_r\) real and even; they do not replace that square by an absolute square. The inherited additive Weil dictionary gives \(C_r(t)=\mathfrak q(\tau_tk_r,k_r)\) with its factor-one normalization. In particular \(C_r(0)=\mathfrak q(k_r,k_r)>0\) by the supplied small-aperture positivity theorem.

Write

\[
\Delta=\sup_\rho |\Re\rho-1/2|.
\]

Under an off-line zero, \(0<\Delta\le1/2\). The inherited Gevrey estimate and zero count give \(\sum_\rho m_\rho|\widehat k_r(\gamma_\rho)|^2<\infty\), and hence \(|C_r(t)|\le S_re^{\Delta t}\) for \(t\ge0\).

## 2. A self-contained positive-Laplace lemma

**Lemma.** Let \(u\ge0\) be locally integrable and of finite exponential order on \([0,\infty)\). If its Laplace integral has finite real abscissa of convergence \(\sigma_c\), then its holomorphic transform cannot extend holomorphically to a neighborhood of the real point \(\sigma_c\).

**Proof.** Suppose it extends to a disk of radius \(R>0\) centered at \(\sigma_c\). At \(x_0=\sigma_c+R/4\), its Taylor series has radius at least \(3R/4\). Differentiation of the convergent Laplace integral gives

\[
(-1)^nU^{(n)}(x_0)=\int_0^\infty t^n e^{-x_0t}u(t)\,dt\ge0.
\]

At \(x_1=x_0-R/2<\sigma_c\), the Taylor series therefore has nonnegative terms. Its finite sum and monotone convergence imply

\[
\int_0^\infty e^{-x_1t}u(t)\,dt
=\sum_{n\ge0}\frac{(R/2)^n}{n!}
\int_0^\infty t^ne^{-x_0t}u(t)\,dt<\infty,
\]

contrary to the definition of \(\sigma_c\). QED.

The same proof works after deleting or adding a compact initial interval. No named external theorem is needed for this step.

## 3. Both detector phases have the full exponential type

**Theorem P.** Under an off-line zero, for every \(0\le\beta<\Delta\), every \(M>0\), and every \(T_0\), there are \(t_+,t_->T_0\) such that

\[
C_r(t_+)>Me^{\beta t_+},\qquad
C_r(t_-)<-Me^{\beta t_-}.
\tag{P4}
\]

Consequently the positive and negative parts separately have exponential type \(\Delta\).

**Proof.** In the initial half-plane \(\Re p>\Delta\), termwise integration gives

\[
R_r(p)=\mathcal LC_r(p)
=\sum_\rho\frac{m_\rho\widehat k_r(\gamma_\rho)^2}{p-\lambda_\rho}.
\tag{P5}
\]

This series is normally convergent on compact sets avoiding its poles. To see this, the finitely many bounded-height zeros cause no problem, and for all other zeros the denominator is bounded below by a constant times their height; absolute summability of the numerators then dominates the tail. Thus (P5) is a meromorphic continuation, with a nonzero residue at every off-line zero. There is no pole at any positive real point: a positive real \(\lambda\) would be a real nontrivial zero of \(\zeta\). For \(0<s<1\), the alternating eta series is positive by grouping its successive pairs, while \(1-2^{1-s}<0\), so \(\zeta(s)=\eta(s)/(1-2^{1-s})<0\). For \(s>1\) its Dirichlet series is positive. The point \(s=1\) is a pole, not a zero. The zero-series continuation is consequently holomorphic at the real point \(p=\Delta\), including the case \(\Delta=1/2\).

Suppose, for a contradiction, \(C_r(t)\ge-Me^{\beta t}\) on some terminal interval. On that interval define \(u(t)=C_r(t)+Me^{\beta t}\ge0\), and set \(u=0\) on the preceding compact interval. The exponential upper bound gives \(\sigma_c(u)\le\Delta\). If \(\sigma_c(u)<\Delta\), choose a visible right pole with real part greater than \(\max(\sigma_c(u),\beta)\). The Laplace transform of \(u\), minus \(M/(p-\beta)\) and the entire initial correction, would make \(R_r\) holomorphic there, contradicting its nonzero residue. Hence \(\sigma_c(u)=\Delta\).

But that same expression, using the meromorphic continuation (P5), is holomorphic near the real point \(\Delta>\beta\). This contradicts the positive-Laplace lemma. Applying the argument to \(-C_r\) excludes the opposite eventual upper bound. This proves (P4).

The upper type of each part is at most \(\Delta\) by the original exponential bound; (P4) for every smaller \(\beta\) gives the matching lower type. QED.

This theorem strengthens a bare absolute-growth or negative-determinant conclusion. It does not establish a common observation time or a uniform lower bound over all zeros.

## 4. Original even and odd witnesses, with their exact zero pattern

For \(t>2r\), use centered translations and define

\[
v^+_{r,t}(x)=k_r(x-t/2)+k_r(x+t/2),\qquad
v^-_{r,t}(x)=k_r(x-t/2)-k_r(x+t/2).
\tag{P6}
\]

Their two supports are disjoint. Writing \(n_r=\|k_r\|_2^2\), the exact identities are

\[
\|v^\pm_{r,t}\|_2^2=2n_r,\qquad
\mathfrak q(v^\pm_{r,t},v^\pm_{r,t})
=2[C_r(0)\pm C_r(t)].
\tag{P7}
\]

The vectors are respectively even and odd, pole-neutral, and supported in the physical interval of full length \(L=t+2r\). Their transforms retain the original phase:

\[
\widehat v^+_{r,t}(z)=2\cos(tz/2)\widehat k_r(z),\qquad
\widehat v^-_{r,t}(z)=2i\sin(tz/2)\widehat k_r(z).
\tag{P8}
\]

Cosine and sine have only real zeros. At \(z=\pm i/2\), cosine is nonzero and sine is nonzero because \(t>0\). Thus both sources have exactly the same two simple nonreal zeros \(\pm i/2\) as the original detector, and no other nonreal zeros.

Moreover, the even source is the pole-killed image of the **nonnegative** compact function

\[
g^+_{r,t}(x)=q_r(x-t/2)+q_r(x+t/2)\ge0,
\quad v^+_{r,t}=(\partial_x^2-1/4)g^+_{r,t}.
\tag{P9}
\]

By Theorem P, each parity has arbitrarily late witnesses with negative Rayleigh quotient of exponential depth. More precisely, for fixed \(0<\beta<\Delta\), choosing \(M=4n_r\) and then sufficiently large \(t\) gives along an even sequence and an odd sequence

\[
\frac{\mathfrak q(v^\pm_{r,t},v^\pm_{r,t})}{\|v^\pm_{r,t}\|_2^2}
\le-2e^{\beta t}.
\tag{P10}
\]

The constants and the two sequences can differ. The same fixed \(r\), original source, two-translate phase, and norm normalization remain in every formula. No ground has been substituted.

In particular, a later theorem that a selected pole-neutral ground has only the elementary nonreal source zeros does **not** contradict the original detector's construction: (P8) already has that pattern. An opposing energy or phase restriction still has to be proved.

## 5. Exact compact inverse of pole killing

Let \(I=[-a,a]\), and let \(f\in L^2(\mathbb R)\) be supported in \(I\). Define \(\ell_\pm(f)=\int f(x)e^{\pm x/2}\,dx\).

**Theorem K.** The following are equivalent:

1. \(\ell_+(f)=\ell_-(f)=0\).
2. There exists a unique \(g\in H^2(\mathbb R)\), supported in \(I\), with \((\partial_x^2-1/4)g=f\).

The source is explicitly

\[
g(x)=-\int_{-a}^a e^{-|x-y|/2}f(y)\,dy.
\tag{P11}
\]

It satisfies \(g(\pm a)=g'(\pm a)=0\) in the Sobolev trace sense. If \(f\in H^s(\mathbb R)\), then \(g\in H^{s+2}(\mathbb R)\).

**Proof.** The distributional fundamental solution of \(\partial_x^2-1/4\) is \(-e^{-|x|/2}\): its derivative has jump one at zero. Formula (P11) is its convolution with \(f\). For \(x>a\), it is \(-e^{-x/2}\ell_+(f)\); for \(x<-a\), it is \(-e^{x/2}\ell_-(f)\). Thus the two moment conditions give exact compact support. On the real Fourier axis,

\[
\widehat g(\xi)=-\frac{\widehat f(\xi)}{\xi^2+1/4},
\]

which proves the asserted Sobolev regularity and uniqueness in \(H^2\). A globally \(H^2\) function vanishing outside \(I\) has both zero traces at each endpoint. Conversely, integration by parts against the two exponential solutions, or the same Fourier identity at \(\pm i/2\), proves the two vanishing moments of \(f\). QED.

This establishes a bounded inverse between the pole-neutral compact \(L^2\) sources and their clamped \(H^2\) potentials. It does not imply that the potential is nonnegative, is the original \(q_r\), or is Gevrey smooth. Those stronger facts must be retained independently when the source is (P6).

## 6. What a constrained contact actually says

For the closed native Weil form \(\mathfrak q\) on \(I\), let

\[
\mathcal N_a=\{f:\ell_+(f)=\ell_-(f)=0\}
\]

inside its form domain. If \(f\) is an eigenvector of the form restricted to \(\mathcal N_a\), with eigenvalue \(\lambda\), then its weak Euler equation has the form

\[
(W*f)(x)=\lambda f(x)+A e^{x/2}+B e^{-x/2}
\quad\text{on }(-a,a)
\tag{P12}
\]

for some scalars \(A,B\). To justify this, the continuous functional \(v\mapsto\mathfrak q(v,f)-\lambda\langle v,f\rangle\) vanishes on the simultaneous kernel of the two continuous moment functionals. It therefore factors through their two-dimensional quotient. Testing on compact smooth functions identifies its distributional representative with the stated exponential combination. Since the right side is \(L^2(I)\), this also identifies the compressed operator representative of the same form eigenvector.

At a restricted zero contact, \(\lambda=0\), but \(A,B\) are not thereby zero. Thus replacing (P12) by the unrestricted contact equation \(W*f=0\) would erase precisely the constraints that preserved pole neutrality. Likewise a negative \(\lambda\) must remain in the equation.

Writing \(f=(\partial_x^2-1/4)g\) by Theorem K gives the exact distributional interior equation

\[
(\partial_x^2-1/4)[W*(\partial_x^2-1/4)g]
=\lambda(\partial_x^2-1/4)^2g.
\tag{P13}
\]

This kills the two finite-rank multipliers only after applying the differential operator. It does not grant additional derivatives of \(f\), suppress endpoint distributions from a globally differentiated source, or provide a global exterior bound. The undifferentiated equation (P12), the compact potential (P11), and both endpoint traces remain the primary source data.

## 7. Closing attempt and current status

The new input to the joint campaign is a stronger simultaneous witness package: both exponential phases are available; the even source has a positive precursor; the original sine/cosine factor is explicit; the norm, scale, pole cancellation, source zero pattern, and physical support are known before any minimization. The negative-threshold and source-transport notes then test how much of this package can be carried into a selected finite state.

The results here do not show that these data are incompatible. In particular, the original source's elementary-zero pattern is consistent with the constrained descent classification. The remaining work must bound the actual native quadratic value, the source-specific prime response, or the complete constrained Schur complement. No such opposite inequality is asserted in this note.

### Source dependencies

- v2.9, `ANALYTIC_PRESSURE_POINT_EXTRACTED/proofs/01_single_universal_detector.md`: exact sinc construction, Gevrey estimates, universal visibility and summed-zero convergence.
- v2.5/v2.9 source dictionary: factor-one additive Weil form and the complex form-domain extension.
- v2.9, `STEP3_STEP4_REQUIREMENTS_v1_0_SOURCE_EXTRACTED.md`: retention of source, scale, centering phase, moment constraints and actual selected state.
- All arguments in Sections 2–6 above are supplied in this note; they do not assume the unresolved Step 4 upper estimate.
