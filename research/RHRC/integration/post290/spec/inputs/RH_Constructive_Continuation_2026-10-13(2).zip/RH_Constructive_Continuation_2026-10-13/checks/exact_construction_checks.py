"""Finite exact controls for the constructive continuation.
These are algebra and scope tests. They do not prove infinite analytic statements.
"""
from __future__ import annotations
from fractions import Fraction as F
from math import comb, factorial, gcd, isqrt
from pathlib import Path
import json
import sympy as s

counts={}
def check(group, condition):
    if not bool(condition):raise AssertionError(group)
    counts[group]=counts.get(group,0)+1

p,b=s.symbols('p b');alpha=b-s.Rational(1,2)
cb=(p-s.Rational(1,2))/((p+s.Rational(1,2))*(p+b))
check('completion_algebra',s.cancel(cb-(-1/alpha/(p+s.Rational(1,2))+(alpha+1)/alpha/(p+b)))==0)
c1=cb.subs(b,1);c3=cb.subs(b,s.Rational(3,2))
check('completion_algebra',s.cancel(c3/c1-(p+1)/(p+s.Rational(3,2)))==0)
check('completion_algebra',s.cancel(c1/c3-(1+s.Rational(1,2)/(p+1)))==0)
J=(p*p-s.Rational(1,4))**2
check('completion_algebra',s.limit(c3*J,p,-s.Rational(1,2))==0)
check('completion_algebra',s.limit((p+s.Rational(3,2))*c3,p,-s.Rational(3,2))==2)
# Exact physical bound after multiplying the triangle kernel by sqrt(x).
for N in range(1,101):
    for delta in [F(0),F(1,4),F(1,2),F(3,4),F(999,1000)]:
        x=F(N)+delta;value=F(N)*(N+1-x)/x
        check('triangle_kernel_bounds',0<value<=1)
# Beyond the admissible completion parameter: b=5/2, x=7/4<2.
check('completion_sharpness',F(3)/F(7,4)**2-1==F(-1,49))
check('completion_sharpness',F(7,4)<2)
# The rational constant certificate uses the exact identity below.
check('completion_mass',F(2,3)*F(121,200)/F(207,500)==F(605,621))
check('completion_mass',707**2<2*500**2)

u=s.symbols('u',real=True);T=s.symbols('T',real=True)
def exp_integral(poly,d):
    P=s.Poly(s.expand(poly),u)
    return s.simplify(sum(coef*s.factorial(k)/(2*d)**(k+1) for (k,),coef in P.terms()))
for n in range(7):
    for d in [s.Rational(1,8),s.Rational(1,3),s.Rational(2,3)]:
        Q=(-1)**n*s.factorial(n)/(2*d)**n*s.laguerre(n,2*d*u)
        check('laguerre_jet_constructor',s.Poly(Q,u).LC()==1)
        for j in range(n):
            check('laguerre_jet_constructor',exp_integral(Q*(u+T)**j,d)==0)
        K=s.factorial(n)**2/(2*d)**(2*n+1)
        check('laguerre_jet_constructor',exp_integral(Q*Q,d)==K)
        check('laguerre_jet_constructor',exp_integral((-1)**n*(u+T)**n*Q,d)==(-1)**n*K)
        # This tests the multiplicity factorial; n>=2 detects its deletion.
        if n>=2:check('mutation_guards',K!=1/(2*d)**(2*n+1))

# Conjugate-paired synthetic jets: tests Hermitian phase accounting, not zeta zeros.
eps=s.Rational(1,8)
lam=s.Rational(1,4)+20*s.I
idx=[(lam,0),(lam,1),(s.conjugate(lam),0),(s.conjugate(lam),1)]
G=s.Matrix([[(-1)**(j+k)*s.factorial(j+k)/(z+s.conjugate(w)-2*eps)**(j+k+1)
             for w,k in idx] for z,j in idx])
check('finite_jet_gram',s.simplify(G-G.conjugate().T)==s.zeros(4))
for n in range(1,5):check('finite_jet_gram',s.simplify(G[:n,:n].det())>0)
y=s.Matrix([0,2+3*s.I,0,2-3*s.I]);coeff=G.inv()*y
check('finite_jet_gram',s.simplify(G*coeff-y)==s.zeros(4,1))
check('finite_jet_gram',s.simplify(coeff[2]-s.conjugate(coeff[0]))==0)
check('finite_jet_gram',s.simplify(coeff[3]-s.conjugate(coeff[1]))==0)
cost=s.simplify((y.conjugate().T*G.inv()*y)[0])
check('finite_jet_gram',cost.is_Rational and cost>0)
# Removing the conjugation does not produce the Hermitian Gram we used.
wrong=s.Matrix([[(-1)**(j+k)*s.factorial(j+k)/(z+w-2*eps)**(j+k+1)
                 for w,k in idx] for z,j in idx])
check('mutation_guards',s.simplify(wrong-wrong.conjugate().T)!=s.zeros(4))

# Exact finite-dimensional realization of valid Landweber versus false zero limit.
A=s.Matrix([[s.Rational(1,3),s.Rational(1,6)],[s.Rational(1,3),s.Rational(1,6)]])
K=A*A.T;Id=s.eye(2);source=s.Matrix([1,0]);f=s.zeros(2,1);e=source
q2=s.Rational(5,18)
for n in range(12):
    fnew=f+A.T*e;enew=source-A*fnew
    check('landweber_identities',enew==(Id-K)*e)
    check('landweber_identities',(enew.T*enew)[0] <= (e.T*e)[0]-(2-q2)*(e.T*K*e)[0])
    # The exact invariant null component is never removed.
    check('landweber_identities',enew[0]-enew[1]==1)
    f,e=fnew,enew
check('mutation_guards',(s.Matrix([1,-1]).T*source)[0]!=0)
check('landweber_identities',K*s.Matrix([1,-1])==s.zeros(2,1))

# Divisor coefficients represented in the free vector space on log(primes).
def log_vector(n):return {int(q):int(a) for q,a in s.factorint(n).items()}
def coef_A(n,Y):
    out={}
    for a in s.divisors(n):
        if F(a)>Y:
            mu=int(s.mobius(a))
            if mu:
                for q,e in log_vector(n//a).items():out[q]=out.get(q,0)+mu*e
    return {q:e for q,e in out.items() if e}
for n in range(2,2001):
    fac=s.factorint(n)
    if len(fac)==1:
        check('prime_power_support',coef_A(n,F(isqrt(n)+1))=={})
check('strict_cutoff_seams',coef_A(42,F(7))=={2:1,3:1})
check('strict_cutoff_seams',coef_A(42,F(20,3))=={})
check('strict_cutoff_seams',coef_A(49,F(7))=={})
check('mutation_guards',coef_A(49,F(6))=={7:-1})
check('composite_signs',coef_A(202,F(15))=={2:-1})
check('composite_signs',coef_A(2*101*103,F(2*101*103,3))=={2:1})
# e^(2s) <= 1/(1-2s) < 21/20 at s=1/4096.
check('coprime_overlap',F(2048,2047)<F(21,20))
for prime in list(s.primerange(2,501)):
    lo=(20*prime+20)//21;hi=(21*prime)//20
    for n in range(max(2,lo),hi+1):
        if n!=prime:check('coprime_overlap',gcd(prime,n)==1)

# Coherent modulation: exact cancellation of the atom phase and source phase.
t,tau,ln=s.symbols('t tau ell',real=True)
check('coherent_phase',s.simplify(s.exp(-s.I*tau*ln)*s.exp(-s.I*tau*(t-ln))-s.exp(-s.I*tau*t))==0)
q=s.Function('q')(t)
mod=s.exp(-s.I*tau*t)*q
D=lambda v:s.diff(v,t)+s.I*tau*v
check('coherent_phase',s.simplify(D(D(mod))-s.Rational(1,4)*mod-s.exp(-s.I*tau*t)*(s.diff(q,t,2)-s.Rational(1,4)*q))==0)

out={'status':'PASS','assertions_by_group':counts,'total_assertions':sum(counts.values()),
     'paired_jet_minimum_norm_squared_exact':str(cost),
     'scope':'Finite exact algebra, synthetic operator controls and arithmetic support tests only; not a Lean proof or RH closure.'}
root=Path(__file__).resolve().parents[1]
(root/'evidence'/'exact_construction_checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
