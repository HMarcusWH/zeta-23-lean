---
title: "Constructing the missing objects"
subtitle: "Native contraction, exact correction costs, and a source-preserving Step 4 attempt"
author: "RH project research note · prepared for Marcus Hermansson"
date: "13 October 2026"
documentclass: article
fontsize: 11pt
papersize: a4
geometry: [margin=22mm]
mainfont: Liberation Serif
sansfont: Liberation Sans
monofont: DejaVu Sans Mono
colorlinks: true
linkcolor: black
urlcolor: black
toc: true
toc-depth: 1
---

\newpage

# Research result and exact boundary

**Step 4 is still OPEN.** This campaign constructs concrete objects satisfying several of the previously specified requirements, rather than introducing another unspecified solver or norm. It does not construct the missing global signed cancellation estimate or prove that the native range residual is zero.

The strongest new construction is an explicitly positive native convolution kernel

$$a_{\triangle}(t)=e^{-3t/2}\lfloor e^t\rfloor\bigl(\lfloor e^t\rfloor+1-e^t\bigr),\qquad t\ge0,$$

with a rigorously certified mass below $605/621<1$. It uses the actual integer lattice and the unchanged original detector-derived source. Its completion is optimized inside an explicitly solved one-parameter family. The corresponding input has a faster tail, while the off-line zero divisor and the original pole visibility remain intact.

A positive contractive forward operator is not automatically invertible. An exact native-frequency enclosure defeats the obvious inverse iteration. The paper instead constructs an adjoint-based iteration whose residual decreases and converges strongly to the precise native adjoint-kernel component. It supplies the full finite-jet minimum-cost correction formula, preserving complex phases and multiplicities. The sharp single-zero leakage exponent used there is inherited from B04 and is not presented as a new discovery.

On the arithmetic side, the original field and its long-divisor representation are paired before taking an absolute bound. The late interaction contains only a prime on one side and a non-prime-power composite on the other, with coprime indices. A whole near-gap sector is independently absolutely summable. The remaining signed interaction is an explicit function of the actual source and coefficients. Its quiet-subsequence bound, or an independently proved quantitative non-saturation angle, would suffice for closure. Neither is established here.

## Authority and evidence

All new infinite-dimensional arguments in this note are **PAPER deductions**. The original detector, Gevrey drive, compact-potential bridge, and the previous stable arithmetic error decomposition are inherited PAPER premises. Their selected source texts are copied unchanged in the archive. The arguments do not require a new continuous full-contact existence theorem or identify the original detector with a later selected ground.

No new local Lean build or repository mutation occurred. The live read found merged main still at the #288 merge. At the pinned #290 head, the focused Step 3 build now succeeds; other workflows were running or queued. The branch also reports a separate non-finite interval-remainder bug invalidating prior whole-cover receipts. No such numerical cover is used as a premise here. The repository observation appendix states exactly what was and was not independently checked.

Two finite suites pass: a rational-outward enclosure of the new mass bound and two native-frequency checks, and 3,047 exact algebraic/support assertions. They validate their stated finite objects, not the open global conclusion. The review in this package is a self-review, not an external or independent-agent review.

## Dependency map: keep the same source

The source is fixed once:

$$q_s\ \longmapsto\ k_s=Pq_s\ \longmapsto\ j_s=P^2q_s,
\qquad s=1/4096,\quad P=\partial^2-1/4.$$

The following two constructions then retain that exact source.

**Range construction.** Native integer divisor identity $\to$ positive completion $\to$ actual stable input $\to$ explicit adjoint iteration $\to$ exact residual projection. The last projection has not been shown to vanish.

**Arithmetic construction.** Native prime field $\to$ same-source stable-error decomposition $\to$ prime–composite mixed pairing $\to$ controlled near-gap sector $\to$ complete remaining coprime interaction. Its required upper law has not been proved.

Step 1 supplies nonzero native residue data. Step 2 supplies the unchanged source's visibility of each off-line zero. Step 3 supplies compact pole-neutral duality and exact source transport. Those facts produce the lower obstruction and make either new upper law sufficient; they do not themselves prove that upper law.

The detailed proofs follow. Their equation numbers are local to each numbered section. Every norm of a source or arithmetic output has its damping and domain stated before it is used.


# 1. Constructing a positive native completion with norm below one

**Status: PAPER deduction.** The construction changes the rational completion of the native integer operator, not the original detector, the integer lattice, the von Mangoldt coefficients, or the zeta zero divisor. No RH assumption is used in this section. The numerical constant is supported by the exact rational enclosure in the package.

## 1.1 Frozen source

Retain the previous campaign's fixed scale $s=1/4096$, compact even Gevrey probability density $q_s$, and

$$
P=\partial_t^2-\tfrac14,\qquad k_s=Pq_s,\qquad j_s=P^2q_s.
$$

Write

$$
J_s(p)=\int_{\mathbb R}e^{-pt}j_s(t)\,dt
       =(p^2-\tfrac14)^2Q_s(p).
$$

The source has the two double elementary zeros and is nonzero at every off-line native zero coordinate $\lambda=\rho-1/2$. These source facts, the compact test-space inverse of $P$, and the original two-lobe forcing identity are inherited PAPER premises from the original-detector package, not results re-formalized here.

The actual measures and fields are

$$
N=\sum_{n\ge1}n^{-1/2}\delta_{\log n},\qquad
\Pi=\sum_{n\ge2}\Lambda(n)n^{-1/2}\delta_{\log n},
$$

$$
X=\Pi*j_s,\qquad U=((\log n)N)*j_s.
$$

All these convolutions are locally finite. Because $s<\log2$, both $X$ and $U$ vanish before $\log2-s>0$. The $n=1$ term of $U$ is zero. The native divisor identity $1*\Lambda=\log$ gives

$$N*X=U. \tag{1.1}$$

The prior fixed-source integer-drive proof supplies constants $C_s,\kappa_s>0$ such that, for sufficiently large $t$,

$$|U(t)|\le C_s\exp(-\kappa_s e^{t/2}). \tag{1.2}$$

We use (1.2) only as an inherited analytic bound on this exact source. Consequently $\widehat U$ is entire, and the identity initially obtained for $\Re p>1/2$ continues as

$$\widehat U(p)=-J_s(p)\zeta'(p+1/2). \tag{1.3}$$

The double zero of $J_s$ cancels the double pole of $\zeta'$ at $p=1/2$.

## 1.2 Solve a one-parameter completion requirement

For $b>1/2$, put $\alpha=b-1/2$ and choose

$$
c_b(p)=\frac{p-1/2}{(p+1/2)(p+b)}
=-\frac1\alpha\frac1{p+1/2}
 +\frac{\alpha+1}{\alpha}\frac1{p+b}.
$$

Its causal kernel is

$$c_b(t)=\frac{-e^{-t/2}+(\alpha+1)e^{-bt}}\alpha\,1_{t\ge0}.$$

The zero at $p=1/2$ cancels the elementary zeta pole. The two denominator poles are strictly on the left. Define $a_b=c_b*N$ locally, and let $x=e^t$, $n=\lfloor x\rfloor$. Direct summation gives the exact, native formula

$$
a_b(t)=\frac{x^{-1/2}}\alpha
\left[(\alpha+1)x^{-\alpha}\sum_{k=1}^{n}k^\alpha-n\right]. \tag{1.4}
$$

This formula involves every integer up to the true floor, not selected primes or altered coefficients.

**Theorem 1 (sharp positivity interval in this family).** For $1/2<b\le3/2$,

$$0<a_b(t)\le\frac{\alpha+1}{2\alpha}e^{-t/2}\quad(t\ge0). \tag{1.5}$$

For each $b>3/2$, the kernel is negative on a nonempty subinterval before the first prime, $0<t<\log2$.

**Proof.** For $0<\alpha\le1$, induction and the concave Bernoulli inequality prove

$$
\sum_{k=1}^{n}k^\alpha\ge\frac{n(n+1)^\alpha}{\alpha+1}.
$$

Indeed, the induction step reduces to

$$\left(1+\frac1{n+1}\right)^\alpha\le1+\frac\alpha{n+1}.$$

Since $n\le x<n+1$, substitution in (1.4) gives strict positivity. The composite trapezoidal inequality for the concave function $u^\alpha$ gives

$$\sum_{k=1}^{n}k^\alpha\le\frac{n^{\alpha+1}}{\alpha+1}+\frac12n^\alpha.$$

Thus the bracket in (1.4) is at most

$$n[(n/x)^\alpha-1]+\tfrac12(\alpha+1)(n/x)^\alpha
\le\tfrac12(\alpha+1),$$

which proves (1.5).

For $\alpha>1$, use $n=1$ in (1.4). Its sign is the sign of $(\alpha+1)x^{-\alpha}-1$. Since $\alpha+1<2^\alpha$, the zero $x=(\alpha+1)^{1/\alpha}$ lies strictly between $1$ and $2$, and the kernel is negative to its right before $2$. This is sharpness only within the displayed family, not a claim of optimality over all possible completions. $\square$

## 1.3 The endpoint is an elementary floor kernel

At $b=3/2$, the power sum is exact:

$$
\boxed{a_{\triangle}(t)=e^{-3t/2}\lfloor e^t\rfloor
\bigl(\lfloor e^t\rfloor+1-e^t\bigr),\quad t\ge0.} \tag{1.6}
$$

Its left limit is zero at each positive integer threshold; the right jump is $n^{-1/2}$ at $t=\log n$. These point conventions do not affect the $L^1$ convolution operator. In particular,

$$0\le a_{\triangle}(t)\le e^{-t/2},\qquad a_{\triangle}(0+)=1.$$

The Laplace transform, first obtained in the absolutely convergent half-plane and then continued using this envelope, is

$$
\boxed{A_{\triangle}(p)=
\frac{p-1/2}{(p+1/2)(p+3/2)}\zeta(p+1/2).} \tag{1.7}
$$

The apparent singularity at $p=1/2$ is removable and is not a zero.

The total mass is

$$q_{\triangle}=\int_0^\infty a_{\triangle}(t)\,dt
=-\frac23\zeta(1/2). \tag{1.8}$$

It is strictly less than one. Here is a rational certificate, rather than a decimal assertion. Let $\eta(1/2)=\sum_{n\ge1}(-1)^{n-1}/\sqrt n$. Its positive Euler transform is

$$\eta(1/2)=\sum_{k\ge0}2^{-k-1}\sum_{j=0}^k(-1)^j\binom{k}{j}(j+1)^{-1/2}.$$

The inner differences belong to $[0,1]$: use the integral for $(j+1)^{-1/2}$ and the nonnegative factor $(1-e^{-u})^k$. The tail after $14$ terms is at most $2^{-14}$. Rational square-root enclosures give

$$0.6048974044190445<\eta(1/2)<0.6049584395752946<\frac{121}{200}.$$

The full rational endpoints, not the printed decimals, are in the certificate. Since $\sqrt2>707/500$ and $\zeta(1/2)=\eta(1/2)/(1-\sqrt2)$,

$$
\boxed{0<q_{\triangle}<\frac{605}{621}<1.} \tag{1.9}
$$

For $\epsilon\ge0$, let $\mathsf A_\epsilon$ be convolution on ordinary $L^2(0,\infty)$ by $a_{\triangle,\epsilon}(t)=e^{-\epsilon t}a_{\triangle}(t)$. Young's inequality gives

$$\|\mathsf A_\epsilon\|\le q_{\triangle}<605/621.$$

In fact its norm equals the integral of the positive kernel, by testing increasingly long nearly constant inputs. We only need the upper bound.

Thus the native operator $I-\mathsf A_\epsilon$ has the genuine Neumann inverse

$$\|(I-\mathsf A_\epsilon)^{-1}\|\le621/16. \tag{1.10}$$

This is an inverse of $I-\mathsf A_\epsilon$, not an inverse of $\mathsf A_\epsilon$.

Within the positive family of Theorem 1 the mass is exactly $-\zeta(1/2)/b$. It decreases with $b$, so $b=3/2$ simultaneously minimizes this mass and maximizes the tail exponent in (1.12) within that family. This limited optimization does not assert optimality over all possible native completions.

## 1.4 The original input has a faster tail

Set $y_b=c_b*U$. Then the exact causal equation is

$$a_b*X=y_b. \tag{1.11}$$

Since $J_s(-1/2)=0$ and $\zeta'(0)$ is finite, (1.3) gives

$$\int_0^\infty e^{u/2}U(u)\,du=0.$$

Therefore, with $\alpha=b-1/2$,

$$
\begin{split}
y_b(t)={}&\frac{\alpha+1}{\alpha}\widehat U(-b)e^{-bt}\\
&+\frac1\alpha e^{-t/2}\int_t^\infty e^{u/2}U(u)\,du
-\frac{\alpha+1}{\alpha}e^{-bt}\int_t^\infty e^{bu}U(u)\,du.
\end{split} \tag{1.12}
$$

The last two terms decay faster than every exponential, using (1.2). In particular

$$y_{\triangle}(t)=2\widehat U(-3/2)e^{-3t/2}+\text{super-exponentially decaying remainder},$$

and $e^{\tau t}y_{\triangle}\in L^2$ for every $\tau<3/2$. This is an actual upper bound on the unchanged-source input. It is not an upper bound on $X$.

## 1.5 Exact relation to B04 and retained visibility

The old B04 multiplier used $b=1$. The new one satisfies

$$A_{\triangle}(p)=\frac{p+1}{p+3/2}A_1(p). \tag{1.13}$$

This left factor is bounded and causally invertible on every nonnegatively damped $L^2$ space; its inverse is $1+\tfrac12/(p+1)$, of norm at most $3/2$. The old and new range conditions are therefore equivalent after applying the same factor to the input. In particular no zero-divisor obstruction has been removed.

At a hypothetical native zero $\rho$, let $\lambda=\rho-1/2$ and let $m$ be its multiplicity. For $\Re\lambda>0$,

$$\widehat y_{\triangle}(p)=-c_{3/2}(p)J_s(p)\zeta'(p+1/2),$$

$$\widehat y_{\triangle}^{(j)}(\lambda)=0\ (j<m-1),\qquad
\widehat y_{\triangle}^{(m-1)}(\lambda)
=-c_{3/2}(\lambda)J_s(\lambda)\zeta^{(m)}(\rho)\ne0. \tag{1.14}$$

There is no missing factorial in (1.14). Meanwhile

$$\operatorname{Res}_{p=\lambda}\widehat X(p)=-mJ_s(\lambda). \tag{1.15}$$

Thus the same source remains visible in Step 1, complete in the Step 2 paper sense, and attached to the exact Step 3 compact-potential bridge. The new positive contraction is useful native operator structure. It is not Step 4 closure, because its zeros still annihilate the unstable part when it acts forward.


# 2. Two inverse constructions: a native failure and a valid residual iteration

**Status: PAPER deduction, with a rigorously enclosed native-frequency falsifier.** This section actually constructs the approximation sequence. Its limit is identified exactly. The assertion that the limiting residual is zero remains OPEN.

## 2.1 Keep source, candidate output, and residual distinct

For fixed $\epsilon\ge0$, work in ordinary $H=L^2(0,\infty)$ with

$$y_\epsilon(t)=e^{-\epsilon t}y_{\triangle}(t),\qquad
\mathsf A_\epsilon g=(e^{-\epsilon\cdot}a_{\triangle})*g.$$

The exact original output is locally $X_\epsilon=e^{-\epsilon t}X$. It is not assumed to belong to $H$. The original source $j_s$, the actual integer kernel and the input $y_\epsilon$ never change. A vector $f_n\in H$ below is an approximation to the output, not the original two-lobe detector or a selected canonical ground.

The construction in Section 1 gives $\|\mathsf A_\epsilon\|\le q<1$, where the fixed rational choice $q=605/621$ is sufficient.

## 2.2 The obvious inverse iteration fails on the actual native operator

The tempting iteration is

$$f_0=0,\qquad f_{n+1}=f_n+(y_\epsilon-\mathsf A_\epsilon f_n).$$

Its residual is

$$e_n=(I-\mathsf A_\epsilon)^n y_\epsilon. \tag{2.1}$$

A contraction bound for $\mathsf A_\epsilon$ does not bound powers of $I-\mathsf A_\epsilon$. This distinction is not merely a hypothetical warning. The package's integer-outward interval calculation establishes, at both $\epsilon=0$ and $\epsilon=1/100$,

$$
\Re A_{\triangle}(\epsilon+12i)<-\frac4{100},\qquad
\left|1-A_{\triangle}(\epsilon+12i)\right|^2>\frac{109}{100}. \tag{2.2}
$$

The calculation uses the actual $\zeta(1/2+\epsilon+12i)$, not a planted zero or modified prime system. It is obtained from 63 Dirichlet terms, eight Bernoulli corrections and an explicit Euler--Maclaurin remainder. Every transcendental evaluation is enclosed using rational square-root, logarithm, sine and cosine bounds. The stored intervals are rational; decimal displays have no authority.

By continuity, $|1-A_{\triangle}(\epsilon+i\omega)|>1+c$ on some open frequency interval, with $c>0$. The transform of $y_\epsilon$ is analytic near that interval and not identically zero. Therefore it has positive $L^2$ mass on a subinterval. Plancherel applied to (2.1) shows that the residual norms grow at least geometrically with $n$. The naive iteration does not converge for these actual inputs.

This finite-frequency conclusion does not require an off-line zero and is not evidence that one exists.

For reproducibility, the Euler--Maclaurin remainder used at $N=64$, $M=8$, $z=1/2+\epsilon+12i$ is bounded by

$$
\frac{4}{6^{16}}\left(\prod_{j=0}^{15}(13+j)\right)
\frac{8}{64^{16}}\frac2{31}.
$$

Indeed $|(z)_{16}|\le\prod(13+j)$, $\Re z\ge1/2$, $\pi>3$, and the periodic-Bernoulli bound gives $|B_{16}(\{x\})|/16!\le2\zeta(16)/(2\pi)^{16}<4/6^{16}$. The formula and its integral remainder are classical Euler--Maclaurin analysis; the program exposes the complete bound rather than trusting a special-function decimal.

## 2.3 A valid native construction using the adjoint

The adjoint is explicit:

$$
(\mathsf A_\epsilon^*g)(t)
=\int_0^\infty e^{-\epsilon u}a_{\triangle}(u)g(t+u)\,du.
$$

It is an adjoint observation, not causal physical evolution. Use it to define the well-posed unit-step Landweber iteration

$$
\boxed{
 f_0=0,\quad e_n=y_\epsilon-\mathsf A_\epsilon f_n,\quad
 f_{n+1}=f_n+\mathsf A_\epsilon^*e_n.
} \tag{2.3}
$$

No zeta zero location, desired positivity, or global norm of $X$ is used to construct these vectors.

Let $K_\epsilon=\mathsf A_\epsilon\mathsf A_\epsilon^*$. Then

$$0\le K_\epsilon\le q^2I,\qquad
 e_n=(I-K_\epsilon)^n y_\epsilon.$$

All iterates exist in $H$, and

$$
\begin{split}
\|e_{n+1}\|^2
&=\|e_n\|^2-2\|\mathsf A_\epsilon^*e_n\|^2
 +\|K_\epsilon e_n\|^2\\
&\le\|e_n\|^2-(2-q^2)\|\mathsf A_\epsilon^*e_n\|^2.
\end{split} \tag{2.4}
$$

This is a proved descent inequality on the actual constructed residual, not an assumed sign of a Weil form.

The spectral theorem and dominated convergence give the exact strong limit

$$
\boxed{
 e_n\longrightarrow e_\infty
 =\operatorname{proj}_{\ker\mathsf A_\epsilon^*}y_\epsilon.
} \tag{2.5}
$$

There is no conclusion here that $f_n$ has a bounded norm or converges. Even an input in the closure of a nonclosed range can require unbounded approximate preimages. That distinction is essential to Path B.

## 2.4 Exactly what must be established for closure

For $\epsilon>0$, the inherited B04 factorization, together with the boundedly invertible completion change, identifies $\ker\mathsf A_\epsilon^*$ with the model-space defect generated by native zeros $\rho$ satisfying $\Re\rho>1/2+\epsilon$. The exact final derivative in (1.14) is nonzero at each such zero. Consequently

$$
\boxed{
\lim_{n\to\infty}\|e_n\|=0
\quad\Longleftrightarrow\quad
\zeta(\rho)\ne0\text{ for }\Re\rho>1/2+\epsilon.
} \tag{2.6}
$$

Equation (2.6) uses B04's absence of additional singular inner and delay factors. It is an inherited range theorem specialized to an explicitly constructed sequence; it is not a proof of its left side. The boundary case $\epsilon=0$ is not needed and is not silently substituted into that inherited theorem.

The construction has converted an unspecified approximant requirement into a definite native iteration with a monotone residual. The remaining theorem must exclude a nonzero stationary residual for this input. It is not supplied by monotonicity alone.

One concrete sufficient progress law, on the actual nonzero residuals, would be

$$
\|\mathsf A_\epsilon^*e_n\|^2\ge\kappa_n\|e_n\|^2,
\qquad\kappa_n\ge0,\qquad\sum_n\kappa_n=\infty. \tag{2.7}
$$

Then (2.4) forces the zero limit. No universal coercivity of $\mathsf A_\epsilon^*$ is asserted. Condition (2.7), or another native exclusion of $e_\infty$, remains OPEN.

## 2.5 Why finite evaluation is a well-defined task

Every finite iterate in (2.3) depends only on the explicit integer kernel and the fixed original input. Finite-domain quadrature is not an RH premise. The inequality $a_{\triangle}\le e^{-t/2}$ controls kernel tails, and (1.12) controls the input tail. The sinc density itself can be approximated without changing its definition: keep a fixed finite smooth prefix of its box convolution and let the remaining uniform-sum tail have support radius $s/(M+1)$. For each derivative through order four, a mean-value estimate against the next derivative of that fixed smooth prefix bounds the truncation error. This gives convergent, explicitly bounded finite descriptions of $j_s$.

Such a finite computation may be expensive. This campaign did not execute a continuum Landweber sweep for the actual $q_s$. Its checks cover the displayed algebra and finite native constant/frequency enclosures; they are not a numerical claim that (2.6) converges to zero.

## 2.6 A fully constructed bounded inverse that is nevertheless blind

The genuinely bounded inverse from Section 1 produces

$$w_\epsilon=(I-\mathsf A_\epsilon)^{-1}y_\epsilon\in H.$$

But wherever ordinary Laplace products apply,

$$\widehat w(p)=\frac{A_{\triangle}(p)}{1-A_{\triangle}(p)}\widehat X(p).$$

At an off-line native zero, the numerator cancels the pole of $X$. Thus this explicitly bounded response is not the uncancelled observation required by Step 1. It is a legitimate constructed object with an exact, recorded loss of visibility.


# 3. Constructing the least-cost correction under the full native jet constraints

**Status: PAPER deduction.** B04 already proved the no-polynomial-loss Laguerre leakage lower bound. That lower bound is not claimed as new here. This section adds an explicit minimum-norm constructor for arbitrary finite collections of jets, preserves their cross-phases, and applies the bound to every stable future completion that keeps an exact original prefix.

## 3.1 Complete source jets

Fix $\epsilon>0$ and retain $X$, $y_{\triangle}$, and $A_{\triangle}$. Work in

$$H_\epsilon=L^2([0,\infty),e^{-2\epsilon t}\,dt).$$

Let $z\in H_\epsilon$ agree with the actual locally defined $X$ on $[0,T]$. This includes, but is not restricted to, the zero extension of the original prefix. Define

$$r=y_{\triangle}-a_{\triangle}*z.$$

Causality gives $r=0$ almost everywhere on $[0,T]$. At each hypothetical right zero $\lambda_i=\rho_i-1/2$ of multiplicity $m_i$, with $\Re\lambda_i>\epsilon$, bounded Laplace evaluation gives

$$
\int_T^\infty(-t)^j e^{-\lambda_i t}r(t)\,dt
=b_{i,j}:=\widehat y_{\triangle}^{(j)}(\lambda_i),
\qquad0\le j<m_i. \tag{3.1}
$$

The native data are

$$b_{i,j}=0\ (j<m_i-1),\qquad
b_{i,m_i-1}=-c_{3/2}(\lambda_i)J_s(\lambda_i)\zeta^{(m_i)}(\rho_i)\ne0.$$

All complex phases remain. No uniform lower bound on $\zeta^{(m_i)}(\rho_i)$ is assumed.

## 3.2 Solve the finite moment problem exactly

Let $F$ be any finite list of distinct $\lambda_i$ with their indicated jets. Put

$$w_{i,j}(t)=(-t)^j e^{-\lambda_i t}1_{t\ge T}.$$

The finite Hermitian Gram matrix is

$$
\begin{split}
G_{(i,j),(\ell,k)}(T)
&=\int_T^\infty w_{i,j}(t)\overline{w_{\ell,k}(t)}e^{2\epsilon t}\,dt\\
&=(-1)^{j+k}\int_T^\infty t^{j+k}
 e^{-(\lambda_i+\overline{\lambda_\ell}-2\epsilon)t}\,dt.
\end{split} \tag{3.2}
$$

Every entry is explicit. For $h=j+k$ and $a=\lambda_i+\overline{\lambda_\ell}-2\epsilon$,

$$\int_T^\infty t^h e^{-at}\,dt
=e^{-aT}\sum_{r=0}^{h}\frac{h!}{(h-r)!}\frac{T^{h-r}}{a^{r+1}}.$$

The exponential-polynomial functions are linearly independent on an interval. Hence $G(T)$ is strictly positive definite. The unique least-norm tail satisfying this finite set of requirements is

$$
\boxed{
 r_F^*(t)=e^{2\epsilon t}\sum_{(i,j)\in F}
 [G(T)^{-1}b]_{i,j}\,\overline{w_{i,j}(t)},
\qquad
\|r_F^*\|_\epsilon^2=b^*G(T)^{-1}b.
} \tag{3.3}
$$

To prove this, substitute the expression into (3.1), which gives $G G^{-1}b=b$. Every other admissible tail differs by a vector orthogonal to all the Riesz kernels, so Pythagoras proves minimality. This is a construction, not only a lower estimate.

If the list is closed under complex conjugation and its data have native conjugate symmetry, uniqueness implies $r_F^*$ is real. A minimizer using only one member of a nonreal conjugate pair is generally complex. Its cost is a valid lower bound for real tails, but it is not the sharp paired real-source problem.

**Feasibility boundary.** Equation (3.3) solves only the finite moment constraints. It need not be realizable as $y_{\triangle}-a_{\triangle}*z$ for a stable native output continuation, and need not satisfy unlisted native jets. It is a rigorous lower relaxation of that problem. Its existence cannot be promoted into native inverse solvability.

## 3.3 B04's sharp single-zero cost, now with an explicit minimizer

Let $\lambda=\beta+i\gamma$, $d=\beta-\epsilon>0$, $m\ge1$, $n=m-1$, and $c=b_{m-1}$. Define the monic Laguerre polynomial

$$Q_n(u)=\frac{(-1)^n n!}{(2d)^n}L_n(2du),\qquad
K_n=\int_0^\infty e^{-2du}Q_n(u)^2du
=\frac{(n!)^2}{(2d)^{2n+1}}.$$

The finite single-zero problem has the minimizer

$$r^*(t)=\frac{(-1)^n c e^{2dT}}{K_n}
 e^{(2\epsilon-\overline\lambda)t}Q_n(t-T)1_{t\ge T}.$$

Orthogonality to all lower powers gives every lower jet zero, while the top jet is exactly $c$. Its norm is

$$
\boxed{
\|r^*\|_\epsilon^2
=\frac{(2d)^{2m-1}}{((m-1)!)^2}|c|^2e^{2dT}.
} \tag{3.4}
$$

For the actual real problem, include the conjugate zero in (3.3). In either case every stable $z$ agreeing with $X$ on $[0,T]$ obeys the lower bound (3.4). Redesigning the tail cannot improve this bound to a subexponential cost while keeping those exact native conditions, under the hypothetical zero.

Applying the same bound to $z=1_{[0,T]}X$ and using $\|a_{\triangle}*z\|_\epsilon\le q\|z\|_\epsilon$ gives

$$
\|X\|_{\epsilon,[0,T]}
\ge \frac{|c|(2d)^{m-1/2}}{q(m-1)!}e^{dT}
-\frac{\|y_{\triangle}\|_\epsilon}{q}. \tag{3.5}
$$

Thus the lower obstruction holds at every sufficiently large horizon, not only at a favorable original two-lobe phase. This is the B04 full-jet argument applied to the unchanged new fixed source; no greatest-displacement zero is needed.

## 3.4 The exact residual of the constructed iteration

For $T=0$, (3.3) is the squared norm of the projection of $y_{\triangle}$ onto the finite native adjoint-jet space. B04's full range characterization implies that these finite spaces span densely the entire adjoint kernel. Therefore the residual of Section 2 satisfies

$$
\boxed{
\|e_\infty\|^2
=\sup_{F\text{ finite native right jets}}b_F^*G_F(0)^{-1}b_F.
} \tag{3.6}
$$

The damping is included in (3.2); the two Hilbert-space conventions are related by multiplication by $e^{-\epsilon t}$. Formula (3.6) preserves the cross terms between zeros, multiplicities, and the original source values. It does not replace this Hermitian Gram matrix by complex-symmetric spectral residue data.

Equations (2.5) and (3.6) provide a primal construction and its exact dual obstruction. They do not establish that the supremum is zero. The finite Gram controls in the code use synthetic rational zero coordinates solely to test algebra; they are not assertions of native zeros.


# 4. Use two exact arithmetic representations before taking the square

**Status: PAPER deduction under the original-detector package's stable-error decomposition.** This section retains the actual long-divisor coefficients and the original fixed source. It supplies an independent bound for an additional interaction sector. The remaining separated, coprime, prime--composite interaction is not bounded here.

## 4.1 The inherited exact decomposition

Use the same $j_s$ and $X=\Pi*j_s$. The previous campaign supplies

$$X=R+E,\qquad E\in H_\epsilon\quad\text{for every }\epsilon>0. \tag{4.1}$$

Here $R=R_s^\sharp$ is not a free residual. For $t\ge1$ it is exactly

$$
R(t)=\sum_n\frac{B_n(t)}{\sqrt n}j_s(t-\log n),
$$

$$B_n(t)=1_{\{n\le e^{t+d},\ b_{L_c(t)}(n)>Z(t)\}}
 w_{P(t)}(n)A_{Y(t)}(n), \tag{4.2}$$

and $R=0$ on the earlier interval. All symbols have their frozen original meanings:

$$A_Y(n)=\sum_{a\mid n,\ a>Y}\mu(a)\log(n/a),\qquad
w_P(n)=1_{\{\omega(\gcd(n,P))\le1\}},$$

$$Y(t)=\frac{e^t}{B_sP(t)t^2},\quad
L_c(t)=B_sP(t)e^dt^2,\quad
P(t)\le\log(t+2).$$

$P(t)$ is the original increasing initial primorial and $b_{L_c}$ is the original rough-core map. $Z(t)=\exp(t/\log(t+2))$. In particular the time-dependent coefficient in (4.2) stays inside every integral below. No derivative of that coefficient is taken.

## 4.2 The residual has no prime-power coefficient on a sufficiently late active window

There is $T_0$ such that for $t\ge T_0$,

$$Y(t)\ge e^{(t+s)/2}\quad\text{and}\quad Y(t)\ge1.$$

This follows from the exponential numerator and the fixed polylogarithmic denominator. If $j_s(t-\log n)\ne0$, then $n\le e^{t+s}$. For a prime power $n=p^k$ with $k\ge2$, every squarefree divisor is $1$ or $p\le\sqrt n\le Y(t)$, so $A_{Y(t)}(n)=0$. For $k=1$, the only possible remaining divisor is $p$ itself, whose coefficient is $\mu(p)\log1=0$. Thus

$$
\boxed{B_{p^k}(t)=0\quad\text{whenever }t\ge T_0
\text{ and }j_s(t-\log(p^k))\ne0.} \tag{4.3}
$$

This is coefficient support, not pointwise vanishing of $R$ near a prime. Nearby composite translates can overlap that same time window.

## 4.3 Remove higher powers as a complete controlled field

Write

$$X_1(t)=\sum_{p\text{ prime}}\frac{\log p}{\sqrt p}j_s(t-\log p),
\qquad H=X-X_1.$$

The entire higher-power field belongs to $H_\epsilon$, because weighted Young's inequality gives

$$
\|H\|_\epsilon
\le\|e^{-\epsilon u}j_s(u)\|_{L^2(\mathbb R)}
\sum_p\sum_{k\ge2}(\log p)p^{-k(1/2+\epsilon)}<\infty. \tag{4.4}
$$

This argument requires positive damping. It does not assert an undamped finite-variation estimate. Combining (4.1) and (4.4),

$$X_1=R+Z,\qquad Z=E-H\in H_\epsilon\quad(\epsilon>0).$$

For $\mathcal E_\epsilon(T)=\|X_1\|_{\epsilon,[0,T]}^2$, the exact mixed identity is

$$
\left|\mathcal E_\epsilon(T)-\Re\langle X_1,R\rangle_{\epsilon,[0,T]}\right|
\le \|E-H\|_\epsilon\sqrt{\mathcal E_\epsilon(T)}. \tag{4.5}
$$

This is why it is useful not to square the divisor representation immediately. The native first-prime field and the long-divisor field have genuinely different coefficient supports, while their complete output discrepancy is controlled.

## 4.4 Every late mixed pair is coprime

Expanding the finite-horizon mixed pairing gives terms

$$
\frac{\log p}{\sqrt{pn}}
\int_{T_0}^{T} e^{-2\epsilon t}B_n(t)
 j_s(t-\log p)j_s(t-\log n)\,dt. \tag{4.6}
$$

By (4.3), $n$ is not a prime power. Overlap requires

$$|\log(n/p)|\le2s.$$

Since $e^{2s}<2$, a distinct multiple of the prime $p$ cannot lie in this interval. Therefore every nonzero late mixed term has

$$
\boxed{n\text{ non-prime-power},\quad n\ne p,\quad (p,n)=1.} \tag{4.7}
$$

This is not an assumed independence of primes and composites. It is an exact support restriction on their mixed energy. The whole finite initial segment $[0,T_0]$ contributes a fixed finite constant.

## 4.5 A stronger coefficient bound uses the actual short cofactor budget

On an active source window, set $m=n/a$ in (4.2). The strict condition $a>Y(t)$ gives

$$m<n/Y(t)\le L_c(t).$$

Consequently, without any Möbius cancellation,

$$
|A_{Y(t)}(n)|
\le\sum_{m<L_c(t)}\log m
\le C_s(1+t)^3
\le C'_s(1+\log n)^3. \tag{4.8}
$$

The first bound uses $L_c(t)=O_s(t^2\log(t+2))$ and $\log^2(t+2)=O(1+t)$. It is important to use this actual cofactor constraint, rather than replacing it by an arbitrary divisor-count bound. The mask and rough-core indicator have absolute value at most one.

## 4.6 A critical-width interaction strip is independently summable

Fix $0<\epsilon<1/2$ and define

$$H_\epsilon(p)=\frac{p^{2\epsilon}}{(1+\log p)^6}.$$

**Theorem 2.** The total absolute contribution of all mixed terms (4.6) with

$$0<|n-p|\le H_\epsilon(p)$$

is finite over the full half-line, uniformly in the terminal horizon $T$.

**Proof.** Let $M_s=\|j_s\|_\infty$. On an active overlap, $t\in[\log p-s,\log p+s]$ and $n/p\in[e^{-2s},e^{2s}]$. Formula (4.8) bounds the absolute integral of one term by

$$C_{s,\epsilon}(1+\log p)^4p^{-1-2\epsilon}.$$

There are at most $2H_\epsilon(p)+1$ admissible integers $n$. Summing even over all integers $p\ge2$ rather than just primes bounds the total by a constant times

$$
\sum_{p\ge2}\frac1{p(1+\log p)^2}
+\sum_{p\ge2}(1+\log p)^4p^{-1-2\epsilon},
$$

both convergent. This is an independent arithmetic upper bound; it assumes neither the target norm of $X$ nor an off-line zero. $\square$

The sixth logarithmic power is a convenient sufficient choice, not an optimality claim. The endpoint without a logarithmic loss is not inferred from this estimate.

## 4.7 The remaining exact interaction

Let $\Gamma_\epsilon(T)$ be the complete real sum (4.6) after restricting to

$$
 p\text{ prime},\quad n\text{ non-prime-power},\quad(p,n)=1,
 \quad |\log(n/p)|\le2s,
 \quad |n-p|>H_\epsilon(p), \tag{4.9}
$$

with every original mask, rough-core condition, strict cutoff, coefficient and phase-bearing source factor retained. It is a finite, source-defined number at each finite $T$.

Equations (4.5) and Theorem 2 prove

$$
\boxed{
|\mathcal E_\epsilon(T)-\Gamma_\epsilon(T)|
\le C_0+C_1\sqrt{\mathcal E_\epsilon(T)}.
} \tag{4.10}
$$

In particular, for suitable fixed $C$,

$$\mathcal E_\epsilon(T)\le2\Gamma_\epsilon(T)_++C,
\qquad \Gamma_\epsilon(T)_+\le2\mathcal E_\epsilon(T)+C. \tag{4.11}$$

Here $x_+=\max(x,0)$. One uses $C_1\sqrt E\le(E+C_1^2)/2$; no sign is assigned separately to the terms in the mixed sum.

## 4.8 The stepwise closing implication is explicit

Suppose a native zero has $\Re\rho-1/2=\beta>\epsilon$. Apply the original source values to the full-jet lower bound (3.5), then subtract the bounded higher-power field in (4.4). This gives constants $c>0,T_1$ such that

$$\mathcal E_\epsilon(T)\ge c e^{2(\beta-\epsilon)T}\qquad(T\ge T_1).$$

Equation (4.10) therefore gives

$$\Gamma_\epsilon(T)>0\text{ eventually},\qquad
\liminf_{T\to\infty}\frac{\log(1+\Gamma_\epsilon(T)_+)}T
\ge2(\beta-\epsilon)>0. \tag{4.12}$$

A sufficient remaining estimate is thus

$$
\boxed{
\liminf_{T\to\infty}\frac{\log(1+\Gamma_\epsilon(T)_+)}T=0
\quad\text{for every }\epsilon\in\{1/3,1/4,1/5,\ldots\}.
} \tag{4.13}
$$

No common subsequence or uniform constants in $\epsilon$ are needed. Any right zero would violate (4.13) for a sufficiently small listed damping. Reflection then treats the left side. The use of an arbitrarily late quiet subsequence is justified by the every-large-horizon lower bound; it would not be justified by only an unspecified subsequence of deep negative trials.

**Equation (4.13) is OPEN.** The new construction does not prove cancellation in the separated coprime sector (4.9). It has removed the coefficient diagonal, all higher prime powers as a controlled field, and the displayed near-gap strip from the remaining estimate.

## 4.9 A quantitative compatibility demand, not an automatic contradiction

Under a hypothetical right zero, $\|X_1\|_{\epsilon,[0,T]}$ grows exponentially and $\|X_1-R\|_\epsilon$ remains bounded. Hence the normalized real inner product of these two different-support outputs satisfies

$$
\frac{\Re\langle X_1,R\rangle_{\epsilon,[0,T]}}
{\|X_1\|_{\epsilon,[0,T]}\|R\|_{\epsilon,[0,T]}}
=1-O(e^{-2(\beta-\epsilon)T}). \tag{4.14}
$$

This follows from $\|X_1-R\|^2=(a-b)^2+2ab(1-\cos\theta)$. It is an exact quantitative restriction on an admissible counterexample: the two arithmetic representations must become extremely aligned despite disjoint coefficient supports. Dense logarithmic translates are not orthogonal, so disjoint supports alone do not contradict (4.14). An independent non-saturation estimate for these actual coefficients could be useful; none is claimed here.


## 4.10 A source-specific angle condition would suffice

The two-output geometry also gives an exact alternative to estimating the whole interaction sum. At horizons where both norms are nonzero, set

$$c_T=\frac{\Re\langle X_1,R\rangle_{\epsilon,[0,T]}}
{\|X_1\|_{\epsilon,[0,T]}\|R\|_{\epsilon,[0,T]}}.$$

Suppose that along an unbounded sequence of horizons one could prove, on these actual arithmetic outputs,

$$c_T\le1-\delta_T,\qquad 0<\delta_T\le1,
\qquad\frac{\log(1/\delta_T)}{T}\longrightarrow0. \tag{4.15}$$

Writing $a=\|X_1\|$, $b=\|R\|$, completing the square gives

$$
\|Z\|_\epsilon^2\ge a^2+b^2-2(1-\delta_T)ab
=[b-(1-\delta_T)a]^2+(2\delta_T-\delta_T^2)a^2.
$$

Thus $\mathcal E_\epsilon(T)\le\|Z\|_\epsilon^2/(2\delta_T-\delta_T^2)$ on that sequence, contradicting (4.12) whenever a right zero lies beyond $\epsilon$. A polynomial lower bound for the actual angular separation would be sufficient. A horizon with $R=0$ is handled directly by $X_1=Z$.

Condition (4.15) is OPEN. Positivity of a Gram determinant proves only $|c_T|\le1$, which is not a quantitative separation. Coefficient disjointness does not supply (4.15) because the translated source functions are not orthogonal. The condition identifies the exact non-saturation property a phase-preserving construction would have to establish; it is not evidence that the property holds.


# 5. Phase preservation and the attempted final closures

**Status: PAPER algebra and scope audit.** This records which construction requirements were met and where the attempted closing inferences failed.

## 5.1 Coherent phase averaging does not diagonalize the original energy

One tempting construction is to average vertical phases of the prime coefficients and keep only a diagonal arithmetic term. Test it before using it.

For real $\tau$, let

$$\Pi_\tau=\sum_n\Lambda(n)n^{-1/2}e^{-i\tau\log n}\delta_{\log n},
\qquad j_{s,\tau}(u)=e^{-i\tau u}j_s(u).$$

If the original source is transported coherently with the prime phases, then

$$
\boxed{\Pi_\tau*j_{s,\tau}(t)=e^{-i\tau t}X(t).} \tag{5.1}
$$

The coefficient phase and the source phase cancel internally at each summand. Every prefix energy is unchanged. In the expanded square, all relative phases introduced by the twist cancel as well: this averaging cannot remove the coprime mixed interaction of Section 4.

The differential source law is also transported exactly:

$$P_\tau=(\partial+i\tau)^2-1/4,\qquad
P_\tau^2(e^{-i\tau t}q_s)=e^{-i\tau t}P^2q_s.$$

Using $P$ instead of $P_\tau$ would change the pole-neutrality requirements. Keeping $j_s$ fixed while twisting only the arithmetic coefficients likewise creates a different source problem. Neither operation is an estimate on the unchanged original field.

This is a scoped falsification of a phase-averaging shortcut, not a claim that no phase-dependent arithmetic estimate is possible.

## 5.2 What has actually been constructed

The following objects are supplied with formulas and proofs in this package:

* The whole one-parameter completion family, its exact positivity interval, and the endpoint native floor kernel.
* A rational strict-contraction bound and a bounded inverse of the complement $I-\mathsf A_\epsilon$.
* The unchanged-source input, with its double-pole cancellations and faster exponential tail.
* A native adjoint-based output-approximation sequence, a proved descent law, and its exact limiting residual.
* The least-cost tail matching any finite collection of original zero jets, including the full Hermitian cross-phase matrix.
* A mixed prime--composite energy formula and an independently controlled near-gap strip.

The construction does not replace the original $q_s$, alter prime weights, choose a hypothetical zeta zero numerically, identify a selected ground with the detector, or assume $X\in H_\epsilon$.

## 5.3 The failed final inferences, stated precisely

**Contraction applied to the wrong operator.** A strict bound for $\mathsf A$ proves invertibility of $I-\mathsf A$, not of $\mathsf A$. The actual-frequency certificate in Section 2 defeats the naive inverse iteration. The bounded complementary response has an exact native zero factor and loses the Step 1 pole.

**Finite moment feasibility mistaken for a controlled native future.** Every finite jet problem has a unique least-norm solution. Under a right zero its required norm grows exponentially with the matched prefix length. That solution is only a relaxation of full native range feasibility. No global cost bound follows from having solved all its finite linear equations.

**Monotone residual mistaken for zero residual.** The valid iteration has a decreasing error norm and a strong limit. Its invariant component is exactly the native adjoint-kernel projection. The residual does not disappear merely because each step is mathematically well defined and decreases the controllable component.

**Disjoint coefficients mistaken for orthogonal outputs.** The native first-prime field and the late residual have no common coefficient index. Their translates overlap densely on logarithmic time. The near-gap estimate removes a genuine sector; it does not determine the sign or size of the remaining separated coprime interaction.

**Positive precursor mistaken for a positive differentiated source.** The source is still $P^2q_s$, not $q_s$. No positivity statement has been inserted into a signed energy by changing that source.

## 5.4 Two exact remaining contracts

There are now two concrete alternatives, neither established here.

The range construction closes if its actual limiting residual is zero for every positive damping in a sequence tending to zero. An explicit sufficient native estimate is the non-summable relative-progress law (2.7).

The original-detector arithmetic construction closes if the separated coprime interaction has the quiet-subsequence property (4.13). The all-horizon jet lower bound then yields the contradiction directly. This route uses the compact-potential source adapter and does not require a new continuous-contact existence theorem or an extra finite-ground sign assumption.

They are alternative analytic targets, not a claim that both must be proved. They have not become logically easy because the constructions are explicit.

## 5.5 What is new relative to the sources inspected

The old $b=1$ native kernel, its Hardy zero-divisor characterization, and B04's sharp Laguerre lower bound are inherited. The current contribution is the $b$-family positivity proof with the sharp endpoint $b=3/2$, the explicit strict mass bound, the faster same-source driving formula, the native inverse-iteration falsifier, the definite adjoint iteration with its retained defect, the finite-jet minimum-cost constructor, and the prime--composite/coprime interaction reduction with its critical-width strip bound.

The finite linear-algebra tools themselves are standard. No priority claim over all mathematical literature is made. These are derived applications and new combinations relative to the inspected project frontier.

**Current result:** supporting constructions and bounds have been supplied; neither remaining native exclusion has been proved. Step 4 and RH remain OPEN in this package.


\newpage

# Evidence, source register, and research implications

## Exact source lineage

The following sources are included, unchanged, in the research archive. The machine-readable register gives complete relative paths, byte hashes, and the main-commit anchor. The names below are reading labels, not a second claim authority.

**S1 — Fixed original precursor and projected forcing.** Previous original-detector campaign, Section 4: the exact $j_s=P^2q_s$ field, double elementary zeros, integer-drive estimate, complete long-divisor residual, and stable error. Its numbered equation (22) was explicitly open; the present paper does not silently import it as proved.

**S2 — Direct pole-neutral forcing bridge.** Previous original-detector source-transport note: compact same-interval inverse of $P$, its norm at most four, all translated/reflected forcing terms, and the original-witness inequality.

**S3 — Original phase and pole-neutral source.** Previous source/phase proof: original positive precursor, source zero pattern, and retained two-lobe phases.

**S4 — Slow-refinement arithmetic.** Previous original-detector arithmetic note: the actual integer-drive proof, cutoff definitions, strict inequalities, and scale costs.

**S5 — Native scale-limit falsifier.** Previous original-detector note: the non-uniformly-integrable native refinement martingale, signed covariance, and the distinction between finite-scale and uniform-horizon estimates.

**S6 — Universal detector.** Master v2.9 source proof: the sinc product, compact Gevrey probability density, and nonvanishing at off-line coordinates.

**S7 — B04 sharp dual leakage.** The full multiplicity jet/Laguerre bound is inherited. Section 3 adds the finite multi-jet minimum-cost constructor, not a new claim to the inherited exponent.

**S8 — B04 Hardy range and zero test.** The multiplier's closed range is the Blaschke-divisor range for positive damping, with no additional singular-inner or delay factor. Section 2 uses this characterization to identify the exact limiting residual; it does not prove membership by assuming it.

**S9–S10 — Previous arithmetic sector and adaptive mask.** The original smooth-sector estimate and prime-power-preserving mask, including their complete stable errors, feed Section 4. Time-dependent coefficients remain inside the finite integrals.

**S11–S14 — Merged repository mathematical sources.** `ArithmeticReduction`, `CanonicalPrimeRemainder`, `CanonicalGoodSectorGram`, and `ApertureFreedom`, read in the pinned merged-main archive. The first is an equivalence audit, the second an exact native decomposition, the third requires sector goodness for its Gram inequality, and the fourth supplies eventual finite badness under an off-line zero. None supplies the missing upper bound used here.

The current branch's reciprocal-aperture and strict-even shifted-ray source files were also read through the live GitHub connector. Their scope remains local curvature/endpoint transport and same-selected-state identity, respectively; they do not imply the global estimates in this paper. These live reads are recorded as observations, not presented as newly compiled source files inside this archive.

## Standard mathematical ingredients checked

NIST DLMF §25.2 was checked for the zeta Dirichlet derivative, eta relation, meromorphic continuation, and Euler–Maclaurin representation. DLMF §25.11 provides the corresponding tail/Euler–Maclaurin reference, and §18.3 records the Laguerre normalization/orthogonality convention. The paper writes out its actual rational remainder bound and finite Laguerre calculations. These ingredient checks are not a literature-based solution of Step 4.

References: [DLMF §25.2](https://dlmf.nist.gov/25.2), [DLMF §25.11](https://dlmf.nist.gov/25.11), [DLMF §18.3](https://dlmf.nist.gov/18.3).

## Pinned repository observation

Merged main: `bb7c9c9d54fa2d1f82ad5b682c31148539a8f78c`.

Main tree: `e492714b5d5db02b6fc4ed2e10d0c81ef66d9087`.

Observed #290 head: `314be1364d8332d34d0a0d3c22a0e4da82e9dcc8`.

At that observation #290 remained open, draft and unmerged. The current-head workflow list contained 19 runs: nine successful, eight in progress and two queued. This is a pinned partial observation, not a statement that those jobs retained that status thereafter.

The focused formal job 115095211343 on run 38335717936 completed successfully at 02:26:04 UTC on 13 October. Its compile-all-new-roots and proof-escape steps were read as successful. The focused modified-prime job 115095211528 also completed successfully. Its two-endpoint certification step and upload result were read, but its artifact payload was not re-audited in this campaign. The 29 individual axiom reports and checkout tree were not separately downloaded here.

The PR body reports a distinct false-positive path, `min(0, nan.lower())`, that discarded an unresolved Taylor remainder. The body states that affected whole-cover receipts were invalidated and guards repaired. This campaign does not adopt either the withdrawn covers or newer body-reported interval counts as independent proof premises.

Formal validity gates, regression checks and research-producing checks remain distinct. The full #290 workflow harvest and acceptance audit is not claimed complete. No new formal theorem authority is claimed by this paper.

## Finite verification actually run

The native enclosure script uses integer endpoints with denominator $10^{50}$ and rounds every arithmetic operation outward. It encloses square roots using integer square roots, logarithms using a convergent atanh series, pi using a Machin formula, sine and cosine using Taylor bounds, and the finite zeta computation using an explicit periodic-Bernoulli remainder. It rejects any denominator interval containing zero. Decimal strings are displays only.

Its conclusions are the strict mass bound and two actual-frequency failures of the naive inverse iteration. They are not a continuum output simulation or an assertion of any off-line zero.

The exact algebra suite checks 3,047 assertions. It includes 500 floor-kernel cases, 126 Laguerre-constructor checks, 333 prime-power support cases, 2,008 overlap/coprimality checks, a conjugate-paired rational Gram example, finite Landweber identities, strict-cutoff seams, signed coefficients, and mutation guards. The synthetic Gram and finite operator examples are controls, not native zeta data.

Reproduction: install `requirements.txt`, then run `python run_checks.py`. Integrity: run `python verify_manifest.py`. The scripts do not access the network and do not invoke Lean.

## Post-validation research pass

**What became formally true.** Nothing new was formalized in this campaign. The observed focused branch build improved, but the paper's results remain PAPER deductions with scoped finite checks.

**What changed mathematically.** An unspecified positive completion became a completely explicit native kernel with a strict norm bound. An unspecified range-approximation sequence became a definite iteration with a rigorously identified limit. Finite interpolation became an explicit least-cost correction problem with every retained jet and phase present. A further arithmetic interaction sector acquired an independent uniform bound.

**Upstream implications.** Positive rational completions should be chosen before estimating their norm; the endpoint parameter improves both mass and input decay while preserving the source. Pole-killed source data should be retained when computing jets and future-correction costs. The original source's double elementary zeros are used in the improved driving tail.

**Downstream implications.** A native quantitative relative-progress estimate on the explicit iteration would close the range route. A quiet-subsequence estimate on the exact separated interaction, or a subexponential lower separation of its two actual output directions, would close the original-detector route. The every-horizon lower bound is what authorizes different quiet subsequences for different damping parameters.

**Resurrected and still-blocked routes.** A positive small-norm native forward construction is now available. The inverse-stability route is not thereby resurrected: the exact same zero divisor remains, and the native-frequency test defeats the naive inverse iteration. Finite moment repair is constructible, but uniform repair cost cannot be inferred from finite feasibility.

**New clue, labeled LEAD.** The possible counterexample must make two source-bound arithmetic outputs with disjoint coefficient supports exponentially close in direction. Their exact weights, adaptive cutoff, prime/composite distinction and coprimality are all retained. A native non-saturation inequality is therefore a precise phase-sensitive target, rather than an appeal to generic Gram positivity.

**Falsification checks.** The actual-frequency obstruction, invariant residual in a finite operator control, conjugation mutations, strict-cutoff seams and coherent-phase identity all survive their checks. None is generalized to an impossibility theorem about every possible Step 4 method.

**Highest-leverage next theorem.** Prove a non-summable relative-progress estimate for the actual residual iteration, or a non-saturation/quiet-subsequence estimate for the exact coprime interaction. The next proof must use the native coefficients or another genuinely native constraint to establish that estimate. Merely solving finite equations, obtaining a positive auxiliary norm, or adding further coordinate identities does not establish it.

**Terminal statement: neither required exclusion is proved here. Step 4 and RH remain OPEN.**
