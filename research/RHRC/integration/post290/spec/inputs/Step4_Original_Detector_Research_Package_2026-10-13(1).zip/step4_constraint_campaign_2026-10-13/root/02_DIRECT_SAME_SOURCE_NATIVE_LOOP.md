# The native loop on the original pole-neutral source

Date: 13 October 2026. Status: **new paper derivation using the inherited native kernel and causal multiplier theorems**. This note does not assume a full positive-semidefinite contact, and does not replace a finite compression equation by a continuous eigen-equation.

The earlier joint campaign applied the source contraction primarily to a canonical full-contact source and then convolved it with the arithmetic detector. Here the same construction is made directly on the original detector, or on the newly selected pole-neutral finite source. Its source, phase, scale and complete finite history remain explicit.

## 1. Eligible sources

Let \(f\) be a nonzero real source of definite parity, supported in \([-a,a]\), with enough positive Sobolev regularity for the inherited native causal convolution to be locally \(L^2\). All original Gevrey detectors and the legal finite sources in this campaign satisfy that condition. Assume its Fourier transform has no nonreal zeros except \(\pm i/2\), of equal multiplicity \(m\ge1\). Define

\[
D_f(p)=\int_{-a}^a f(x)e^{-px}\,dx.
\]

The original two-lobe sources in Note 01 have \(m=1\), as do the newly selected deep pole-neutral grounds. Their autocorrelations have \(m=2\). Each source is kept as its own object; autocorrelation is an explicit map, not an identification of a ground with its detector. The intermediate repaired finite approximation \(p\) need not have this zero pattern, so Theorem N does not automatically apply to that approximation before the separate constrained-ground selection.

Finite exponential type, parity, and the stated zero location give the paired Hadamard factorization

\[
D_f(p)=C(p^2-1/4)^m p^\nu
\prod_j(1+p^2/\gamma_j^2),\qquad \gamma_j>0,
\tag{N1}
\]

with multiplicities included and \(\sum_j\gamma_j^{-2}<\infty\). The factor \(e^{bp}\) from the order-one factorization is absent by definite parity. No assertion that the underlying compact potential is nonnegative is used here.

## 2. The source quotient remains contractive despite the mandatory pole zeros

For \(h\ge1/\sqrt2\), put

\[
T_{f,h}(p)=\frac{D_f(p)}{D_f(p+h)}.
\]

**Theorem N.** The ratio is holomorphic on \(\Re p>0\) and

\[
\boxed{\|T_{f,h}\|_{H^\infty(\mathbb C_+)}\le1,
\qquad h\ge1/\sqrt2.}
\tag{N2}
\]

**Proof.** Each imaginary-axis zero factor contracts under a positive horizontal shift. Explicitly, for real \(\gamma\),

\[
|p+h-i\gamma|^2-|p-i\gamma|^2
=h(2\Re p+h)>0.
\]

It is useful to keep the mandatory pair together, rather than bound its two factors separately. Write \(p=x+iy\), \(x\ge0\). Direct expansion gives

\[
\begin{aligned}
&|(p+h)^2-1/4|^2-|p^2-1/4|^2\\
&\quad=h(2x+h)
[2x^2+2xh+h^2+2y^2-1/2]\ge0.
\end{aligned}
\tag{N3}
\]

when \(h\ge1/\sqrt2\). All denominator zeros lie strictly to the left of the closed right half-plane. Apply these bounds to finite paired products in (N1), then pass to their locally uniform limit. This proves (N2), including all multiplicities. QED.

The threshold is sharp uniformly over this source class. For \(0<h<1/2\), the denominator has a genuine right-half-plane zero at \(p=1/2-h\), uncancelled by the numerator. At \(h=1/2\) there is a boundary pole. If \(1/2<h<1/\sqrt2\), the original small seed \(k_r\) has

\[
|T_{k_r,h}(0)|
=\frac{1/4}{(h^2-1/4)Q_r(h)},
\qquad Q_r(h)=\int q_r(x)e^{-hx}\,dx\longrightarrow1
\quad(r\downarrow0).
\]

This exceeds one for sufficiently small \(r\), and hence also at nearby interior points by continuity. Thus the old all-real-source argument allowing every \(h>0\) cannot be copied unchanged after retaining the mandatory pole zeros. Treating the pair jointly improves the elementary sufficient threshold \(h\ge1\) to the sharp uniform threshold \(1/\sqrt2\). The useful gamma-removing shift \(h=2\) is admissible.

Let \(\mathsf T_{f,h}\) be the bounded causal multiplier supplied by (N2), and let \(\mathsf M_hv(t)=e^{-ht}v(t)\). The inherited Hardy/causal realization gives contraction on every nonnegative-damping space and on each causal prefix. It does not assert that the inverse Fourier transform of \(T_{f,h}\) is an \(L^1\) function.

## 3. The actual finite history for this source

Write \(L=2a\), \(f_+(t)=f(t-a)\), supported in \([0,L]\), and use the actual causal native distribution \(W_+\). Define

\[
c_f(t)=-\mathbf1_{(0,L)}(t)(W_+*f_+)(t),
\qquad v_f(s)=(W*f)(a+s),\quad s>0.
\tag{N4}
\]

The endpoint values do not affect the \(L^2\) class. By the stated source regularity, \(c_f\in L^2\) and is compactly supported. Causality and support give the exact identity

\[
W_+*f_++c_f=\tau_Lv_f.
\tag{N5}
\]

For the exterior \(x>a\), the negative-time half of \(W\) has no interaction with the support of \(f\), so the right side is the **actual** full native exterior. This proves (N5) for this source without assuming any contact equation. No endpoint distribution is introduced: (N4) cuts a locally \(L^2\) output; it does not differentiate that cutoff.

For the original small seed \(k_r\), or its small autocorrelation \(h_r\), (N4) is an explicit prime-free history because \(L<\log2\). A widely separated two-lobe witness instead has a large interval and a prime-containing history. For a selected large finite source the history likewise includes all actual prime powers with \(\log n<L\). Its compression residual and pole multipliers remain separate data in the selected-state note; (N5) does not make them zero.

## 4. A direct contracted equation

Put \(k_h=(1-e^{-ht})W_+\), and define

\[
\mathsf S_{f,h}=e^{ah}\mathsf T_{f,h},\qquad
\mathsf B_{f,h}=e^{-ah}\mathsf T_{f,h}\mathsf M_h.
\]

The exact source-recovery identity is

\[
\mathsf S_{f,h}(\mathsf M_h f_+)=f_+,
\]

because their Laplace transforms are both \(e^{-ap}D_f(p)\). Tilt (N5) as a whole, apply this recovery operator, and subtract it from (N5). The full result is

\[
\boxed{
k_h*f_++c_f-\mathsf S_{f,h}\mathsf M_hc_f
=\tau_L(I-\mathsf B_{f,h})v_f.
}
\tag{N6}
\]

It satisfies the finite-prefix estimate

\[
(1-e^{-ah})\|v\|_{\epsilon,T}
\le\|(I-\mathsf B_{f,h})v\|_{\epsilon,T}
\le(1+e^{-ah})\|v\|_{\epsilon,T},
\quad\epsilon\ge0.
\tag{N7}
\]

Here \(\|v\|_{\epsilon,T}^2=\int_0^T e^{-2\epsilon s}|v(s)|^2ds\). The proof uses causal prefix contraction before any global integrability is assumed. If the forcing is globally in that weighted space, the Neumann inverse and prefix uniqueness identify its inverse with the actual \(v_f\).

Thus the C-type contraction is now available on the original pole-neutral detector and on the same finite pole-neutral source supplied by Steps 1–3. It no longer requires a detour through a different full-contact vector.

## 5. The literal prime response, with no continuous main term

At \(h=2\), the inherited exact digamma cancellation gives

\[
k_2=(e^{t/2}-e^{-3t/2}-e^{-5t/2})\,dt
-\sum_{n\ge2}\Lambda(n)n^{-1/2}(1-n^{-2})\delta_{\log n}.
\tag{N8}
\]

Define the actual arithmetic response on the same source

\[
\mathcal A_f(s)=\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}
f(a+s-\log n).
\tag{N9}
\]

There is **no** \(e^{(a+s)/2}D_f(1/2)\) centering term, because the retained source has \(D_f(1/2)=0\). This is the direct gain from imposing the original pole neutrality throughout the state selection.

Advancing (N6) by the full \(L\), and keeping its entire history term, yields

\[
\boxed{(I-\mathsf B_{f,2})v_f=-\mathcal A_f+b_f,
\qquad b_f\in L^2(0,\infty).}
\tag{N10}
\]

Here \(b_f\) is explicitly the advanced sum of the two decaying elementary convolutions, the \(n^{-2}\)-weighted prime convolution, and \(-\mathsf S_{f,2}\mathsf M_2c_f\). The leading elementary exponential has vanished after the source interval by exact pole neutrality; its finite initial contribution has already been included in the complete history. The weighted prime measure has finite total variation since \(\sum_{n\ge2}(\log n)n^{-5/2}<\infty\). The other stated terms are \(L^2\) by compact convolution or the proved multiplier bound.

Consequently, for every \(\epsilon\ge0\),

\[
v_f\in L^2_\epsilon\quad\Longleftrightarrow\quad
\mathcal A_f\in L^2_\epsilon.
\tag{N11}
\]

For \(\epsilon>0\), all prime powers of exponent at least two are a separately controlled remainder by weighted Young's inequality:

\[
\sum_{p}\sum_{j\ge2}(\log p)p^{-j(1/2+\epsilon)}<\infty.
\]

Thus (N11) is also equivalent, for positive damping, to the corresponding membership of the literal prime-only field

\[
\mathcal P_f(s)=\sum_{p\ {m prime}}
\frac{\log p}{\sqrt p}f(a+s-\log p).
\tag{N12}
\]

No uniform bound over the varying selected-source family is asserted. The constants in (N10) can depend on the source and its physical aperture.

## 6. The same native B input and sensor

Let the inherited native integer kernel satisfy

\[
A_N(p)=\frac{p-1/2}{(p+1/2)(p+1)}\zeta(p+1/2),
\qquad q_N=a_N*W_+.
\]

The independently established weighted integrability of \(a_N\) and \(q_N\), with positive margins below \(1/2\), gives from (N5)

\[
\tau_L(a_N*v_f)=q_N*f_++a_N*c_f.
\tag{N13}
\]

The right side is a controlled \(L^2\) output on this same source. Its inverse problem remains sensitive to the actual zeros of \(A_N\).

The fixed shifted sensor \(r_2=e^{-2t}a_N\) from the previous campaign is zero-free in the right half-plane. Its bounded graph inverse is retained as proved there:

\[
v=M_{5/2}*\left[z'+4z+\tfrac32(e^{-3t/2}\mathbf1_+)*z\right],
\quad z=r_2*v.
\tag{N14}
\]

This is an \(L^2\leftrightarrow H^1_0\) graph statement, not a raw bounded \(L^2\) inverse. It applies to the unchanged source output. No discarded derivative is supplied by the negative-threshold construction.

At every hypothetical right zero \(\lambda=\rho-1/2\), the source transform \(D_f(\lambda)\) is nonzero because its only right-half-plane source zero is the elementary point \(1/2\). The actual exterior therefore retains

\[
\operatorname{Res}_{p=\lambda}\mathcal Lv_f(p)
=m_\rho e^{a\lambda}D_f(\lambda)\ne0.
\tag{N15}
\]

The shifted sensor also retains that pole since \(A_N(\lambda+2)\ne0\). These statements cover every native zero multiplicity. The compact history contributes an entire transform and cannot cancel a residue.

## 7. What the source-specific loop does and does not close

Equations (N6), (N10), (N13), and (N14) are now a single explicit system on one retained source. Original pole neutrality has a visible effect: the growing continuous centering term is exactly absent. The actual finite prefix, the source-derived feedback, the literal prime sum, and the fixed native sensor coexist without a source substitution.

The contraction in (N7) controls feedback. The stable output in (N13) contains the unshifted native transfer function whose zeros are the disputed modes. The shifted sensor has a correct inverse but still needs an upper bound for its actual output. Neither fact, alone or together, bounds \(\mathcal A_f\) or \(\mathcal P_f\) in (N10).

In particular, the source's two pole cancellations do not give all the smooth arithmetic estimates on every other pole-neutral source. For example, the integer drive \((tN)*f\) generally retains a leading term proportional to \(D_f'(1/2)e^{t/2}\). The A detector \(h=k*k\) removes that term by a **double** pole zero. Taking an autocorrelation is a valid explicit adapter, but it changes the source and must be recorded. Gevrey bounds on the original detector cannot be silently assigned to a selected finite ground.

The remaining closing opportunity is therefore quantitative: use the actual detector-driven Schur identity and its newly controlled inverse, or a genuinely source-specific arithmetic estimate, to bound the right side of (N10). This note supplies the exact retained-source interface for that attempt; it does not assert the missing bound.
