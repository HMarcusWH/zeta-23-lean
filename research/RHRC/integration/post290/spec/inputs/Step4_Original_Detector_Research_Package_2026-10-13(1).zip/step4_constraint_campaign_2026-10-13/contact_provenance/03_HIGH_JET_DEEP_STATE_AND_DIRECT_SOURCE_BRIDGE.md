# High endpoint jets preserve the deep state; the original source also has a direct adapter

Date: 13 October 2026. Status: **new paper derivation and independent review. Step 4 remains open.**

This note proves that the negative-threshold state of Note 01 survives a number of endpoint conditions proportional to the aperture. It also records the simpler exact adapter that ultimately removes the need for those extra conditions when estimating the actual original detector forcing. The two constructions are kept distinct.

## 1. Freeze the stronger carrier before selecting the threshold

Fix `L`, an integer `m>=2`, and the centered coefficient convention of Note 01. Define

\[
 V^{(m)}_{L,K}=
 \{u:\sum_{n=-K}^K n^j u_n=0\quad(0\le j\le m)\},
 \qquad
 V^{(m),\mathrm{pn}}_{L,K}=V^{(m)}_{L,K}\cap\ker\ell_+\cap\ker\ell_-.
 \tag{H1}
\]

These are exactly the finite sources whose endpoint jets through order `m` vanish, together with the two original exponential moments. The integer `m=m(L)` is fixed throughout the cutoff search at this aperture. All cutoff inclusions are exact zero padding; `m` must not change while searching for the first crossing.

The even and odd pole-neutral dimensions are

\[
 d_+(K,m)=\max\{0,K-\lfloor m/2\rfloor-1\},\qquad
 d_-(K,m)=\max\{0,K-\lceil m/2\rceil-1\}.
 \tag{H2}
\]

To check the count, the even raw carrier has `K+1` coefficients and `floor(m/2)+1` independent even Vandermonde conditions, up to exhaustion of that space. The odd raw carrier has `K` coefficients and `ceil(m/2)` independent odd Vandermonde conditions, again up to exhaustion. In each surviving legal parity the two exponential moments are one nonzero functional. Nonvanishing can be seen without approximation: write

\[
 R_u(z)=\frac{N_u(z)}{\prod_{n=-K}^K(z-\omega_n)}.
\]

The denominator is odd. The numerator has degree at most `2K-m-1`; an even source admits the numerator `1` whenever its legal parity is nonzero, and an odd source admits the numerator `z`. Neither vanishes at `i/2`. The sine factor and denominator are nonzero there, so the pole functional is nonzero. This proves (H2), including the zero-dimensional boundary cases.

Every parity adds at most one dimension at a new cutoff. If `K_d` is the detector cutoff and `d_\pm=d_\pm(K_d,m)`, the number of eigenvalues across every nonempty cutoff through `K_d`, with multiplicity, is exactly

\[
 M_m=\frac{d_+(d_++1)}2+\frac{d_-(d_-+1)}2
 \le (K_d-2)(K_d-1).
 \tag{H3}
\]

## 2. The original fixed source reaches this carrier at the quartic cutoff

The new universal detector bridge in `source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md` is extended in Sections 2–6 of `source_transport/03_FINITE_BAND_SENSOR_WITH_EXACT_BOUNDARY_REMAINDER.md`. Its high-jet construction starts with the actual two translated lobes of the original nonnegative precursor `q_s`, at one fixed scale `s>0`. Set

\[
 K_d=\lceil L^4\rceil,\qquad
 M=\left\lceil\frac{m+3}{2}\right\rceil,\qquad
 N=K_d-M,
 \quad B_{L,M}(x)=\sin^{2M}(\pi x/L).
 \tag{H4}
\]

The lobes lie on unit-collared supports. Divide each by `B`, Fourier truncate to `N`, add the proved uniform tail bound as a positive padding, multiply back by `B`, and take the original reflected combination with its original sign. Apply `P=partial_x^2-1/4` and normalize. The cutoff is exactly at most `N+M=K_d`. The precursor jets through `2M-1` vanish, so the source jets through `2M-3`, including every jet through `m`, vanish. Both exponential moments vanish exactly. The even precursor remains nonnegative; for the odd source the common padding cancels under reflection. These are statements about the retained original trial, not positivity claims about the selected ground.

For completeness, the estimates permitting `m` to grow are

\[
 |(B_{L,M}^{-1})^{(j)}(x)|
 \le(2L/3)^{2M}4^j j!,\qquad
 \|B_{L,M}^{(j)}\|_\infty\le(2\pi M/L)^j.
 \tag{H5}
\]

The first follows from a fixed Cauchy disk on the unit collars; the second follows from the absolute sum one of the Fourier coefficients of `sin^{2M}`. When `m=ceil(kappa L)` with fixed `kappa`, the Gevrey decay constant is unchanged, the multiplication costs through three derivatives are bounded, and the normalized source error satisfies

\[
 \|p-f_{a,\sigma}\|_{H^1}
 \le C_s L^{2M+1/2}\exp[-c_s\sqrt{N/L}].
 \tag{H6}
\]

Its logarithm after multiplying by the full native form bound and any fixed polynomial in `L` is at most

\[
 O_\kappa(L\log L)+L/2-c_sL^{3/2}\longrightarrow-\infty.
 \tag{H7}
\]

Thus the cofinal exponential negative depth of the original fixed detector survives in this stronger carrier at the same prescribed cutoff. The input to the following construction is the actual retained unit trial

\[
 p\in V^{(m),\mathrm{pn}}_{L,K_d},\qquad Q(p)\le-D,
 \qquad D=\exp(\delta L)
 \tag{H8}
\]

after discarding an initial range and adjusting a fixed positive `delta` if necessary. The full phase, source identity, coefficients, normalization and approximation receipt remain attached.

This budget uses a fixed source scale. The separate `s~A/L` bridge has only an exponential-in-`L` margin and does not automatically pay `O(L log L)` extra endpoint cost. No such transfer is asserted here.

## 3. Deep threshold, both predecessors and quantitative inverse

Apply the longest-gap construction of Note 01 to all spectra on (H1), including both parities. There is an exact finite choice

\[
 D/3<\eta<D/2,\qquad
 g_m=\frac{D}{12(M_m+1)},\qquad
 \operatorname{dist}(-\eta,\text{all these spectra})\ge g_m.
 \tag{H9}
\]

The original trial (H8) guarantees a first cutoff `K_eta<=K_d` at which the full pole-neutral minimum is below `-eta`. Select a normalized definite-parity global ground `u` there, with eigenvalue `lambda=-mu`. Both parity predecessors satisfy

\[
 P_{\rm pred}+\eta I\succeq g_m I,\quad
 \lambda\le-\eta-g_m,\quad
 P_{\rm pred}-\lambda I\succeq2g_m I.
 \tag{H10}
\]

Consequently

\[
 \boxed{\|(P_{\rm pred}-\lambda I)^{-1}\|
 \le\frac{6(M_m+1)}D\le\frac{6K_d^2}{D}.}
 \tag{H11}
\]

The selected parity must add a dimension at its first crossing, so its shell has dimension one. The empty predecessor case is harmless. No unshifted predecessor positivity is inferred, and the selected source is not identified with the original trial.

## 4. Zero-flip descent retains every new endpoint condition

In this carrier the endpoint conditions are equivalent to

\[
 R_u(z)=O(z^{-m-2})\quad(z\to\infty).
 \tag{H12}
\]

The exact zero flip at a nonreal source zero `w` multiplies `R_u` by `(z-conj(w))/(z-w)`. Since that multiplier tends to one, (H12), every endpoint condition and the cutoff all survive. The coefficient norm, real-line Fourier modulus, autocorrelation and native form also survive exactly, as in Note 01.

Away from the mandatory poles, the flip preserves both exponential moments. If a mandatory pole has multiplicity at least two, flipping once at that pole also preserves both moments. Global positive semidefiniteness of the shifted ground compression on both parities makes the flipped source a ground at the same eigenvalue. Project onto the original selected parity and subtract the scalar shell value using

\[
 A_w(z)=\frac{z^2-|w|^2}{z^2-w^2},\qquad
 h_n=[A_w(\omega_n)-A_w(\omega_{K_\eta})]u_n.
 \tag{H13}
\]

This is still legal in (H1), still pole-neutral and still a ground, while both extreme coefficients vanish. It is nonzero: the fractional function is injective in `z^2` on the finite real nodes, and support only at the extreme pair would contradict the zeroth even moment or first odd moment. Those moments are included because `m>=2`. Thus it would give a predecessor with energy below `-eta`, contradicting (H10).

The selected high-jet source therefore has exactly the mandatory simple nonreal pair:

\[
 F_u(z)=(z^2+1/4)G(z),\qquad G\text{ entire with only real zeros}.
 \tag{H14}
\]

The canonical compact primitive has the same cutoff,

\[
 g_n=-u_n/(\omega_n^2+1/4),\qquad Pg=f_u.
 \tag{H15}
\]

The two pole moments make its value and first derivative zero at both endpoints. The equation `g''=f_u+g/4` then gives every endpoint jet of `g` through order `m+2` equal to zero. Its transform is `-G`. No sign of `g` is inferred from (H14).

## 5. The extra finite constraint multipliers must remain

Relative to the compression `H_K^(m)` on the endpoint-constrained carrier `V^(m)`, the pole-neutral ground equation has only the pole-constraint residual:

\[
 (H_K^{(m)}-\lambda I)u=V_m\alpha.
 \tag{H16}
\]

Relative to the original legal compression on `V^(2)`, there are additional higher-moment multipliers:

\[
 (H_K^{(2)}-\lambda I)u
 =V_2\alpha+\sum_{j=3}^m\beta_j r_{j,K},
 \tag{H17}
\]

where `r_j,K` are the Riesz vectors of the moment functionals restricted to `V^(2)`. One can use any independent basis of this constraint span; the displayed multipliers need not be unique if the listed constraints are redundant. Neither (H16) nor (H17) is a pointwise full native equation. The outer Galerkin residual remains present. This construction imposes no high-jet regularity on a ground previously selected in a different carrier.

The actual detector Schur identities of Notes 01–02 remain valid after consistently replacing all carriers, projectors and blocks by (H1). This includes the original vector `p`, the actual projected forcing, both phases and the selected spectral threshold. There is no need to reconstruct a fictional unrestricted shell.

## 6. The high-jet sensor is valid, but the original forcing has a shorter route

The independently reviewed sensor theorem in source-transport Note 03 states, for any unit `phi` in (H1), a second detector scale with `theta=delta_probe(2pi K/L)<=1/2`, and the exact periodic inverse followed by physical zero extension,

\[
 \|k_{\delta_{\rm probe}}*v_I-\phi_I\|_2
 \le C\theta^{m+3/2},\qquad \|v\|_2\le4\sec\theta.
 \tag{H18}
\]

The error is confined to the two probe collars. Its proof retains the exact `delta` and `delta-prime` endpoint distributions; the constant is independent of `m`. Taking `m>=kappa L` with `kappa |log theta|>1/2+epsilon` makes that error beat the elementary `poly(L) exp(L/2)` bound for the actual original field. The fixed-source budget (H7) pays this strengthening.

For the original forcing, however, one can use its already retained smooth construction directly. Let

\[
 F_{k_s}=\Pi*k_s,\quad k_s=Pq_s,\quad
 X_s=P F_{k_s}=\Pi*P^2q_s.
 \tag{H19}
\]

For any ordinary pole-neutral legal test `phi` on the source interval, its compact primitive (H15) obeys `g=g'=0` at both endpoints and `||g||_2<=4||phi||_2`. Two integrations by parts give the exact same-interval identity

\[
 \langle F_{k_s},\phi\rangle
 =\langle X_s,g\rangle,
 \qquad
 \boxed{\|\Pi_S F_{k_s}\|_2\le4\|X_s\|_{L^2(I)}.}
 \tag{H20}
\]

There is no boundary remainder. Translations and reflections commute with `P`, so (H20) also applies to the complete four-term original forcing, with the actual phase and history. Its Archimedean part and known `eta p` term are still retained separately.

The arithmetic source in (H19) has transform `(p^2-1/4)^2 D_q(p)`, hence the double pole zeros needed by the integer-drive cancellation, and its original fixed Gevrey constants are unchanged. This directly exploits both Step 1's source construction and the pole constraints maintained through Steps 2–3. It neither identifies `X_s` with the earlier autocorrelation field nor inverts a smoothing convolution. The exact relationship is `F_{h_s}=q_s*X_s`.

Thus the high-jet theorem supplies a valid optional stronger generated state and a separate quantitative sensor control, but it is not needed to repair the derivative mismatch for this original forcing. The remaining obligation is an independently proved bound for the full signed arithmetic residual of the actual source `P^2q_s`, or a sufficient native lower bound. Controlled mask sectors and the new exact adapters do not establish that estimate. Step 4 remains open.

## 7. Review and scope

The high-jet finite bridge and sensor proof were independently checked directly from `source_transport/03_FINITE_BAND_SENSOR_WITH_EXACT_BOUNDARY_REMAINDER.md`, Sections 2–6. The dimensions, threshold selection, zero-flip extension and new finite constraint terms above were checked separately from the original three-jet argument. The exact finite controls accompanying Notes 01–02 include high-jet moment, pole, compact-primitive and shell cases; these controls validate algebraic identities rather than the missing native arithmetic estimate.

All claims here are paper-level deductions. No repository theorem is relabeled, no Lean compilation claim is made, and no RH conclusion is asserted.
