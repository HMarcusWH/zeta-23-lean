# Step 4: original detector retained — research package

## Status

This package contains a new paper research campaign based on the supplied project sources. Step 4 remains open at an explicit native signed arithmetic estimate. No Lean build, repository merge, RH theorem or formal theorem upgrade is claimed.

## Start here

- `Step4_Original_Detector_2026-10-13.pdf`: complete reading copy, including the overview, all fifteen proof/review chapters and the precise remaining bound.
- `PAPER_OVERVIEW.md`: overview and simultaneous witness record.
- `source_transport/04_DIRECT_POLE_NEUTRAL_FORCING_BRIDGE.md`: central new compact-potential map and original-witness bound.
- `detector_arithmetic/04_FIXED_ORIGINAL_PRECURSOR_AND_PROJECTED_FORCING.md`: fixed original-seed arithmetic reduction and explicit open residual.
- `ROOT_REVIEW.md`: independent review, retained hypotheses, corrections and closing status.

## Proof folders

- `root/`: two-sided detector phase, compact pole-neutral inverse and exact native loop.
- `detector_arithmetic/`: positive refinement, normalization, actual scale-limit failure, uniform integer-drive bounds, controlled mask sectors, final fixed-source residual and review.
- `source_transport/`: positive quartic finite bridge, exact phase echoes, physical finite-band recovery and direct same-interval source map.
- `contact_provenance/`: deep neutral threshold, spectral gap, source-specific Schur forcing, optional high-jet carrier and review.
- `dependencies/`: unchanged selected source notes from the previous campaign and supplied master, included for provenance and prerequisites. These retain their original historical statuses.
- `validation/`: compact final validation report and source manifest.

## Reproduce the exact finite controls

Run from the package root with Python 3 and SymPy installed:

```sh
python3 detector_arithmetic/verify_detector_refinement.py
python3 source_transport/exact_controls.py
python3 contact_provenance/verify_deep_state_exact.py
```

The saved JSON files document exact checks and mutation falsifiers. They validate finite algebra and rule out specific shortcuts. Universal analytic assertions are justified in the proof notes, not by these finite calculations.

To rebuild the PDF, use `python3 build_paper.py` with Pandoc, XeLaTeX and the TeX packages listed in that script installed. The build reads the same fifteen source chapters. Dependency notes and review receipts remain separately available in this package.

## Source conventions

P = d²/dx² − 1/4. The original detector is k_s=Pq_s, where q_s is the supplied nonnegative sinc-product probability density. Its autocorrelation source is h_s=k_s*k_s. The new directly derived arithmetic source is j_s=P²q_s, so h_s=q_s*j_s exactly. Different notes retain their local symbols and equation tags; the overview states the shared definitions. A finite approximation and a selected ground are never identified with the original source without the stated map or error bound.
