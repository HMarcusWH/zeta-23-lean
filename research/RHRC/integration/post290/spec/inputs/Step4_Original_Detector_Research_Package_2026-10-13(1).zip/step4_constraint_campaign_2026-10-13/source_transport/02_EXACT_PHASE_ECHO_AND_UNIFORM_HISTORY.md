# The original phase as an explicit causal echo filter

Date: 13 October 2026. Status: **new paper identities and estimates for the actual two-lobe detector. The remaining native forcing estimate is not supplied.**

The original two-translate phase produces an explicit delay filter. Its norm is uniform in the lobe separation. More strongly, the compact source history, after the exact shifted-source correction and exterior advance, has a uniform \(L^2\) bound over the whole original family. These facts apply before ground selection. They do not require an unrestricted contact equation.

## 1. Exact source and safe initial domain

Let \(q_s,k_s,n_s\) be the original source of Note 01, fix \(a>s>0\), and put

\[
d=2a,\qquad R=a+s,\qquad L_0=2R=d+2s,\qquad
\kappa_s(t)=\frac{k_s(t-s)}{\sqrt{2n_s}}.
\tag{1.1}
\]

Here \(L_0\) is the physical support length; the finite carrier uses the larger length \(L_0+2\) with unit collars. The causal version of the exact centered source is

\[
f_+=\sigma\kappa_s+T_d\kappa_s,\qquad
(T_du)(t)=u(t-d)\mathbf1_{t\ge d}.
\tag{1.2}
\]

Thus the left lobe has coefficient \(\sigma\), the right coefficient \(1\), exactly as in Note 01. Let \(W_+\) be the inherited causal half of the native Weil distribution, including the specified half-weight local term, so that the symmetric distribution is \(W=W_++W_+^*\). Its Laplace transform is

\[
J(p)=\frac{\xi'}{\xi}(p+1/2).
\tag{1.3}
\]

All convolution identities can first be read in a right half-plane \(\Re p>1/2\), or in causal distributions of finite exponential order. The fixed source is smooth and flat at its causal endpoints. For every \(\alpha>1/2\),

\[
H_s:=W_+*\kappa_s\in L^2_\alpha,\qquad
\|H_s\|_{L^2_\alpha}\le C_\alpha s^{-1}
\quad(0<s\le1).
\tag{1.4}
\]

Here \(\|u\|_{L^2_\alpha}=\|e^{-\alpha t}u(t)\|_{L^2(0,\infty)}\). To justify the bound, the absolutely convergent logarithmic derivative and the elementary archimedean term give
\(|J(\alpha+i\xi)|\le C_\alpha(1+|\xi|)\); Plancherel then uses
\(\|\kappa_s\|_{H^1}\le C/s\), with the harmless exponential weight on its support \([0,2s]\). This is a safe-half-plane estimate, not an assertion at every positive damping.

Define the full native compact prefix and exterior by

\[
c_f=-\mathbf1_{[0,L_0]}(W_+*f_+),\qquad
v_f(u)=(W_+*f_+)(L_0+u),\quad u\ge0 .
\tag{1.5}
\]

Values at the single endpoint do not affect these \(L^2\) assertions. Exactly,

\[
W_+*f_++c_f=T_{L_0}v_f,\qquad
v_f(u)=\sigma H_s(L_0+u)+H_s(2s+u).
\tag{1.6}
\]

No source is replaced by a selected ground in (1.5)–(1.6).

## 2. The phase quotient is a stable delay measure

Let \(D_k(p)=\int k_s(x)e^{-px}\,dx=(p^2-1/4)Q_s(p)\), where
\(Q_s(p)=\int q_s(x)e^{-px}\,dx=P_s(ip)\). For \(h\ge1\), put

\[
S_{k,h}(p)=e^{sh}\frac{D_k(p)}{D_k(p+h)} .
\tag{2.1}
\]

The paired imaginary zeros of \(Q_s\) imply
\(|Q_s(p)/Q_s(p+h)|\le1\) for \(\Re p\ge0\). For each imaginary zero pair this follows because
\(|p^2+b^2|^2=(x^2+(y-b)^2)(x^2+(y+b)^2)\) is increasing in \(x^2\), where \(p=x+iy\). Pass to the convergent paired product. The elementary real factors also contract for \(h\ge1\), since

\[
|p+h-1/2|^2-|p-1/2|^2=h(2\Re p+h-1)\ge0
\tag{2.2}
\]

and the factor with \(+1/2\) satisfies an even stronger inequality. Therefore \(S_{k,h}\) is a causal \(H^\infty\) multiplier with norm at most \(e^{sh}\).

For the full source, define

\[
S_{f,h}(p)=e^{Rh}\frac{D_f(p)}{D_f(p+h)},\qquad
D_f(p)=\frac{D_k(p)(e^{-ap}+\sigma e^{ap})}{\sqrt{2n_s}}.
\tag{2.3}
\]

The exact phase factorization is

\[
S_{f,h}(p)=S_{k,h}(p)
\frac{1+\sigma e^{-dp}}{1+\sigma e^{-dh}e^{-dp}}.
\tag{2.4}
\]

The adjacent factors in (2.4) are multiplied. Write \(q=e^{-dh}\in(0,1)\). The second factor is the transform of the causal finite signed measure

\[
E_{\sigma,d,h}
=\delta_0+
\sigma(1-q)\sum_{n\ge1}(-\sigma q)^{n-1}\delta_{nd}.
\tag{2.5}
\]

Its total variation is exactly \(2\), since the atom at zero is disjoint from the positive-delay atoms and the latter have total variation one. On every \(L^2_\epsilon\), \(\epsilon\ge0\), causal convolution by this measure consequently has norm at most \(2\). Thus

\[
\|S_{f,h}\|_{L^2_\epsilon\to L^2_\epsilon}\le2e^{sh},
\tag{2.6}
\]

uniformly in the separation \(d\). This is sharper at large separation than the generic bound \(e^{Rh}\). It retains the precise sign of every delayed echo.

There is also a useful stronger weighted bound for the single-lobe operator. If

\[
\tau>0,\qquad h\ge1+2\tau,
\tag{2.7}
\]

the same factor comparison holds on \(\Re p\ge-\tau\): for imaginary pairs use \(h\ge2\tau\), and for the elementary factors use \(h\ge1+2\tau\). Therefore

\[
\|e^{\tau t}S_{k,h}y\|_2\le e^{sh}\|e^{\tau t}y\|_2.
\tag{2.8}
\]

We can use \(h=2,\tau=1/2\), for example. No inverse of the unshifted zeta factor is involved.

## 3. Uniform control of the advanced compact history

Let \(M_hu=e^{-ht}u\), and define the exact advanced history

\[
j_{f,h}(u)=(S_{f,h}M_hc_f)(L_0+u),\qquad u\ge0.
\tag{3.1}
\]

Suppose (2.7) holds, and set \(\alpha=h-\tau>1/2\). From (1.2), (1.4) and (1.5),

\[
\|e^{\tau t}M_hc_f\|_2
\le (1+e^{-\alpha d})\|H_s\|_{L^2_\alpha}.
\tag{3.2}
\]

Indeed, \(M_hc_f\) is the restriction of
\(-\sigma M_hH_s-e^{-hd}T_dM_hH_s\); conjugation by \(e^{\tau t}\) changes the second coefficient to \(e^{-(h-\tau)d}\).

Put \(z=S_{k,h}M_hc_f\), a causal function. Equation (2.8) gives

\[
\|e^{\tau t}z\|_2
\le e^{sh}(1+e^{-\alpha d})\|H_s\|_{L^2_\alpha}.
\tag{3.3}
\]

Now use the exact echo series (2.5). Its undelayed contribution to (3.1) has norm at most \(e^{-\tau L_0}\|e^{\tau t}z\|_2\). The first echo is
\(\sigma(1-q)z(2s+u)\), whose norm is at most \((1-q)\|z\|_2\). For \(n\ge2\), the argument is
\(u-[(n-1)d-2s]\). Since \(d>2s\), these are causal delays, with the same unweighted norm as \(z\); their coefficients have total variation \(q\). Hence

\[
\|j_{f,h}\|_2
\le (1+e^{-\tau L_0})e^{sh}(1+e^{-\alpha d})
\|H_s\|_{L^2_\alpha}
\le C_hs^{-1},\qquad 0<s\le1.
\tag{3.4}
\]

The last constant can be fixed after choosing \(h,\tau\), independently of \(a\) and \(\sigma\). The same bound holds at every positive damping, since those norms are smaller.

This is an upper estimate on a source-specific term that the generic contact construction left as an arbitrary compact companion. It does not say that \(c_f\) itself is small. In fact, for the real unit original source,

\[
2\Re\langle f_+,c_f\rangle
=-\mathfrak q(f_+,f_+).
\tag{3.5}
\]

Thus a Rayleigh quotient at most \(-D\) forces \(\|c_f\|_2\ge D/2\). There is no conflict: the damping, exact phase echoes and exterior advance in (3.1) suppress the large late part and retain a controlled earlier contribution. Also, (3.4) is only an \(L^2\) statement. Cutting off \(c_f\) can introduce jumps; no unproved \(H^1\) or zero-trace claim is attached to it.

## 4. Exact gamma-free forcing and the remaining same-source estimate

Let \(\Delta_h=(1-e^{-ht})W_+\). Since \(S_{f,h}M_hf_+=f_+\), multiplication of the full identity (1.6) by the shift filter gives, as causal distributions,

\[
\Delta_h*f_++c_f-S_{f,h}M_hc_f
=T_{L_0}\!\left[v_f-e^{-hL_0}S_{f,h}M_hv_f\right].
\tag{4.1}
\]

All terms before \(L_0\) cancel only in this complete combination. After the exterior advance, the identity is

\[
v_f-B_{f,h}v_f=y_{f,h}-j_{f,h},\qquad
B_{f,h}=e^{-hL_0}S_{f,h}M_h,\qquad
y_{f,h}(u)=(\Delta_h*f_+)(L_0+u).
\tag{4.2}
\]

The improved prefix norm bound is

\[
\|P_TB_{f,h}v\|_{L^2_\epsilon}
\le2e^{-hd-sh}\|P_Tv\|_{L^2_\epsilon}.
\tag{4.3}
\]

Here causality justifies replacing the input by its prefix; no unknown exterior norm is inserted. The generic source quotient also gives \(e^{-hR}<1\), so the smaller of the two bounds is a strict contraction. This yields a valid absorption once the complete forcing on the right of (4.2) is controlled.

For \(h=2\), the exact inherited gamma-free measure is

\[
\Delta_2=
(e^{t/2}-e^{-3t/2}-e^{-5t/2})\,dt
-\sum_{n\ge2}\Lambda(n)n^{-1/2}(1-n^{-2})\delta_{\log n}.
\tag{4.4}
\]

Writing \(K_{s,h}=\Delta_h*\kappa_s\), the same original phase remains visible:

\[
y_{f,h}(u)=\sigma K_{s,h}(L_0+u)+K_{s,h}(2s+u).
\tag{4.5}
\]

The uniform history estimate (3.4) therefore leaves a precise target: control the actual far translate in (4.5), together with the fixed single-lobe tail, at all needed positive dampings or on the actual prefixes. The gamma-free coefficient \(1-n^{-2}\) and the original single-\(k_s\) source remain in that target. No arithmetic sign gain follows by treating this signed source as a positive one.

The old stable first-order native sensor can be applied to (4.2), but it does not erase this target. Plain \(L^2_\epsilon\) control of an uncancelled output is enough for the associated pole contradiction; recovery through that sensor's inverse requires the stated causal \(H^1_{\epsilon,0}\) graph domain, or the separate all-damping smooth-source interpolation argument. Neither inference is assumed for the cut-off history alone.

## 5. What ground selection can and cannot add here

For a pole-neutral finite ground, the native Euler equation is compressed. Its retained terms are the eigenvalue, the two moment multipliers, and the Galerkin residual outside the selected carrier. The parity component of the causal prefix is related to these terms, but the opposite causal component is not eliminated.

In particular, \(\lambda<0\) contributes a large signed compact term rather than a positive causal measure. The shifted source quotient is an \(H^\infty\) contraction, not a positivity-preserving multiplier on these signed histories. A small predecessor resolvent alone therefore does not bound the complete prefix or the forcing in (4.5). The original detector's special echo identity is stronger than the generic source-ratio norm, but it does not identify the selected finite ground with that detector.

### Dependencies and scope

- Note 01 in this directory supplies the exact original source, norms, phase and finite transport.
- The inherited v2.9 native causal dictionary supplies \(J=\xi'/\xi\), the half-weight convention and the safe-half-plane transform identity.
- The previous frozen campaign's Path B sensor note supplies the gamma-free expression (4.4) and the separate graph-domain inverse.
- This campaign's root note supplies the pole-neutral source constraint and its compact inverse.

The delay factor, separation-independent operator norm, and uniform advanced-history estimate are proved in Sections 2–3 above. They advance the source-specific reduction while leaving the arithmetic upper estimate in (4.5) explicit.
