# Constraint campaign: detector and arithmetic result ledger

Date: 13 October 2026. All new mathematical results here have **PAPER** status. They are not Lean declarations, and they do not establish Step 4 or RH.

## Main result

The strongest combined adapter is in **Note 04**. For the original fixed detector
\(k_s=Pq_s\), \(P=\partial^2-1/4\), exact pole neutrality of a test supplies a compact inverse of \(P\) with norm at most four. Consequently the actual projected prime forcing is controlled by

\[
X_s=P F_{k_s}=\Pi*P^2q_s,
\qquad
\|\Pi_SF_{k_s}\|_2\le4\|X_s\|_{L^2(I)}.
\]

This keeps the original positive precursor, fixed scale, prime weights and observation interval. Its arithmetic kernel has the exact double pole zeros needed by the integer-lattice argument. The prior mask and rough-core estimates therefore give a fixed-source decomposition
\(X_s=R_s^\sharp+D_s^\sharp+r_s^\sharp\), with the last two whole fields controlled in every positively damped \(L^2\) norm. The original two-lobe witness itself satisfies the explicit inequality (15a) of Note 04.

An independent all-positive-damping upper bound on the complete signed \(R_s^\sharp\) would contradict the actual original deep phase sequence and close the original chain. **That bound is not proved.** The output is a new direct source adapter and sharper exact arithmetic target, with the last unsupported implication identified.

## Claims and their limits

| File / location | Proved result | Limit retained |
|---|---|---|
| Note 01, (3)–(9) | Exact positive dyadic factorization of the actual universal detector; compact support, complex-square transfer factor, accumulated damping and phase cost | The fine source is always recorded with the exact map reconstructing the original source; no uniform visibility time over zeros |
| Note 01, (10)–(14) | Finite-interval tilted Jensen/variance, all initial and terminal histories, and multiscale variance telescoping | The final fine-scale energy is not automatically bounded |
| Note 01, (15)–(17) | Exact \(s^{-5}\) normalization; logarithmic normalized self-energy; same-sign coarse-to-fine extraction with explicit loss of depth | A refined trial is not declared to be a null vector or a selected ground |
| Note 02, (3)–(9) | Actual-source scale martingale; almost-sure eventual zero but nonzero fixed mean at the first native prime; non-uniform integrability and diverging second moments | This refutes the specified raw scale-limit inference, not projected finite-source recovery or all possible estimates |
| Note 02, (10)–(19) | Exact full squared energy, signed covariance kernel with retained pole factors, uniform diagonal bound \(O_\epsilon(s^{-9})\), and finite-horizon atom limit | No exchange of the scale and horizon limits; no upper bound on the full signed off-diagonal energy |
| Note 03, (2)–(19) | Uniform scale-dependent integer drive; compensated \(B_s\asymp1/s\); slow refinement with controlled discarded fields \(\exp(O_\eta(T^{3/4}))\) on the complete prefix | The source scale is frozen throughout each prefix; faster refinement is not granted the old constants |
| Note 03, (21) | Explicit closing inequality for the original fixed detector, with slow dyadic descendants and full anticipation | Conditions (22)/(24), on the entire residual or signed prime-pair energy, remain OPEN |
| Note 04, (1)–(15a) | Direct compact test-space bridge, actual four prime translates and known shift, fixed original-precursor arithmetic reduction, and original-witness closing inequality | No inverse of convolution by \(k_s\), no replacement of the original trial by a ground, and no sign assigned to the Schur diagonal |
| Note 04, (16)–(21) | Uniform mixed-source arithmetic constants for \(P^2(q_s*b_\delta)\), and exact stable commutator of the moving mask with probe smoothing | The original \(q_s\) must remain in the measured source; the complete signed residual remains |
| Note 04, (23) | Actual unconditional absolute bound of size \(\operatorname{poly}(L)e^{L/2}\) | Its exponent does not oppose a deep witness rate \(\beta<1/2\), even after the proved small predecessor inverse is inserted |

## New source combination versus an unsupported substitution

The final field \(X_s\) is a derivative of the original single-detector prime field, and the original A field is exactly \(F_{h_s}=q_s*X_s\). The compact inverse acts on the pole-neutral test, with its endpoint traces proved; it does not undo an arbitrary compact filter on an unknown output. These identities are why the final projected bridge is stronger than simply combining the former A/B/C stopping statements.

The finite carrier keeps the original plus/minus lobe coefficient, reflection parity, exact pole moments, and norm-approximation record. It does not keep the entire original cosine/sine transform factor exactly after endpoint repair. The selected negative-threshold ground is separately retained with its multipliers and its compressed Euler equation.

## Reproducible finite controls

Run `python verify_detector_refinement.py` from this directory, or invoke it by its path. It writes `DETECTOR_REFINEMENT_CONTROLS.json`.

- 165 exact rational finite-product moment identities, including the variance of the refinement law.
- 111 exact detector-refinement evaluations, including all selected polynomial knots and their adjacent intervals.
- 15 exact pair-variance checks.
- Four normalization identities checked by independent exact piecewise-polynomial integration.
- Eight exact finite-product martingale levels with constant means and increasing second moments.
- Six exact squared-kernel polynomial factorizations and six slow-scale exponent budgets.

All checks passed. They control finite algebraic implementations and seams. The infinite-product, native prime, infinite-horizon and universal claims are supported by the written proofs, not inferred from finite tests.

## Review and freeze

See `05_REVIEW_RECEIPT.md` for the independent reviews and exact scope. The note files, script and control output are frozen for parent packaging after the final receipt and checksum manifest are written. No earlier campaign artifact was modified.
