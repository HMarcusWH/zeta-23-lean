# Step 4 with the original detector retained

Research campaign: 13 October 2026. **Status: new paper derivations and checked compositions; Step 4 remains open. No new Lean theorem is claimed.**

## 1. The question this campaign actually tests

The question is whether the information produced by Steps 1, 2 and 3 becomes incompatible when retained together: the original universal detector, its positive seed, its two-translate phase, its exact scale, its normalization, its negative depth, its finite construction, and the constrained state selected from it. This campaign works from the supplied project proofs and derives new statements. It does not search the literature for a purported solution.

The project numbering is preserved. Step 1 (Bird) supplies detectability of a hypothetical off-line zero. Step 2 (Fish) prevents small horizontal displacement from defeating detection; the supplied paper refinement gives one fixed universal sinc detector. Step 3 transports the obstruction into admissible representations. Step 4 must independently exclude the generated situation. A finite ground is generally a different vector from the original detector. Retaining both vectors, their exact relation and the original source record is essential.

The strongest new connection is a direct use of the original pole constraints. Let

\[
P=\partial_x^2-\tfrac14,\qquad k_s=Pq_s,
\qquad F_{k_s}=\Pi*k_s,
\qquad \Pi=\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}\delta_{\log n}.
\]

Every compact pole-neutral test \(\phi\) has a compact, clamped potential \(g=P^{-1}\phi\), with \(\|g\|_2\le4\|\phi\|_2\). Consequently

\[
\boxed{\quad
\langle F_{k_s},\phi\rangle
=\langle X_s,g\rangle,
\qquad X_s:=PF_{k_s}=\Pi*P^2q_s.
\quad}
\]

This is exact on the same physical interval. It introduces no endpoint remainder, probe scale, derivative loss, or change to the prime weights. It converts the actual single-\(k_s\) forcing in the finite constrained equation into a double-pole-killed source made from the original positive seed. The arithmetic cancellation machinery applies directly to this source, with fixed-source constants. That composition was unavailable when pole neutrality and the original seed were discarded.

The remaining native signed arithmetic term has not been bounded. The construction advances the frontier; it does not establish the requested contradiction.

## 2. Results obtained in this campaign

### Both original phases, with exponential negative depth

Write \(C_r(t)\) for the actual zero correlation of the universal detector, keeping its complex-square coefficients, and let \(\Delta=\sup_\rho|\Re\rho-1/2|\). Under an off-line zero, both signs separately have type \(\Delta\): for each \(0\le\beta<\Delta\), each \(M>0\), and arbitrarily late times,

\[
C_r(t_+)>Me^{\beta t_+},\qquad
C_r(t_-)<-Me^{\beta t_-}.
\]

The proof uses nonzero residues, absence of a positive-real native zero, and an elementary positive-Laplace argument. It needs neither a rightmost zero nor simplicity of native zeros. It yields deep negative witnesses in both original parity branches. The even branch retains a nonnegative precursor. The exact sine/cosine phase remains recorded before finite approximation.

### Positive refinement retains phase transport and normalization

For every dyadic descendant \(s=r/2^J\), the actual detector satisfies

\[
q_r=q_s*\nu_{r,s},\quad k_r=k_s*\nu_{r,s},
\quad h_r=h_s*\sigma_{r,s},\quad \sigma_{r,s}=\nu_{r,s}*\nu_{r,s},
\]

with positive probability measures and explicit supports. The same identities hold for the full correlation and arithmetic fields. The complex transfer factor, tilted probability laws, complete finite histories, terminal anticipation, and variance terms are retained. A signed coarse witness yields a same-sign fine witness within \(2r\). Its normalized depth pays the actual \(s^5\) cost, because \(\|k_s\|_2^2\asymp s^{-5}\).

### The actual universal detector enters the quartic carrier

A positive endpoint correction now transports the original sinc-product detector, not a different seed, to cutoff \(K(L)=\lceil L^4\rceil\). It preserves the original relative lobe sign and reflection, the two pole moments, and a nonnegative even potential. The finite approximation retains a quantified error rather than an invented exact cosine factor. The full form error is bounded by

\[
C(1+L)L^{13/2}s^{-2}
\exp\!\left(\frac L2-c\sqrt{\frac{s(K(L)-3)}L}\right).
\]

This is negligible for fixed scale and for \(s\asymp L^{-b}\), \(b<1\). The source-specific bridge had been an explicit missing composition in the supplied master. It is proved here on paper.

### A negative threshold preserves depth and buys an inverse bound

Let \(p_L\) be the normalized finite approximation, with \(\mathfrak q(p_L)\le-D_L\). Choose a negative threshold \(-\eta\), with \(D_L/3<\eta<D_L/2\), avoiding the spectra of all earlier pole-neutral carriers. Select the first cutoff whose bottom falls below it.

The original \(p_L\) remains in the record; the selected ground \(u\) is an additional vector. The construction gives both shifted predecessor lower bounds and

\[
\|(A_{\rm pred}-\lambda I)^{-1}\|
\le\frac{6(K_d^2+1)}{D_L}
=O(L^8e^{-\beta' L})
\]

along a retained deep sequence. The detailed count gives a slightly sharper constant. Constrained zero-flipping proves that the selected source has only the two mandatory simple nonreal zeros \(\pm i/2\). Its exact compact potential is retained. The compressed Euler equation keeps the pole multipliers and the Galerkin residual. It is not promoted to an unrestricted contact equation.

### The original phase controls a previously arbitrary history term

For lobe separation \(d\), source half-width \(s\), and \(q=e^{-dh}\), the source quotient factors through the explicit causal measure

\[
\delta_0+\sigma(1-q)
\sum_{n\ge1}(-\sigma q)^{n-1}\delta_{nd}.
\]

Its total variation is two. The phase-specific filter norm is independent of separation. The corrected and advanced compact history has norm \(O(s^{-1})\), uniformly in separation and parity. This is an actual source-dependent upper estimate; it does not bound the remaining far-translated prime field.

### Pole constraints give a direct arithmetic-to-projection map

For any pole-neutral carrier \(S\) on a physical interval \(I\), the boxed identity in Section 1 gives

\[
\boxed{\quad
\|\operatorname{proj}_S(F_{k_s}|_I)\|_2
\le4\|X_s\|_{L^2(I)},
\qquad X_s=\Pi*P^2q_s.
\quad}
\]

The four translated/reflected fields in the actual two-lobe forcing obey the corresponding identities on their exact intervals. Since

\[
\mathcal L(P^2q_s)(p)=(p^2-1/4)^2Q_s(p),
\]

both elementary poles are killed twice. The compensated integer drive, prime-power-preserving mask and controlled rough-core estimates therefore apply with the original fixed seed. A separate finite-band sensor theorem and an effective-band inverse are also proved, but the direct map is the stronger route for this projected forcing.

## 3. The simultaneous witness record

The combined object retains the following data together.

| Data | Exact use |
|---|---|
| Original \(q_r,k_r\), fixed scale and nonzero residues | Detectability and the final pole contradiction |
| Relative sign, translate and complex phase factor | Both deep branches, exact echo filter, source-specific fields |
| Dyadic law and normalization | Controlled scale change with an explicit depth cost |
| Original trial and positive even potential | Actual source transport, not arbitrary negativity |
| Finite approximation and error | Legal quartic carrier with exact pole moments |
| Negative threshold and predecessor spectra | Quantitative inverse at the actual negative eigenvalue |
| Ground, multipliers and full Schur data | Valid compressed equations, with no missing source term |
| Compact test potentials | Direct conversion of single-pole forcing to \(P^2q_s\) |
| Signed native arithmetic residual | The remaining independent upper estimate |

The original trial, its finite approximation, and the selected ground are distinct objects. Statements about one are transferred only by the displayed identities or error bounds. The construction history remains part of the record even where a selected vector does not inherit positivity or the original lobe phase.

## 4. The remaining inequality is explicit

For the original autocorrelation field, the slow-refinement argument yields, for every damping \(\eta>0\),

\[
\|F_r\|_{\eta,[0,T]}
\le e^{v_0r^2\eta^2}
\left(\|R_{s_\eta(T)}\|_{\eta,[0,T+2r]}
+e^{C_\eta T^{3/4}}\right),
\]

where \(s_\eta(T)\asymp T^{-\min(1/2,\eta)}\) is frozen throughout the entire prefix. Here \(R_s\) is the full signed large-rough-core field after the exact mask and divisor decomposition. The diagonal energy and the other two complete fields have been bounded. Equivalently, the positive part of the complete signed off-diagonal pair energy must have subexponential growth at this frozen scale.

The direct compact-potential map gives a second, fixed-source target. Decompose the actual field

\[
X_s=\Pi*P^2q_s=\mathcal R_s+\mathcal D_s+\mathcal E_s
\]

using the same exact arithmetic construction. The integer-drive remainder \(\mathcal E_s\) and the small-rough-core field \(\mathcal D_s\) are controlled. The native signed residual \(\mathcal R_s\) is not. An independent all-positive-damping bound for this fixed original-seed field would exclude every off-line native pole; an adequate projected estimate would also feed the actual finite source equations.

These are two sufficient closing routes. No equivalence between their residuals is asserted merely because both arise from the same detector. A small predecessor inverse also does not by itself supply either upper bound: the Schur identity still contains the actual forcing and the diagonal term.

## 5. Attempts that were tested and did not close the proof

Positive refinement gives a true scale martingale. It does not justify sending scale to zero inside the native energy. At the actual first-prime response this martingale is eventually zero almost surely, has a fixed nonzero mean at every finite level, and is not uniformly integrable. The failure is unconditional and source-specific. It rules out that proposed limiting inference, not all uses of scale refinement.

Preserving exponential depth makes the predecessor inverse exponentially small. An absolute bound on the native coupling can still grow too quickly, so multiplying these two estimates does not prove a contradiction. The exact detector forcing is retained in the Schur completion.

The source-zero classification is compatible with the original detector: its sine/cosine factors and sinc factors already have only real zeros after removal of the mandatory pole pair. That agreement is useful transport information, not an opposing sign.

Fine probes at first appear to impose harmful scale-dependent arithmetic constants. Retaining the convolution with the original seed removes that particular loss. The still simpler compact-potential identity removes the probe altogether for the projected forcing. Neither repair supplies the remaining signed prime cancellation.

## 6. Proof status and reading guide

All new results in this volume are paper arguments. Independent branch reviews checked their maps, quantifiers, endpoint terms, normalization and scope. Exact finite rational controls check refinement identities, moments, variance, normalization, spectral gaps, zero-flipping, Schur completion and mutation failures. They support implementation consistency and falsify specific wrong shortcuts; they are not substitutes for the universal proofs. No repository theorem, axiom audit or Lean build is upgraded by this campaign.

Read the two root notes for the phase theorem and exact native loop. The detector/arithmetic notes then develop refinement, the failed zero-scale limit, the slow-scale closing inequality and the final fixed-source duality adapter. The source-transport notes prove the actual quartic bridge, explicit phase echoes, finite-band recovery and the direct compact-potential map. The contact notes construct the deep neutral state and preserve its actual detector forcing. The final review records the main interfaces and the unresolved sign.

The accompanying package contains the editable proof sources, controls, review receipts and selected source dependencies. The conclusion of the campaign is precise: substantially more of Steps 1–3 is now used in Step 4, and several losses of information have been repaired; the signed native upper estimate needed to close Step 4 is still unproved.
