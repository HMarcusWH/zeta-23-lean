#!/usr/bin/env python3
"""Assemble the paper from reviewed source notes.

Requires Pandoc, XeLaTeX, and standard TeX packages: amsmath, adjustbox,
fancyhdr, xurl, fvextra, longtable, booktabs, geometry, fontspec.
The Python code uses the standard library. No network calls.
"""
from pathlib import Path
import json
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
BUILD.mkdir(exist_ok=True)
FILES = ['PAPER_OVERVIEW.md', 'root/01_TWO_SIDED_PHASE_AND_POLE_NEUTRAL_SOURCE.md', 'detector_arithmetic/01_POSITIVE_REFINEMENT_AND_PHASE_DEPTH.md', 'source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md', 'contact_provenance/01_DEEP_POLE_NEUTRAL_STATE_WITH_SPECTRAL_GAP.md', 'contact_provenance/02_ACTUAL_DETECTOR_FORCING_IN_THE_SCHUR_IDENTITY.md', 'source_transport/04_DIRECT_POLE_NEUTRAL_FORCING_BRIDGE.md', 'detector_arithmetic/04_FIXED_ORIGINAL_PRECURSOR_AND_PROJECTED_FORCING.md', 'root/02_DIRECT_SAME_SOURCE_NATIVE_LOOP.md', 'source_transport/02_EXACT_PHASE_ECHO_AND_UNIFORM_HISTORY.md', 'detector_arithmetic/02_NATIVE_BIRTH_VARIANCE_AND_SCALE_LIMIT.md', 'detector_arithmetic/03_SLOW_REFINEMENT_AND_THE_CLOSING_INEQUALITY.md', 'source_transport/03_FINITE_BAND_SENSOR_WITH_EXACT_BOUNDARY_REMAINDER.md', 'contact_provenance/03_HIGH_JET_DEEP_STATE_AND_DIRECT_SOURCE_BRIDGE.md', 'ROOT_REVIEW.md']
TITLE_OVERRIDES = {}

def prepare_note(name):
    s = (ROOT / name).read_text()
    bad = [ord(c) for c in s if ord(c) < 32 and c not in "\n\t\r"]
    if bad:
        raise ValueError(f"Nonprinting controls in {name}: {bad}")
    if name in TITLE_OVERRIDES:
        s = re.sub(r"^# .*$", "# " + TITLE_OVERRIDES[name], s, count=1,
                   flags=re.M)
    # The PDF is a portable reading copy. Exact original link text and paths
    # remain in the underlying notes and the selected-source manifest.
    def local_link(m):
        label = m.group(1)
        target = m.group(2)
        if target.startswith(("sandbox:", "../", "./")) or target.endswith(".md"):
            return label
        return m.group(0)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", local_link, s)
    # Long literal paths use TeX's breakable path command in the reading copy.
    tick = chr(96)
    s = re.sub(tick + r"([^" + tick + r"\n]+)" + tick,
               lambda m: (r"\path{" + m.group(1) + "}"
                          if len(m.group(1)) >= 35 or
                          m.group(1).endswith((".md", ".py", ".json"))
                          else m.group(0)), s)
    s = re.sub(r"(?<![A-Za-z0-9_./{-])([A-Za-z0-9_./-]+\.(?:md|py|json|txt))"
               r"(?![A-Za-z0-9_/-])",
               lambda m: r"\path{" + m.group(1) + "}", s)
    s = s.replace("\u2014", " - ").replace("\u2013", "-").replace("\u2011", "-")
    return s

metadata = r"""---
title: "Step 4 with the original detector retained"
subtitle: "Phase, scale, compact potentials and a source-preserving A/B/C composition"
author: "Joint paper research campaign"
date: "13 October 2026"
documentclass: report
fontsize: 11pt
geometry:
  - a4paper
  - margin=24mm
  - headheight=14pt
colorlinks: true
linkcolor: MidnightBlue
urlcolor: MidnightBlue
toc: true
toc-depth: 1
numbersections: false
linestretch: 1.06
---

"""
header = r"""
\usepackage{adjustbox}
\usepackage{xurl}
\usepackage{fancyhdr}
\usepackage{fvextra}
\RecustomVerbatimEnvironment{verbatim}{Verbatim}{breaklines=true,fontsize=\small}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small Step 4 -- Original detector retained}
\fancyhead[R]{\small Paper research / OPEN}
\fancyfoot[C]{\thepage}
\renewcommand{\headrulewidth}{0.3pt}
\setlength{\emergencystretch}{3em}
\Urlmuskip=0mu plus 2mu
\setcounter{tocdepth}{0}
\setlength{\parskip}{0.42em}
\widowpenalty=10000
\clubpenalty=10000
\displaywidowpenalty=10000
\raggedbottom
"""
(BUILD / "paper_header.tex").write_text(header)
assembled = metadata + "\n\n".join(prepare_note(f) for f in FILES)
(BUILD / "assembled_paper.md").write_text(assembled)
tex_path = BUILD / "Step4_Original_Detector_2026-10-13.tex"
cmd = [
    "pandoc", str(BUILD / "assembled_paper.md"),
    "--from=markdown+tex_math_single_backslash+raw_tex",
    "--to=latex", "--standalone", "--top-level-division=chapter",
    "--no-highlight", "--include-in-header=" + str(BUILD / "paper_header.tex"),
    "--output=" + str(tex_path),
]
subprocess.run(cmd, check=True, cwd=ROOT)
tex = tex_path.read_text()
# Preserve each local equation tag, while shrinking only displays which would
# exceed the available line width. This avoids clipped long exact identities.
display_count = 0
def fit_display(m):
    global display_count
    display_count += 1
    body = m.group(1)
    tags = re.findall(r"\\tag\{([^{}]*)\}", body)
    if len(tags) > 1:
        raise ValueError("Multiple tags in one display")
    body = re.sub(r"\\tag\{[^{}]*\}", "", body)
    body = body.replace(r"\begin{split}", r"\begin{aligned}")
    body = body.replace(r"\end{split}", r"\end{aligned}")
    body = "\n".join(line for line in body.splitlines() if line.strip())
    tag = (r"\tag{" + tags[0] + "}") if tags else ""
    reserve = "42pt" if tags else "0pt"
    return (
        r"\begin{equation*}" + "\n" + (tag + "\n" if tag else "")
        + r"\begin{adjustbox}{max width=\dimexpr\linewidth-" + reserve
        + r"\relax}" + "\n" + r"$\displaystyle " + body + "$\n"
        + r"\end{adjustbox}" + "\n" + r"\end{equation*}"
    )
tex = re.sub(r"\\\[(.*?)\\\]", fit_display, tex, flags=re.S)
tex_path.write_text(tex)
for run in range(3):
    result = subprocess.run(
        ["xelatex", "-interaction=nonstopmode", "-halt-on-error",
         "-output-directory=" + str(BUILD), str(tex_path)],
        cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT
    )
    (BUILD / f"xelatex_run_{run+1}.txt").write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-8000:])
        raise SystemExit(result.returncode)
pdf_path = ROOT / "Step4_Original_Detector_2026-10-13.pdf"
shutil.copyfile(BUILD / (tex_path.stem + ".pdf"), pdf_path)
print(json.dumps({
    "pdf": str(pdf_path),
    "chapters": len(FILES),
    "display_equations": display_count,
    "bytes": pdf_path.stat().st_size
}))
