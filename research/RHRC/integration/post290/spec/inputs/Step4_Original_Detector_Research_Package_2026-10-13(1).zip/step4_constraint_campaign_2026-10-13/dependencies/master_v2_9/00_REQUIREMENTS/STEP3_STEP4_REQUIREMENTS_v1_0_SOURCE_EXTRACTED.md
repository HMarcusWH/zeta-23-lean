# Source extraction (not the original)

Pandoc extraction of the supplied DOCX. The original DOCX is authoritative for layout and equation presentation. The source is a REQUIREMENTS specification, not a completed reverse-engineered solution or proof.

---

**Terminal mathematical status: RH_OPEN.** This specification defines
what a successful construction must prove, the exact objects it must
concern, and the evidence required to accept it. It is the requirements
stage requested after the paper-first research continuation. Selecting
and reverse-engineering a construction is the subsequent stage.

**Principal requirement.** Step 3 must provide a valid composition from
a hypothetical off-line zero to the objects used by the proposed
argument, preserving every property needed downstream. Step 4 must prove
an independent incompatibility on that covered class. The contradiction
must remain valid for variable finite cutoff, arbitrarily large
aperture, and every generated parity branch.

The central missing result remains mathematical. Existing identities,
positive starting windows, regularity, compactness, and equivalent
formulations provide useful constraints. A complete proof still needs an
independently justified restriction that excludes the negative state.
This document specifies that obligation without assuming it.

# 1 Scope and requirement conventions

The specification applies to the zeta-23-lean programme, including the
two-translate obstruction, canonical source matrices, the globally
aligned residual of PR 247, and the secular and source infrastructure
through PR 287. It incorporates the internally reviewed paper arguments
and interval controls in the research continuation of 11 October 2026.
Online research was checked on 11 October UTC, corresponding to 12
October in Stockholm during preparation.

**Must** identifies a condition for accepting a claimed proof under this
specification. **If used** makes a requirement conditional on the
selected mathematical route. Requirements for Tracks A, B and C are
alternatives or supporting components; the successful construction need
not complete all three. A theorem that bypasses a representation also
bypasses the interface requirements specific to that representation.

Each requirement has a stable identifier. Its acceptance test concerns
mathematics and evidence, not software volume. A requirement can be
discharged by an existing theorem, an independently checked new paper
proof, or a justified composition. Novelty is not required. A paper
proof and its future Lean realization remain separate authority levels.

| **Status**       | **Meaning in this specification**                                                                                   |
|------------------|---------------------------------------------------------------------------------------------------------------------|
| FORMAL           | Existing checked Lean declaration at the pinned tree, with its stated hypotheses                                    |
| PAPER            | Complete argument in the preceding continuation, with independent internal review; not a newly compiled declaration |
| CERTIFIED FINITE | Exact or outward-rounded finite verification with the source-to-claim boundary stated                               |
| EXTERNAL         | An external theorem or author-reported certificate, whose exact use and dependencies must be accepted               |
| OPEN             | A proof, transfer, sign, quantitative estimate, or quantifier extension still required                              |
| FALSIFIED        | A particular claim has a counterexample satisfying its stated hypotheses                                            |

The use of a conditional lemma inside a proof is legitimate if its
premises are proved at its application. The use of the hypothetical
off-line zero or negative residual in a contradiction argument is also
legitimate. Neither practice is itself circular.

# 2 Pinned mathematical baseline

The live main refresh returned commit
`ecc6450f28eb6aed944bda8fe9a09296d033fc3e`, with tree
`a105ffd52c96cd0c39712dcdba45e967282efc9d`. This matches the checked
tree of PR 287 head `40495f39b7510b49a7fe3493b42d9fe3880d6d22`. The
previously audited exact-head record contains 16 successful workflow
runs and 50 successful jobs: 13 formal-validity gates, 34 regression
gates, and 3 research-producing checks. A research check can succeed by
correctly finding a failed conjecture. Its green status does not prove
positivity. \[S1, R1\]

| **Existing result**                                 | **Authority and precise consequence**                                                                                                   |
|-----------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| Off-line zero detection and shrinking radius family | FORMAL. Every relevant off-line zero has a detector witness; parameters may depend on the zero                                          |
| Eventual badness at every aperture                  | FORMAL. Beyond a zero-dependent threshold, every aperture has some bad finite cutoff                                                    |
| Globally aligned residual generation                | FORMAL. Actual residuals occur at arbitrarily large apertures, retaining whole-cell provenance                                          |
| Residual exclusion equivalence                      | FORMAL. GlobalBottomResidualExclusion is equivalent to RH; exclusion itself remains OPEN                                                |
| Global F04                                          | FORMAL at every positive aperture and finite cutoff for the specified canonical even derivative family; it supplies identities          |
| Additive Weil and canonical identity                | PAPER. Factor-one equality for arbitrary complex finite Fourier vectors                                                                 |
| Supported form-domain extension                     | PAPER. Smooth complex coercivity extends with the same constant to the logarithmic form domain                                          |
| Independent positive starting window                | PAPER plus CERTIFIED FINITE scalar bounds. All finite cutoffs and complex tests through full aperture 197/500, with lower bound 1/20000 |
| Shifted ground and tie analysis                     | Existing FORMAL ingredients plus PAPER compositions; some same-ground wrappers remain unimplemented                                     |
| Local aperture stability and finite negative index  | PAPER. Useful local or fixed-aperture control; neither establishes residual exclusion                                                   |
| Full continuous K equals 3 certificate              | OPEN under the preserved D2 equals Full decision                                                                                        |
| Zhu and Liu larger windows                          | EXTERNAL finite-window claims; complete independent certificate replay remains a separate dependency                                    |

**Requirement BASE-01.** Every claim used in the eventual proof must
retain its authority label, exact theorem statement, version, and
hypotheses. Acceptance requires a dependency record distinguishing a
proved implication from a proved premise, and distinguishing a finite
certificate from a universal theorem. Obsolete conditional registry
descriptions must not override a newer proved declaration, and a newer
declaration must not be credited with a stronger conclusion than its
type.

**Requirement BASE-02.** The final target must refer to the genuine
Riemann zeta function and the existing definition of RiemannHypothesis.
Acceptance includes the nontrivial-zero domain, multiplicities where
relevant, the standard functional equation and gamma/pole normalization,
and the final connection to the project’s zero configuration. A theorem
about a synthetic prime system, an auxiliary real-zero function, or a
modified matrix is not the terminal target.

# 3 Exact input and sufficient output contracts

## 3 1 The retained state

Fix an arbitrary state

$$s:GlobalBottomResidualState(Q).$$

Use the following names throughout any same-state composition:

$$L = s.aligned.firstBad.L,\quad N = s.aligned.firstBad.Nstar,\quad K = N + 1,$$

$$p = s.aligned.firstBad.p,\quad\quad\lambda = s.aligned.lam,\quad\quad u = s.groundTrial.$$

Here $L > 0$, $N \geq 1$, $K \geq 2$, and $u \neq 0$. Let $E_{K}$ and
$O_{K}$ be the actual complex boundary-flat even and odd carriers. In
centered coordinates they impose the moments $M_{0} = M_{1} = M_{2} = 0$
together with parity; each carrier has dimension $K - 1$. Let $A$ and
$B$ be the even and odd compressed canonical operators, with bottoms $a$
and $b$. The retained value is

$$\lambda = \min(a,b) < 0,\quad\quad C_{p}u = \lambda u.$$

The last equation is an equation for the **compressed operator**
$C_{p}$. It is not automatically an eigenvalue equation for the
unrestricted ambient matrix or the continuous Weil operator. Its
quadratic energy is nevertheless the ambient canonical quadratic value
on the legal vector. Both parity predecessors at cutoff $N$ are
nonnegative. The cell-minimal finite index is retained across the
physical cell $\left( \log Q,\log(Q + 1) \right)$, while witnesses at
other apertures may differ. Ties select even in the residual type and
retain information about both parity grounds. \[S2–S5\]

## 3 2 The existing necessary arithmetic condition

Write $P_{s}$ for canonicalPrimeRemainderEnergy and $B_{s}$ for
canonicalPrimeFreeBudget, evaluated on this same $L,K,u$. The formal
energy identity gives

$$\mathcal{E}_{s} = - P_{s} - B_{s} = \lambda \parallel u \parallel^{2} < 0,$$

and hence

$$P_{s} + B_{s} = - \lambda \parallel u \parallel^{2} > 0.\quad\quad\text{(1)}$$

This is the precise necessary condition that the direct arithmetic route
must contradict. Eliminating $\lambda$ has removed one variable, but has
not supplied an independent restriction. \[S6\]

For clarity, if $e_{u}(\omega)$ denotes sourceAtomRealEnergy and

$$R(x) = \sum_{n \leq x}^{}\frac{\Lambda(n)}{\sqrt{n}} - 2\sqrt{x},$$

then

$$P_{s} = \frac{1}{L}\int_{0}^{L}R\left( e^{t} \right)e_{u}\prime(1 - t/L)\, dt.\quad\quad\text{(2)}$$

The prime-free budget contains the pole-tail integral, the reduced
archimedean diagonal and off-diagonal energies, and the scalar
correction:

$$B_{s} = \frac{1}{L}\int_{0}^{L}2e^{- t/2}e_{u}\prime(1 - t/L)\, dt + E_{arch,diag}(u) + E_{arch,off}(u) + c_{arch}(L) \parallel u \parallel^{2}.$$

Here the two reduced archimedean energies are matrixRealEnergy of
reducedArchDiagonal and reducedArchOffDiagonal on $u$. The coefficient
$c_{arch}$ is exactly the repository’s canonicalArchScalarCorrection,
equal to twice the sum of sourceEq411DerivedCorrection and wCorrection.
These names bind the convention; this expression must not be reassembled
with a second copy of a correction. \[S6–S7\]

## 3 3 Alternative sufficient terminal contracts

The eventual solution must prove at least one sufficient contract. These
alternatives specify success without choosing how to achieve it.

**Contract RES Direct residual exclusion**

$$\forall Q \in \mathbb{N}\mspace{6mu}\forall s:GlobalBottomResidualState(Q),\quad\bot.$$

This is the existing GlobalBottomResidualExclusion target. Its
equivalence to RH is formal. \[S8\]

**Contract TAIL Residual exclusion beyond one threshold**

$$\exists L_{*} \in \mathbb{R}\mspace{6mu}\forall Q\mspace{6mu}\forall s:GlobalBottomResidualState(Q),\quad L(s) > L_{*} \Rightarrow \bot.$$

The generator supplies a state beyond every real bound, so TAIL is
sufficient. The direct arithmetic instance is to prove
$P_{s} + B_{s} \leq 0$ for every such tail state, contradicting (1). The
threshold must not depend on the individual residual or its cutoff in a
way that leaves uncovered states. \[S9\]

**Contract COFINAL Cofinal good apertures at all finite cutoffs**

$$\forall R_{0} \in \mathbb{R}\mspace{6mu}\exists L > \max\left( R_{0},0 \right)\mspace{6mu}\forall K \in \mathbb{N},\quad\neg AnyParityBad(L,K).$$

This suffices because the repository proves the stronger upstream
implication

$$\text{off-line zero} \Rightarrow \exists L_{0} > 0\mspace{6mu}\forall L > L_{0}\mspace{6mu}\exists K:AnyParityBad(L,K).\quad\quad\text{(3)}$$

Choose a good aperture above $L_{0}$ to contradict (3). Nonnegativity on
both legal carriers is sufficient; strict positivity with a uniform
margin is unnecessary. A cofinal family of physical cells, each
containing an all-cutoff good aperture, is another sufficient contract.
\[S10\]

A first-negative-boundary or analytic-limit proof is also admissible if
it proves an explicit reduction to one of these contracts or directly to
RH. In that case, its own covering reduction is part of the required
proof.

**Requirement TARGET-01.** The selected output contract and its
quantifier order must be written before evaluating a candidate.
Acceptance is an exact composition from the existing generator to a
contradiction. Cofinal positive apertures cannot be justified from
unbounded badness alone; their sufficiency here uses the stronger
theorem (3).

**Requirement TARGET-02.** Do not add unnecessary success conditions. A
universal detector index, a common finite cutoff, positivity at every
aperture, a nonvanishing spectral gap uniform in aperture, all-real
coefficients only, or completion of every research track is not part of
the general specification. Additional conditions introduced by a chosen
method must themselves be proved or the method must be narrowed.

# 4 Step 3 representation requirements

## 4 1 Preserve the generated witness

**S3-01 State identity and provenance.** Every relation combined on the
residual route must start from the same named state $s$, or from an
explicitly defined image of it. The record must include the
zero-dependent existence choices where used, physical cell, aperture,
cutoff, selected parity, negative shift, nonzero vector, legal moments,
metric, and ground equation. It must distinguish the true groundTrial
from a historical zero-shift trial. **Acceptance:** a reader can
substitute the same symbols into all premises without making an
additional existential choice or identifying different vectors by
notation. \[S2–S5\]

**S3-02 Transformation strength.** Every representation map must state
exactly what it preserves: quadratic value, sign, norm, eigenvalue,
ground minimality, source moments, parity, or only existence of a
negative vector. **Acceptance:** downstream arguments use only the
preserved properties. An isometry preserves norm; transporting energy
additionally requires a proved form identity or intertwining. A
congruence transports inertia under its stated invertibility conditions.
Similarity transports eigenvalues but need not transport Hermitian
positivity. A Schur projection normally changes the vector and does not
preserve its original moments.

**S3-03 Normalization and complex scalars.** The proof must fix the
inner-product convention, Fourier sign, centering phase, support units,
source coefficients and normalization. If $u = cv$ with $c \neq 0$,
quadratic energies scale by $|c|^{2}$, while linear moments and the
source functional scale by $c$. **Acceptance:** every normalization
divides only by a proved nonzero quantity and transports the prime
remainder and budget together. A real-vector restriction requires an
explicit decomposition theorem valid for the actual Hermitian form.

## 4 2 Connect the exact forms and their domains

**S3-04 Additive identity if used.** The available PAPER bridge uses

$$f_{L,u}(x) = L^{- 1/2}\mathbf{1}_{\lbrack 0,L\rbrack}(x)\sum_{n = - K}^{K}u_{n}e^{2\pi inx/L},\quad\quad F_{f}(t) = \int f(x)e^{- itx}\, dx.$$

It proves $\parallel f_{L,u} \parallel_{2} = \parallel u \parallel$ and

$$Q_{Weil}\left( f_{L,u} \right) = u^{*}S_{L,K}u.\quad\quad\text{(4)}$$

The factor is one. **Acceptance:** the exact pole pairing
$2\Re\left( F_{f}(i/2)\overline{F_{f}( - i/2)} \right)$, complete
digamma contribution, every prime power, and source correction occur
exactly once. Full source aperture $L$ corresponds to external
half-width $L/2$. The complete complex domain is retained. A separately
defined multiplicative carrier requires its own identity; (4) does not
identify all similarly named forms automatically. \[R2, S11\]

**S3-05 Analytic operations and regularity.** Every interchange, limit,
integration by parts, derivative, and operator extension must have a
domain and a convergence justification. The supported logarithmic form
domain is described by

$$J(f) = \frac{1}{2\pi}\int_{\mathbb{R}}^{}\left\lbrack A_{\infty}(t) - A_{\infty}(0) \right\rbrack\left| F_{f}(t) \right|^{2}dt < \infty,$$

where $A_{\infty}(t) = \Re\psi(1/4 + it/2) - \log\pi$. The preceding
PAPER proof gives the smooth form core and hard-window membership. For
actual boundary-flat vectors, the repository already proves a compactly
supported global $C^{2}$ extension; zero-trace $H^{1}$ membership
follows by an elementary analytic bridge. **Acceptance:** use the
available regularity actually needed, prove any stronger regularity
being invoked, and state the topology in which every limiting identity
holds. Totalized integrals do not establish convergence. \[R2, S12\]

**S3-06 Finite and continuous operators.** If an external theorem
concerns a full continuous ground state, the proof must separately
establish why it applies to the chosen finite state or construct and
control a new continuous ground. Equation (4) preserves the quadratic
value; the finite eigen-equation generally supplies only a Galerkin
equation. **Acceptance:** a new continuous ground has proved existence
and sign, and every finite source or moment restriction later used on it
has its own transport theorem. The continuous spectral bottom must not
be renamed $\lambda$ without proving equality. A form core is not
automatically an operator core; essential self-adjointness and
operator-core density must be proved when the selected theorem requires
them.

## 4 3 Use the correct spectral shift

Let $D:E_{K} \rightarrow O_{K}$ be the actual centered-index
equivalence, $g$ the cubic source vector, and
$H:E_{K} \rightarrow \mathbb{C}$ the exact source functional. The
relation is

$$BD - DA = gH,\quad\quad d = D^{- 1}g.$$

The map $D$ is not an isometry. The following requirements apply only
when the corresponding branch uses secular or source arguments. A direct
form inequality can cover these branches without this machinery. \[S13,
R3\]

**S3-07 Strict even.** Under $\lambda = a < b$, use
$B - \lambda I \succ 0$. The canonical ray is

$$v = D^{- 1}(B - \lambda I)^{- 1}g,$$

and the adapter must establish $u = H(u)v$, $H(u) \neq 0$, and
$H(v) = 1$ for the retained even ground. **Acceptance:** invoke a
negative-shift theorem with its strict gap, preserve the scalar gauge,
and transport the arithmetic from $u$. Zero-contact identities
containing $B^{- 1}$ do not apply by changing the name of the spectral
parameter.

**S3-08 Strict odd.** Under $\lambda = b < a$, use the reverse ray

$$v_{E} = (A - \lambda I)^{- 1}d,\quad\quad v_{O} = Dv_{E},\quad\quad H\left( v_{E} \right) = - 1.$$

The reverse determinant has the sign $1 + H\left( v_{E} \right)$. Source
statements on an odd vector use its even pullback. The current branch
package contains an existential odd ground in hreverse; it is not stated
to equal groundTrial. **Acceptance:** prove direct applicability to
groundTrial or prove eigenline/scalar transport, retaining all norm
factors. The reviewed quantitative odd cubic-moment estimate is an
available PAPER result, not an already exported negative-ground Lean
wrapper. \[S14, R3\]

**S3-09 Tied ground.** Under $a = b = \lambda$, both shifted operators
are singular. Retain both kernels and the even selection made by the
residual type. **Acceptance:** use kernel projection or a pseudoinverse
with its kernel component. Both cases $P_{\ker(B - \lambda I)}g = 0$ and
$\neq 0$ must be covered if this classification is used. The finite
scalar limit of a secular function need not determine its vector
resolvent. A tie cannot be excluded by importing a strict-branch
inverse. At the negative first-bad tie, the predecessor argument bounds
each parity’s negative multiplicity by one; it does not establish
simplicity at every zero contact. \[R3\]

## 4 4 Align contact and arithmetic representations

**S3-10 Contact provenance if used.** A transition from a negative
residual to a zero contact changes the aperture and usually the vector.
If the argument uses first-crossing properties, its finite-cutoff
extraction must produce the exact first-negative boundary, with
nonnegative prefix and negative values arbitrarily close on the outgoing
side. A continuous-operator route needs its analogous proved extraction
and transport. **Acceptance:** preserve the fields actually required by
the exclusion theorem, prove its branch coverage, and independently
establish source or derivative properties at the contact. A theorem
excluding every zero contact may instead use a weaker contact
extraction. A tangent zero alone does not supply outgoing negativity.
\[S15\]

**S3-11 Derivative authority if used.** Reuse global F04 for its exact
canonical even target. Distinguish differentiation in spectral shift,
physical aperture, reciprocal aperture, and a fixed or moving vector.
**Acceptance:** include chain-rule factors, Euler correction, source
transport, and one-sided seam terms required by the selected derivative.
Odd or multiple-contact uses require an applicable theorem. F04
identifies a physical expression; its sign remains a separate question.
\[S16\]

**S3-12 Relation register and dependency graph.** The Step 3 output must
list each used map or theorem with its domain, codomain, preserved
facts, hypotheses, source, status and downstream use. The graph must
distinguish equivalence, one-way implication, exact identity, inequality
and conditional transfer. **Acceptance:** every path in the proposed
proof has a theorem-backed composition. Numerical agreement and similar
terminology are not graph edges. Only the subgraph needed for the
selected sufficient contract must be completed.

# 5 Step 4 universal mathematical requirements

## 5 1 Establish an independent restriction

**S4-01 Independent derivation.** The closing restriction must be proved
from accepted mathematics and the actual hypotheses of the
counterexample argument. A result with RH-equivalent strength is an
admissible target. **Acceptance:** the dependency tree contains no
unproved RH, residual exclusion, global positivity, global
positive-kernel property, or renamed opposite arithmetic sign. The proof
must expose where it uses information beyond the negative-ground
identity. A contradiction may use all consequences of the hypothetical
negative state, provided no desired conclusion is inserted as a premise.

**S4-02 Actual applicability.** The proved restriction must apply to
every state required by the chosen contract. **Acceptance:** all extra
hypotheses are derived from the generator, established independently on
the covered domain, or handled by a proved branch reduction. An
inequality for a convenient trial function, pole-neutral subspace, fixed
source gauge, or special parity remains partial if the actual state is
not shown to belong to that class.

**S4-03 Incompatibility strength.** The new result must logically
contradict the existing necessary conditions. **Acceptance:** write the
final algebraic or analytic contradiction explicitly. For the direct
arithmetic route, an upper bound $U_{s}$ is sufficient only if the proof
also gives $P_{s} + B_{s} \leq U_{s} \leq 0$. A small positive upper
bound, a relative error larger than the available margin, or another
expression equal to $P_{s} + B_{s}$ does not exclude the state. A
successful alternative can contradict a different necessary condition,
but must exhibit that contradiction equally explicitly.

**S4-04 Genuine arithmetic.** Where the argument distinguishes zeta from
matched modified-prime systems, it must use a proved property of the
actual coefficients or their analytic completion. **Acceptance:**
identify the exact coefficient formula
$\Lambda\left( p^{j} \right) = \log p$, the gamma and pole data,
Euler-product or functional-equation input, or other established
arithmetic theorem that does the distinguishing. Positive weights,
prime-power consistency and coarse prime asymptotics alone are
insufficient for the controls already constructed. The proof need not
fail on every artificial system; it must exclude every negative model
satisfying all premises actually used.

**S4-05 All required parameters.** The theorem must cover variable $K$
and the aperture range of the selected contract, with no lower bound on
the hypothetical nonzero distance from the critical line.
**Acceptance:** every constant has declared dependence, and every limit
or estimate is uniform exactly where the composition requires it.
State-dependent constants are allowed when the final quantifiers remain
valid. A cutoff-dependent threshold cannot establish the
common-threshold version of TAIL without further work.

**S4-06 Complete branch coverage.** Every generated possibility must be
covered by a theorem or bypassed by a stronger common argument.
**Acceptance:** the branch table in Section 8 has no unresolved required
row. In particular, strict even, strict odd and tied grounds cannot be
identified. A proof of COFINAL by a direct form inequality can cover
them simultaneously and need not prove separate contact theorems.

**S4-07 Preserve information under elimination.** Elimination must
preserve logical direction, exceptional loci and inequalities.
**Acceptance:** establish nonzero denominators, range conditions,
complex conjugation, and any positivity needed by Schur complements or
divisions. If an elimination enlarges the possible state set, prove
incompatibility on that enlarged set or retain the missing restrictions.
Polynomial syzygies alone do not preserve spectral ordering, positivity
or analytic realizability.

# 6 Requirements for the three investigation tracks

## 6 1 Track A source arithmetic

**A-01 Same signed integral.** The candidate must constrain (2), or an
exactly equivalent expression, on the retained true ground. If a bound
on $\psi(x) - x$ is imported, derive its relation to the weighted
remainder $R(x)$ by justified partial summation. **Acceptance:** retain
endpoint contributions, the chain-rule factor, prime-power jumps, and
the actual signed weight $e_{u}\prime(1 - t/L)$. An upper bound on $|R|$
becomes useful only after a proved bound on the matching source-weighted
variation and a closed final budget.

**A-02 Entire energy budget.** Local moment or endpoint information must
be combined with the older-prime contribution and the entire prime-free
budget. The PAPER strict-odd result supplies a nonzero cubic moment and
a favorable recent-prime interval, with a radius depending on the parity
gap and $K$. **Acceptance:** quantify that interval, estimate every
contribution outside it, and prove that the resulting inequality
contradicts (1). A sign on a subset of primes is not a sign for the
complete sum.

**A-03 Gap and source normalization control.** A resolvent or moment
estimate containing $(a - \lambda)^{- 1}$, $(b - \lambda)^{- 1}$,
$\parallel H \parallel$, or a normalization factor must track it through
the final inequality. **Acceptance:** either prove the necessary bound
in the covered branch, show cancellation with a justified nonzero
factor, or treat the small-gap and tie regimes separately. Neither a
fitted lower gap nor a source normalization sampled at one ground is
admissible.

## 6 2 Track B first-negative exclusion

**B-01 Generate the correct first boundary.** Starting from a negative
witness, construct a fixed-cutoff positive/negative bracket and its
boundary using the exact continuity theorem. **Acceptance:** the
boundary has zero ground value, a nonnegative prefix, and outgoing
negative values. Excluding arbitrary zeros is stronger than necessary;
harmless tangent contacts may remain. When using the full continuous
bottom instead, prove the finite-to-continuous reduction and state which
witness changes. \[S15, S17\]

**B-02 Prove continuation through a vanishing margin.** A Gronwall-type
route must independently estimate a coefficient whose integral remains
finite all the way up to the alleged crossing. It must establish
absolute continuity of the scalar margin $m$, or the corresponding
regularity hypotheses of the chosen comparison theorem. For example, if
$m\prime + Cm \geq 0$ is used with a positive initial $m$, the
comparison requires an integrable coefficient on the relevant interval
including its contact endpoint. An unbounded but integrable coefficient
is permitted. **Acceptance:** derive $C$ from established arithmetic or
operator estimates. Defining $C = - m\prime/m$ is merely an identity
until the required integrability is separately proved. Other noncrossing
principles are admissible with their own complete hypotheses.

**B-03 Seam compatibility.** A propagation proof crossing $L = \log q$
must treat entry of each prime power, the exact endpoint correlation,
and every derivative jump used. The PAPER estimate bounds the entering
atom by $\beta_{q}J(f)/R_{\rho}\left( L - \log q \right)$, with a
coefficient tending to zero, where $\beta_{q} = \Lambda(q)/\sqrt{q}$ and
$R_{\rho}(\delta) = \int_{\delta}^{\infty}\rho(s)ds$. **Acceptance:**
prove a background estimate strong enough to absorb this relative form
bound. Small overlap length is not an $L^{2}$ operator-norm bound. A
bound relative to $J$ is not automatically relative to the vanishing
Weil margin. \[R4\]

**B-04 Global continuation or cofinal reach.** Local extension from
$Q \geq cI$ to a slightly larger interval with $Q \geq (c/2)I$ is
available on paper. **Acceptance:** if iterated, prove that the reached
apertures have the required unbounded range. Steps that shrink as $c$
tends to zero can accumulate at a finite aperture. Higher-order
contacts, eigenvalue multiplicities, parity changes and fresh/inherited
regions must be covered unless the argument bypasses them.

## 6 3 Track C compatibility and finite reduction

**C-01 Identify the nonredundant remainder.** For each proposed
elimination, record the original relations, eliminated variables,
surviving relation and its independent premises. **Acceptance:** verify
that the survivor is not simply the characteristic equation, negative
energy, Ward identity, normalization, or the desired positivity in
another notation. Logical equivalence to RH is not a reason to discard a
target; absence of an independent proof is the relevant failure.

**C-02 Preserve the domain of a Schur reduction.** If a positive
complement is eliminated, prove the complement’s lower bound, existence
and boundedness of its inverse, and the domain of the cross operator.
The exact remaining expression has the form

$$S_{eff} = H_{E} - C^{*}H_{F}^{- 1}C.$$

**Acceptance:** prove the completed-square identity and the required
sign or inertia implication. Eigenvalues need not be preserved
individually. The projected vector is a new witness; source moments of
the original ground require transport. A finite-dimensional $S_{eff}$
containing an infinite-dimensional inverse is not yet a finite
arithmetic certificate. \[R5\]

**C-03 Control omitted directions.** Finite negative index at each
aperture does not identify a sufficient canonical Fourier cutoff and
does not prove index zero. **Acceptance:** any finite checker used for
all-$K$ positivity must include a theorem covering the entire omitted
space and its coupling to the retained space. Any asymptotic source-atom
or bulk trace law must be connected to the complete zeta-weighted
operator and the spectral edge needed for exclusion, with valid
parameter dependence.

# 7 External research requirements and import register

## 7 1 Requirements for accepting an external input

**EXT-01 Exact source and status.** Pin the author, title, version,
theorem number, domain, assumptions, and applicable errata. Record which
proof and certificate components were inspected and which were
independently reproduced. **Acceptance:** author claims, theorem proofs,
numerical certificates, reproduction receipts, and Lean declarations
remain distinct. The research scan below covers the programmes
materially relevant to this construction; it is not a claim to have
exhaustively audited all RH literature.

**EXT-02 Independent certificate authority.** If a computational theorem
is used as a premise, verify its complete source-to-target construction
and every finite certificate required by the theorem, together with the
analytic reduction and tails. **Acceptance:** no substitution of a
checksum, sample entry, previously recorded PASS, small scalar subset,
or host program axiom for the complete asserted sign. A finite
certificate can prove an infinite-dimensional statement only through a
proved reduction.

**EXT-03 Spectral identification if used.** Self-adjointness and real
zeros of an auxiliary characteristic function require a separate theorem
identifying the object with the zeta target. **Acceptance:** establish
the shift, normalization, completeness and limit topology needed to
transport zero exclusion. If a locally uniform analytic limit is used,
prove its nonzero target and domain; numerical matching of finitely many
zeros is insufficient. A positive shifted form does not prove the
unshifted form positive.

**EXT-04 Arithmetic estimates if used.** A zero-density,
pair-correlation, PNT or finite-height result must be converted to an
estimate on the covered witness class. **Acceptance:** supply an exact
source-weighted bound or an amplification theorem showing that one
off-line zero would violate the imported quantitative result. A positive
proportion, density-one statement, or finite verification can leave
isolated exceptions.

## 7 2 Closest operator and positivity programmes

**Suzuki September 2026.** Theorem 1.1 identifies the localized Weil
operator as a Friedrichs extension of $D^{*}G_{a}D$; the subsequent
results provide a smooth form core, continuity of its lowest eigenvalue,
and positivity with simple even ground for sufficiently small $a$. The
auxiliary real-zero construction uses a shift below that lowest
eigenvalue. The global limiting identification remains conjectural.
Required use: the correct domain and shift, plus a separate connection
to the finite generated ground. Global positive-kernel structure cannot
be assumed. \[E1\]

**Connes and van Suijlekom and the CCM programme.** The precise
real-zero theorem requires the form defined from the one-sided
distribution, a lower-bounded essentially self-adjoint operator on
trigonometric polynomials, and an isolated simple even ground. Its proof
uses an operator core. Remark 4.3 explains why symmetrizing a
distribution can lose boundary data. These are requirements only for a
route using that result. Global approximation to the zeta target remains
an additional obligation. The 2026 Connes survey supplies context for
this programme. \[E2–E4\]

**Zhu version 2.** The reported complex coercivity is
$8.9 \times 10^{- 18}$ at half-width $0.8$, hence full aperture $1.6$.
The support-$2.38$ positivity claim was retracted after an envelope
inequality error. Trial upper bounds and the fitted decay law are not
lower bounds; the large-aperture upper-bound theorem assumes RH. The
pointwise-comb obstruction applies to the stated method. Required use:
accept the complete valid-window certificate, match (4), and retain the
window restriction. \[E5\]

**Liu.** The supplied manuscript and author dissemination report complex
smooth-test lower bounds $2^{- 151}$ at half-width $1$ and $2^{- 49162}$
at half-width $17/16$. After the PAPER bridge they would yield all-$K$
bounds through full apertures $2$ and $17/8$. The larger certificate
retains prime power $8$ and the compensating tail. The earlier 56 scalar
checks do not verify the full Gram and source certificate. The public
frozen instructions distinguish Theorem B clean reconstruction and
complete verification from Theorem A retained-proposal verification.
These are explicit dependencies if imported. \[E6, R1\]

**Groskin finite dictionary and tail order.** The supplied version 3
gives an exact finite dictionary and a positive omitted archimedean
increment at fixed source cutoff and band. The input class and
pole-neutral quotient must be aligned with the actual state. Positivity
of the isolated tail does not establish positivity of the full form,
positive secular residues, or monotonicity in aperture. Direct arXiv
retrieval did not complete in this refresh; the supplied paper and
public author repository were available. \[E7\]

**Groskin corrected prime-edge measure.** The corrected version 2 gives
an exact prime-power derivative event and finite source-to-jet geometry.
Its corrections retain removable poles and repeated eigenvalues,
restrict reciprocal identities, and make the proposed string
interpretation conditional on missing positivity properties. Required
use: prove equality with the production path, including coordinate and
derivative conventions. The arithmetic event identity recovers its input
coefficient; an additional theorem must extract an exclusion inequality.
\[E8\]

**Groskin sine Loewner operator.** The newer programme gives trace and
boundary results for the elementary sine Loewner operator, including
finite-matrix comparisons. Its isolated boundary interaction statements
do not provide uniform laws as the spectral level approaches zero or a
band edge. Required use: prove transfer from the source atom to the
complete signed arithmetic combination and control the relevant spectral
edge. Bulk trace information alone does not exclude a single negative
ground. This review screened the stated scope and source introduction;
it did not audit all proofs in the 88-page work. \[E9\]

## 7 3 Independent arithmetic and alternative criteria

**Explicit PNT and zero-free estimates.** Johnston–Yang and the
September 2026 Fiori–Jaskari paper provide unconditional error estimates
for $\psi(x) - x$ with stated ranges. Bellotti–Trudgian–Yang supplies a
new explicit zero-free strip near the one-line. These are potential
arithmetic inputs to A-01. Their bounds must be partially summed with
the actual signed source and shown strong enough for the final budget. A
one-line zero-free strip leaves possible zeros near the critical line.
\[E10–E12\]

**Density and pair correlation.** Guth–Maynard’s large-value work
improves zero-density bounds. Lamzouri’s September 2026 paper derives
unconditional proportions using pair correlation and a Hilbert-space
inequality. These provide averaged information. An application here
needs a proved bridge from the generated obstruction to a forbidden
count or weighted mass; a single exceptional zero is not excluded by the
quoted type of average alone. \[E13–E14\]

**Weil and Li and Nyman–Beurling.** The criteria and their exact
dictionaries are independent mathematical theorems. Universal Weil
positivity, all-index Li positivity, and the requisite Hilbert-space
approximation are alternative RH-strength conclusions. Changing from one
criterion to another supplies Step 3 information; Step 4 must prove the
needed sign or norm convergence independently. The discrete Báez-Duarte
criterion also shows why a convenient formal Möbius sum is not a
substitute for a norm-convergent construction. \[E15–E17\]

**de Branges and canonical systems.** Available constructions have
specified parameter ranges or explicit RH assumptions. Required use:
establish a positive Hamiltonian, inner function or reproducing kernel
over the range actually needed without assuming the positivity
conclusion through the construction of its Hilbert space. The name of a
positive-kernel theory does not certify that the zeta-derived kernel
satisfies its hypotheses. \[E18–E19\]

**Jensen polynomials and de Bruijn–Newman.** Eventual hyperbolicity for
every fixed degree has a degree-dependent starting shift; it is not
all-degree, all-shift hyperbolicity. Rodgers–Tao proves the lower
direction for Newman’s constant, while RH requires the opposite upper
direction. Either framework can supply a target or an independent
estimate, but its missing quantifiers or direction must remain explicit.
\[E20–E21\]

**Finite-height verification.** Rigorous verification through a finite
height can force a hypothetical exceptional zero above that height. It
supplies no bound on the aperture or finite cutoff required to detect
every higher zero without an additional theorem. The established
$3 \times 10^{12}$ result is a finite-height statement, not a truncation
of the present all-parameter obligation. \[E22\]

# 8 Complete branch and parameter assessment

The final construction must complete the appropriate row by a covering
theorem or a proved bypass. It need not solve each row using a separate
local mechanism.

| **Case**                              | **Required treatment**                                                     | **Scope limit to preserve**                                          |
|---------------------------------------|----------------------------------------------------------------------------|----------------------------------------------------------------------|
| Strict-even negative ground           | Correct shifted ray or a common form inequality                            | Opposite unshifted block need not be positive                        |
| Strict-odd negative ground            | Reverse sign and explicit same-ground transport                            | Existential hreverse vector is not automatically groundTrial         |
| Negative parity tie                   | Even selection and both kernels; singular-safe reasoning                   | No strict inverse at the common ground                               |
| Multiple zero contact                 | Kernel-aware boundary argument if contacts are used                        | Negative first-bad simplicity does not prove zero-contact simplicity |
| Stationary contact                    | Complete higher-order or noncrossing control                               | Nonnegative local curvature does not exclude an odd-order crossing   |
| Nonstationary contact                 | Correct directional inequality on the outgoing side                        | Stationary response identities are inapplicable without stationarity |
| Fresh-born negative region            | Boundary generated with its correct ancestry                               | Inherited stationarity cannot be assumed                             |
| Inherited negative region             | Retain the relevant first-bad and prefix conditions                        | A local contact is not automatically first negative                  |
| Prime-power seam                      | Exact entry convention and required one-sided regularity                   | Smooth cell calculus alone does not cross the seam                   |
| Arbitrary finite cutoff               | All K at the required aperture or an all-K reduction                       | Finite negative index is not a sufficient Fourier cutoff             |
| Unbounded aperture                    | TAIL tail coverage, COFINAL cofinality, or another proved global reduction | A finite collection of windows is insufficient                       |
| Vanishing parity gap                  | Gap-dependent estimates remain valid or the tie is handled                 | No uniform separation is supplied by the generator                   |
| Complex source and scaling            | Full Hermitian domain or proved real decomposition                         | Linear and quadratic quantities scale differently                    |
| Zero height and off-line displacement | Every permitted nontrivial zero; no positive distance threshold            | Finite-height checks and coarse localization leave a tail            |

**Requirement COVER-01.** The finished proof must include a coverage
certificate identifying which theorem covers each required row and which
rows are bypassed by the selected contract. A row marked irrelevant
needs a mathematical reason, not a numerical absence of that case. For a
direct all-vector inequality, most local contact rows are bypassed
because no negative vector exists to generate a contact.

# 9 Falsification requirements

**FALS-01 Match the hypotheses.** Before accepting a candidate, list its
full hypotheses and compare them with the relevant controls below. A
counterexample refutes a candidate only if it satisfies all those
hypotheses. Conversely, a candidate is not repaired merely by adding a
condition that has not been proved for the actual state. Record which
mathematical input excludes each otherwise matched negative control.

| **Control**                                 | **What it tests**                                                                                        | **Required interpretation**                                                                               |
|---------------------------------------------|----------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|
| Pair-D C1                                   | Carrier geometry, reversal, centered-index commutator and positive predecessors with negative successors | Structural parity squeeze alone is insufficient; full canonical arithmetic is absent                      |
| Legal K equals 2 negative source atom       | Actual moments, D and cubic source, phase and shifted overlap                                            | Source geometry and one atom’s coefficient do not determine the complete form                             |
| Generic positive rank-one secular example   | A positive increasing transform can attain its root at negative shift                                    | Positive measure or positive slope alone is not exclusion                                                 |
| Strict-branch and tied exact models         | Pseudoinverse kernel terms, removable scalar poles and singular limits                                   | Retain the full kernel and actual branch hypotheses                                                       |
| Odd-order contact family                    | Stationary contacts with optimized curvature zero and outgoing negative Schur scalar                     | No fixed finite jet list establishes general noncrossing                                                  |
| Genuine canonical K equals 4 and 5 residues | Signed secular residues on genuine positive matrices                                                     | Universal positive-residue assertions are false; no negative-ground premise was tested                    |
| Q14 genuine point and modified weights      | Near-zero margins, coefficient sensitivity and ground rotation                                           | Exact genuine arithmetic must distinguish modified systems; fixed-ray and moving-ground thresholds differ |
| Prime-power-consistent extension            | Modified finite prime bases with all their powers scaled coherently                                      | Positive weights and coarse PNT behaviour alone remain insufficient                                       |
| Endpoint packets                            | Order-one correlation on a shrinking overlap                                                             | Ordinary L2 norm does not give seam smallness; control form energy                                        |
| Compact-resolvent crossing and Schur model  | Positive high tail and finite negative index with a bad low block                                        | Compactness and finite index do not prove positivity                                                      |
| Large-aperture and variable-cutoff examples | Quantifier order and loss of constants                                                                   | Fixed-K or bounded-window success does not establish TAIL or COFINAL                                      |

The decisive exact instances already available include
$T(\mu) = 3/(2 - \mu)$, which is positive and increasing but satisfies
$T( - 1) = 1$; a fixed-$D$ family with Schur scalar $- t^{m}$ for every
odd $m \geq 3$; and genuine residue signs $( + , + , - )$ at
$K = 4,L = 13/10$ and $( + , + , - , - )$ at $K = 5,L = 11/10$. The
latter were checked by outward source intervals and exact interval
inertia. \[R3–R6\]

At the rational Q14 aperture, the certified modified-weight crossing
lies near $2.17232814518 \times 10^{- 13}$ in the multiplicative
perturbation parameter, while the original fixed-ray threshold is
different. A coherent extension of that perturbation changes the
weighted remainder uniformly by less than $1.674 \times 10^{- 12}$ and
retains a coarse PNT asymptotic. It does not retain the genuine
coefficients or completed functional equation. These are controls on
inadequate hypotheses, not counterexamples to RH. \[R6\]

**FALS-02 Use the fastest decisive test.** First test algebraic and
quantifier consistency, then matched exact low-dimensional controls,
then canonical interval cases, then expensive parameter ranges. A proof
proposal requiring all secular residues nonnegative fails immediately on
the existing genuine controls. A barrier derived by division by its
margin fails the explicit higher-order contact test unless integrability
is separately proved. A surviving candidate still needs an analytic
proof.

**FALS-03 Preserve rejected claims precisely.** Record the exact
falsified statement, counterexample, verified hypotheses, and scope. Do
not promote a failed lower bound into a negative value of the actual
form, or a method-specific obstruction into an impossibility theorem for
all Step 4 approaches. Repair is legitimate when the strengthened
premises are independently established on every needed generated state.

# 10 Quantitative and certificate requirements

**NUM-01 Proof-relevant precision.** Every numerical sign used as proof
evidence must have exact rational or outward-rounded bounds, validated
source normalization, complete input data, and a theorem relating the
verified finite object to the claimed object. **Acceptance:** a sign
interval excludes zero in the required direction, or a non-strict
equality/sign has an exact proof. A higher precision floating-point
value is not automatically an enclosure.

**NUM-02 Continuous coverage.** A continuous-aperture certificate must
prove coverage of every claimed point, including endpoints and seams,
with an error estimate valid on each covered cell. **Acceptance:** the
union of certified cells is the full stated range, every parity sector
claimed by that certificate is covered, and any omitted tail or
parameter range has its own theorem. Both sectors are required by the
combined WP4 Full or terminal positivity claim; a correctly labeled
one-parity partial certificate remains valid. A positive grid, frozen
basin or single rational aperture cannot be labeled a continuous
certificate.

**NUM-03 Full error budget.** The inequality must include source
approximation, quadrature, rounding, basis conversion, compression,
complement and coupling errors, as applicable. **Acceptance:** the final
margin dominates the sum or correct quadratic combination of all errors.
Signed channel cancellations may be bounded separately only after
proving that the resulting loss still leaves a sufficient bound.

**NUM-04 Reproducibility and authority.** A finite verification package
must identify its exact input hashes, dependency versions, precision and
rounding model, expected mathematical statement, checker and output.
Separate proposal generation from verification where possible.
**Acceptance:** another execution can reproduce the certificate from the
pinned inputs, and the report distinguishes interval authority from a
kernel-checked fact. Replaying a subset of a larger certificate does not
discharge the omitted obligations.

# 11 Requirements that must not be silently strengthened or weakened

The following distinctions are part of TARGET-02 and S4-05.

| **Tempting substitute**                                 | **Exact requirement**                                                                                       |
|---------------------------------------------------------|-------------------------------------------------------------------------------------------------------------|
| For each K there are arbitrarily large good apertures   | At one selected cofinal aperture, every finite K is good, unless a different sufficient reduction is proved |
| Every tested K is good at each chosen aperture          | A theorem covers all untested cutoffs and their interactions                                                |
| A uniform positive constant for all apertures           | Nonnegativity is sufficient for COFINAL; a method requiring a constant must prove it                        |
| Only strict-even residuals                              | Cover strict odd and ties, or prove they are excluded by another theorem                                    |
| Every zero contact must be absent                       | Excluding actual outgoing first-negative boundaries is sufficient for propagation                           |
| A positive ambient shifted operator                     | Establish the sign needed for the unshifted object or retain the shift in a valid conclusion                |
| A positive archimedean tail                             | Control the complete pole, archimedean and prime combination                                                |
| Small residual after eliminating shared variables       | Prove a residual whose sign is actually incompatible with the generated state                               |
| Real-rooted approximants numerically near zeta zeros    | Prove complete analytic identification and a zero-preserving limit                                          |
| Every auxiliary lemma must reject every countermodel    | Test the entire used hypothesis set and the completed chain                                                 |
| Every external paper must be fully imported             | Import only dependencies needed by the selected construction                                                |
| Full continuous K equals 3 proves the universal theorem | Preserve it as the required finite work package; all-K and unbounded-aperture obligations remain            |

A simple logical control is $Bad(L,K) \Leftrightarrow K > L$. Every
fixed $K$ is eventually good as $L$ grows, and badness persists when $K$
increases. Nevertheless every finite $L$ has a bad $K$. This illustrates
why cutoff-dependent large-aperture results cannot be interchanged with
an all-cutoff good aperture.

# 12 Completion gates for the next stage

## 12 1 Step 3 completion

**GATE-01.** Step 3 is complete for a selected construction when its
used representation graph composes from the existing counterexample
generator to the exact input of the proposed exclusion theorem. Every
edge has a proof, every domain and shift agrees, every change of vector
has sufficient transported properties, and every branch needed by that
construction is covered. Equivalent descriptions beyond this used graph
are optional.

The review deliverable must include the state definitions, the map
register, the normalization/domain proof, the used shifted or contact
adapters, and the source/status ledger. A collection of individually
valid theorems with incompatible witnesses does not pass.

## 12 2 Step 4 paper completion

**GATE-02.** Step 4 is complete on paper only when a finite proof chain
establishes one sufficient terminal contract with no open mathematical
leaf. The proof must explicitly contradict a generated necessary
condition or otherwise imply RH, pass the branch assessment, and survive
independent checking of its arithmetic, limits, quantifiers and
countermodels. Independent internal review must be described accurately
and not represented as external peer review.

The shortest direct arithmetic chain has four obligations:

1.  Instantiate an arbitrary actual residual beyond the chosen common
    threshold.
2.  Transport the existing strict inequality $P_{s} + B_{s} > 0$ without
    changing its witness.
3.  Prove from independent mathematics $P_{s} + B_{s} \leq 0$ on that
    same covered state.
4.  Derive the contradiction and invoke the existing off-line-zero
    generator or terminal equivalence.

Only item 3 is the decisive missing sign; items 1 and 2 still require
exact interfaces in any changed representation. The shortest cofinal
alternative is to prove all-$K$ legal nonnegativity at arbitrarily large
common apertures and contradict (3). These are specifications of the
required output, not proofs that either output has been constructed.

## 12 3 Lean and terminal claim completion

**GATE-03.** Lean implementation follows an accepted paper proof and
separate authorization. Its specification must match the mathematical
statement actually proved, discharge every imported premise through an
accepted route, and identify the permitted foundational axioms. The
existing project axiom policy permits propext, Classical.choice and
Quot.sound; additional unproved arithmetic or RH-strength axioms cannot
silently stand in for the result. Exact-head formal-validity checks,
relevant regression checks, graph consistency and claim-validation gates
must then pass. Source and certificate audits remain distinct from a
successful build.

**GATE-04.** The project retains RH_OPEN until the complete proof and
formal claim-validation gates succeed. Partial improvements must be
recorded with their exact scope. A complete finite window, a new
equality, a paper adapter, a green check or an RH-equivalent target is
not itself a terminal proof.

# 13 Preservation of the established work packages

This requirements document does not change work-package ownership or
authorize implementation. The mathematical success contracts above are
distinct from completion of the already chosen engineering packages. In
particular, WP4 remains Full K equals 3 even if a later mathematical
proof uses a different global route. \[R7\]

| **Package** | **Preserved obligation and relationship to this specification**                                                                                                   |
|-------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| WP0         | Exact live source and theorem authority; do not restart completed orientation                                                                                     |
| WP1         | Reciprocal-aperture concavity and its existing normalization and derivative premises                                                                              |
| WP2         | K equals 2 gap gluing and the hybrid record; M51 has K equals 2 even scope                                                                                        |
| WP3         | Strict-even true-ground to shifted-ray adapter; broader PAPER branch results do not imply compiled wrappers                                                       |
| WP4         | D2 equals Full: both K equals 3 parity bottoms strictly positive on the entire interval from 1/512 to log 16, with the established small-aperture result below it |
| WP5         | Prescribed modified-prime K equals 2 crossing certificate; the later K equals 3 Q14 weight-parameter control does not replace it                                  |
| WP6         | Signed-correlation investigation with its required controls and precise disposition                                                                               |
| WP7         | Integration, exact-head checks, graph and registry consistency, and post-green mathematical assessment after separately authorized implementation                 |

The full WP4 statement is

$$\forall p \in \{ even,odd\}\mspace{6mu}\forall L \in \left\lbrack 1/512,\log 16 \right\rbrack,\quad parityRayleighBottom(p,L,3) > 0.$$

It requires continuous coverage, complete normalization, both parity
carriers and all relevant seams. The earlier prescribed feasibility gate
and stopping rules remain in force. This document does not substitute a
frozen-point certificate or a new finite sample for that decision.

# 14 Required output of the subsequent solution design stage

The next stage must propose a construction against this specification.
Its deliverable should contain the selected terminal contract, the
smallest required theorem set, exact candidate statements, available
inputs, open lemmas, quantitative target bounds and first decisive
falsification tests. It should identify which existing results it reuses
and which optional representations it bypasses.

Before an approach is presented as a solution, it must explain which
independent input defeats the matched negative controls, why the result
constrains the actual witness, and how its quantifiers cover the chosen
terminal contract. It may conclude that a proposed construction fails.
That is useful if the failure is exact and preserves the strongest valid
partial result.

The requirements are now concrete: preserve a valid mathematical
composition, establish a sufficient independent exclusion result, and
prove the full required coverage. No specific inequality, kernel, flow,
arithmetic estimate or compatibility invariant is presumed to exist
merely because the requirements name the role it would have to fill.

# 15 Source register

Repository links below are pinned to the unchanged merged main commit.
The research baseline is the delivered RH Research Continuation Paper
First archive of 11 October 2026, SHA256
`677a13bc80e6a564d0fd784405005745bfb007f1abb59b9ffa8ac0ffb0dac94c`. Its
PAPER and certificate claims retain that packet’s authority boundaries.

## Repository sources

- **S1** [Merged main
  commit](https://github.com/HMarcusWH/zeta-23-lean/commit/ecc6450f28eb6aed944bda8fe9a09296d033fc3e).
  Live branch refresh and retained exact-head authority record.
- **S2**
  [GlobalParityBottomResidualState](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/GlobalParityBottomResidualState.lean).
  Exact branch and retained-state types.
- **S3**
  [GlobalParityBottomGroundTrial](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/GlobalParityBottomGroundTrial.lean).
  groundTrial, nonzero and compressed eigenmode, exact energy.
- **S4**
  [FirstBadSpectralInterfaces](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/FirstBadSpectralInterfaces.lean)
  and
  [WholeCellBiRegularCanonicalEnergy](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/WholeCellBiRegularCanonicalEnergy.lean).
  Predecessors and whole-cell provenance.
- **S5**
  [ConstrainedParityGeometry](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/ConstrainedParityGeometry.lean)
  and
  [ParityBadness](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/ParityBadness.lean).
  Legal carriers and badness.
- **S6**
  [GlobalParityBottomPrimeRemainder](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/GlobalParityBottomPrimeRemainder.lean)
  and
  [GlobalParityBottomPrimeWeight](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/GlobalParityBottomPrimeWeight.lean).
  groundTrial_primeRemainder_plus_budget_pos and same-ground weight.
- **S7**
  [CanonicalPrimeRemainder](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/CanonicalPrimeRemainder.lean).
  Weighted remainder, complete budget and sign convention.
- **S8**
  [GlobalParityBottomArithmeticEquivalenceAudit](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/ExceptionalZero/GlobalParityBottomArithmeticEquivalenceAudit.lean).
  GlobalBottomResidualExclusion and its equivalence to RH.
- **S9**
  [GlobalParityBottomGeneratedState](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/ExceptionalZero/GlobalParityBottomGeneratedState.lean).
  Arbitrarily large residual generation.
- **S10**
  [ApertureFreedom](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/ExceptionalZero/ApertureFreedom.lean).
  eventually_all_apertures_have_anyParityBad_of_offLine_zero.
- **S11**
  [CanonicalRegularizedEnergyIdentity](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/CanonicalRegularizedEnergyIdentity.lean)
  and
  [SourceNormalizationRepair](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/SourceNormalizationRepair.lean).
  Existing exact finite normalization.
- **S12**
  [BoundaryFlatFiniteSpace](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/BoundaryFlatFiniteSpace.lean).
  Global C2 boundary-flat extension.
- **S13**
  [CanonicalShiftedSecular](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/CanonicalShiftedSecular.lean).
  Shifted criterion and eigenvector identity.
- **S14**
  [GlobalParityBottomBranchPackage](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/GlobalParityBottomBranchPackage.lean).
  Actual branch fields and strict-odd existential ground.
- **S15**
  [GlobalParityFirstNegativeBoundary](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/GlobalParityFirstNegativeBoundary.lean).
  Fixed-cutoff boundary, prefix and outgoing negativity.
- **S16**
  [CanonicalGlobalF04](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/CanonicalGlobalF04.lean).
  productionContactF04DerivativeAuthority_of_pos and its even target.
- **S17**
  [CanonicalGroundContinuity](https://github.com/HMarcusWH/zeta-23-lean/blob/ecc6450f28eb6aed944bda8fe9a09296d033fc3e/Zeta23/CCM/CanonicalGroundContinuity.lean).
  Fixed-cutoff matrix and ground continuity.

## Prior research and programme sources

- **R1** Research continuation RESEARCH_CONCLUSION,
  AUDIT_AND_VERIFICATION, formal_state_refresh and formal_job_authority,
  11 October 2026.
- **R2** T1_analytic_transfer and independent review in that packet. The
  digamma identity uses [NIST DLMF
  5.9.16](https://dlmf.nist.gov/5.9#E16).
- **R3** Track_A_true_ground, Track_A_independent_review and exact
  rational controls in that packet.
- **R4** Track_B_propagation, its independent review, support
  certificate, and Aperture_stability with independent review.
- **R5** Track_C_finite_index and its independent review, including
  exact Schur-domain analysis.
- **R6** q14_weight_interval, signed_secular_residue_interval and
  historical_controls_replay programs and exact receipts in that packet;
  TURTLE_RESIDUAL_LEDGER.
- **R7** RH Research Master version 2.3, including
  POST287_NEXT_THREAD_PLAN_ORIGINAL_INPUT of 11 October 2026, Sections
  WP0–WP7; explicit D2 equals Full decision at 14:21 UTC. Later PAPER
  results update authority without altering that decision.

## External primary sources

- **E1** Masatoshi Suzuki, [Weil’s quadratic form via the screw
  function](https://arxiv.org/html/2606.09096v3), version 3, 23
  September 2026, Theorems 1.1 and 1.3–1.5, and Corollaries 1.2 and 1.6.
  Full HTML reviewed for the stated import boundaries.
- **E2** Alain Connes and Walter van Suijlekom, [Quadratic Forms Real
  Zeros and Echoes of the Spectral
  Action](https://arxiv.org/html/2511.23257v1), precise Theorem 6.1 and
  Remark 4.3, alongside the introductory Theorem 1.2.
- **E3** Alain Connes, Caterina Consani and Henri Moscovici, [Zeta
  Spectral Triples](https://arxiv.org/html/2511.22755v1), Theorem 5.10
  and final programme discussion.
- **E4** Alain Connes, [The Riemann Hypothesis Past Present and a Letter
  Through Time](https://arxiv.org/abs/2602.04022), 2026. Survey and
  spectral-limit context.
- **E5** Xuefeng Zhu, [Weil positivity in compact windows a finite
  reduction certified two sided bounds and a Landau Widom decay
  law](https://arxiv.org/html/2608.24827v2), version 2, Theorem 1.2,
  Corollary 6.3 and Sections 7, 13 and 14. Full primary HTML confirmed;
  no complete certificate replay in this specification task.
- **E6** Vincent Liu, Certified Weil Positivity Beyond the Unit Window,
  supplied manuscript and [author
  dissemination](https://www.alphaxiv.org/abs/2609.weil-positivity-riemann-zeta-bounds);
  [frozen reproduction
  instructions](https://github.com/luciferyu666/certified-weil-positivity/blob/b6cd2183c1e79c6c27a34267812a7b2d73ed1b59/REPRODUCIBILITY.md).
  Detailed scope comes from the manuscript and frozen instructions, not
  the page’s generated overview.
- **E7** Akiva Groskin, [A finite Guinand Weil dictionary and
  archimedean tail order for the truncated Weil quadratic
  form](https://arxiv.org/abs/2607.02828v3), supplied version 3; [author
  source
  repository](https://github.com/akivag613/connes-cvs-/tree/9881eeb02ceb9f7c94e65c0eaaa2a3e81e3e7aaf/papers/2_guinand_weil_dictionary_tail_order).
- **E8** Akiva Groskin, [A matrix valued von Mangoldt measure in the
  finite Connes van Suijlekom
  path](https://github.com/akivag613/connes-cvs-/tree/9881eeb02ceb9f7c94e65c0eaaa2a3e81e3e7aaf/papers/3_matrix_von_mangoldt_measure),
  corrected version 2. README corrections and theorem-sensitive source
  passages inspected.
- **E9** Akiva Groskin, [Bulk trace laws and algebraic boundary
  interaction for the sine Loewner
  operator](https://github.com/akivag613/connes-cvs-/tree/9881eeb02ceb9f7c94e65c0eaaa2a3e81e3e7aaf/papers/4_sine_loewner_bulk_boundary),
  September 2026. Introduction, scope, further questions and
  reproduction description inspected; full proof audit remains outside
  this specification.
- **E10** Daniel R. Johnston and Andrew Yang, [Some explicit estimates
  for the error term in the prime number
  theorem](https://arxiv.org/html/2204.01980v2), Theorem 1.1.
- **E11** Andrew Fiori and Mikko Jaskari, [Explicit bounds for the prime
  number theorem](https://arxiv.org/html/2609.23222v1), Theorem 1.1,
  September 2026. No independent numerical-table replay claimed.
- **E12** Chiara Bellotti, Tim Trudgian and Andrew Yang, [Zero free
  regions inspired by work of Heath
  Brown](https://arxiv.org/html/2603.21490v1), Theorem 1. The exact
  theorem-body inequality controls any boundary use.
- **E13** Larry Guth and James Maynard, [New large value estimates for
  Dirichlet
  polynomials](https://annals.math.princeton.edu/2026/203-2/p06), Annals
  of Mathematics 203, 2026, 623–675; [full
  preprint](https://arxiv.org/html/2405.20552v2).
- **E14** Youness Lamzouri, [A new proof that more than two thirds of
  the zeros of the Riemann zeta function are simple and on the critical
  line](https://arxiv.org/html/2609.02882v2), September 2026.
- **E15** Masatoshi Suzuki, [Aspects of the screw function corresponding
  to the Riemann zeta function](https://arxiv.org/pdf/2206.03682),
  Section 3.2; Journal of the London Mathematical Society, DOI
  10.1112/jlms.12785.
- **E16** Xian-Jin Li, [The positivity of a sequence of numbers and the
  Riemann
  hypothesis](https://www.sciencedirect.com/science/article/pii/S0022314X97921375),
  1997; Enrico Bombieri and Jeffrey Lagarias, [Complements to Li’s
  criterion for the Riemann
  hypothesis](https://www.sciencedirect.com/science/article/pii/S0022314X99923922), 1999.
  Publisher abstracts and available author source used for criterion
  scope.
- **E17** Luis Báez-Duarte, [A strengthening of the Nyman Beurling
  criterion for the Riemann
  hypothesis](https://arxiv.org/pdf/math/0202141), Theorem 1.1.
- **E18** Masatoshi Suzuki, [A canonical system of differential
  equations arising from the Riemann zeta
  function](https://arxiv.org/abs/1204.1827), with its stated
  unconditional parameter range.
- **E19** Masatoshi Suzuki, [On the Hilbert space derived from the Weil
  distribution](https://arxiv.org/abs/2301.00421), with explicit RH
  assumptions on the global construction.
- **E20** Michael Griffin, Ken Ono, Larry Rolen and Don Zagier, [Jensen
  polynomials for the Riemann zeta function and other
  sequences](https://pmc.ncbi.nlm.nih.gov/articles/PMC6561287/), PNAS
  116, 2019, Theorems 1 and 2.
- **E21** Brad Rodgers and Terence Tao, [The de Bruijn Newman constant
  is nonnegative](https://arxiv.org/abs/1801.05914).
- **E22** David Platt and Tim Trudgian, [The Riemann hypothesis is true
  up to 3 times 10 to the 12](https://arxiv.org/abs/2004.09765),
  rigorous finite-height verification.

**Final specification status.** The mathematical requirements are
defined. The decisive Step 4 construction is OPEN. This document adds no
repository source, PR, merge, workflow run, or claim that an unproved
inequality has been established.
