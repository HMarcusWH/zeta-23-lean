# Detector/arithmetic constraint campaign: review receipt

Date: 13 October 2026. Status: **PAPER proofs and exact finite controls; no formalization or Step 4 closure.**

## Authored proof files

1. `01_POSITIVE_REFINEMENT_AND_PHASE_DEPTH.md`
2. `02_NATIVE_BIRTH_VARIANCE_AND_SCALE_LIMIT.md`
3. `03_SLOW_REFINEMENT_AND_THE_CLOSING_INEQUALITY.md`
4. `04_FIXED_ORIGINAL_PRECURSOR_AND_PROJECTED_FORCING.md`

The shared derivations use unchanged project-master and prior-campaign sources identified in each note. No source authority was silently changed from paper to Lean.

## Independent reviews received

- **Root and contact-provenance reviewers, Note 01:** the uniform splitting measure, total support \(2(r-s)\), variance constant, tilted normalization, complex-square phase, all finite histories, exact \(s^{-5}\) scale law, logarithmic normalized self-energy and phase/depth transfer passed independent review. The missing TeX backslash before `operatorname{law}` was fixed. The root phase theorem is cited as proved in the current paper campaign, rather than merely proposed.
- **Root, Note 02:** the actual first-prime martingale and its non-uniform-integrability conclusion were accepted as a source-specific obstruction independent of RH. The written result remains limited to that scale-limit inference; it does not rule out the later direct projected bridge.
- **Root, Note 03:** the Poisson prefactors, the \(u\in[0,1]\) history, the slow-scale exponent calculation, the frozen-source convention throughout the prefix and the original-source inequality passed independent audit. The final source-record wording was corrected so that the OPEN conditions (22)/(24) are not described as proved. The finite phase wording now distinguishes the original lobe sign and reflection parity from an exactly preserved cosine/sine transform factor.
- **Root and contact-provenance reviewers, Note 04:** the direct fixed-precursor arithmetic adapter, the norm-four compact test-space bridge, exact residual and forcing, common probe-width budget, uniform mixed-source constants and stable mask commutator passed independent review. The alternative fixed scale was explicitly restricted to \(0<s\le1/4096\), which justifies the no-negative-history statements. The original-witness inequality (15a) uses the independently proved source-transport direct-duality theorem.

The final elementary bound (23) in Note 04 is explicitly too weak to close the deep-witness contradiction. The known spectral shift and signed Schur diagonal remain in the record.

## Cross-reviews performed by this branch

- `source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md`: the positive \(\sin^6\) endpoint construction, uniform derivative/tail estimates, exact odd-padding cancellation, positive even precursor, pole neutrality, \(s^{-5}\) normalization, \(L^{13/2}s^{-j}\) errors, and variable-scale quartic bridge were checked independently. Its two-dimensional phase eigenspaces are correctly not identified with a full selected ground.
- `contact_provenance/01_DEEP_POLE_NEUTRAL_STATE_WITH_SPECTRAL_GAP.md`: the spectrum count \((K_d-2)(K_d-1)\), gap and \(6(M+1)/D\) inverse, pole-neutral zero-flip descent including the simple mandatory pair, five endpoint jets and KKT multiplier were checked independently.
- `contact_provenance/02_ACTUAL_DETECTOR_FORCING_IN_THE_SCHUR_IDENTITY.md`: the actual Schur forcing, full four-field prime response, known shift, exact finite approximation cost, and the distinction between \(F_k\) and \(F_h=k*F_k\) were checked. The single-zero integer-drive main term is correctly retained.
- `source_transport/04_DIRECT_POLE_NEUTRAL_FORCING_BRIDGE.md`: the compact inverse, exact projected duality, original witness bound, optional weighted finite-radius Neumann recovery, true finite-prime truncation and original Gevrey effective-band estimate were checked. The retained original \(q_s\) convolution makes its mixed arithmetic probe constants uniform as explained in Note 04 here.

## Executed controls

Command:

```text
python step4_constraint_campaign_2026-10-13/detector_arithmetic/verify_detector_refinement.py
```

Result: **PASS**, exit code 0.

The generated JSON records 165 moment checks, 111 refinement/seam checks, 15 variance checks, four normalization checks, eight martingale levels, six kernel factorization checks and six slow-scale exponent checks. Every algebraic comparison uses exact rational arithmetic. Floating values in the martingale table are display summaries after the exact comparisons, not proof tolerances.

These tests use finite uniform-product analogues of the detector to check the implementation of refinement, normalization and variance. They do not approximate the native infinite zero set or promote a finite check to a universal statement.

## Unclosed assertions

- Note 03, (22)/(24): the complete signed slow-family residual / native prime-pair upper bound.
- Note 04, (22): the complete signed fixed-original-precursor residual in all positive damping norms.
- The independent lower sign for the complete source-driven Schur energy, if that route is used instead of the direct original witness contradiction.

The adapters and discarded-sector estimates are proved. The assertions listed above remain OPEN. No RH proof, formal Lean change, repository write, or external publication was made in this branch.

## Freeze

All branch files are frozen for parent packaging after the accompanying `SHA256SUMS.txt` is generated. That manifest covers the proof notes, result ledger, this receipt, executable control and its JSON output. Earlier campaign and review artifacts remain unchanged.
