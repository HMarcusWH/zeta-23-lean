# A second detector recovers the actual finite projection

Date: 13 October 2026. Status: **new paper proof and closing attempt. The physical boundary error is controlled; the mixed-source signed arithmetic estimate remains open.**

This note tests the proposed second, smaller detector on the actual finite source equation. It proves a finite-band recovery inequality with an exact boundary remainder. The original pole constraints remove the long-range elementary inverse, and stronger endpoint jets make the remaining boundary error exponentially small. The same original two-lobe detector can be transported into that stronger carrier at the prescribed quartic cutoff.

The later Note 04, DIRECT_POLE_NEUTRAL_FORCING_BRIDGE, gives the shorter central source transfer without a tiny probe. The present theorem remains an independent quantitative boundary result. Section 8 incorporates the later fixed-precursor arithmetic improvement, so a cost from discarding the original smoothing is not presented as an unavoidable obstruction.

## 1. Setting and the second sensor

Let \(I=[0,L]\), \(K\ge1\), \(\Omega=2\pi K/L\), and let \(E_{L,K}\) be the \(L\)-periodic trigonometric polynomials with \(|n|\le K\), restricted to \(I\). They are not declared periodic as physical sources: physical sources below are extended by zero outside \(I\).

For \(m\ge2\), let \(\mathcal S_{L,K,m}\) be any subspace of \(E_{L,K}\) whose members \(\phi\) have

\[
\phi^{(j)}(0)=\phi^{(j)}(L)=0\quad(0\le j\le m),\qquad
\int_I\phi(x)e^{x/2}\,dx=\int_I\phi(x)e^{-x/2}\,dx=0.
\tag{1.1}
\]

Parity restrictions can be imposed as well. Let \(q_\delta\) be the actual sinc-product probability density, and \(k_\delta=(\partial^2-1/4)q_\delta\), at a second scale \(\delta>0\). Assume

\[
0<\theta:=\delta\Omega\le1/2,\qquad \delta<L/2.
\tag{1.2}
\]

Since \(q_\delta\) is a probability density supported in \([-\delta,\delta]\), its Fourier transform satisfies

\[
P_\delta(\xi)=\int q_\delta(x)\cos(\xi x)\,dx
\ge\cos\theta>0,\qquad |\xi|\le\Omega .
\tag{1.3}
\]

Thus the finite-band inverse of the periodic convolution multiplier
\(\widehat k_\delta(\xi)=-(\xi^2+1/4)P_\delta(\xi)\) has \(L^2(I)\) norm at most \(4\sec\theta\). This elementary lower bound avoids every real source zero on the band. It does not invert the sensor on all real frequencies.

## 2. Pole neutrality makes the first inverse compact

For \(\phi\in\mathcal S_{L,K,m}\), solve \(Pg=\phi\) in the periodic finite band, where \(P=\partial^2-1/4\):

\[
g_n=-\frac{\phi_n}{(2\pi n/L)^2+1/4}.
\tag{2.1}
\]

Integration by parts, using periodicity of \(g,g'\), gives

\[
\int_I\phi(x)e^{x/2}\,dx
=(e^{L/2}-1)[g'(0)-g(0)/2],
\tag{2.2}
\]

\[
\int_I\phi(x)e^{-x/2}\,dx
=(e^{-L/2}-1)[g'(0)+g(0)/2].
\tag{2.3}
\]

Both moments vanish, so \(g(0)=g'(0)=0\), and the same holds at \(L\). The differential equation and the jets of \(\phi\) then give

\[
g^{(j)}(0)=g^{(j)}(L)=0\qquad(0\le j\le m+2).
\tag{2.4}
\]

Consequently the zero extension of \(g\) is exactly the compact inverse \(P^{-1}\phi\). No exponential homogeneous solution or omitted endpoint distribution is needed.

Define the finite-band periodic polynomial

\[
v_n=\frac{g_n}{P_\delta(2\pi n/L)}.
\tag{2.5}
\]

It satisfies the periodic identity \(k_\delta*_{\rm per}v=\phi\) and

\[
\|v\|_{L^2(I)}\le4\sec\theta\,\|\phi\|_{L^2(I)}.
\tag{2.6}
\]

The physical zero extension \(v_I\) need not have zero endpoint traces. The next section keeps those traces exactly.

## 3. Uniform endpoint estimate for the inverse

Put \(A_K=\sqrt{(2K+1)/L}\). Fourier Cauchy–Schwarz gives

\[
\|\phi^{(j)}\|_\infty\le A_K\Omega^j\|\phi\|_2,\qquad
\|g^{(j)}\|_\infty\le A_K\Omega^{j-2}\|\phi\|_2\quad(j\ge2).
\tag{3.1}
\]

The reciprocal of the fixed unit-scale source is analytic in \(|z|\le1\). Indeed, positivity, evenness and support in \([-1,1]\) give

\[
|P_1(z)-1|\le\cosh|z|-1\le\cosh1-1<1 .
\tag{3.2}
\]

Write

\[
\frac1{P_1(z)}=\sum_{j\ge0}b_jz^{2j},\qquad
|b_j|\le M_0:=\frac1{2-\cosh1}.
\tag{3.3}
\]

The coefficient bound is Cauchy's inequality on the unit circle. On the finite band this yields uniformly convergent series

\[
v=\sum_{j\ge0}b_j(-1)^j\delta^{2j}g^{(2j)},\qquad
w:=Pv=\sum_{j\ge0}b_j(-1)^j\delta^{2j}\phi^{(2j)}.
\tag{3.4}
\]

Using (2.4) in the first series and (3.1) for its remaining terms gives

\[
|v(0)|=|v(L)|
\le C A_K\Omega^{-2}\theta^{m+3}\|\phi\|_2,
\tag{3.5}
\]

\[
|v'(0)|=|v'(L)|
\le C A_K\Omega^{-1}\theta^{m+2}\|\phi\|_2.
\tag{3.6}
\]

Here and below \(C\) is independent of \(m,L,K,\delta\). The first surviving even derivative can have order larger than the displayed minimum; replacing its exponent by the minimum gives the stated upper bound because \(\theta<1\).

For \(|x|\le\delta\), interpreted periodically around either endpoint, the vanished jets of \(\phi\) imply, for \(2j\le m\),

\[
|\phi^{(2j)}(x)|
\le
\frac{A_K\Omega^{m+1}|x|^{m+1-2j}}
 {(m+1-2j)!}\|\phi\|_2.
\tag{3.7}
\]

Insert this into the second series of (3.4). The sum of the reciprocal factorials is at most \(e\); the remaining geometric series is bounded using \(\theta\le1/2\). Thus

\[
\sup_{\operatorname{dist}(x,L\mathbb Z)\le\delta}|w(x)|
\le C A_K\theta^{m+1}\|\phi\|_2.
\tag{3.8}
\]

This uniformity in \(m\) is essential. It permits a number of endpoint constraints proportional to \(L\).

## 4. Exact physical error, with every endpoint distribution

Define

\[
e_{\delta,\phi}=k_\delta*v_I-\phi_I,
\qquad
E_\delta=[-\delta,\delta]\cup[L-\delta,L+\delta].
\tag{4.1}
\]

The periodic identity is exact away from the two collars, so \(\operatorname{supp}e_{\delta,\phi}\subset E_\delta\).
Distributional differentiation of the physical zero extension gives exactly

\[
P(v_I)=w_I+
v'(0)(\delta_0-\delta_L)+
v(0)(\delta'_0-\delta'_L).
\tag{4.2}
\]

There is no omission of the \(\delta'\) term. Therefore

\[
e_{\delta,\phi}
=q_\delta*w_I-\phi_I
+v'(0)[q_\delta(\,\cdot\,)-q_\delta(\,\cdot-L)]
+v(0)[q'_\delta(\,\cdot\,)-q'_\delta(\,\cdot-L)].
\tag{4.3}
\]

For an interior collar point, the first difference is exactly the missing wrapped portion of the periodic convolution; that missing portion samples \(w\) only within distance \(\delta\) of an endpoint. For an exterior collar point, \(q_\delta*w_I\) likewise samples \(w\) only within distance \(\delta\) of the nearer endpoint. Thus, since \(q_\delta\) is a probability kernel, (3.8) bounds the first difference by \(C A_K\theta^{m+1}\|\phi\|_2\). No bound on a \(2\delta\)-neighborhood is silently substituted. For the remaining terms, use
\(\|q_\delta\|_\infty=\delta^{-1}\|q_1\|_\infty\),
\(\|q'_\delta\|_\infty=\delta^{-2}\|q_1'\|_\infty\),
(3.5)–(3.6), and \(\delta\Omega=\theta\). Each has the same upper bound. Since the total collar length is \(4\delta\),

\[
\boxed{\;
\|e_{\delta,\phi}\|_{L^2(\mathbb R)}
\le C\theta^{m+3/2}\|\phi\|_2 .
\;}
\tag{4.4}
\]

Indeed \(\sqrt\delta A_K\le\sqrt{3\theta/(2\pi)}\) for \(K\ge1\). This proves a genuine physical-versus-periodic comparison. Ordinary legal jets \(m=2\) give the factor \(\theta^{7/2}\); stronger jets improve it exponentially in \(m\).

## 5. Recovery of the actual finite projection

Let \(F\) be any locally \(L^2\) field on \([-\delta,L+\delta]\). Evenness of the real kernel and compact support justify the exact pairing identity

\[
\langle F,\phi_I\rangle
=\langle k_\delta*F,v_I\rangle
-\langle F,e_{\delta,\phi}\rangle.
\tag{5.1}
\]

All integrations use only the indicated finite interval and collars. Global periodicity or a periodization of the growing native field is not assumed.
Taking the supremum over unit \(\phi\in\mathcal S_{L,K,m}\) yields

\[
\boxed{\;
\|\Pi_{\mathcal S}(F|_I)\|_2
\le4\sec\theta\,\|k_\delta*F\|_{L^2(I)}
+C\theta^{m+3/2}\|F\|_{L^2(E_\delta)} .
\;}
\tag{5.2}
\]

This is the promised finite-band sensor inequality. The exact collar field remains present until it is estimated. Endpoint jets of a source do not imply endpoint jets of the nonlocal native response.

For the actual single-\(k_s\) prime field

\[
F_{k_s}(t)=\sum_{n\ge2}\Lambda(n)n^{-1/2}k_s(t-\log n),
\tag{5.3}
\]

the elementary bound \(\Lambda(n)\le\log n\), support of \(k_s\), and fixed-source smoothness give
\(|F_{k_s}(t)|\le C_s(1+t)e^{t/2}\) for \(t\ge0\), after adjusting \(C_s\) on a compact initial interval. The translated and reflected fields in the actual detector forcing have arguments at most \(L+O_s(1)\) on the relevant collars. Hence their total collar norm has an upper bound \(C_s\operatorname{poly}(L)e^{L/2}\).

Fix \(0<\theta_0\le1/2\) and take
\(m(L)\ge\kappa L\), with

\[
\kappa|\log\theta_0|>\frac12+\eta .
\tag{5.4}
\]

Then for \(\theta\le\theta_0\), the second term in (5.2) is
\(C_s\operatorname{poly}(L)e^{-\eta L}\).
This uses only the crude native field bound, without a new cancellation assumption. The same estimate applies term by term to the exact translated/reflected forcing recorded in the contact-provenance note. Its explicitly controlled archimedean term is added separately.

## 6. The original positive detector fits the stronger carrier

The positive endpoint construction in Note 01 has a uniform extension. At a fixed original source scale \(s>0\), replace \(\sin^6(\pi x/L)\) by

\[
B_{L,M}(x)=\sin^{2M}(\pi x/L),\qquad
M=\left\lceil\frac{m+3}{2}\right\rceil,\qquad
N=K(L)-M.
\tag{6.1}
\]

The corrected seed has jets \(0,\ldots,2M-1\) zero; after applying \(P\), the source has jets \(0,\ldots,2M-3\) zero, including every requested jet through \(m\).

The disk estimate on the unit collars is now

\[
|(B_{L,M}^{-1})^{(j)}(x)|
\le(2L/3)^{2M}4^j j!.
\tag{6.2}
\]

The Gevrey optimization consequently retains a decay constant independent of \(M\); the extra prefactor is \(L^{2M}\). Also the Fourier coefficients of \(B_{L,M}\) have absolute sum one, so

\[
\|B_{L,M}^{(j)}\|_\infty\le(2\pi M/L)^j.
\tag{6.3}
\]

For \(M=O(L)\), its \(H^2\) and \(H^3\) multiplication constants are uniformly bounded, with a constant depending only on the fixed ratio bound. Repeating the same positive padding, exact reflected combination and normalization therefore gives

\[
\|u_{\sigma,N}-f_\sigma\|_{H^1}
\le C_s L^{2M+1/2}
\exp[-c_s\sqrt{N/L}],
\tag{6.4}
\]

with a changed fixed-source constant. A harmless fixed power of \(L\) could also be included without changing the conclusion.

At \(K(L)=\lceil L^4\rceil\) and \(m=\lceil\kappa L\rceil\), the logarithm of this error, and of its native form cost, is

\[
O_\kappa(L\log L)+\frac L2-c_sL^{3/2}\longrightarrow-\infty .
\tag{6.5}
\]

Thus the exact fixed original detector has a legal high-jet approximation at the same prescribed quartic cutoff, with both phases, exact pole moments, nonnegative even precursor and negative-depth receipt retained. This extension uses fixed \(s\). It does not import the linear-in-\(L\) jet count into the \(s\asymp A/L\) estimate, whose Fourier margin is only exponential in \(L\).

The stronger carrier may now be used in a separate deep-threshold selection. Its projected Euler equation must retain the additional endpoint-constraint multipliers. No high-jet condition is assigned to a ground selected in a different carrier.

## 7. Reaching the actual double-\(k\) arithmetic sensor

Choose the probe scale as a dyadic descendant \(\delta=s/2^J\) with
\(\theta_0/2<\delta\Omega\le\theta_0\). Then \(\delta\asymp L/K\), and the exact positive refinement identity is

\[
q_s=q_\delta*\nu_{s,\delta},\qquad
k_s=k_\delta*\nu_{s,\delta},\qquad
\nu_{s,\delta}\ge0,\quad \nu_{s,\delta}(\mathbb R)=1.
\tag{7.1}
\]

Write \(\Pi=\sum_{n\ge2}\Lambda(n)n^{-1/2}\delta_{\log n}\),
\(h_\delta=k_\delta*k_\delta\), and
\(F_{h_\delta}=\Pi*h_\delta\). Exactly,

\[
k_\delta*F_{k_s}
=\Pi*k_\delta*k_s
=F_{h_\delta}*\nu_{s,\delta}.
\tag{7.2}
\]

This reaches the arithmetic branch's actual double-\(k_\delta\) field by applying only one additional sensor to the existing single-\(k_s\) source. Only the two original simple pole moments were inverted in Sections 2–4; no unsupported double-pole constraint on the test vector is required.

The probability measure in (7.1) is bilateral, supported in
\([-(s-\delta),s-\delta]\). Norm comparisons therefore retain that bounded anticipation and the initial history. Unweighted Young bounds apply on the enlarged observation interval. Under damping \(\epsilon>0\), its conjugated total variation is at most \(e^{\epsilon(s-\delta)}\), a fixed-source constant. The exact translations and reflections of the original forcing must likewise remain in the observation intervals.

For the quartic cutoff, the new scale is of order \(L^{-3}\). Combining (5.2), (5.4) and (7.2) gives a concrete route from the **actual arithmetic double-\(k\) response** to the **actual constrained finite projection**, up to a proved exponentially small boundary error and the already recorded finite source approximation error.

## 8. Final closing attempt and exact remaining obligation

The complete attempt is now explicit. Retain a fixed original source and its phase; construct its high-jet finite trial; select the deep pole-neutral state in that same stronger carrier; retain its actual Schur forcing; apply (5.2) to the translated single-\(k_s\) prime fields; and identify the measured fields by (7.2).

The measured field must retain the original source smoothing. In fact, even without a dyadic relation, its exact kernel is

\[
k_\delta*F_{k_s}=\Pi*j_{s,\delta},
\qquad j_{s,\delta}=P^2(q_s*q_\delta).
\tag{8.1}
\]

The new arithmetic mixed-source observation is decisive for the bookkeeping: since \(q_\delta\) is a positive probability kernel,

\[
\|j_{s,\delta}^{(j)}\|_1
\le\|(P^2q_s)^{(j)}\|_1
\quad(j\ge0).
\tag{8.2}
\]

For the fixed original \(s\), its Gevrey constants are therefore uniform in the tiny probe scale, and its support is uniformly bounded. The double pole moments are exact. The compensated integer-drive estimate, mask and controlled rough-core sector can consequently be proved with constants depending on the original \(s\), rather than deteriorating as \(\delta^{-1}\). This is developed in the arithmetic branch's uniform mixed-source reduction.

If one instead bounded \(F_{h_\delta}\) separately and discarded the retained convolution in (7.2), the older standalone estimate would produce a cofactor budget of order \(L^5\log L\) and fail to give every-small-damping control through that particular absolute Rankin bound. That is an avoidable loss of source information, not a limitation of the exact mixed field (8.1).

The remaining input is a bound on the full signed residual for the actual mixed kernel (8.1), on the correct observation intervals and with constants strong enough for the intended conclusion. Its controlled sectors and the boundary error do not supply that signed bound.

Moreover, Note 04 gives an even shorter source-specific route: the compact inverse \(P^{-1}\) transfers the projection directly to \(\Pi*P^2q_s\), with no tiny probe. The finite-band theorem here remains an independent quantitative recovery result, but is not asserted to be necessary for the final source bridge.

### Source and review record

- Note 01 in this directory: actual universal detector, exact finite carrier, positive endpoint correction and native approximation bound.
- The original sinc source and dyadic refinement: detector_arithmetic/01_POSITIVE_REFINEMENT_AND_PHASE_DEPTH.md.
- The actual finite forcing with its four translated/reflected prime fields: contact_provenance/02_ACTUAL_DETECTOR_FORCING_IN_THE_SCHUR_IDENTITY.md.
- The scale-dependent Poisson remainder, rough-core estimate and slow-scale scope: detector_arithmetic/03_SLOW_REFINEMENT_AND_THE_CLOSING_INEQUALITY.md, Sections 1–3.
- The fixed-precursor uniform mixed-source improvement: detector_arithmetic/04_FIXED_ORIGINAL_PRECURSOR_AND_PROJECTED_FORCING.md.
- The high-jet carrier selection is a separate construction in the contact-provenance branch; this note proves the original trial and sensor adapter it requires.

All finite-band, endpoint, physical-pairing and high-jet transport estimates above are paper arguments. No new compiled theorem or unconditional Step 4 conclusion is claimed.
