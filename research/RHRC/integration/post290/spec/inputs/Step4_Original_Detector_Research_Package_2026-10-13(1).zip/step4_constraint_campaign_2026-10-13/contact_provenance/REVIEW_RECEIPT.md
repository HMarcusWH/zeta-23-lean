# Contact provenance: final proof and review receipt

Date: 13 October 2026. **Frozen paper record. Step 4 remains open. No new Lean theorem or build claim.**

## New results in this branch

1. `01_DEEP_POLE_NEUTRAL_STATE_WITH_SPECTRAL_GAP.md` retains the original detector as an explicit second witness and chooses a negative spectral threshold comparable to its actual depth. A longest-gap argument over all earlier pole-neutral spectra proves the predecessor inverse bound `6(M+1)/D`, rather than assuming a spectral gap. Both parity predecessors and the actual negative eigenvalue are retained.
2. The same note proves pole-neutral zero-flip descent. The selected source has only the mandatory simple nonreal pair; its same-cutoff compact potential, five endpoint jets, pole multipliers and Galerkin residual remain in the record. This is a new constrained finite state, not a stronger assertion about the repository's old zero-threshold state.
3. `02_ACTUAL_DETECTOR_FORCING_IN_THE_SCHUR_IDENTITY.md` writes the original detector's exact projected forcing in the Schur identity. It retains all four translated/reflected prime fields, the original phase, the Archimedean term, the spectral shift and the actual finite approximation error. Both elementary pole channels vanish exactly. The bound `eta<D/2<=|Q(p)|/2<=poly(L) exp(L/2)` explicitly pays the `eta ||e||` approximation term.
4. The same note records the direct compact-potential adapter. For every pole-neutral test `phi=Pg`, both endpoint traces of `g` vanish, `||g||_2<=4||phi||_2`, and `⟨F_k,phi⟩=⟨P F_k,g⟩` on the identical interval. Thus the actual forcing reaches the arithmetic source `P²q` without a fine detector, an endpoint loss or an inverse of convolution by `k`. The original phase and all four histories survive.
5. `03_HIGH_JET_DEEP_STATE_AND_DIRECT_SOURCE_BRIDGE.md` proves the optional stronger carrier extension. Its exact parity dimensions are `max(0,K-floor(m/2)-1)` and `max(0,K-ceil(m/2)-1)`; the total spectral count is the sum of their triangular numbers. The depth/gap and zero-flip proofs survive all `m` endpoint constraints. The compact potential has jets through `m+2`, and the extra finite KKT moment multipliers are explicit. The fixed-source positive finite bridge pays `m~kappa L` at `K=ceil(L^4)`. The note does not apply that cost to the separate `s~A/L` regime.

## Source hierarchy

The universal sinc-product finite bridge is the **new** proof in `source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md`. Its fixed-source high-jet extension is in source-transport Note 03. The exact positive refinement and depth bookkeeping are in `detector_arithmetic/01_POSITIVE_REFINEMENT_AND_PHASE_DEPTH.md`. The old v2.9 source supplied the Fourier/growing-form mechanism for a separately constructed Gevrey bump; it is not cited as already proving the universal detector's complete finite bridge.

Inherited zero-flip and native source identities are identified by their exact unchanged source paths in contact Note 01. New finite selection, compact-potential adapters and arithmetic compositions are labeled paper derivations. The original trial, repaired finite trial and selected ground are distinct vectors throughout. Positivity of the original even potential is never assigned to a selected ground without a proof.

## Independent reviews completed

| Source | Review result and scope |
|---|---|
| `root/01_TWO_SIDED_PHASE_AND_POLE_NEUTRAL_SOURCE.md` | Passed the positive-Laplace proof, both signed detector types, nonzero residues, original phase factors, compact kernel `-exp(-|x|/2)`, and constrained full weak equation with both pole multipliers. |
| `root/02_DIRECT_SAME_SOURCE_NATIVE_LOOP.md` | Passed the same-source history identity, source quotient, native-loop equivalence and corrected gamma-free prime response. Independently verified the sharper mandatory-pair contraction threshold `h>=1/sqrt(2)` and its sharp small-radius counterexamples below that threshold. Eligibility of original sources and selected neutral grounds is kept distinct from arbitrary finite approximants. |
| `detector_arithmetic/01_POSITIVE_REFINEMENT_AND_PHASE_DEPTH.md` | Passed support and exact probability laws, complex transfer factor, damped mass and variance, complete finite histories, normalized scale cost, logarithmic self-energy, and same-sign depth extraction. |
| `detector_arithmetic/03_SLOW_REFINEMENT_AND_THE_CLOSING_INEQUALITY.md` | Passed the uniform Poisson prefactor and exponent, `B_s=B_0/s`, complete prefix split, frozen scale quantifiers, exponent inequalities, original-source estimate, and equivalence with the complete signed off-diagonal energy up to controlled diagonal/sectors. The sufficient closing bound remains explicitly open. |
| `detector_arithmetic/04_FIXED_ORIGINAL_PRECURSOR_AND_PROJECTED_FORCING.md` | Passed the actual `P²q_s` source, compact test-space map, four-field coefficient, retained shift, source-specific projected error, fixed-source drive/mask/core bounds, explicit full signed residual, and uniform optional probe commutator. The stated absence of negative initial history is checked at the actual small scale `s=1/4096` and descendants. |
| `source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md` | Passed source-specific Gevrey bounds, positive endpoint division and padding, exact pole moments, phase/reflection preservation, normalization and full growing-form budget. No real-zero classification is inferred for its finite approximation. |
| `source_transport/03_FINITE_BAND_SENSOR_WITH_EXACT_BOUNDARY_REMAINDER.md` | Passed Sections 2–6: same-band compact potential, uniform reciprocal coefficients, exact endpoint delta/delta-prime distributions, collar support, uniform `theta^(m+3/2)` error and fixed-source high-jet approximation. The simpler direct adapter makes this sensor optional for the original forcing. |
| `source_transport/04_DIRECT_POLE_NEUTRAL_FORCING_BRIDGE.md` | Passed direct duality on the full codimension-two test space, all four original forcing terms, original-witness energy bound, exact `h_s=q_s*P²q_s` reconstruction, positive compact inverse, local/weighted norms, exact physical truncation and effective-band residual estimate. The signed arithmetic bound is not supplied by these adapters. |
| `PAPER_OVERVIEW.md` | Passed the hierarchy of claims, source distinctions, same-source composition, quantitative inverse statement, two separate sufficient closing routes, and explicit open status. |

The arithmetic branch independently reviewed contact Notes 01–02 and confirmed the spectral count, inverse factor, pole-neutral flip including the mandatory pair, compact primitive, KKT residual and Schur forcing formulas. The root independently reviewed their direct forcing and integer-drive signs. The contact branch separately checked the new high-jet dimensions and zero-flip extension, rather than inferring them from notation alone.

## Exact finite controls

Final command:

```text
python3 contact_provenance/verify_deep_state_exact.py
```

Final result: **214 checks PASS; five mutation falsifiers rejected.** The machine-readable output is `DEEP_STATE_EXACT_CONTROLS.json`.

The controls use only Python's standard library and exact rational/Gaussian-rational arithmetic. They check spectral-gap selection, repeated and endpoint spectra, spectral counts, a retained-depth nested model, exact zero flips, mandatory pole multiplicity, shell cancellation, compact-potential moments, complex Schur completion, constrained KKT residuals, the paired-pole polynomial, and high-jet carrier ranks and seed jets. The high-jet dimensions are checked independently by exact row reduction of the actual moment and pole constraints.

The five rejected shortcuts are: transferring depth from a zero-threshold state, flipping a simple mandatory pole while claiming pole neutrality, dropping the actual detector response from Schur energy, replacing a constrained ground by an unrestricted eigenvector, and asserting pair contraction at `h=3/5`. These are finite algebra controls, not tests of an infinite native cancellation estimate or substitutes for the paper proofs.

## Remaining mathematical obligation

The direct bridge repairs an actual source mismatch: pole-neutral tests convert the single-pole prime forcing to the double-pole field `Pi*P²q_s`, with the same original fixed positive precursor and the same interval. The complete signed arithmetic residual of that source still needs an independent all-positive-damping bound, or an adequate independent native lower inequality must oppose the generated negative state.

The proved small inverse alone does not determine the Schur sign; its original forcing, known shift and diagonal term remain. Positive refinement does not supply an unjustified zero-scale limit. The full source record has been retained and several losses of information removed, but none of these records or adapters is labeled a proof of the missing signed bound. **Step 4 remains open.**
