# Shared universal detector: a controlled 4A–4B composition, not a proof

**Mathematical authority: PAPER for universal-construction results; DERIVED algebra for stated normalization; closing restrictions OPEN.**

The supplied analytic packet constructs for any fixed `r>0` the probability density `q_r` with `int q_r=1`, the compact even source `k_r=q_r''-q_r/4`, and the entire product `P_r`. Hence

\[\int k_r=-1/4,\qquad \widehat k_r(\gamma_\rho)=\rho(\rho-1)P_r(\gamma_\rho).\]

For each nontrivial off-line zero, `P_r(gamma_rho) != 0`. The paper argument allows **one fixed** `r=1/4096` in place of zero-dependent small radii for the *off-line visibility* component of the detector route. The canonical radius bank remains the *Lean-proved* route; this alternate detector has not been imported as a Lean declaration or shown identical to the old canonical bump.

The fixed-detector first-prime calculation of the earlier v2.7 strategy considers a real even pole-killed `k` and `kappa=k*k`; its square-channel asymptotic is `1/2 (int k)^2`. The above normalization gives `1/32` for this candidate universal `k_r`. **Cross-check the full additive Weil normalization, support coordinates, and exact source hypothesis before promoting this combination into a theorem.**

- **4A can target:** the signed localized first-prime remainder of this same explicit `k_r`, or a completed-form inequality on the generated canonical witness. Universal visibility does not supply cancellation of that remainder.
- **4B can target:** its exact `C_r(t)` / `V_t=S(tau_t(k_r*k_r))` on the one fixed frequency interval `[1,2]`. The work term remains uncontrolled.
- **4C can test:** whether the same seed's detector, finite matrices and multiple source maps impose a new compatibility invariant. Complex-symmetric rank-one spectral residues and common convolution identities already hold for synthetic off-line zeros, so they are **not** a new exclusion law.

**Potential new bridge:** Gevrey-order-two estimates for `q_r` resemble the hypotheses of the earlier quartic `K(L)=ceil(L^4)` Fourier witness construction. The older quartic proof used a *different explicit seed*. It is a **LEAD** to transfer the complete approximation estimates to the new universally visible source. Do not claim this cross-proof transport as already established; it must preserve endpoint moment corrections, H1 errors, normalization, parity and all aperture/cutoff quantifiers.

**Research output contract:** one complete quantified lemma joining the two source constructions, or an exact counterexample to the proposed transfer. Then a separate independent closing analytic/arithmetic/geometric restriction. Zero visibility alone is not RH exclusion. `RH_OPEN`.
