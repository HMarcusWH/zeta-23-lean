"""Finite exact controls for the paper identities; no RH or analytic certification."""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json


def mul(a, b):
    out = {}
    for i, x in a.items():
        for j, y in b.items():
            out[i + j] = out.get(i + j, Q(0)) + x * y
    return {i: x for i, x in out.items() if x}


def add(a, b):
    out = dict(a)
    for i, x in b.items():
        out[i] = out.get(i, Q(0)) + x
    return {i: x for i, x in out.items() if x}


def power(a, n):
    out = {0: Q(1)}
    for _ in range(n):
        out = mul(out, a)
    return out


def derivative(a, order=1):
    for _ in range(order):
        a = {i - 1: i * x for i, x in a.items() if i}
    return a


def evaluate(a, x):
    return sum(v * x**i for i, v in a.items())


def integral01(a):
    return sum(x / (i + 1) for i, x in a.items())


checks, mutations = [], []


def check(name, value):
    assert value, name
    checks.append(name)


def reject(name, value):
    assert not value, name
    mutations.append(name)


sin2 = {-1: Q(-1, 4), 0: Q(1, 2), 1: Q(-1, 4)}
for M in (3, 7, 12):
    coeff = power(sin2, M)
    moments = [sum(Q(n)**j * x for n, x in coeff.items())
               for j in range(2 * M + 1)]
    check(f"sin_power_{2*M}_endpoint_jets",
          all(x == 0 for x in moments[:2*M]))
    check(f"sin_power_{2*M}_first_nonzero_jet",
          moments[2*M] == (-1)**M * Q(factorial(2*M), 2**(2*M)))
    check(f"sin_power_{2*M}_coefficient_l1",
          sum(abs(x) for x in coeff.values()) == 1)
    source = {n: -(Q(n*n) + Q(1, 4))*x for n, x in coeff.items()}
    check(f"P_source_{2*M}_legal_jets",
          all(sum(Q(n)**j*x for n, x in source.items()) == 0
              for j in range(2*M-2)))

B6 = power(sin2, 3)
check("sin_six_explicit_coefficients",
      B6 == {0: Q(5,16), -1: Q(-15,64), 1: Q(-15,64),
             -2: Q(3,32), 2: Q(3,32), -3: Q(-1,64), 3: Q(-1,64)})
bad = dict(B6)
bad[0] += Q(1, 64)
reject("mutation_nonvanishing_endpoint_padding",
       sum(bad.values()) == 0)

for sigma in (-1, 1):
    q = Q(1, 3)
    c = {0: Q(1)}
    for n in range(1, 10):
        c[n] = sigma*(1-q)*(-sigma*q)**(n-1)
    product = mul(c, {0: Q(1), 1: sigma*q})
    check(f"phase_echo_series_sigma_{sigma}",
          all(product.get(n, 0) == ({0: Q(1), 1: Q(sigma)}).get(n, 0)
              for n in range(10)))
    wrong = dict(c)
    wrong[1] = -wrong[1]
    wrong_product = mul(wrong, {0: Q(1), 1: sigma*q})
    reject(f"mutation_wrong_first_echo_sigma_{sigma}",
           wrong_product.get(1) == sigma)

one_minus_z = {0: Q(1), 1: Q(-1)}
for M in (1, 2, 7, 16):
    J = {}
    for j in range(M):
        J = add(J, power(one_minus_z, j))
    check(f"positive_neumann_polynomial_M_{M}",
          add(mul(J, {1: Q(1)}), power(one_minus_z, M)) == {0: Q(1)})
    if M > 1:
        wrong = add(J, {0: Q(-1)})
        reject(f"mutation_omitted_identity_term_M_{M}",
               add(mul(wrong, {1: Q(1)}), power(one_minus_z, M))
               == {0: Q(1)})

# Distributional zero-extension formula tested against exact polynomial jets.
v = {0: Q(1), 1: Q(2), 2: Q(3), 3: Q(-1)}
vp, vpp = derivative(v), derivative(v, 2)
Pv = add(vpp, {i: -x/4 for i, x in v.items()})
wrong_pass = True
for k in range(7):
    psi = {k: Q(1)}
    psip = derivative(psi)
    Ppsi = add(derivative(psi, 2), {k: Q(-1, 4)})
    lhs = integral01(mul(v, Ppsi))
    boundary_delta = evaluate(vp, Q(0))*evaluate(psi, Q(0)) \
        - evaluate(vp, Q(1))*evaluate(psi, Q(1))
    boundary_deltaprime = -evaluate(v, Q(0))*evaluate(psip, Q(0)) \
        + evaluate(v, Q(1))*evaluate(psip, Q(1))
    rhs = integral01(mul(Pv, psi)) + boundary_delta + boundary_deltaprime
    check(f"physical_P_extension_delta_signs_test_{k}", lhs == rhs)
    wrong_pass = wrong_pass and (
        lhs == integral01(mul(Pv, psi)) + boundary_delta - boundary_deltaprime)
reject("mutation_reversed_delta_prime_sign", wrong_pass)

# Integration by parts changes the negative differential cross term to
# a positive norm term in ||q''-q/4||².
check("norm_scaling_positive_cross_coefficient",
      -2*Q(1,4)*Q(-1) == Q(1,2))
reject("mutation_negative_cross_coefficient",
       -2*Q(1,4)*Q(-1) == Q(-1,2))

root = Path(__file__).resolve().parent
for p in root.glob("*.md"):
    s = p.read_text()
    check(f"{p.name}_balanced_displays", s.count(r"\[") == s.count(r"\]"))
    check(f"{p.name}_no_control_characters",
          all(ord(c) >= 32 or c in "\n\t\r" for c in s))

receipt = {
    "status": "PASS",
    "scope": "Exact finite polynomial, Fourier-jet, delay-series, endpoint-distribution, and display controls only.",
    "not_claimed": [
        "Analytic estimates certified by these finite tests",
        "New compiled Lean theorem",
        "Native signed arithmetic upper bound",
        "Step 4 closure or RH conclusion"
    ],
    "checks_passed": len(checks),
    "mutation_falsifiers_passed": len(mutations),
    "checks": checks,
    "mutations_rejected": mutations
}
(root / "EXACT_CONTROLS.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({k: receipt[k] for k in
                  ("status", "checks_passed", "mutation_falsifiers_passed")}))
