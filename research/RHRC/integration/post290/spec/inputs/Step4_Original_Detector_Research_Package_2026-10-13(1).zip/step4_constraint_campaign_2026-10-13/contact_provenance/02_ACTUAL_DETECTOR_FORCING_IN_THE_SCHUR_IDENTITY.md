# The actual detector forcing inside the Schur identity

Date: 2026-10-13. Status: **NEW PAPER DERIVATION**. This note continues the deep-threshold state without replacing its detector input by an operator norm. The last arithmetic estimate remains open.

## 1. An exact source-level completion of the square

Use the notation of `01_DEEP_POLE_NEUTRAL_STATE_WITH_SPECTRAL_GAP.md`. Let

\[
 S=V_{L,K_\eta-1}^{\rm pn},\qquad
 V_{L,K_d}^{\rm pn}=S\oplus Y,
 \qquad p=x+y
\]

be the actual orthogonal decomposition of the original finite detector. The shifted compression has blocks

\[
 H+\eta I=\begin{pmatrix}P_\eta&B\\B^*&D_\eta\end{pmatrix},
 \quad P_\eta\succeq gI,
 \quad \Sigma_\eta=D_\eta-B^*P_\eta^{-1}B.
\]

Define its actual projected forcing

\[
 b=\Pi_S(H+\eta I)p=P_\eta x+By.                       \tag{F1}
\]

Completion of the square can then be written directly as

\[
 \boxed{Q(p)+\eta
 =\langle b,P_\eta^{-1}b\rangle
  +\langle y,\Sigma_\eta y\rangle.}                    \tag{F2}
\]

This retains the original coefficients, phase, and scale in `b` and `y`. In particular

\[
 \langle y,\Sigma_\eta y\rangle
 =Q(p)+\eta-\langle b,P_\eta^{-1}b\rangle<-D/2.        \tag{F3}
\]

The inverse is controlled by `1/g=12(M+1)/D`. It is therefore unnecessary to estimate every native shell coupling by a generic operator norm merely to state the problem. However, the forcing `b` itself has to be controlled on this source; a small inverse does not bound an arbitrarily large forcing.

## 2. Both elementary pole channels disappear from this forcing

Let `A_arch` be the real-line Fourier multiplier

\[
 A(\xi)=\Re\psi(1/4+i\xi/2)-\log\pi,
\]

and let the symmetric literal prime operator act by

\[
 (\mathcal T_\Lambda f)(x)
 =\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}
  \{f(x-\log n)+f(x+\log n)\}.
\]

Only finitely many summands meet the source interval. The complete additive form represents

\[
 W*f=A_{\rm arch}f+P_{\rm elem}f-\mathcal T_\Lambda f.
\]

The elementary pole operator is the rank-two operator with source functionals `ell_+` and `ell_-`. The original finite trial satisfies both exact equations, so `P_elem p=0`. Consequently the actual forcing in (F1) is

\[
 \boxed{b=\Pi_S\{A_{\rm arch}p-\mathcal T_\Lambda p+\eta p\}.}
                                                               \tag{F4}
\]

The absence of the elementary pole operator is a real consequence of retaining the original detector's pole neutrality. It is not available for the old unrestricted first-bad ground. The known shift term `eta p` remains and must not be omitted.

For the selected pole-neutral ground, the same formula must still include its pole-constraint Lagrange multiplier when written as an Euler equation. Formula (F4) concerns the actual forcing of the **trial** `p`, not an assertion that its projection is zero.

## 3. The prime forcing is an explicit single-detector field

Before finite approximation let

\[
 f(x)=\frac{k(x-a)+\sigma k(x+a)}{\sqrt{2n}},
 \qquad n=\|k\|_2^2,
 \quad \operatorname{supp}k\subset[-r,r],
\]

with the original real even detector and its original phase. Define

\[
 F_k(t)=\sum_{n\ge2}\frac{\Lambda(n)}{\sqrt n}
              k(t-\log n).                              \tag{F5}
\]

The exact symmetric prime action is

\[
 \mathcal T_\Lambda f(x)=\frac{1}{\sqrt{2n}}
 \bigl[F_k(x-a)+F_k(a-x)
       +\sigma F_k(x+a)+\sigma F_k(-x-a)\bigr].         \tag{F6}
\]

All four terms are retained. The identity uses evenness of `k` to express the reflected prime operator as `F_k(-t)`. Its compact support makes every displayed evaluation pointwise finite. For the usual unit-collared aperture `L=2a+2r+2`, their relevant positive arguments are bounded above by `L`. If `r<log 2`, then `F_k` vanishes on negative arguments and on `[0,log 2-r)`.

The Archimedean part has an aperture-independent full-line bound at fixed detector scale:

\[
 \|A_{\rm arch} f\|_2
 \le \frac{\sqrt2}{\sqrt n}\|A_{\rm arch}k\|_2=:C_k.
\]

It follows, without any prime cancellation estimate, that the source forcing satisfies

\[
 \left\|\Pi_S\{W*f+\eta f\}-\eta\Pi_Sf\right\|_2
 \le C_k+2\sqrt{\frac2n}\,\|F_k\|_{L^2(0,L)}.           \tag{F7}
\]

The exact source-dependent quantity is therefore the signed prime field `F_k`, not an unspecified worst-case shell norm. Neither the compact support nor the exact pole moments supply an upper estimate for the last norm.

## 4. The finite approximation error is separately small

Let `e=p-f` be the actual source error furnished by the new finite bridge. For a unit vector `v` in `S`, the finite Fourier carrier gives

\[
 \|v\|_{H^1}\le
 \sqrt{1+(2\pi(K_\eta-1)/L)^2}.
\]

The inherited full bilinear form bound therefore yields

\[
 \|\Pi_S W*e\|_2
 \le C_Q(1+L)e^{L/2}
  \sqrt{1+(2\pi(K_\eta-1)/L)^2}\,\|e\|_{H^1}.          \tag{F8}
\]

Adding the known shift gives

\[
 \|b-\Pi_S(W*f+\eta f)\|_2
 \le\left[C_Q(1+L)e^{L/2}
 \sqrt{1+(2\pi(K_\eta-1)/L)^2}+\eta\right]\|e\|_{H^1}.
                                                               \tag{F9}
\]

The shift is itself bounded by the ambient form estimate. Since `p` is a unit vector at cutoff `K_d`,

\[
 \eta<D/2\le |Q(p)|/2
 \le \tfrac12 C_Q(1+L)e^{L/2}
       \{1+(2\pi K_d/L)^2\}.                         \tag{F9a}
\]

Thus the `eta ||e||` term introduces no larger exponential cost than the inherited growing-form estimate. At fixed detector scale, `K_eta<=K_d=ceil(L^4)` and the finite bridge's stretched-exponential error make (F9) tend to zero. On the scale-dependent families the same conclusion uses the explicit budgets in `source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md` and the refinement note. There is no need to absorb the approximation error into an unknown prime-discrepancy constant.

## 5. The autocorrelation interface and its apparent derivative mismatch

Path A's fixed arithmetic source is the autocorrelation `h=k*k`. Because `k` is real and even,

\[
 F_h=\Pi*h=k*F_k.                                      \tag{F10}
\]

Thus the actual single-detector forcing of the Schur problem and A's smoothed arithmetic field are connected by an exact convolution on the original source. They are not identical fields.

There is a second important distinction in the integer drive. With

\[
 N=\sum_{n\ge1}n^{-1/2}\delta_{\log n},
 \qquad D_k(p)=\int k(u)e^{-pu}\,du,
\]

the formal continuous main term in `(tN)*k`, or equivalently the actual simple pole of its Laplace transform `-zeta'(p+1/2)D_k(p)`, is

\[
 e^{t/2}\{tD_k(1/2)+D_k'(1/2)\}
 =D_k'(1/2)e^{t/2}.                                    \tag{F11}
\]

For the original detector `k=(partial_x^2-1/4)q`,

\[
 D_k(p)=(p^2-1/4)D_q(p),\qquad D_k'(1/2)=D_q(1/2)>0.
\]

The **single** pole zero does not remove (F11). The autocorrelation has `D_h=D_k^2`, which has a double zero and removes both coefficients. This is why the inherited rapidly decaying A drive applies directly to `h`. Importing that decay into (F5) without (F10) would drop actual source information.

Convolution by `k` is smoothing and has its own source zeros. Formula (F10) alone is not a bounded inverse estimate recovering `F_k` from `F_h` on a finite horizon. The direct same-source native-loop note supplies valid source-specific pole and contraction identities; it does not authorize such an inverse without its stated function-space hypotheses.

## 6. Pole-neutral testing removes the mismatch exactly

There is a stronger same-source adapter that does not invert (F10). For every `phi` in the pole-neutral predecessor `S`, let `g=P^{-1}phi`, where `P=partial_x^2-1/4`. The exact finite formula from Note 01 gives a compact, same-cutoff `g` with both `g` and `g'` zero at the endpoints and

\[
 \|g\|_2\le4\|\phi\|_2.
\]

For the actual smooth field (F5), two integrations by parts on the **same** source interval `I` therefore give

\[
 \langle F_k,\phi\rangle_I
 =\langle P F_k,g\rangle_I,
 \qquad X_k:=P F_k=\Pi*P^2q.                          \tag{F12}
\]

No endpoint term, extended observation horizon, or periodic native field is introduced. The operator `P` commutes with each of the four translations and reflections in (F6). Thus if `J_f` denotes precisely its bracket divided by `sqrt(2n)`, and `X_f=P J_f` denotes the identical combination with `F_k` replaced by `X_k`, then

\[
 \boxed{\|\Pi_S J_f\|_2\le4\|X_f\|_{L^2(I)}.}       \tag{F13}
\]

In particular (F7) improves to the fully explicit bound

\[
 \|\Pi_S(W*f+\eta f)-\eta\Pi_S f\|_2
 \le C_k+8\sqrt{2/n}\,\|X_k\|_{L^2(0,L)}            \tag{F14}
\]

under the same radius and collar conventions. The derivative has been moved onto the known smooth original field, not onto an uncontrolled finite test vector. Its source `P^2q` has the double pole zeros needed by the arithmetic integer-drive estimate. Because the original `q` is fixed, its Gevrey constants are fixed as well. The original phase, scale and all four histories survive unchanged. This adapter uses only the original two pole moments and ordinary legal endpoint conditions; the optional high-jet sensor construction is not required for it.

The field `X_k` is not the earlier autocorrelation field `F_h`. The exact source identity is `F_h=q*X_k`. No inverse of that smoothing is claimed. Path A's source-level mask and controlled-sector arguments must be applied to the actual kernel `P^2q`; the full signed residual for that kernel remains an independent arithmetic obligation. This direct adapter is developed jointly with `source_transport/04_DIRECT_POLE_NEUTRAL_FORCING_BRIDGE.md`.

## 7. The result of the closing attempt

The actual source reduction removes both elementary pole channels and makes the needed forcing an explicit four-term combination of one retained prime field, plus a controlled Archimedean term, known spectral shift, and vanishing finite approximation error. The negative-threshold choice separately controls the predecessor inverse. This is a concrete stepwise combination of detector construction, arithmetic response, and structural Schur reduction.

The exact adapter (F12)-(F14) supplies a valid double-pole arithmetic source for the actual projected forcing. It does not supply a subexponential estimate for that source's full signed residual, or an independent lower bound for the remaining diagonal/Schur energy. The known spectral shift `eta p` remains. Even an upper bound for the positive response term in (F2) would not on its own rule out a negative diagonal term in the Schur complement.

The current closing target is now exact and source-preserving: use the literal signed arithmetic of (F12)-(F14), together with the selected seed and multiplier constraints, to give the independent lower bound that opposes (F3), or use the same original source's direct native loop and an independently proved all-damping arithmetic bound. The identities above do not assert either missing bound.
