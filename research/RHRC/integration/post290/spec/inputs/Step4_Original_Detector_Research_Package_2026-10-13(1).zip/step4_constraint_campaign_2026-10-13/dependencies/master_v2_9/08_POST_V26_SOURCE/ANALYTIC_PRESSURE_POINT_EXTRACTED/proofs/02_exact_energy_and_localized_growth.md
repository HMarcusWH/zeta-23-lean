# Exact energy balance and persistence of a visible pole in a bounded frequency interval

**Status:** paper deductions; no new Lean theorem. The input transform and its `L^2` admissibility are those explicitly defined and checked in Section 8 of the supplied `Detector_Transport_and_Temperedness.txt`. This note does not assume the RH-equivalent norm identity from Suzuki.

## 1. Exact objects

Let `k` be a smooth compact real-even detector and `h=k*k`. Define

\[
 A(z)=\xi(1/2-iz),\qquad
 a(x)=\frac{A(x)}{A(x)+iA'(x)},\qquad x\in\mathbb R.
\]

Resolve removable real singularities. Because `A` is real on the real axis,

\[
 |a|\le1,\qquad \Re a=|a|^2,\qquad
 |a|^2+|1-a|^2=1.                                         \tag{1}
\]

The function is nonzero almost everywhere; zeros of the nonzero entire `A` are discrete. The spectral transform, with the positive Fourier convention, is

\[
 (S\psi)(x)=ia(x)\sum_\rho
       \frac{m_\rho\widehat\psi(\gamma_\rho)}{x-\gamma_\rho}.
\]

Let `C(t)=sum m_rho Fh(gamma_rho) exp(i gamma_rho t)` and `V_t=S(tau_t h)`. The inherited, unconditional `L^2` identity is

\[
 V_t(x)=e^{ixt}\left[V_0(x)+a(x)F_t(x)\right],\qquad
 F_t(x)=\int_0^t e^{-ixs}C(s)\,ds.                         \tag{2}
\]

Here `F_t` is in `L^2` by Plancherel. The multiplier `a` need not be in `L^2`; it is therefore invalid to assume that the formal global differential forcing `a C(t)` is an `L^2` vector.

## 2. Energy balance, including the term a closure proof would have to control

With inner product conjugate-linear in its first argument, (2) gives

\[
 \boxed{\|V_t\|_2^2-\|V_0\|_2^2
 =2\Re\langle V_0,aF_t\rangle+\|aF_t\|_2^2.}             \tag{3}
\]

This is not an upper estimate: it is the exact energy change. In addition, (1) gives

\[
 \boxed{\|aF_t\|_2^2+\|(1-a)F_t\|_2^2
 =2\pi\int_0^t|C(s)|^2\,ds.}                             \tag{4}
\]

Thus the apparently favorable boundary multiplier law partitions the input energy between two channels. It does not prove that the input energy or the orbit energy is bounded. There is no sign control on the cross term in (3).

On a bounded real interval `I`, both `x` and `a` are bounded and belong to the required local spaces. Consequently the restricted orbit is strongly continuously differentiable in `L^2(I)` and

\[
 \frac d{dt}\|V_t\|_{L^2(I)}^2
 =2\Re\left(C(t)\int_I a(x)\overline{V_t(x)}\,dx\right).  \tag{5}
\]

The skew multiplication term contributes zero. This is the rigorous local version of the formal energy calculation. It leaves a work term, not a conserved positive energy.

Setting that work term to zero, or bounding it by the desired spectral margin, would be an additional theorem. No such theorem is proved for the native zeta transform in this pass.

## 3. Exact growth remains in every fixed nonempty frequency interval

Let `b` be the supremal displacement among zeros visible to `k`, including zero as a possible supremum. The preceding baseline gives

\[
 \limsup_{t\to\infty}t^{-1}\log(1+|C(t)|)=b.
\]

**Theorem 2.** For every bounded interval `I` of positive length,

\[
 \boxed{\limsup_{t\to\infty}
 \frac{\log(1+\|V_t\|_{L^2(I)})}{t}=b.}                   \tag{6}
\]

The same equality holds for the full `L^2` norm. In particular, an exposed off-line mode cannot be explained away as energy that merely escapes to infinite real frequency in this representation.

### Proof

Absolute summability gives `|C(t)|<=S exp(bt)`. From (2) and Plancherel,

\[
 \|V_t\|_2\le\|V_0\|_2+\sqrt{2\pi}\|C\|_{L^2(0,t)}.
\]

This proves the upper bound in (6), including `b=0`, where the estimate is at most square-root polynomial. The lower bound is automatic if `b=0`.

For `Re p>b`, the Bochner Laplace transform of (2) is

\[
 \boxed{\mathcal L V(p)(x)=
 \frac{V_0(x)}{p-ix}+
 \frac{a(x)}{p-ix}\,R(p),\qquad
 R(p)=\sum_\rho\frac{m_\rho\widehat k(\gamma_\rho)^2}
                             {p-i\gamma_\rho}.}          \tag{7}
\]

The interchanges on this safe half-plane are dominated by the displayed exponential bound and the bounded multiplication resolvent. As an `L^2`-valued function, `a(x)/(p-ix)` is holomorphic for `Re p>0`; its norm is at most `sqrt(pi/Re p)`. The first term is holomorphic there as well. The scalar `R` is meromorphic with the nonzero residues retained by the detector theorem.

At a visible pole `lambda=i gamma=rho-1/2` with positive real part, the residue of the right side is

\[
 m_\rho\widehat k(\gamma)^2\,
       \frac{a(x)}{\lambda-ix}.                            \tag{8}
\]

Its restriction to every `I` has strictly positive norm: the coefficient is nonzero, the denominator has nonzero real part, and `a` is nonzero almost everywhere. No other term at that same pole cancels this residue; multiplicity is already grouped.

If the restricted orbit had exponential type less than `b`, choose a visible pole with real part above that type. Its `L^2(I)` Laplace transform would extend holomorphically across the pole. Equation (7), identity continuation, and (8) contradict that extension. For complete explicitness, pair the residue with a bounded `L^2(I)` functional that does not annihilate it, reducing the contradiction to scalar holomorphy. This proves (6).

For the universal detector of Note 01, `b=Delta` for this one fixed source. Equation (6) therefore reduces the analytic closing problem to one explicit orbit on, for example, `I=[1,2]`. This is a reduction, not a proof of its boundedness.

## 4. Why erasing the forcing is not the correct conservation law

Suppose the transform's actual orbit obeyed the free law `V_t=e^{ixt}V_0` for every `t>=0`. Then (2) gives `aF_t=0` almost everywhere. Since `a` is nonzero almost everywhere, `F_t=0`; Plancherel implies `C=0` on `[0,t]` for every `t`. The meromorphic resolvent then has every residue zero. The defining transform has `V_0=0`.

Thus the nonzero transformed source cannot become a free multiplication orbit merely by declaring its forcing absent. A valid unitary realization, if established, must include the correct feedback/domain structure. Norm conservation and free multiplication are distinct claims: the stable exact control in Note 03 has nonzero forcing but constant norm.

## 5. Boundary losslessness is not causality

Writing `Theta=2a-1`, (1) says `|Theta(x)|=1` for real `x`. Multiplication by `Theta` is unitary on the full real-frequency `L^2` space. This alone does not say its inverse Fourier transform preserves a one-sided time-support subspace. A meromorphic multiplier can have unimodular real boundary values while having upper-half-plane poles.

The rational control in Note 03 exhibits exactly this failure with the same formula `a=A/(A+iA')`, not with an unrelated imposed forcing. A contour or Hardy-space step that discarded those poles would insert the unproved condition. For the native entire function, this pass did not establish the one-sided analytic control needed to justify that contour step.

## What was attempted and what failed

The attempted closure was to turn the elementary positive-boundary relation (1) into a conservation or dissipative law. The exact calculation yields (3)-(5). The cross work has no established opposing sign, and the matched rational control grows exponentially despite (1). The localized residue result shows that the missing bound is substantive even in one bounded spectral interval; it cannot be supplied by excluding only a remote frequency tail.
