#!/usr/bin/env python3
"""Exact finite-product controls for the constraint-preserving detector proofs.

The analytic notes prove the infinite-product statements. These controls use
finite uniform convolutions and rational arithmetic; they do not certify RH,
an infinite scale limit, or a universal arithmetic norm estimate.
"""

from collections import defaultdict
from fractions import Fraction as Q
from math import comb, factorial
from pathlib import Path
import json


def convolve_moments(a, b):
    return [sum(Q(comb(n, k)) * a[k] * b[n-k]
                for k in range(n+1)) for n in range(len(a))]


def point_moments(x, order):
    return [x**n for n in range(order+1)]


def uniform_moments(widths, order):
    result = [Q(1)] + [Q(0)] * order
    for c in widths:
        one = [c**n / (n+1) if n % 2 == 0 else Q(0)
               for n in range(order+1)]
        result = convolve_moments(result, one)
    return result


def add_sign(law, width):
    result = defaultdict(Q)
    for x, p in law.items():
        result[x-width] += p / 2
        result[x+width] += p / 2
    return dict(result)


def refinement_law(r, levels, count, copies=1):
    law = {Q(0): Q(1)}
    for level in range(1, levels+1):
        for j in range(1, count+1):
            for _ in range(copies):
                law = add_sign(law, r / (2**level * j * (j+1)))
    return law


def law_moments(law, order):
    return [sum(p*x**n for x, p in law.items())
            for n in range(order+1)]


def widths(r, count):
    return [r / (j*(j+1)) for j in range(1, count+1)]


def box_knots(ws):
    knots = {Q(0): 1}
    for w in ws:
        result = defaultdict(int)
        for x, sign in knots.items():
            result[x] += sign
            result[x+2*w] -= sign
        knots = dict(result)
    total = sum(ws)
    return {x-total: sign for x, sign in knots.items() if sign}


def box_derivative(x, ws, derivative):
    if abs(x) > sum(ws):
        return Q(0)
    degree = len(ws) - 1 - derivative
    assert degree >= 0
    denominator = Q(factorial(degree))
    for w in ws:
        denominator *= 2*w
    numerator = sum(sign * (x-knot)**degree
                    for knot, sign in box_knots(ws).items() if x > knot)
    return numerator / denominator


def h(r, x, count=3):
    ws = widths(r, count) * 2
    return (box_derivative(x, ws, 4)
            - box_derivative(x, ws, 2) / 2
            + box_derivative(x, ws, 0) / 16)


def polynomial_add(a, b):
    out = [Q(0)] * max(len(a), len(b))
    for i, x in enumerate(a):
        out[i] += x
    for i, x in enumerate(b):
        out[i] += x
    return out


def polynomial_product(a, b):
    out = [Q(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i+j] += x*y
    return out


def box_polynomial(midpoint, ws, derivative):
    degree = len(ws) - 1 - derivative
    denominator = Q(factorial(degree))
    for w in ws:
        denominator *= 2*w
    result = [Q(0)] * (degree+1)
    for knot, sign in box_knots(ws).items():
        if knot < midpoint:
            for j in range(degree+1):
                result[j] += (Q(sign * comb(degree, j))
                              * (-knot)**(degree-j) / denominator)
    return result


def exact_squared_norm(r, count, terms):
    ws = widths(r, count)
    knots = sorted(box_knots(ws))
    answer = Q(0)
    for left, right in zip(knots, knots[1:]):
        mid = (left+right) / 2
        poly = [Q(0)]
        for derivative, coefficient in terms:
            add = [coefficient*x for x in box_polynomial(mid, ws, derivative)]
            poly = polynomial_add(poly, add)
        square = polynomial_product(poly, poly)
        answer += sum(c * (right**(i+1)-left**(i+1)) / (i+1)
                      for i, c in enumerate(square))
    return answer


def run():
    checks = {}
    moment_cases = 0
    for count in range(1, 6):
        for levels in range(1, 4):
            r = Q(1)
            s = r / 2**levels
            order = 10
            coarse = uniform_moments(widths(r, count), order)
            fine = uniform_moments(widths(s, count), order)
            nu = refinement_law(r, levels, count)
            assert convolve_moments(fine, law_moments(nu, order)) == coarse
            assert sum(nu.values()) == 1
            assert law_moments(nu, 1)[1] == 0
            expected_variance = ((r*r-s*s) / 3
                                 * sum(Q(1, j*j*(j+1)*(j+1))
                                       for j in range(1, count+1)))
            assert law_moments(nu, 2)[2] == expected_variance
            moment_cases += order+1
    checks['exact_uniform_refinement_moments'] = moment_cases

    identity_cases = 0
    variance_cases = 0
    for r in [Q(1), Q(1, 4), Q(1, 4096)]:
        s = r/2
        law = refinement_law(r, 1, 3, copies=2)
        coarse_knots = sorted(box_knots(widths(r, 3)*2))
        points = sorted(set(coarse_knots + [(a+b)/2 for a, b in
                                            zip(coarse_knots, coarse_knots[1:])]))
        for x in points:
            values = [(p, h(s, x-u)) for u, p in law.items()]
            mean = sum(p*v for p, v in values)
            assert mean == h(r, x)
            identity_cases += 1
            if x in coarse_knots[::4]:
                var = sum(p*v*v for p, v in values) - mean*mean
                pair_variance = sum(p*q*(v-w)**2
                                    for p, v in values for q, w in values) / 2
                assert var == pair_variance and var >= 0
                variance_cases += 1
    checks['exact_h_refinement_including_knots'] = identity_cases
    checks['exact_pair_variance_checks'] = variance_cases

    # Independent exact polynomial integration verifies the s^-5 norm law.
    q2 = exact_squared_norm(Q(1), 3, [(2, Q(1))])
    q1 = exact_squared_norm(Q(1), 3, [(1, Q(1))])
    q0 = exact_squared_norm(Q(1), 3, [(0, Q(1))])
    norm_cases = 0
    for s in [Q(1), Q(1, 2), Q(1, 4), Q(1, 4096)]:
        actual = exact_squared_norm(s, 3, [(2, Q(1)), (0, Q(-1, 4))])
        predicted = q2/s**5 + q1/(2*s**3) + q0/(16*s)
        assert actual == predicted
        norm_cases += 1
    checks['exact_normalization_integrals'] = norm_cases

    # A finite-product first-atom martingale: exact means, increasing moments.
    # These finitely many levels illustrate, but do not prove, Note 02's limit.
    r = Q(1)
    t = Q(0)
    initial = h(r, t)
    assert initial != 0
    rows = []
    previous_second = Q(0)
    for levels in range(8):
        s = r / 2**levels
        law = refinement_law(r, levels, 3, copies=2)
        mean = Q(0)
        second = Q(0)
        nonzero_probability = Q(0)
        for u, probability in law.items():
            value = h(s, t-u)
            mean += probability*value
            second += probability*value*value
            if value:
                nonzero_probability += probability
        assert mean == initial
        assert second >= previous_second
        previous_second = second
        rows.append({'level': levels, 'scale': str(s),
                     'mean_exact': str(mean),
                     'second_moment_float': float(second),
                     'nonzero_probability_float': float(nonzero_probability),
                     'finite_law_states': len(law)})
    checks['finite_product_martingale_levels'] = rows

    factor_cases = 0
    exponent_cases = 0
    for eta in [Q(1,1000), Q(1,100), Q(1,10), Q(1,2), Q(1), Q(2)]:
        plus = [eta*eta-Q(1,4), 2*eta, Q(1)]
        minus = [eta*eta-Q(1,4), -2*eta, Q(1)]
        left = polynomial_product(plus, minus)
        right = polynomial_product([-((eta+Q(1,2))**2), Q(0), Q(1)],
                                   [-((eta-Q(1,2))**2), Q(0), Q(1)])
        assert left == right
        factor_cases += 1
        b = min(Q(1,2), eta)
        delta = min(Q(1,4), eta/2)
        early = b*(Q(1,2)-delta) + Q(3,4)*(1-2*delta)
        late = b*(Q(1,2)-delta) - Q(3,2)*delta
        assert early < Q(3,4) and late < 0 and delta < eta
        exponent_cases += 1
    checks['exact_squared_kernel_factorizations'] = factor_cases
    checks['slow_scale_exponent_budget_checks'] = exponent_cases
    result = {
        'status': 'PASS',
        'scope': ('Exact rational controls for finite uniform products, source '
                  'normalization, refinement seams, variance, and exponent '
                  'algebra. The infinite-product and universal claims are '
                  'proved in the notes, not inferred from this script.'),
        'checks': checks,
    }
    destination = Path(__file__).with_name('DETECTOR_REFINEMENT_CONTROLS.json')
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'],
                      'moment_checks': moment_cases,
                      'refinement_seam_checks': identity_cases,
                      'variance_checks': variance_cases,
                      'normalization_checks': norm_cases,
                      'martingale_levels': len(rows),
                      'output': str(destination)}))


if __name__ == '__main__':
    run()
