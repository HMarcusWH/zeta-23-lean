# Constraint campaign: exact positive refinement of the original universal detector

Date: 13 October 2026. Status: **PAPER / DERIVED; not formalized.**

This note keeps the actual universal detector of the master proof. It proves an exact relation between its scales, including complex phase, all finite histories, and the normalization cost of a deep two-lobe witness. A finer source is always recorded together with the explicit convolution that reconstructs the original fixed source; it is never substituted by an unsupported source identification.

## 1. Source and notation

Use the master convention

\[
\widehat f(z)=\int_{\mathbb R}f(x)e^{izx}\,dx,
\qquad Q_r(p)=\int_{\mathbb R}q_r(x)e^{-px}\,dx.
\]

The original construction is

\[
c_j(r)=\frac r{j(j+1)},\qquad
q_r=\mathop{*}_{j\ge1}\frac{1_{[-c_j(r),c_j(r)]}}{2c_j(r)},
\qquad k_r=(\partial^2-1/4)q_r.
\]

Here \(q_r\) is even, nonnegative, smooth, has mass one, and is supported on \([-r,r]\). Put

\[
b_r=q_r*q_r,\qquad h_r=k_r*k_r=(\partial^2-1/4)^2b_r.
\]

Their bilateral Laplace transforms satisfy

\[
H_r(p)=(p^2-1/4)^2Q_r(p)^2,
\quad
Q_r(p)=\prod_{j\ge1}\frac{\sinh(c_j(r)p)}{c_j(r)p}.
\tag{1}
\]

The fixed source used in the previous A/B/C campaign has \(r=r_*=1/4096\). All assertions below hold for \(0<s\le r\le r_*\), with the explicitly stated dyadic relation between \(s\) and \(r\).

Define the native prime field and complete spectral correlation by

\[
F_r(t)=\sum_{n\ge1}\frac{\Lambda(n)}{\sqrt n}h_r(t-\log n),
\qquad
C_r(t)=\sum_\rho m_\rho H_r(\lambda_\rho)e^{\lambda_\rho t},
\quad \lambda_\rho=\rho-1/2.
\tag{2}
\]

The first sum is locally finite. The second and its translates on compact sets are absolutely convergent by the master Gevrey bound and zero count. For \(t>2r\), the supplied exact formula is \(C_r(t)=-F_r(t)-A_r(t)\), with the complete gamma tail \(A_r\) retained.

## 2. Exact positive refinement

**Theorem 1.** Let \(s=r/2^J\), \(J\ge0\). There is an even probability measure \(\nu_{r,s}\), supported in \([-(r-s),r-s]\), such that, with \(\sigma_{r,s}=\nu_{r,s}*\nu_{r,s}\),

\[
\boxed{
q_r=q_s*\nu_{r,s},\qquad
k_r=k_s*\nu_{r,s},\qquad
h_r=h_s*\sigma_{r,s}.
}
\tag{3}
\]

In particular \(\sigma_{r,s}\) is an even probability measure supported in
\([-a,a]\), \(a=2(r-s)\), and

\[
\boxed{F_r=\sigma_{r,s}*F_s,\qquad C_r=\sigma_{r,s}*C_s.}
\tag{4}
\]

**Proof.** A uniform variable on \([-c,c]\) is exactly the sum of an independent uniform variable on \([-c/2,c/2]\) and a fair sign times \(c/2\). Iterating this identity for every original width gives the law

\[
\nu_{r,s}=\operatorname{law}
\left(\sum_{j\ge1}\sum_{\ell=1}^{J}
\epsilon_{j,\ell}\frac{r}{2^\ell j(j+1)}\right),
\tag{5}
\]

where the signs are independent and fair. The sum of the absolute widths is \(r-s\), so all sums and products converge on the indicated compact support. This proves the first identity in (3). Differentiation commutes with convolution by a compact measure, which proves the other two. Local finiteness gives the first identity in (4). For the second, integrate the absolutely convergent complete zero sum on the compact translation interval; its coefficients obey exactly the transform identity in (6) below. QED.

No horizon has been changed to an infinite horizon, and no prime or cofactor mixed term has been deleted.

## 3. Damping and complex-square phase have explicit costs

Let

\[
M_{r,s}(p)=\int e^{-pu}\,\sigma_{r,s}(du).
\]

The exact transfer factor is

\[
\boxed{
M_{r,s}(p)=\frac{Q_r(p)^2}{Q_s(p)^2}
=\prod_{j\ge1}\prod_{\ell=1}^{J}
\cosh\!\left(\frac{rp}{2^\ell j(j+1)}\right)^2.
}
\tag{6}
\]

The quotient is interpreted through the entire product if numerator and denominator both vanish on the imaginary axis. At a native off-line \(\lambda\), its real part is nonzero, so no cosh factor vanishes and the convergent product is nonzero. Consequently the complex-square residue is transported as

\[
H_r(\lambda)=M_{r,s}(\lambda)H_s(\lambda).
\tag{7}
\]

It is not transported by \(|M_{r,s}(\lambda)|\), by a modulus square, or by an unsigned spectral sum.

Set

\[
v_0=\frac13\sum_{j\ge1}\frac1{j^2(j+1)^2}
=\frac{\pi^2}{9}-1.
\]

The exact variance of \(\sigma_{r,s}\) is \(2v_0(r^2-s^2)\). The elementary inequality \(\cosh x\le e^{x^2/2}\), applied to the independent sign factors, gives for every real \(\epsilon\)

\[
\boxed{
1\le M_{r,s}(\epsilon)
\le\exp\!\big(v_0(r^2-s^2)\epsilon^2\big).
}
\tag{8}
\]

This accumulated bound depends on the total scale change, not the number of dyadic levels. For complex \(p\), symmetry and Taylor's integral remainder give the additional phase-sensitive estimate

\[
|M_{r,s}(p)-1|
\le v_0(r^2-s^2)|p|^2 e^{2(r-s)|p|}.
\tag{9}
\]

Indeed the linear term integrates to zero and
\(|e^{-pu}-1+pu|\le |p|^2u^2e^{|p||u|}/2\).
Whenever the right side of (9) is \(\theta<1\), it gives
\(1-\theta\le |M|\le1+\theta\) and, for example,
\(|\arg M|\le\arctan(\theta/(1-\theta))\).
These are fixed-mode bounds; no uniform visibility time over all zeta zeros is asserted.

## 4. Exact finite-interval Jensen and variance identities

Let \(X_r\) denote either field in (2), or any locally square-integrable family satisfying (4). For a fixed real damping \(\epsilon\), define

\[
Y_r(t)=\frac{e^{-\epsilon t}X_r(t)}{Q_r(\epsilon)^2},
\qquad
\sigma^\epsilon_{r,s}(du)
=\frac{e^{-\epsilon u}}{M_{r,s}(\epsilon)}\sigma_{r,s}(du).
\]

The latter is a probability measure, and \(Y_r=\sigma^\epsilon_{r,s}*Y_s\). For a finite interval \(I=[b,T]\), put

\[
E_r(I)=\int_I|Y_r(t)|^2dt,
\]

\[
V_{r,s}(I)=\frac12\iint\sigma^\epsilon_{r,s}(du)
\sigma^\epsilon_{r,s}(dv)
\int_I|Y_s(t-u)-Y_s(t-v)|^2dt.
\]

The elementary variance identity, integrated over \(I\), proves the exact formula

\[
\boxed{
E_r([b,T])+V_{r,s}([b,T])
=\int E_s([b-u,T-u])\,\sigma^\epsilon_{r,s}(du).
}
\tag{10}
\]

In particular,

\[
\begin{split}
E_s([b-a,T+a])-E_r([b,T])
={}&V_{r,s}([b,T])\\
&+\int\left[
E_s([b-a,b-u])+E_s([T-u,T+a])
\right]\sigma^\epsilon_{r,s}(du).
\end{split}
\tag{11}
\]

Both history and terminal terms in (11) are nonnegative. The formula applies to the bilateral spectral field without a causal extension convention.

For the native prime field, the first possible support point is \(\log2-2s\). Since \(4r_*<\log2\), this is larger than \(a\). Thus all lower boundary pieces in (11), with \(b=0\), vanish exactly. For \(T\ge a\),

\[
\boxed{
E_s([0,T+a])-E_r([0,T])
=V_{r,s}([0,T])
+\int E_s([T-u,T+a])\,\sigma^\epsilon_{r,s}(du).
}
\tag{12}
\]

Consequently, in unnormalized weighted norms,

\[
\boxed{
\|F_r\|_{\epsilon,[0,T]}
\le M_{r,s}(\epsilon)\,
\|F_s\|_{\epsilon,[0,T+2(r-s)]}.
}
\tag{13}
\]

The right side includes anticipation by the full support width. Deleting it would invalidate the finite-horizon inference.

For completeness the variance also telescopes across all intermediate scales. Write \(r_j=r/2^j\), let \(\tau_j=\sigma^\epsilon_{r_j,r_{j+1}}\), and let
\(v_j=\tau_j*|Y_{r_{j+1}}|^2-|Y_{r_j}|^2\ge0\).
If \(\tau_{<j}=\tau_0*\cdots*\tau_{j-1}\) and \(\tau_{<0}=\delta_0\), then

\[
\sigma^\epsilon_{r,s}*|Y_s|^2-|Y_r|^2
=\sum_{j=0}^{J-1}\tau_{<j}*v_j.
\tag{14}
\]

This follows by a finite telescoping sum. Integrating (14) on a finite interval keeps every shifted interval on its right side. Positivity of the variances does not itself bound the final fine-scale energy.

## 5. Exact normalization and self-energy budgets

Scaling gives \(q_s(x)=s^{-1}q_1(x/s)\). Let \(n_s=\|k_s\|_2^2\). Integration by parts, with no endpoint term, proves

\[
\boxed{
n_s=s^{-5}\|q_1''\|_2^2
+\frac12s^{-3}\|q_1'\|_2^2
+\frac1{16}s^{-1}\|q_1\|_2^2.
}
\tag{15}
\]

In particular there are fixed positive constants \(c_n,C_n\) such that
\(c_ns^{-5}\le n_s\le C_ns^{-5}\) for \(0<s\le r_*\).
The first coefficient is positive because a compactly supported mass-one smooth function cannot have identically zero second derivative.

The original Gevrey estimate and unconditional zero count also imply a uniform self-energy bound

\[
\boxed{
\frac{|C_s(0)|}{n_s}
\le C\log(2+1/s).
}
\tag{16}
\]

Here is a direct proof. For \(\lambda=\rho-1/2\), with \(|\Re\lambda|\le1/2\), the master product bound gives
\(|H_s(\lambda)|\le C(1+|\Im\lambda|)^4e^{-c\sqrt{s|\Im\lambda|}}\).
The number of zeros up to height \(U\), with multiplicity, is at most
\(C(U+2)\log(U+2)\). The block below \(1/s\) contributes
\(O(s^{-5}\log(2+1/s))\). On the block
\(2^j/s<|\Im\lambda|\le2^{j+1}/s\), the contribution is at most

\[
Cs^{-5}2^{5(j+1)}
\big(\log(2+1/s)+j+1\big)e^{-c2^{j/2}}.
\]

The sum of these bounds is a constant times the same initial budget. Division by (15) proves (16), without estimating any native Möbius mean.

## 6. Phase and depth propagate through the scale history

**Theorem 2.** Suppose the original fixed source has a real value
\(C_r(t)\le-D\), \(D>0\). For every dyadic \(s\le r\), there is a point
\(t_s\in[t-2(r-s),t+2(r-s)]\) such that \(C_s(t_s)\le-D\).

This is immediate from the positive average in (4) and continuity. The symmetric statement holds for \(C_r(t)\ge D\).

For large enough \(t\), put \(a_s=t_s/2>s\) and retain the even source

\[
f_{s,+}=\frac{\tau_{a_s}k_s+\tau_{-a_s}k_s}{\sqrt{2n_s}}.
\]

It has norm one, keeps both exact pole moments, and has the **positive** compact precursor
\((\tau_{a_s}q_s+\tau_{-a_s}q_s)/\sqrt{2n_s}\).
The supplied two-lobe identity yields

\[
\boxed{
\mathcal Q(f_{s,+})
=\frac{C_s(0)+C_s(t_s)}{n_s}
\le C\log(2+1/s)-C_n^{-1}D s^5.
}
\tag{17}
\]

A positive coarse value gives the corresponding deep odd source. The phase is selected from the actual real correlation, while the complex-square residues and their refinement factor remain those of (7).

If a coarse sequence has \(D\ge e^{\beta t}\), polynomial refinement
\(s\asymp t^{-b}\) loses only the explicit factor \(t^{-5b}\). For every
\(\beta'<\beta\), (17) is eventually at most \(-e^{\beta't}\), after a fixed constant change. Exponential refinement \(s\asymp e^{-\alpha t}\) retains a positive exponential depth by this estimate only when \(5\alpha<\beta\); the retained exponent can be any number below \(\beta-5\alpha\).

This theorem is conditional on the displayed coarse signed value. Theorem P in `../root/01_TWO_SIDED_PHASE_AND_POLE_NEUTRAL_SOURCE.md` proves that a hypothetical off-line zero supplies both signed sequences. No zero attaining the maximal displacement is required here.

The finite bridge and the negative-threshold contact construction are separate interfaces. Their proofs must retain \((s,t_s,\nu_{r,s},D,n_s)\). This note neither declares \(f_{s,+}\) a null vector nor identifies a resulting ground state with the original two-lobe vector.

## Source record

- Master v2.9, `08_POST_V26_SOURCE/ANALYTIC_PRESSURE_POINT_EXTRACTED/proofs/01_single_universal_detector.md`, Sections 1–4: exact source, transform, Gevrey bound, visibility, support, complete zero sum.
- Master v2.8, `08_POST_V26_SOURCE/STRATEGY_PACKET_EXTRACTED/01_Detector_Provenance_and_Polynomial_Cutoff.txt`: exact two-lobe norm/form identity and finite detector provenance.
- The positive refinement measure, damped finite-interval variance, accumulated complex-moment budget, uniform self-energy estimate, and quantitative scale/phase transfer are derived in this note.
