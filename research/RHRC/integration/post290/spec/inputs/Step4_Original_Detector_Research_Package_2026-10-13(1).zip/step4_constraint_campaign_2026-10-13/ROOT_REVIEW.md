# Mathematical review and exact closing status

Date: 13 October 2026. Review authority: paper derivations and finite controls, not Lean verification.

## 1. What was reviewed

This campaign begins from the supplied original sinc-product detector, native factor-one Weil dictionary, form-domain foundations and causal dictionary. The new proofs were reviewed as compositions of those inputs. Historical claims about repository status were not used to upgrade any new result to formal authority. The supplied v2.9 master explicitly treated the universal-detector-to-quartic-carrier bridge as unfinished because an earlier cutoff argument used a different seed; this campaign supplies a source-specific paper construction.

The root review checked the two-sided phase argument, compact inverse, source quotient and exact feedback loop; all three branch interfaces; the scale-dependent Poisson estimate and all-prefix arithmetic bound; the finite positive endpoint construction; the constrained spectral gap and zero-flip descent; the actual four-field detector forcing; and the direct compact-potential map. Independent branch reviews checked the same interfaces from their receiving side.

## 2. Findings and corrections incorporated

### Original detector and both phases

The coefficient in the zero series is a complex square. Reflection makes the total correlation real; no replacement by absolute squares is made. Nonzero residues at every off-line zero and meromorphic continuation are justified by the supplied Gevrey decay and absolute convergence. The positive-Laplace argument uses analyticity at the real abscissa, not a rightmost zero. It proves both signs separately. The later normalized exponential-depth statement uses strictly positive \(\beta\); this qualification was made explicit so the fixed diagonal can be absorbed by \(e^{\beta t}\).

The original even source has a positive precursor. Its odd counterpart has the explicit difference precursor. The selected ground is not assigned either precursor or the original translate phase.

### Compact inverse and projected forcing

The fundamental solution of \(P=\partial^2-1/4\) is \(-e^{-|x|/2}\); its derivative jump is one. The two exponential moments are exactly the coefficients of its two exterior tails. Their vanishing therefore gives a compact \(H^2\) potential and both clamped endpoint traces. On the real Fourier axis the inverse has norm at most four.

The direct identity

\[
\langle F_{k_s},\phi\rangle
=\langle \Pi*P^2q_s,P^{-1}\phi\rangle
\]

holds for the actual smooth native field and every compact pole-neutral test. Both integrations by parts have zero endpoint terms. Translation and reflection commute with \(P\), so the four fields in the actual two-lobe forcing are covered. The archimedean term and threshold term remain separate in the projected equation.

This is the key final composition. It avoids the incorrect claim that a single-\(k_s\) source already has a double zero, and it avoids imposing a double-moment constraint on the finite test. The second pole-killing operator is transferred using the test's original compact potential.

### Finite carrier and spectral selection

The positive \(\sin^6\) endpoint factor, Fourier approximation, positive padding, and application of \(P\) preserve the required moments and finite cutoff. The repaired finite source carries the original relative lobe coefficients and reflection exactly. It approximates the original physical sine/cosine transform; that entire transform is not asserted to remain unchanged.

The form estimate pays its full \(e^{L/2}\) cost. At quartic cutoff the Gevrey decay defeats it for the stated source scales. Higher endpoint order is an additional construction with its own \(\exp(O(m\log L))\) cost. It is not retroactively assigned to a ground from another carrier.

The spectral threshold lies in \((D/3,D/2)\) and is chosen away from all relevant finite spectra. Both shifted predecessors are positive. The inverse is taken at the actual negative selected eigenvalue, with the specified gap. No unshifted predecessor positivity or depth preservation at the first zero crossing is inferred.

Constrained zero-flipping preserves norm, autocorrelation, native form and the two pole moments when the mandatory simple pole roots are excluded. A repeated mandatory root could be flipped while retaining neutrality and is therefore also ruled out. Parity projection and shell cancellation yield a lower-cutoff contradiction. The original source already satisfies the resulting nonreal-root pattern, so this classification does not itself give the closing contradiction.

The finite equation remains compressed. Its two pole multipliers and residual outside the carrier are recorded. The original detector's completed-square Schur identity retains the actual forcing and the diagonal block.

### Native loop and original phase

The paired elementary factor gives source-quotient contraction for \(h\ge1/\sqrt2\); this improves the more conservative factor-by-factor bound \(h\ge1\). The uniform threshold is sharp for this class as the original radius tends to zero. Multiplicity is retained. No simple-native-zero premise is used.

The exact two-lobe phase factor is a signed delay measure of total variation two. Its echo coefficients and causal shifts are retained. The advanced compact history has a uniform unweighted \(L^2\) bound even though the uncompensated compact history may be large. No unproved \(H^1\) trace claim is attached to a cut-off history.

Gamma-free forcing keeps \(1-n^{-2}\) until its stable correction is explicitly separated. Pole neutrality removes the elementary growing center; it does not make the signed prime source positive.

### Positive scale refinement and arithmetic constants

The refinement measure is positive, bilateral and of known support. Weighted comparison uses its exponential tilt and retains the terminal anticipation. The norm scales as \(s^{-5}\), and the signed witness depth pays this normalization. Refinement transports complex phase through an explicit nonvanishing factor; it does not hold that phase numerically fixed.

The uniform integer-drive estimate pays the factor \(\sqrt{s}\) in its decay exponent and the stated polynomial prefactor. The compensated cutoff therefore uses \(B_s=B_0/s\). The finite initial interval is retained explicitly. The slow scale is frozen for the whole prefix; the running arithmetic cutoffs do not change that source. The split at \(T^{3/4}\) and its two exponent inequalities were independently checked.

The scale-zero martingale failure is for the actual first-prime native response, not a substitute model. It is eventually zero almost surely while preserving nonzero expectation at all finite levels. Thus the proposed limit lacks uniform integrability. Finite rational model checks illustrate the mechanism; the proof for the original infinite-product source is analytic.

The final fixed-source arithmetic adapter retains \(q_s\) inside \(P^2q_s\), or inside \(P^2(q_s*q_\delta*q_\delta)\) when a probe is used. Convolution with a positive probability measure does not enlarge the original derivative \(L^1\) bounds. The apparent fine-probe loss disappears for this actual mixed source. Bounding the bare fine-scale field first would discard that advantage.

## 3. What the controls do and do not establish

The scripts use exact rational finite algebra for identities with a finite specialization: uniform-product refinement, native knot conventions, source norms, variance, kernel factors, scale exponents, spectral gaps, legal moment repair, zero flipping, Schur completion and shifted-factor contraction. Mutation controls deliberately remove an essential term or hypothesis and check that the resulting statement fails. The saved JSON files report each script's scope and result.

The universal statements are justified by the written proofs. Passing finite controls is not a proof of an infinite-product theorem, native cancellation, the Riemann Hypothesis, or Lean compilation. No numerical experiment on unknown off-line zeros is used.

## 4. Closing attempts and the precise remaining gap

The complete record does not yet produce an incompatible pair of bounds. It provides stronger quantitative necessary conditions and exact maps into a smaller arithmetic task.

For the original autocorrelation source, the slow-scale theorem bounds every displayed field except the complete signed large-rough-core residual, equivalently the positive part of the signed off-diagonal pair energy. For the direct compact-potential route, the remaining task is the signed residual of the fixed original-seed field \(X_s=\Pi*P^2q_s\). Its integer-drive remainder and controlled core are handled without a changing-scale penalty.

An independent all-positive-damping upper bound for \(X_s\) would close the native pole argument: its transform contains \(-\zeta'/\zeta\) multiplied by \((p^2-1/4)^2Q_s(p)\), which is nonzero at every nontrivial off-line pole. That upper bound is not assumed or proved here.

For a Schur closure, even a small response term must be combined with the correct diagonal inequality. The identity

\[
\mathfrak q(p)+\eta
=\langle b,(A_{\rm pred}+\eta I)^{-1}b\rangle
+\langle y,\Sigma_\eta y\rangle
\]

retains both terms. The exponentially small predecessor inverse does not set \(b\) to zero and does not prove \(\Sigma_\eta\ge0\). The phase-specific history estimate likewise leaves the far-translated signed forcing.

The final status is therefore **OPEN at an explicit native signed upper estimate**. The work does establish new paper bridges that retain more of Steps 1–3, including a direct source-preserving projection identity. It supplies no new unconditional Step 4 or RH theorem.
