#!/usr/bin/env python3
"""Exact finite controls using Gaussian rationals and the standard library.
Finite algebra only: no native infinite estimate, RH proof, or Lean claim.
"""
from fractions import Fraction as F
from pathlib import Path
from dataclasses import dataclass
import json

HERE = Path(__file__).resolve().parent
checks, mutations = [], []

@dataclass(frozen=True)
class Q:
    re: F = F(0)
    im: F = F(0)
    def __post_init__(self):
        object.__setattr__(self,"re",F(self.re))
        object.__setattr__(self,"im",F(self.im))
    def __add__(self,other):
        other=q(other); return Q(self.re+other.re,self.im+other.im)
    __radd__=__add__
    def __neg__(self): return Q(-self.re,-self.im)
    def __sub__(self,other): return self+-q(other)
    def __rsub__(self,other): return q(other)+-self
    def __mul__(self,other):
        other=q(other)
        return Q(self.re*other.re-self.im*other.im,self.re*other.im+self.im*other.re)
    __rmul__=__mul__
    def conjugate(self): return Q(self.re,-self.im)
    def norm2(self): return self.re**2+self.im**2
    def __truediv__(self,other):
        other=q(other); value=self*other.conjugate()
        return Q(value.re/other.norm2(),value.im/other.norm2())
    def __rtruediv__(self,other): return q(other)/self
    def __bool__(self): return bool(self.re or self.im)

def q(value): return value if isinstance(value,Q) else Q(F(value))
ZERO, ONE, II = Q(),Q(1),Q(0,1)

def check(name,proposition):
    assert bool(proposition),name
    checks.append(name)

def trim(poly):
    poly=list(map(q,poly))
    while len(poly)>1 and not poly[-1]: poly.pop()
    return poly

def padd(a,b):
    out=[ZERO]*max(len(a),len(b))
    for j,value in enumerate(a): out[j]+=value
    for j,value in enumerate(b): out[j]+=value
    return trim(out)

def pscale(a,value): return trim([q(value)*x for x in a])

def pmul(a,b):
    out=[ZERO]*(len(a)+len(b)-1)
    for j,x in enumerate(a):
        for k,y in enumerate(b): out[j+k]+=x*y
    return trim(out)

def peval(a,x):
    value=ZERO
    for coefficient in reversed(a): value=value*q(x)+coefficient
    return value

def pprod(values):
    out=[ONE]
    for value in values: out=pmul(out,value)
    return out

def spectrum_gap(depth,spectra):
    lo,hi=depth/3,depth/2
    points=sorted({lo,hi,*(-x for x in spectra if lo<=-x<=hi)})
    left,right=max(zip(points,points[1:]),key=lambda pair:pair[1]-pair[0])
    eta=(left+right)/2
    return eta,min(abs(x+eta) for x in spectra),depth/(12*(len(spectra)+1))

# Largest-gap controls, with repeated eigenvalues and endpoint hits.
for j in range(1,41):
    depth=F(j+2,j+1)
    spectra=[F(k*k-4*j,3*j+1) for k in range(-j,j+1)]
    spectra += [-depth,-depth/3,-depth/2,-depth/3]
    eta,gap,g=spectrum_gap(depth,spectra)
    check(f"spectral_gap_{j}",depth/3<eta<depth/2 and gap>=g)

for kd in range(3,50):
    total=sum(2*(k-2) for k in range(3,kd+1))
    check(f"neutral_spectral_count_{kd}",total==(kd-2)*(kd-1))
    check(f"quadratic_inverse_cost_{kd}",total+1<=kd**2)

# Matched nested model: deep original detector, shallow old first-bad state.
even_entries=[F(-1,100),F(1,2),F(-10)]
odd_entries=[F(2),F(-6),F(3)]
depth=F(9); spectra=[]
for size in range(1,4): spectra.extend(even_entries[:size]+odd_entries[:size])
eta,gap,guaranteed=spectrum_gap(depth,spectra)
first_size=next(size for size in range(1,4)
                if min(even_entries[:size]+odd_entries[:size]) < -eta)
lam=min(even_entries[:first_size]+odd_entries[:first_size])
pre=even_entries[:first_size-1]+odd_entries[:first_size-1]
check("deep_state_original_trial",even_entries[-1]<=-depth)
check("deep_state_preserves_depth",lam<=-eta-gap and -lam>depth/3)
check("both_shifted_predecessors",all(x+eta>=gap for x in pre))
check("actual_eigenvalue_gap",all(x-lam>=2*gap for x in pre))
check("gap_inverse_budget",all(1/(x-lam)<=6*(len(spectra)+1)/depth for x in pre))
mutations.append({"name":"zero_threshold_depth_transfer_fails",
                  "detector_energy":str(even_entries[-1]),
                  "first_zero_threshold_energy":str(even_entries[0]),
                  "rejected":even_entries[0]>-depth/3})

def coefficients(k,numerator):
    out={}
    for n in range(-k,k+1):
        derivative=1
        for m in range(-k,k+1):
            if m!=n: derivative*=n-m
        out[n]=peval(numerator,n)/derivative
    return out

def rational_numerator(u):
    out=[ZERO]
    for n,value in u.items():
        factor=pprod([[Q(-m),ONE] for m in u if m!=n])
        out=padd(out,pscale(factor,value))
    return trim(out)

def moment(u,degree):
    return sum((n**degree*value for n,value in u.items()),ZERO)

def pole_neutral(u):
    numerator=rational_numerator(u)
    return not peval(numerator,II/2) and not peval(numerator,-II/2)

pole=[Q(F(1,4)),ZERO,ONE]
wcomplex=Q(1,F(1,3))
flip_cases=[
    (4,II,pmul(pole,[ONE,ZERO,ONE])),
    (4,wcomplex,pmul(pole,[-wcomplex*wcomplex,ZERO,ONE])),
    (4,II/2,pmul(pole,pole)),
    (5,II/2,pprod([pole,pole,pole]))]
for number,(k,w,numerator) in enumerate(flip_cases):
    u=coefficients(k,numerator)
    v={n:value*(n-w.conjugate())/(n-w) for n,value in u.items()}
    aa=lambda x:(x*x-w*w.conjugate())/(x*x-w*w)
    hh={n:(aa(n)-aa(k))*value for n,value in u.items()}
    nu,nv=rational_numerator(u),rational_numerator(v)
    check(f"flip_transform_{number}",pmul([-w,ONE],nv)==pmul([-w.conjugate(),ONE],nu))
    check(f"flip_norm_{number}",sum(vv.norm2() for vv in v.values())==sum(uu.norm2() for uu in u.values()))
    check(f"flip_legal_moments_{number}",all(not moment(v,j) for j in range(3)))
    check(f"flip_pole_neutral_{number}",pole_neutral(v))
    check(f"shell_legal_moments_{number}",all(not moment(hh,j) for j in range(3)))
    check(f"shell_pole_neutral_{number}",pole_neutral(hh))
    check(f"shell_endpoint_and_nonzero_{number}",not hh[k] and not hh[-k] and any(hh.values()))
    nf,df=[-w.conjugate(),ONE],[-w,ONE]
    check(f"real_axis_modulus_{number}",pmul(nf,[x.conjugate() for x in nf])==pmul(df,[x.conjugate() for x in df]))
    seed={n:-value/(n*n+F(1,4)) for n,value in u.items()}
    check(f"seed_five_jets_{number}",all(not moment(seed,j) for j in range(5)))
    check(f"seed_P_identity_{number}",all(-(n*n+F(1,4))*seed[n]==u[n] for n in u))

# Stronger endpoint carriers: direct Gaussian-rational ranks and zero flips.
def rank_exact(rows):
    rows=[list(map(q,row)) for row in rows]
    if not rows: return 0
    pivot=0
    for column in range(len(rows[0])):
        found=next((j for j in range(pivot,len(rows)) if rows[j][column]),None)
        if found is None: continue
        rows[pivot],rows[found]=rows[found],rows[pivot]
        divisor=rows[pivot][column]
        rows[pivot]=[value/divisor for value in rows[pivot]]
        for j in range(len(rows)):
            if j==pivot or not rows[j][column]: continue
            factor=rows[j][column]
            rows[j]=[value-factor*base for value,base in zip(rows[j],rows[pivot])]
        pivot+=1
        if pivot==len(rows): break
    return pivot

for k,m in [(2,2),(4,3),(4,7),(7,6),(8,9),(9,12)]:
    dims=[]
    for parity in [1,-1]:
        basis=[]
        for n in range(0 if parity==1 else 1,k+1):
            vector={j:ZERO for j in range(-k,k+1)}
            vector[n]=ONE
            if n: vector[-n]=Q(parity)
            basis.append(vector)
        rows=[[moment(v,j) for v in basis] for j in range(m+1)]
        rows.append([sum((value/(II/2-n) for n,value in v.items()),ZERO) for v in basis])
        dims.append(len(basis)-rank_exact(rows))
    expected=[max(0,k-m//2-1),max(0,k-(m+1)//2-1)]
    check(f"high_jet_exact_constraint_rank_K{k}_m{m}",dims==expected)
    total=sum(max(0,j-m//2-1)+max(0,j-(m+1)//2-1) for j in range(k+1))
    closed=sum(d*(d+1)//2 for d in expected)
    check(f"high_jet_spectral_count_K{k}_m{m}",total==closed and total+1<=max(1,k*k))

high_cases=[(7,6,II,pmul(pole,[ONE,ZERO,ONE])),
            (8,9,wcomplex,pmul(pole,[-wcomplex*wcomplex,ZERO,ONE])),
            (8,7,II,pmul([ZERO,ONE],pmul(pole,[ONE,ZERO,ONE]))),
            (8,8,II/2,pmul(pole,pole))]
for number,(k,m,w,numerator) in enumerate(high_cases):
    u=coefficients(k,numerator)
    v={n:value*(n-w.conjugate())/(n-w) for n,value in u.items()}
    aa=lambda x:(x*x-w*w.conjugate())/(x*x-w*w)
    shell={n:(aa(n)-aa(k))*value for n,value in u.items()}
    seed={n:-value/(n*n+F(1,4)) for n,value in u.items()}
    check(f"high_jet_original_and_flip_moments_{number}",
          all(not moment(vector,j) for vector in [u,v] for j in range(m+1)))
    check(f"high_jet_shell_and_poles_{number}",
          all(not moment(shell,j) for j in range(m+1)) and pole_neutral(v) and pole_neutral(shell)
          and not shell[k] and not shell[-k] and any(shell.values()))
    check(f"high_jet_compact_seed_mplus2_{number}",all(not moment(seed,j) for j in range(m+3)))
    check(f"compact_inverse_L2_bound_{number}",
          sum(value.norm2() for value in seed.values())<=16*sum(value.norm2() for value in u.values()))

# Flipping a SIMPLE mandated pole is inadmissible.
u=coefficients(3,pole); w=II/2
v={n:value*(n-w.conjugate())/(n-w) for n,value in u.items()}
mutations.append({"name":"simple_pole_flip_destroys_constraint","rejected":not pole_neutral(v)})

def mm(a,b):
    return [[sum((a[i][k]*b[k][j] for k in range(len(b))),ZERO)
             for j in range(len(b[0]))] for i in range(len(a))]
def adj(a):
    return [[a[j][i].conjugate() for j in range(len(a))] for i in range(len(a[0]))]
def madd(a,b):
    return [[a[i][j]+b[i][j] for j in range(len(a[0]))] for i in range(len(a))]
def mscale(a,value): return [[value*x for x in row] for row in a]
def quad(a,v): return mm(adj(v),mm(a,v))[0][0]
def matrix(rows): return [[q(x) for x in row] for row in rows]

P=matrix([[F(3,2),F(1,3)],[F(1,3),F(5,2)]])
det=P[0][0]*P[1][1]-P[0][1]*P[1][0]
Pinv=mscale([[P[1][1],-P[0][1]],[-P[1][0],P[0][0]]],1/det)
B=matrix([[ONE+II,F(2,3)],[-II,2]])
DD=matrix([[F(-11,2),II],[-II,F(-7,3)]])
x=matrix([[Q(F(1,4),1)],[F(-3,5)]])
y=matrix([[Q(F(2,3),-1)],[F(1,2)]])
Sigma=madd(DD,mscale(mm(adj(B),mm(Pinv,B)),-1))
shifted=madd(x,mm(Pinv,mm(B,y)))
cross=mm(adj(x),mm(B,y))[0][0]
left=quad(P,x)+cross+cross.conjugate()+quad(DD,y)
right=quad(P,shifted)+quad(Sigma,y)
check("complex_same_detector_schur_identity",left==right)
check("positive_predecessor_control",P[0][0].re>0 and det.re>0 and not det.im)
mutations.append({"name":"dropping_detector_response_changes_energy",
                  "rejected":left!=quad(P,x)+quad(Sigma,y)})

Hc=matrix([[7,2,0],[2,-3,0],[0,0,4]])
uc,Vc=matrix([[0],[1],[0]]),matrix([[1],[0],[0]])
residual=madd(mm(Hc,uc),mscale(uc,3))
check("constrained_KKT_residual",residual==mscale(Vc,2) and not mm(adj(Vc),uc)[0][0])
mutations.append({"name":"constrained_ground_is_not_unrestricted_eigenvector",
                  "rejected":any(row[0] for row in residual)})

# Exact multivariate identity for the jointly paired mandatory-pole quotient.
# Coordinates are (x,y,h); all coefficients are rational.
def ma(a,b):
    out=dict(a)
    for powers,value in b.items(): out[powers]=out.get(powers,F(0))+value
    return {powers:value for powers,value in out.items() if value}
def ms(a,c): return {powers:value*c for powers,value in a.items() if value*c}
def mt(a,b):
    out={}
    for pa,va in a.items():
        for pb,vb in b.items():
            powers=tuple(x+y for x,y in zip(pa,pb))
            out[powers]=out.get(powers,F(0))+va*vb
    return {powers:value for powers,value in out.items() if value}
mc=lambda c:{(0,0,0):F(c)}
xx,yy,hh={(1,0,0):F(1)},{(0,1,0):F(1)},{(0,0,1):F(1)}
y2=mt(yy,yy)
def paired_modulus(x):
    x2=mt(x,x)
    minus=ma(y2,mc(F(-1,4)))
    plus=ma(y2,mc(F(1,4)))
    return ma(ma(mt(x2,x2),ms(mt(x2,minus),2)),mt(plus,plus))
lhs=ma(paired_modulus(ma(xx,hh)),ms(paired_modulus(xx),-1))
bracket=ma(ma(ma(ms(mt(xx,xx),2),ms(mt(xx,hh),2)),mt(hh,hh)),
           ma(ms(y2,2),mc(F(-1,2))))
rhs=mt(mt(hh,ma(ms(xx,2),hh)),bracket)
check("paired_pole_shift_polynomial_identity",lhs==rhs)
check("three_quarters_joint_contraction",
      F(3,4)**2-F(1,2)>0 and F(1,4)**2<((F(3,4)**2)-F(1,4))**2)
check("three_quarters_individual_right_factor_increases",
      F(1,2)**2>(F(3,4)-F(1,2))**2)
mutations.append({"name":"three_fifths_pole_pair_is_not_contractive_at_zero",
                  "rejected":F(1,4)**2>((F(3,5)**2)-F(1,4))**2,
                  "scope":"exact rational pair only; native sharpness uses Q_r(h)->1 analytically"})

check("all_mutations_rejected",all(x["rejected"] for x in mutations))
report={"status":"PASS","scope":"exact finite algebra only; no RH closure or Lean claim",
        "checks":len(checks),"check_names":checks,"mutation_falsifiers":mutations,
        "threshold_model":{"eta":str(eta),"gap":str(gap),
                           "guaranteed_gap":str(guaranteed),
                           "selected_cutoff":first_size+2,"lambda":str(lam)}}
(HERE/"DEEP_STATE_EXACT_CONTROLS.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({key:report[key] for key in ["status","scope","checks","mutation_falsifiers","threshold_model"]},indent=2))
