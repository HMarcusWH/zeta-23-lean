# A detector-preserving deep threshold state

Date: 2026-10-13. Status: **NEW PAPER DERIVATION**. This is a new state construction, not a new assertion about the repository's zero-threshold `GlobalBottomResidualState`. Step 4 remains open.

## 1. The data are retained before a new minimization is made

Fix the actual nontrivial off-line zero used by Step 1, the actual real even pole-killed detector `k`, its radius and normalization, the two-lobe separation, and its selected reflection sign. Write the resulting normalized physical trial as

\[
 f_{a,\sigma}(x)=\frac{k(x-a)+\sigma k(x+a)}{\sqrt{2\|k\|_2^2}},
 \qquad \sigma\in\{1,-1\}.
\]

The lobes are disjoint, and the exact contraction identity is

\[
 Q(f_{a,\sigma})=
 \frac{Q(k)+\sigma W(\tau_{2a}k,k)}{\|k\|_2^2}.
\]

The original phase `sigma` is part of the state. It is not redefined after spectral minimization. Both pole values vanish. All fixed derivative norms are independent of `a`. For the universal sinc-product detector used in this campaign, the new analytic branch's source-preserving finite bridge supplies the actual boundary-repaired trial `p`, including its coefficients, correction, normalization, and quantitative error. The older v2.9 proof supplies the Fourier and growing-form mechanism for its separately constructed Gevrey bump; it must not be cited as having already established this universal detector's complete bridge. The exact input needed below is:

\[
 p\in V_{L,K_d}^{\rm pn},\quad \|p\|_2=1,\quad
 K_d=\lceil L^4\rceil,\quad Q(p)\le-D,
 \qquad D>0.                                      \tag{1.1}
\]

Along the cofinal detector sequence one can take `D=exp(delta L)` for some fixed `delta>0`, after discarding an initial range. Here `pn` means both exact pole constraints, not only the three boundary coefficient moments. The finite bridge's approximation estimate, allowing its stated fixed polynomial prefactor, is of the form

\[
 \|p-f_{a,\sigma}\|_{H^1}
 \le C_kL^{A_k}e^{-c_k\sqrt{K_d/L}}
\]

up to its explicitly accounted normalization term, for a fixed exponent `A_k`. The new bridge's positive-lobe correction can increase this polynomial prefactor relative to the old five-jet correction. Its stretched-exponential factor still beats the full growing form norm at the stated quartic cutoff. Nothing below substitutes a generic negative vector for these data.

The new selection changes the spectral threshold from zero to a negative number comparable with `D`. This is necessary because minimization at the first *zero*-threshold bad cutoff is known to lose `D`.

## 2. The exact carriers and pole-neutral dimensions

Use the centered source convention

\[
 f_u(x)=L^{-1/2}\mathbf1_{[-L/2,L/2]}(x)
 \sum_{n=-K}^{K}(-1)^n u_ne^{i\omega_nx},
 \qquad \omega_n=2\pi n/L.
\]

The legal carrier is

\[
 V_{L,K}=\{u:\sum_n n^j u_n=0\ (j=0,1,2)\}.
\]

Its inner product is the physical `L^2` inner product, so `||f_u||_2=||u||_2`. Let

\[
 \ell_\pm(u)=\int f_u(x)e^{\pm x/2}\,dx,
 \qquad V_{L,K}^{\rm pn}=V_{L,K}\cap\ker\ell_+\cap\ker\ell_-.
\]

All these spaces embed exactly under padding by zeros. Reflection decomposes the legal carrier into even and odd spaces, each of complex dimension `K-1` for `K>=2`. On either parity, the two pole constraints reduce to one nonzero linear functional. Nonvanishing follows already from the `K=2` legal source transforms, whose rational numerators are a nonzero constant in the even sector and a nonzero multiple of `z` in the odd sector. Neither vanishes at `z=+/-i/2`. Thus

\[
 \dim V_{L,K}^{\rm pn,+}=\dim V_{L,K}^{\rm pn,-}=K-2
 \quad(K\ge2).                                      \tag{2.1}
\]

In particular the pole-neutral carrier at `K=2` is zero. Each parity adds exactly one dimension at each subsequent cutoff. This is the right carrier for preserving the detector's pole killing under ground selection.

Let `H_K^pn` denote the genuine Hermitian Weil compression to the full pole-neutral carrier, including both parities. Its spectrum is a finite real multiset. All spectral minima below are minima over **both** parity sectors. Restricting minimization to the detector's original parity would not justify zero-flip rigidity, because a zero flip can have components in both parities.

## 3. Choose a deep threshold with a quantitative common spectral gap

Let `S` be the multiset union of the spectra of `H_K^pn` for `3<=K<=K_d`. By (2.1), its cardinality, counting repetitions, is

\[
 M=\sum_{K=3}^{K_d}2(K-2)=(K_d-2)(K_d-1).             \tag{3.1}
\]

Consider the finite numbers `-lambda` from these spectra that fall in `[D/3,D/2]`, and adjoin the two interval endpoints. These numbers cut an interval of length `D/6` into at most `M+1` gaps. Choose the midpoint `eta` of a longest gap. Then

\[
 D/3<\eta<D/2,\qquad
 \operatorname{dist}(-\eta,S)\ge
 g:=\frac{D}{12(M+1)}.                                \tag{3.2}
\]

Coincident eigenvalues only reduce the number of gaps. Eigenvalues outside the interval cannot be closer to its chosen midpoint than the nearer adjoined endpoint, so (3.2) controls the entire spectra, not just the points inside the interval. The choice is finite and exact; no numerical eigenvalue approximation is invoked.

Since the actual trial (1.1) has energy at most `-D`, the global pole-neutral minimum at `K_d` is at most `-D<-eta`. Let `K_eta` be the least cutoff whose pole-neutral global minimum is below `-eta`. Then

\[
 3\le K_\eta\le K_d.                                  \tag{3.3}
\]

Let `u` be a normalized definite-parity eigenvector at the global minimum `lambda` of `H_{K_eta}^pn`. Both parity predecessor compressions satisfy

\[
 P+\eta I\succeq gI,
 \qquad \lambda\le-\eta-g.                            \tag{3.4}
\]

The first assertion uses minimality to exclude eigenvalues below `-eta` at the predecessor, and the common gap to exclude the interval `[-eta-g,-eta+g]`. The second uses the same gap at the successor. Put `mu=-lambda`. Then

\[
 \mu\ge\eta+g>D/3,
 \qquad P-\lambda I=P+\mu I\succeq2gI.
\]

Consequently

\[
 \boxed{\|(P-\lambda I)^{-1}\|\le
 \frac{6(M+1)}{D}.}                                   \tag{3.5}
\]

This bound applies to each nonzero parity predecessor; the inverse on a zero-dimensional space has its usual empty meaning. It has an exponential gain along the detector sequence:

\[
 \|(P-\lambda I)^{-1}\|
 \le O(L^8e^{-\delta L}).                              \tag{3.6}
\]

Thus the same augmented state carries the original detector and its phase, its exact finite approximation, a ground with comparable exponential negative depth, both shifted positive predecessors, and a quantitatively controlled predecessor inverse. These properties were not simultaneously supplied by the old zero-threshold state.

This construction does not claim unshifted predecessor positivity. It also does not identify `u` with `p`. The construction history is retained as a tuple with exact maps and identities, rather than collapsed into a false equality.

## 4. Zero-flip descent with the pole constraints retained

Define

\[
 F_u(z)=\int f_u(x)e^{-izx}\,dx
 =\frac{2}{\sqrt L}\sin(zL/2)R_u(z),
 \qquad R_u(z)=\sum_n\frac{u_n}{z-\omega_n}.             \tag{4.1}
\]

The legal moments are equivalent to `R_u(z)=O(z^-4)` at infinity. Let `w` be a nonreal zero of `F_u`. Since the sine factor has only real zeros, `R_u(w)=0`. The exact finite zero flip is

\[
 (T_wu)_n=u_n\frac{\omega_n-\overline w}{\omega_n-w},
 \quad F_{T_wu}(z)=\frac{z-\overline w}{z-w}F_u(z).      \tag{4.2}
\]

Partial fractions prove (4.2); the factor tends to one at infinity, so all three legal moments remain zero. Its modulus on each real `omega_n` is one, hence coefficient norm is preserved. Its modulus on the real Fourier line is also one, so the complete autocorrelation and the genuine Weil form are preserved. These are the inherited exact source identities, including all native arithmetic channels.

If `w` is different from `+/-i/2`, the multiplier in (4.2) is finite and nonzero at both mandatory pole zeros. Thus `T_wu` remains in the **same pole-neutral carrier**. Since `H_{K_eta}^pn-lambda I` is positive semidefinite on that entire carrier, equality of energy and norm makes `T_wu` another `lambda` eigenvector there. Both parity projections remain `lambda` eigenvectors.

Write `pi` for the selected parity of `u`, and set

\[
 A_w(z)=\frac{z^2-|w|^2}{z^2-w^2}.
\]

The parity-`pi` projection of `T_wu` has coefficient `A_w(omega_n)u_n`. Therefore

\[
 h_n=\bigl(A_w(\omega_n)-A_w(\omega_{K_\eta})\bigr)u_n  \tag{4.3}
\]

is a legal pole-neutral `lambda` eigenvector with both extreme coefficients zero. Its remaining coefficients are in `V_{L,K_eta-1}^pn` at the **same** physical aperture.

The vector is nonzero. As a function of `z^2`, `A_w` is a nonconstant linear-fractional function because `w^2-|w|^2 != 0` for nonreal `w`. Thus `A_w(omega_n)=A_w(omega_K)` only at `n^2=K^2`. If (4.3) vanished, `u` would be supported only at the two endpoints. The zeroth legal moment in even parity, or first legal moment in odd parity, then forces `u=0`. This contradicts normalization. There are no zero denominators because every `omega_n` is real.

Exact cutoff compatibility gives

\[
 Q(h)=\lambda\|h\|_2^2< -\eta\|h\|_2^2,
\]

contradicting the predecessor bound (3.4). Thus no nonreal zero other than the mandatory pair is possible.

The same argument applies at `w=i/2` if its multiplicity in `F_u` is at least two. Parity supplies the same multiplicity at `-i/2`. A single flip lowers the multiplicity at one pole by one, increases it at the other by one, and still leaves both pole constraints intact. The parity projection and (4.3) retain at least one zero at each pole. The same descent contradiction follows. Hence both mandated nonreal zeros are simple.

We have proved

\[
 \boxed{F_u(z)=(z^2+1/4)G(z),\qquad
 \text{every zero of }G\text{ is real}.}               \tag{4.4}
\]

The quotient is entire, nonzero, and has the same support type. Real coefficients for the physical source can be chosen because the native form, the pole-neutral carrier, and reflection commute with conjugation. If the selected parity is tied with the other parity, the proof is unchanged: global shifted positivity, not strict parity selection, is what it uses.

For comparison, repeating the entire selection on unrestricted legal carriers gives `M=K_d(K_d-1)` and proves that its selected ground transform has only real zeros. It preserves depth but loses neutrality. Equation (4.4) is the variant that retains the detector's mandatory pole zeros and must be used with its constrained Euler equation.

## 5. The actual compact seed and its five endpoint jets

The quotient (4.4) corresponds to a same-cutoff seed. Let

\[
 g_n=-\frac{u_n}{\omega_n^2+1/4},\qquad
 g(x)=L^{-1/2}\mathbf1_{[-L/2,L/2]}(x)
 \sum_n(-1)^ng_ne^{i\omega_nx}.                         \tag{5.1}
\]

The two pole constraints, expressed through (4.1), imply

\[
 \sum_n\frac{u_n}{\omega_n^2+1/4}=0,\qquad
 \sum_n\frac{\omega_nu_n}{\omega_n^2+1/4}=0.            \tag{5.2}
\]

Thus `g` and `g'` vanish at both endpoints. In the interior,

\[
 (\partial_x^2-1/4)g=f_u.
\]

The three legal endpoint jets of `f_u` and this differential equation give, successively, zero endpoint jets of `g` through order four. Consequently its zero extension is `C^4`, and the displayed differential identity has no boundary delta terms. Its entire transform is

\[
 \widehat g(z)=-G(z).
\]

Hence the constrained deep ground has an explicit compact, same-cutoff, boundary-flat seed whose transform has only real zeros. This does **not** prove that `g` is nonnegative or that it equals the original Gevrey seed. A real-rooted Fourier transform alone supplies neither assertion.

The original seed and the new seed can be recorded simultaneously, together with the original approximation error. There is currently no proved norm or pointwise comparison between them. This is the remaining distinction, not an omitted definition.

## 6. The exact Euler residual is part of the new state

Let `H_K` be the genuine compression to the unrestricted legal carrier, and let `V: C^2 -> V_{L,K}` be the Riesz map for the two pole functionals, so that `V^*u=(ell_+(u),ell_-(u))`. Since the constrained ground is stationary only against vectors in `ker V^*`, its exact equation is

\[
 \boxed{(H_K-\lambda I)u=V\alpha,\qquad V^*u=0}         \tag{6.1}
\]

for a unique vector of multipliers `alpha` after the two functionals are expressed in an independent even/odd basis. Within a fixed parity only one multiplier is present. A convenient physical Riesz vector is the legal projection of `cosh(x/2)` in even parity or `sinh(x/2)` in odd parity.

The explicit pole operator itself vanishes on `u`, since both pole values of `u` are zero. This does not make `alpha` zero: the Archimedean and prime parts may have nonzero projections onto the pole directions. The equation is an exact finite **compression** statement. In physical coordinates it reads

\[
 \Pi_{V_{L,K}}(W*f_u-\lambda f_u)
 =\alpha_+\Pi_{V_{L,K}}e^{x/2}
  +\alpha_-\Pi_{V_{L,K}}e^{-x/2}.                        \tag{6.2}
\]

An additional Galerkin residual lies orthogonally to the legal finite carrier. Equation (6.2) must not be promoted to a pointwise interior differential equation. A full continuous constrained contact can remove that Galerkin residual, but doing so is a separate construction, not a consequence of the finite statement.

The KKT matrix recording all retained information is

\[
 \begin{pmatrix}H_K-\lambda I&-V\\ V^*&0\end{pmatrix}
 \binom{u}{\alpha}=0.                                  \tag{6.3}
\]

This is the correct source equation to pass to Paths A and B. Omitting `V alpha` would manufacture an unrestricted ground and invalidate precisely the pole-preserving improvement.

## 7. The same detector drives an exact Schur inequality

At the original `K_d`, decompose the pole-neutral carrier orthogonally into the full two-parity predecessor

\[
 V_{L,K_\eta-1}^{\rm pn}\oplus Y.
\]

Write the *actual original finite trial* as `p=x+y`. All components are retained, including its phase, coefficients, and exact moment constraints. In this splitting the shifted native compression is

\[
 H_{K_d}^{\rm pn}+\eta I=
 \begin{pmatrix}P_\eta&B\\ B^*&D_\eta\end{pmatrix},
 \qquad P_\eta\succeq gI.
\]

Define the exact Schur complement

\[
 \Sigma_\eta=D_\eta-B^*P_\eta^{-1}B.
\]

Completion of the square gives

\[
 Q(p)+\eta
 =\|P_\eta^{1/2}(x+P_\eta^{-1}By)\|_2^2
  +\langle y,\Sigma_\eta y\rangle.
\]

Since `Q(p)<=-D` and `eta<D/2`,

\[
 \boxed{\langle y,\Sigma_\eta y\rangle<-D/2.}           \tag{7.1}
\]

In particular `y!=0`. This identity keeps the original detector vector as the input to the Schur problem. The correction `P_eta^-1 B y` is actual native data and has a controlled inverse factor `||P_eta^-1||<=12(M+1)/D`. No overlap between `p` and an arbitrarily selected ground was assumed.

At the selected ground cutoff, each parity adds only one dimension. On its selected parity the exact ground equation instead gives

\[
 d+\mu=c^*(P+\mu I)^{-1}c,
 \qquad u\ \propto\ \binom{-(P+\mu I)^{-1}c}{1}.        \tag{7.2}
\]

Here the predecessor and shell are inside the **pole-neutral** carrier. Its basis, source map, and multipliers from (6.1) remain part of the construction. Applying an unrestricted-shell formula without rederiving this basis change would be invalid.

## 8. What this gains, and the unclosed inequality

The previous first-bad reduction asked for control of a possibly very small predecessor gap while losing the detector's negative depth. The new selection trades a harmless polynomial spectral-counting factor for a threshold proportional to the known detector depth. Its inverse estimate (3.5) is an actual proved upper bound, not a new premise.

The unclosed part is the signed native Schur energy in (7.1), or an equivalent lower bound on the real-rooted pole-neutral seed class (4.4)-(5.2). The elementary norm estimate for the native matrix is of size at most a polynomial times `exp(L/2)`. Thus the crude response estimate

\[
 \|B^*P_\eta^{-1}B\|\le
 \frac{12(M+1)}{D}\|B\|^2
\]

can still have size `poly(L) exp((1-delta)L)` along `D=exp(delta L)`. For `delta<1/2`, it does not beat `D`. The exponentially small inverse by itself does not close Step 4. The diagonal term `D_eta` is also signed; no positivity is assumed for it.

A sufficient genuinely new next estimate would bound the **actual detector-driven** negative Schur energy in (7.1) by a subexponential function of `L`, using the exact arithmetic source and the constrained seed information. That estimate is not proved here. Alternatively, a subexponential lower bound for every generated deep-threshold seed satisfying (4.4)-(6.3) would contradict (1.1)-(3.4). These are narrower states than generic contacts, but the independent sign is still required.

## 9. Source dependencies

The inherited proofs were reread directly from the following unchanged files:

- `review/project_steps/34-RH_Research_Master_v2_9_Three_Path_Spectral_Pressure_Point_2026-10-12/RH_Research_Master_v2_9_Three_Path_Spectral_Pressure_Point/08_POST_V26_SOURCE/STRATEGY_PACKET_EXTRACTED/01_Detector_Provenance_and_Polynomial_Cutoff.txt`: actual phase, normalized two-lobe source, exact pole-neutral finite repair, quartic cutoff, energy budget, and the old depth-loss issue.
- The adjacent `02_Generated_State_Provenance_Audit.txt`: distinction between a generated detector, retained first-bad ground, and compressed versus full source equation.
- `review/project_steps/35-RH_Three_Path_Round1_Review_and_Round2_Handoff_2026-10-12/04_EXTRACTED_SOURCES/4C/invariants/ZERO_FLIP_MULTIPLICITY_AND_PROVENANCE_AUDIT.md`: exact zero flip, shell cancellation, its nonvanishing proof, and the known pole-neutral trial versus unrestricted ground counterexample.
- The same package's `dependencies/V25_PAPER_T1_ADDITIVE_WEIL_AND_FORM_CORE.md`: exact centered source normalization and full native autocorrelation form identity.

No literature result asserting the missing RH-strength estimate has been imported. The new deductions are finite spectral separation, constrained minimization, and exact source algebra on these inherited native identities.

The universal detector's positive-lobe finite bridge is the new paper proof in `source_transport/01_UNIVERSAL_DETECTOR_FINITE_BRIDGE.md`. The exact refinement and normalized depth transfer are in `detector_arithmetic/01_POSITIVE_REFINEMENT_AND_PHASE_DEPTH.md`. They are present-campaign dependencies, not inherited v2.9 theorems. The state theorem above starts from their explicit input (1.1) and does not depend on which valid finite bridge produces it. The optional stronger endpoint carrier is treated separately in `contact_provenance/03_HIGH_JET_DEEP_STATE_AND_DIRECT_SOURCE_BRIDGE.md`.
