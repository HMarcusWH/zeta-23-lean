# The actual universal detector in the prescribed finite carrier

Date: 13 October 2026. Status: **new paper proof, conditional on the inherited native Weil dictionary and universal-detector construction. It does not prove Step 4 or assert a new formal Lean result.**

This note preserves the original detector, its two-translate phase, its scale, exact pole neutrality, and the nonnegative precursor of the even branch while passing to the canonical Fourier cutoff \(K(L)=\lceil L^4\rceil\). The estimates are uniform enough to allow detector scales of order \(A/L\), for one sufficiently large fixed constant \(A\). The positive-precursor construction avoids changing an endpoint correction into an untracked sign perturbation.

## 1. Original source and native form

Use \(\widehat f(z)=\int_{\mathbb R}f(x)e^{izx}\,dx\) and \(P=\partial_x^2-1/4\). For \(0<s\le1\), the inherited universal detector is

\[
q_s=*_{j\ge1}\frac{\mathbf 1_{[-s/(j(j+1)),\,s/(j(j+1))]}}
 {2s/(j(j+1))},\qquad
k_s=Pq_s .
\tag{1.1}
\]

Thus \(q_s\) is a real, even, nonnegative \(C^\infty\) probability density, with support \([-s,s]\), and

\[
q_s(x)=s^{-1}q_1(x/s),\qquad
\widehat q_s(z)=P_s(z)=\prod_{j\ge1}\operatorname{sinc}\!\left(\frac{sz}{j(j+1)}\right).
\tag{1.2}
\]

The product has only real zeros. Consequently \(\widehat k_s(z)=-(z^2+1/4)P_s(z)\) has just the two elementary nonreal zeros \(\pm i/2\), each simple. This is a property of the exact smooth detector, not automatically of its finite approximation.

Let \(n_s=\|k_s\|_2^2\). Integration by parts and scaling give the exact identity

\[
n_s=s^{-5}\|q_1''\|_2^2+
 \frac12s^{-3}\|q_1'\|_2^2+
 \frac1{16}s^{-1}\|q_1\|_2^2 .
\tag{1.3}
\]

In particular there are absolute positive constants \(c_n,C_n,C_H\) such that

\[
c_ns^{-5}\le n_s\le C_ns^{-5},\qquad
\frac{\|k_s\|_{H^1}}{\sqrt{n_s}}\le C_Hs^{-1}
\quad(0<s\le1).
\tag{1.4}
\]

On \([0,L]\), choose \(L\ge4\), \(a>s\), and \(a+s\le L/2-1\). Write

\[
x_\pm=L/2\pm a,\quad
q_\pm(x)=q_s(x-x_\pm),\quad
f_\sigma=\frac{Pq_++\sigma Pq_-}{\sqrt{2n_s}},
\qquad \sigma\in\{+1,-1\}.
\tag{1.5}
\]

The two lobes are disjoint and have unit collars from the two endpoints. Thus \(\|f_\sigma\|_2=1\), reflection about \(L/2\) has eigenvalue \(\sigma\), and the primitive

\[
g_\sigma=(q_++\sigma q_-)/\sqrt{2n_s},\qquad f_\sigma=Pg_\sigma
\tag{1.6}
\]

is nonnegative when \(\sigma=+1\). With \(C_s(t)=\mathfrak q(\tau_tk_s,k_s)\) and \(q_0(s)=C_s(0)\), the actual Rayleigh quotient is

\[
\mathfrak q(f_\sigma,f_\sigma)
=\frac{q_0(s)+\sigma C_s(2a)}{n_s}.
\tag{1.7}
\]

Here the spectral representation of \(C_s\) contains \(\widehat k_s(\gamma_\rho)^2\), not its absolute square. This construction retains the real sign \(\sigma\) selected by the original two-lobe phase.

The inherited full native form obeys, on sources supported in an interval of length \(L\ge1\),

\[
|\mathfrak q(F,G)|
\le C_Q(1+L)e^{L/2}\|F\|_{H^1(\mathbb R)}
                              \|G\|_{H^1(\mathbb R)}.
\tag{1.8}
\]

This bound pays for approximation error. Its proof uses the native archimedean multiplier, the exact pole terms, and only \(\Lambda(n)\le\log n\) in the finite prime-power sum. It is not the unresolved Step 4 upper estimate.

## 2. Uniform Gevrey control for this exact source

The inherited sinc-product bound, with \(c_*=(\log2)/2\), is

\[
|P_s(z)|\le2e^{s|\Im z|}e^{-c_*\sqrt{s|z|}} .
\tag{2.1}
\]

Fourier inversion on the real line gives

\[
\|q_s^{(m)}\|_\infty
\le\frac{4(2m+1)!}{\pi c_*^{\,2m+2}s^{m+1}} .
\tag{2.2}
\]

Since the support has length \(2s\), and
\((2m+1)!\le12^m(m!)^2\), including \(m=0\), it follows that

\[
\|q_s^{(m)}\|_1\le
C_0(A_0/s)^m(m!)^2,\qquad
C_0=\frac8{\pi c_*^2},\quad A_0=\frac{12}{c_*^2}.
\tag{2.3}
\]

All subsequent constants are independent of \(a,L,s,\sigma\), unless a dependence is explicitly indicated. This uniformity is the part needed when the scale shrinks with the aperture.

## 3. A positive endpoint correction at finite cutoff

Set

\[
B_L(x)=\sin^6(\pi x/L).
\tag{3.1}
\]

This is a nonnegative real trigonometric polynomial of degree three in the \(L\)-periodic Fourier basis. It has zeros of order six at both endpoints. Define \(a_\pm=q_\pm/B_L\) on the support of \(q_\pm\), and zero elsewhere, then extend periodically. These are smooth nonnegative periodic functions and satisfy \(a_-(x)=a_+(L-x)\).

For a real \(x\in[1,L-1]\), the complex disk \(|z-x|\le1/4\) lies in the region \(3/4\le\Re z\le L-3/4\). Since

\[
|\sin(\pi z/L)|\ge|\sin(\pi\Re z/L)|
\ge \sin(3\pi/(4L))\ge\frac3{2L},
\tag{3.2}
\]

Cauchy's inequality gives

\[
|(B_L^{-1})^{(m)}(x)|\le (2L/3)^6\,4^m m!.
\tag{3.3}
\]

Leibniz's rule and (2.3), using \(m+1\le2^m\) for \(m\ge1\), now imply

\[
\|a_\pm^{(m)}\|_1\le C L^6(A_1/s)^m(m!)^2
\tag{3.4}
\]

for example with \(A_1=2\max(A_0,4)\), after increasing \(C\) for \(m=0\).

Let \(a_{\pm,n}=L^{-1}\int_0^La_\pm(x)e^{-2\pi inx/L}\,dx\). Repeated integration by parts in (3.4), with
\(m=\lfloor\sqrt{s|2\pi n/L|/(4A_1)}\rfloor\), yields

\[
|a_{\pm,n}|\le C L^5e^{-c\sqrt{s|n|/L}}.
\tag{3.5}
\]

The bounded range where the displayed integer is zero is absorbed in \(C\).
Let \(S_N\) be symmetric Fourier truncation to \(|n|\le N\). For \(sN/L\ge1\), summation of (3.5) gives

\[
\|S_Na_\pm-a_\pm\|_\infty
\le \varepsilon_{s,L,N},\qquad
\varepsilon_{s,L,N}:=C L^6s^{-1}
 e^{-c_1\sqrt{sN/L}},
\tag{3.6}
\]

with the same upper bound for both signs. The constants can be fixed from (3.3)–(3.5); their numerical optimization is immaterial to the asymptotic theorem.

Define

\[
g_{\pm,N}=B_L(S_Na_\pm+\varepsilon_{s,L,N}),\qquad
g_{\sigma,N}=\frac{g_{+,N}+\sigma g_{-,N}}{\sqrt{2n_s}},
\quad f_{\sigma,N}=Pg_{\sigma,N}.
\tag{3.7}
\]

This construction has the following exact properties.

- \(g_{\pm,N}\ge0\). The common padding in (3.7) makes the truncated quotient nonnegative at every point.
- \(g_{-,N}(x)=g_{+,N}(L-x)\). Both the reality and the original parity \(\sigma\) are exact.
- The common padding cancels exactly in the odd difference. In the even sum it remains nonnegative.
- Every endpoint jet of \(g_{\pm,N}\) of order \(0,\ldots,5\) vanishes. Therefore \(f_{\sigma,N}\) has endpoint jets \(0,\ldots,3\) equal to zero.
- The cutoff of \(g_{\sigma,N}\), and of \(f_{\sigma,N}\), is at most \(N+3\). Applying \(P\) multiplies each coefficient by \(-((2\pi n/L)^2+1/4)\) and adds no frequency.
- The zero extension of \(f_{\sigma,N}\) is \(C^3\), and in particular lies in the exact legal \(C^2\) canonical carrier. No \(C^\infty\) claim is made for this zero extension.
- Since \(g_{\sigma,N}\) and its first derivative vanish at both endpoints, integration by parts gives

\[
\int_0^L f_{\sigma,N}(x)e^{x/2}\,dx
=\int_0^L f_{\sigma,N}(x)e^{-x/2}\,dx=0.
\tag{3.8}
\]

Thus pole neutrality is exact, rather than an approximation tolerance.

The finite source need not retain the real-zero-only divisor of the original \(P_s\). This construction does not declare that the finite vector is the canonical ground, the first-bad state, or a full-operator eigenfunction.

## 4. Error, including scale and normalization

For \(k=2,3\), Parseval and (3.5) give

\[
\|S_Na_\pm-a_\pm\|_{H^k(0,L)}
\le C L^6s^{-k-1/2}e^{-c_1\sqrt{sN/L}}.
\tag{4.1}
\]

For completeness, the square of the left side is bounded by a constant times

\[
L^{11}\sum_{|n|>N}(1+(n/L)^2)^k
 e^{-2c\sqrt{s|n|/L}}.
\tag{4.2}
\]

Substitution \(u=s|n|/L\) in its integral bound contributes \(L/s\), and the derivative weight is at most
\(C s^{-2k}(1+u^{2k})\). Absorbing this fixed polynomial into a smaller exponential proves (4.1). Multiplication by \(B_L\) is uniformly bounded on these two Sobolev spaces for \(L\ge1\). The padding contributes at most \(C\sqrt L\,\varepsilon_{s,L,N}\).

After division by \(\sqrt{n_s}\), (1.4) gives, for \(j=0,1\),

\[
\|f_{\sigma,N}-f_\sigma\|_{H^j(\mathbb R)}
\le C L^{13/2}s^{-j}e^{-c_1\sqrt{sN/L}}.
\tag{4.3}
\]

The zero extensions in this assertion are legitimate: both the original seed and the corrected seed have the endpoint traces required for the \(H^2\) and \(H^3\) estimates before \(P\) is applied. The raw uncorrected periodic truncation was estimated only on \((0,L)\).

When the \(j=0\) bound is at most \(1/2\), set
\(u_{\sigma,N}=f_{\sigma,N}/\|f_{\sigma,N}\|_2\). Normalization uses a positive scalar, so every exact sign and parity property in Section 3 persists. The normalized version of (4.3) holds with a changed \(C\); here one uses \(\|f_\sigma\|_{H^1}\le C/s\). The native form estimate (1.8) therefore yields

\[
\left|\mathfrak q(u_{\sigma,N},u_{\sigma,N})
       -\mathfrak q(f_\sigma,f_\sigma)\right|
\le C(1+L)L^{13/2}s^{-2}
\exp\!\left(\frac L2-c_1\sqrt{\frac{sN}{L}}\right).
\tag{4.4}
\]

This controls the Rayleigh quotient itself, even when the original value has large negative magnitude.

## 5. Prescribed cutoff and a shrinking scale

Take \(K(L)=\lceil L^4\rceil\) and \(N=K(L)-3\). For large \(L\), \(N\ge L^4/2\). Equation (4.4) has the following consequences.

**Fixed universal source.** For any fixed \(s>0\), its exponent is \(L/2-c_sL^{3/2}\). The form error tends to zero uniformly over both phases and all allowed positions. This supplies the actual universal-sinc source in the finite bridge; it does not silently substitute the earlier nonuniversal bump seed.

**Intermediate shrinking scales.** If \(s=L^{-\theta}\) with \(0<\theta<1\), the negative term has order \(L^{(3-\theta)/2}\), which dominates \(L\). All displayed polynomial losses are paid.

**Scale of order \(1/L\).** Fix any \(\kappa>0\), and choose one sufficiently large constant \(A\) so that

\[
c_1\sqrt{A/2}>\frac12+\kappa.
\tag{5.1}
\]

For \(A/L\le s\le C_A/L\), with \(C_A\) fixed, (4.4) is at most a fixed polynomial in \(L\) times \(e^{-\kappa L}\). The same holds for (4.3). Such scales eventually satisfy \(s\le1\) and \(sN/L\ge1\).

The constant \(A\) is fixed before the large-aperture limit. No assertion is made that an arbitrary small constant in \(s=A/L\) suffices.

## 6. Coupling to the exact dyadic scale family and both phases

The independent scale-refinement note proves

\[
q_r=q_s*\nu_{r,s},\qquad
C_r=C_s*\sigma_{r,s},\qquad
\sigma_{r,s}\ge0,\quad
\sigma_{r,s}(\mathbb R)=1,\quad
\operatorname{supp}\sigma_{r,s}\subset[-2(r-s),2(r-s)]
\tag{6.1}
\]

when \(s=r/2^J\). Therefore \(C_r(t)\le-e^{\beta t}\) implies that some
\(t_s\in[t-2r,t+2r]\) has \(C_s(t_s)\le-e^{\beta t}\). The corresponding positive statement also holds.

Choose a dyadic scale of order \(A/t\), with a sufficiently large fixed multiplicative constant so that the resulting

\[
L=t_s+2s+2
\tag{6.2}
\]

satisfies \(s\ge A/L\). The two unit collars are included in (6.2); \(t_s+2s\) is only the physical support length. Since \(L=t+O_r(1)\), this choice has \(s\asymp A/L\).

The self-energy obeys the crude but adequate bound

\[
|q_0(s)|/n_s\le Cs^{-2},
\tag{6.3}
\]

by (1.8) on a fixed interval and (1.4). Normalization loses only the factor \(n_s\asymp s^{-5}\). Thus the even negative sequence furnished by \(C_r(t)<0\), and the odd negative sequence furnished by \(C_r(t)>0\), each give

\[
\mathfrak q(f_\sigma,f_\sigma)
\le -c_A L^{-5}e^{\beta L}+C_AL^2 .
\tag{6.4}
\]

The exponentially small finite-carrier error (4.4) preserves this bound. In particular, for any \(0<\delta<\beta\), the legal, unit, pole-neutral finite vectors have

\[
\mathfrak q(u_{\sigma,N},u_{\sigma,N})\le-e^{\delta L}
\tag{6.5}
\]

along their respective sufficiently late sequences.

The hypotheses for these sequences are explicit: the inherited native dictionary and universal visibility, an off-line zero, the two-sided phase theorem in the root note, and the exact dyadic refinement. This is a conditional consequence of an off-line zero, not a proof that such a zero exists or does not exist.

## 7. The exact phase survives inside the transported two-dimensional space

Let \(b_{\pm,N}=Pg_{\pm,N}\), before combining or normalizing them. Reflection exchanges the pair, and both the real \(L^2\) pairing and the native real quadratic form commute with that reflection. Hence their two matrices have the exact form

\[
G_N=\begin{pmatrix}\nu_N&\omega_N\\\omega_N&\nu_N\end{pmatrix},
\qquad
Q_N=\begin{pmatrix}d_N&c_N\\c_N&d_N\end{pmatrix}.
\tag{7.1}
\]

They share the eigenvectors \((1,1)\) and \((1,-1)\); for sufficiently accurate approximation \(G_N\) is positive definite. Thus the same original two-lobe phase is a generalized eigenvector of the pair \((Q_N,G_N)\) on this two-dimensional transported source space. Its native quotient is exactly

\[
\frac{d_N+\sigma c_N}{\nu_N+\sigma\omega_N}.
\tag{7.2}
\]

The finite endpoint construction has not erased the phase by choosing an unrelated vector. The later minimization on the entire canonical carrier is an additional operation. Its ground may be different, and its Euler equation remains an equation for the compressed carrier, with the pole-neutral constraint multipliers retained.

## 8. What this adds, and the remaining estimate

The finite witness now carries a concrete source receipt: exact original sinc family, scale down to \(A/L\), two-translate sign, positive even precursor, legal endpoint jets, exact pole cancellation, cutoff \(\lceil L^4\rceil\), unit normalization, and exponential negative depth under an off-line zero. These are simultaneous properties of a constructed vector.

They still do not establish a lower bound for its native prime response or for the constrained canonical compression. One sufficient closing estimate would be a subexponential lower bound for the actual quotients (7.2), uniform along the displayed scale-and-aperture family. Another would bound the complete constrained Schur complement obtained after ground selection without discarding the original detector as a second witness. Neither estimate follows merely from the construction above.

### Source dependencies

- v2.9, 08_POST_V26_SOURCE/ANALYTIC_PRESSURE_POINT_EXTRACTED/proofs/01_single_universal_detector.md: the original sinc source, its smoothness, real-zero product and Gevrey estimate.
- v2.9, 08_POST_V26_SOURCE/STRATEGY_PACKET_EXTRACTED/01_Detector_Provenance_and_Polynomial_Cutoff.txt, Sections 3–5: the exact legal canonical carrier and the native growing-form estimate; the older bridge used a different seed.
- v2.9, 00_REQUIREMENTS/STEP3_STEP4_REQUIREMENTS_v1_0_SOURCE_EXTRACTED.md: identity, phase, scale and actual selected-state requirements.
- This campaign, root/01_TWO_SIDED_PHASE_AND_POLE_NEUTRAL_SOURCE.md: both exponentially large correlation signs for the fixed original detector.
- This campaign, detector_arithmetic/01_POSITIVE_REFINEMENT_AND_PHASE_DEPTH.md: exact positive dyadic convolution and bounded displacement of the large-value witnesses.

The endpoint factor, positive correction, scale-uniform estimates and two-dimensional transport in Sections 2–7 are supplied here.
