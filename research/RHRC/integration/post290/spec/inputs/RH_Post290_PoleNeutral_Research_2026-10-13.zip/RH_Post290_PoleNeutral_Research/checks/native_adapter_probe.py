#!/usr/bin/env python3
"""Native floating-point diagnostic, not interval certification or proof.
Usage: python native_adapter_probe.py --repo /path/to/zeta-23-lean
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np
import sympy as s
from verify_pole_neutral_geometry import geometry

def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',required=True,type=Path);args=p.parse_args()
 source=args.repo/'research/RHRC/routes/R003_ccm_bridge'
 if not source.is_dir(): raise FileNotFoundError(source)
 sys.path.insert(0,str(source))
 from canonical_source_numeric import canonical_source_matrix_L
 rows=[]
 for K in (3,4,5):
  for q in (2,9,13,14,15):
   L=float((np.log(q)+np.log(q+1))/2);aa=float((L/(4*np.pi))**2)
   d=geometry(K,s.Rational(str(aa)))
   E,O,D,ve,vo,Qe,Qo,g,g0=(np.array(d[k],dtype=float) for k in ('E','O','D','ve','vo','Qe','Qo','g','g0'))
   b=float(d['b']);M=canonical_source_matrix_L(L,K);A=E@M@E;B=O@M@O
   R=B@D@E-D@A
   S=g.T@R/float((g.T@g)[0,0])
   alpha=ve.T@A/float((ve.T@ve)[0,0]);S0=(S-b*alpha)@Qe
   A0=Qe@M@Qe;B0=Qo@M@Qo
   R0=B0@D@Qe-D@A0
   rel=lambda T:float(np.linalg.norm(T,ord=2)/(1+np.linalg.norm(M,ord=2)))
   vals,V=np.linalg.eigh(Qe);basis=V[:,vals>.5]
   vals,W=np.linalg.eigh(Qo);obasis=W[:,vals>.5]
   ev,UV=np.linalg.eigh(basis.T@M@basis);ov=np.linalg.eigvalsh(obasis.T@M@obasis)
   u=basis@UV[:,0];lam=float(ev[0]);mu=float(ov[0]);du=D@u
   moment=float(np.arange(-K,K+1,dtype=float)**4@u);src=float((S0@u)[0])
   defect=float(du@B@du-lam*(du@du)-src*moment)
   rows.append({'K':K,'q':q,'L':L,'a':aa,'b':b,
    'original_rank_one_relative_residual':rel(R-g@S),
    'pole_neutral_rank_one_relative_residual':rel(R0-g0@S0),
    'uncorrected_source_relative_residual':rel(R0-g0@(S@Qe)),
    'even_pn_bottom':lam,'odd_pn_bottom':mu,'strict_even':lam<mu,
    'ground_M4':moment,'corrected_source':src,'pairing':src*moment,
    'gap_quarter_lower_bound':(mu-lam)/4,'energy_identity_error':defect})
 report={'status':'DIAGNOSTIC_ONLY','rows':rows,'precision':'IEEE double; native research quadrature',
 'claim_boundary':'No interval sign certification and no RH closure.'}
 out=Path(__file__).resolve().parents[1]/'evidence'/'native_adapter_probe.json'
 out.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'rows':len(rows),'max_corrected_relative_residual':max(r['pole_neutral_rank_one_relative_residual'] for r in rows),
 'max_original_relative_residual':max(r['original_rank_one_relative_residual'] for r in rows),
 'max_uncorrected_relative_residual':max(r['uncorrected_source_relative_residual'] for r in rows),
 'max_identity_error':max(abs(r['energy_identity_error']) for r in rows)}))
 for r in rows:print(r['K'],r['q'],r['even_pn_bottom'],r['odd_pn_bottom'],r['pairing'])
if __name__=='__main__':main()
