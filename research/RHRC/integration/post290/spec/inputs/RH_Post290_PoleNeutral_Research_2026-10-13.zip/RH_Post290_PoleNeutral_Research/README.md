# Post-#290 pole-neutral spectral research

13 October 2026 · **RH OPEN** · PAPER mathematics and finite checks.

Start with `RESEARCH_NOTE.md`. It contains the exact pole-neutral rank-one adapter, a simple-even-ground tie lemma, a same-trial residual inequality, a sharper deep-threshold selector, a matched NON-ZETA prime-atom falsifier, and the precise unclosed RH implication.

`WORKFLOW_HARVEST.md` inventories all 19 final-head workflows and 53 jobs. `SOURCE_REGISTER.json` identifies the exact sources and hashes. `evidence/` contains the executed finite check outputs, reconstructed repository-tree inventory and structured workflow observations. These observations are a review record, not copied official GitHub receipts.

## Status

No new Lean build, GitHub mutation, Drive upload or external peer review occurred. New universal arguments are PAPER proofs. The 1,468 exact assertions are finite checks, not universal theorem authority. The 15 native matrix cases are floating-point diagnostics, not interval certificates. The modified-prime control deliberately changes the actual prime coefficient and is not actual zeta. Four unresolved even K3 layers remain numerical work; they are not negative eigenvalues.

## Reproduce

Use Python 3 with SymPy. The optional native diagnostic also needs NumPy, SciPy and the exact source repository. Supply the uploaded source ZIP and its unpacked repository rather than a newer branch. The check scripts place their results in this package's `evidence/` directory.

```bash
python -m pip install -r requirements.txt
python checks/verify_snapshot.py /path/to/zeta-23-lean-main.zip
python checks/verify_pole_neutral_geometry.py
python checks/verify_modified_prime_control.py
python checks/verify_selection_and_tie_controls.py
python checks/native_adapter_probe.py --repo /path/to/unpacked/zeta-23-lean-main
```

The native diagnostic reconstructs S from the measured commutator; it checks rank-one residual and the pole-neutral correction, not a second independent implementation of the explicit Lean S formula. None of the check scripts writes to GitHub or changes the supplied repository.

## Evidence boundary

Final head: `e95501ab71edb8243d2ee2abf6ceb7a1532d5e59`.
Merge: `9583bbcc587aca8d87e74981b222e6813238d670`.
Tree: `188d1e0ae3a22e66d512c5c807687c6f2fc8d0e0`.

The live final-head focused log reports four separate compiler passes and a promoted proof-escape scan over 438 files. Accepted printed axioms are the standard `propext`, `Classical.choice`, and `Quot.sound`. Full source-referenced K3 positivity, the actual-source opposing estimate and RH remain OPEN.

## Release integrity

`MANIFEST_SHA256.json` hashes the released files except itself. Source materials are referenced, not silently modified or repackaged as new evidence. The ZIP excludes caches, credentials and fonts.
