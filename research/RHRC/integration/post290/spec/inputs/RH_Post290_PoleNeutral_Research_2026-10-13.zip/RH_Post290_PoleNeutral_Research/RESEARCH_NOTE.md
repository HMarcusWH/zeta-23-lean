# Post-#290: pole-neutral spectral rigidity and a direct RH closure attempt

**Date:** 13 October 2026  
**Project:** HMarcusWH/zeta-23-lean  
**Research status:** PAPER deductions and finite checks; **RH OPEN**  
**Repository mutation:** none. **Local Lean build:** none. **Review:** mathematical self-review, not independent peer review.

## 0. Outcome

The attempted contradiction does not close RH. It produces a source-preserving bridge that was missing from the proposed use of #290: the native even/odd rank-one identity can be restricted to the elementary-pole-neutral carriers, but its source functional must be corrected by a precisely determined projection multiplier.

This gives four concrete results at PAPER level:

1. An exact pole-neutral rank-one intertwining formula, its ground-energy inequality, and its negative-shift secular determinant.
2. A fourth-moment nonvanishing lemma that permits an even/odd tie when the even ground is simple.
3. A quantitative residual obstruction applying to the original moment-null trial **without** calling it a ground eigenvector.
4. A bottom-only deep-threshold selection that improves the predecessor inverse budget from quadratic to linear in the terminal cutoff.

A new exact modified-prime control includes pole neutrality and actual constrained ground eigenvectors. It defeats the attempted generic sign closure. Unlike an arbitrary unrelated Hermitian matrix, this control uses the native first-prime source atom at a legal aperture. It changes its coefficient and is therefore **not actual zeta**. In particular, it breaks the exact native divisor identity at the first changed coefficient. It does not refute an exclusion theorem using that identity.

The surviving closing obligation is not another projection or contact-existence theorem. It is an independent restriction on the **unchanged native prime/source data**, strong enough to exclude the corrected spectral state or bound the original detector's residual. No such restriction is proved here.

---

## 1. Exact source and formal authority

### 1.1 The assessment is historically useful but its live status is stale

The supplied assessment described #290 as an unmerged draft with an unsuccessful overall build. The later live state is:

| Object | Checked identity |
|---|---|
| #290 final head | `e95501ab71edb8243d2ee2abf6ceb7a1532d5e59` |
| Merged main / #290 merge | `9583bbcc587aca8d87e74981b222e6813238d670` |
| Final head and merged tree | `188d1e0ae3a22e66d512c5c807687c6f2fc8d0e0` |
| Synthetic PR merge observed in the frozen-gate log | `c934e17487fc1146fc0753f524bca3f62f3fa2a3` |
| Independently fetched synthetic-merge tree | `188d1e0ae3a22e66d512c5c807687c6f2fc8d0e0` |
| Uploaded repository ZIP SHA-256 | `db4a91819f3cd5f974a54389526353d8d953b16c647fe18e998bdb0de5675ab6` |
| Reconstructed ZIP Git tree | `188d1e0ae3a22e66d512c5c807687c6f2fc8d0e0` |
| ZIP tracked-file count | 1,712 |

The ZIP tree was reconstructed from actual file bytes and Unix executable modes, not inferred from its name. The verifier and its complete blob inventory are included.

The final head has 19 successful workflow runs. Its latest check-run inventory has 53 jobs: **51 successful and two skipped**. A successful aggregate workflow does not turn its skipped job into a passed mathematical test.

The focused Lean gate separately builds exactly four roots: reciprocal-aperture concavity, K2 gluing, the conditional K3 window, and the strict-even selected negative-ground ray. Its raw final-head log reports compiler PASS for all four and **CLOSURE PROOF-ESCAPE CHECK: PASS (438 files)** for the promoted scan. The audited declarations printed in that log have the admitted `propext`, `Classical.choice`, and `Quot.sound` axiom footprint. The source registry contains 118 proved-status rows and four OPEN rows; the separate main/compiler-binding workflows are successful, but registry counts are not additional proof terms.

The synthetic checkout `c934e174...` was read from the raw final-head workflow log, and its Git object was independently fetched. Its tree is identical to the final head, merged main and reconstructed source ZIP. The workflow harvest separates live job conclusions from source-pinned historical numerical receipts.

### 1.2 What #290 actually supplies

The source statements retain their hypotheses:

- Reciprocal-aperture concavity is a theorem on its stated domains and with the existing radius/nonzero conditions. It is not all-aperture positivity.
- K2 continuity/gluing consumes the stated M51 input; an interval certificate is not automatically a Lean inhabitant of that input.
- The selected strict-even negative ground is represented by the actual shifted odd resolvent ray. It is not an arbitrary negative-shifted ray.
- The K3 window and cofinal-closure wrappers retain their window premises. They do not prove those premises.
- The modified-prime control is NON-ZETA.
- The signed-ray calculation defeats a sign claim over a larger ray class, not the narrower actual selected-ground theorem.

The crucial inherited algebra used below is in `ParitySourceMomentFourRigidity.lean` and its source-moment/intertwining dependencies. The source lower-bound machinery includes `CanonicalCenteredIndexPoincare.lean` and the selected negative-state continuation in `GlobalBottomStrictEvenShiftedRay.lean`.

**An important non-new result:**

\[
\|u\|^2\le 4\|Du\|^2
\tag{1.1}
\]

already exists in the formal repository. The uniformly controlled even-to-odd centered-index map is not a discovery of this note. Its loss is bounded independently of aperture and cutoff; it is not an available explanation for arbitrary degeneration of the source/moment inequality. The spectral gap and source factors can still degenerate.

### 1.3 Numerical authority after the repair

The corrected bounded state distinguishes:

- K2 even transcript: 1,310 intervals in the corrected recorded cover;
- K2 odd prerequisite: 350 intervals in the corrected recorded cover;
- frozen K3 feasibility: all 18 required boxes pass, including the final-head 384-bit replay;
- full K3 sweep: 26 of 30 layers complete; four even layers remain unresolved, with 7, 7, 11 and 10 blockers for Q=9,13,14,15 respectively.

The frozen fourth-order alternative is skipped because the frozen gate already passes. The full-continuum job is also skipped in the relevant latest workflow. Full K3 continuous two-parity coverage on the required interval remains **D2 OPEN / explicitly deferred**. The 35 remaining blockers are unresolved numerical boxes, not certified negative eigenvalues.

Earlier whole-cover evidence affected by the non-finite remainder bug is not a premise. The stale formal receipt file is also not allowed to override later compiler evidence. The accompanying workflow harvest records both boundaries.

---

## 2. Retaining Steps 1–3 rather than changing witnesses

The formal source chain supplies actual-zeta zero detection, eventual visibility in the canonical radius bank, a negative Weil test, and transport to legal finite canonical negativity. The newer fixed universal detector and prescribed quartic Fourier schedule are PAPER inputs in the supplied packages, not newly Lean-checked roots here.

For the original-detector route, fix

\[
 s=1/4096,\qquad P=\partial_t^2-\tfrac14,
 \qquad k_s=Pq_s,\qquad j_s=P^2q_s,
\tag{2.1}
\]

where the original compact even Gevrey precursor is kept unchanged. The two translated detector phases have the original source's elementary-pole zeros. The paper's two-sided correlation argument gives both positive and negative exponential excursions when an off-line zero exists. These produce even and odd negative trials along appropriate unbounded sequences; the two sequences need not coincide.

The finite approximation can preserve elementary-pole neutrality and high endpoint jets. The strong-carrier construction in the original-detector paper is a construction of **trials**. It does not establish that a ground selected later by minimization inherits every additional endpoint jet of its input trial.

This distinction prevents a tempting false closure:

> original detector has extra vanishing moments; #290 forbids an appropriate ground with vanishing M4; therefore no original detector can be negative.

The middle inference is invalid. A negative Rayleigh trial need not be a ground eigenvector, and the minimizer in a larger space need not retain an extra trial constraint.

Pole neutrality creates a second issue. The original #290 source functional is defined on the legal parity carrier. A minimizer within its pole-neutral subspace solves a compressed equation with an additional normal multiplier. The next section calculates that multiplier instead of discarding it.

---

## 3. Exact pole-neutral rank-one adapter

**Status: PAPER.** This is a finite-dimensional deduction from the existing exact native intertwining identity, with an independent coordinate proof of the extra projection identities. No positivity or RH assumption is used.

### 3.1 Conventions

Fix K≥3 and L>0. Indices are n=−K,…,K and

\[
 D=\operatorname{diag}(n),\qquad
 M_j(u)=\sum_{n=-K}^{K}n^ju_n.
\]

The inner product is conjugate-linear in its first argument. All orthogonal projections below are for the ordinary coefficient Euclidean inner product.

Let E be the even legal carrier, with M0=M2=0, and O the odd legal carrier, with M1=0. Write PE,PO for their projections and M for the actual canonical matrix. Define

\[
 A=P_E M|_E,\qquad B=P_O M|_O,\qquad
 g=P_O(n^3).
\]

The inherited source identity is

\[
 BD-DA=gS,
\qquad g^*Du=M_4(u),\qquad u\in E,
\tag{3.1}
\]

where S is the actual linear canonical source functional. D:E→O is bijective, not unitary.

Set

\[
 a=\left(\frac{L}{4\pi}\right)^2,\quad
 h_n=\frac1{a+n^2},\quad
 v_e=P_Eh,\quad v_o=P_O(Dh).
\tag{3.2}
\]

Define the pole-neutral subspaces and their projections by

\[
 E_0=E\cap\ker v_e^*,\qquad
 O_0=O\cap\ker v_o^*,\qquad Q_e,Q_o.
\tag{3.3}
\]

The vectors ve and vo are nonzero. For ve, otherwise h would agree with an affine function of n² on at least three distinct values, which is impossible for the strictly convex function 1/(a+x). For vo, otherwise n/(a+n²) would be proportional to n on distinct positive n, also impossible. Consequently both spaces have dimension K−2.

These are the elementary-pole conditions for the finite Fourier source on [0,L]. Indeed integrating e^{±t/2}e^{2πint/L} gives a nonzero common scalar times 1/(±1/2+2πin/L). Pairing n and −n reduces the even condition to h*u=0 and the odd condition to (Dh)*u=0. Translating the physical interval only multiplies the elementary moments by nonzero factors.

Let

\[
 N=n^2-\frac{\sum n^2}{2K+1}\mathbf1,
 \quad \nu=\|N\|^2,
 \quad b=\frac{h^*N}{\nu},
 \quad g_0=Q_og.
\tag{3.4}
\]

The scalar b is strictly negative: the covariance of x=n² and the strictly decreasing function 1/(a+x) is negative on a nonconstant finite set. Repeated squared indices cause no difficulty.

Finally set

\[
 A_0=Q_eA|_{E_0},\qquad B_0=Q_oB|_{O_0},\qquad D_0=D|_{E_0}.
\]

### 3.2 Geometric identities

For u∈E,

\[
 v_o^*Du=\sum_n\frac{n^2}{a+n^2}u_n
 =M_0(u)-a h^*u=-a v_e^*u.
\tag{3.5}
\]

Therefore D maps E0 into O0, and equal dimensions plus injectivity make D0 bijective.

For u∈E0, the even legal projection of D²u is

\[
 P_ED^2u=D^2u-\frac{M_4(u)}\nu N.
\tag{3.6}
\]

The constant projection is zero because M2(u)=0. Since h*D²u=M0(u)−a h*u=0, equation (3.6) gives

\[
 v_e^*P_ED^2u=-bM_4(u).
\tag{3.7}
\]

Pairing with Du and using (3.1) now yields

\[
 \boxed{Q_oDv_e=-b g_0.}
\tag{3.8}
\]

This is a vector equality, not only one scalar test: D0 is onto O0, so testing against all Du tests against all vectors in O0.

The vector g0 is nonzero. The K3 pole-neutral vector in Section 7 has M4=−720 for every a>0 and extends by zeros to every larger K. Since g0*Du=M4(u), g0 cannot vanish.

### 3.3 The corrected source

For u∈E0 define

\[
 \alpha(u)=\frac{v_e^*Au}{\|v_e\|^2},
 \qquad S_0(u)=S(u)-b\alpha(u).
\tag{3.9}
\]

The decomposition Au=A0u+α(u)ve and equations (3.1),(3.8) give

\[
\begin{aligned}
 B_0D_0u-D_0A_0u
 &=Q_o(BDu-DAu)+\alpha(u)Q_oDv_e\\
 &=g_0S(u)-b\alpha(u)g_0.
\end{aligned}
\]

Hence

\[
 \boxed{B_0D_0-D_0A_0=g_0S_0.}
\tag{3.10}
\]

The extra pole-normal channel has not enlarged the final defect rank. It combines with the original cubic channel, but it changes the linear functional multiplying that channel.

Using S instead of S0 is generally false. The native floating-point checks below are an explicit diagnostic of that false substitution, not the proof of (3.10).

### 3.4 Ground-energy rigidity and the existing uniform norm transfer

Suppose A0u=λu and u≠0. Write μo for the bottom eigenvalue of B0. Pairing (3.10) with Du gives

\[
 \Re\big(\overline{S_0(u)}M_4(u)\big)
 =\langle B_0Du,Du\rangle-\lambda\|Du\|^2
 \ge(\mu_o-\lambda)\|Du\|^2.
\tag{3.11}
\]

When λ<μo, the inherited bound (1.1), restricted to E0, gives

\[
 \boxed{
 \Re\big(\overline{S_0(u)}M_4(u)\big)
 \ge\frac{\mu_o-\lambda}{4}\|u\|^2>0.}
\tag{3.12}
\]

Thus both M4(u) and S0(u) are nonzero. This applies to a strict-even pole-neutral ground even when the odd ground is itself negative, provided it lies strictly above λ. It is an actual spectral-gap condition, not an assumption that every odd direction is positive.

Under simultaneous unit-phase rotation, S0 and M4 acquire the same phase. Their product in (3.11) is invariant.

### 3.5 Exact shifted-ray and determinant identities

For real λ<μo define

\[
 x^0_\lambda=D_0^{-1}(B_0-\lambda I)^{-1}g_0.
\tag{3.13}
\]

If u is an eigenvector at λ, (3.10) implies

\[
 u=S_0(u)x^0_\lambda,\qquad S_0(x^0_\lambda)=1.
\tag{3.14}
\]

The stronger finite determinant identity is

\[
 \boxed{
 \frac{\det(A_0-\lambda I)}{\det(B_0-\lambda I)}
 =1-S_0(x^0_\lambda).}
\tag{3.15}
\]

To prove it, put Cλ=D0^{-1}(B0−λI)D0. Equation (3.10) says

\[
 A_0-\lambda I=C_\lambda-D_0^{-1}g_0S_0.
\]

Factor Cλ and apply the rank-one determinant identity det(I−xf)=1−f(x). Similarity gives detCλ=det(B0−λI).

Equation (3.15) is an exact exclusion target, not an exclusion theorem. It would be circular to infer S0(xλ)≠1 merely because the left side must be positive under the desired RH conclusion.

---

## 4. A tie-safe fourth-moment lemma

**Status: PAPER.** This extends moment nonvanishing beyond the strict parity gap, but it does not supply the singular odd resolvent at a tie.

### Theorem

Assume the setting of Section 3. Let u≠0 satisfy A0u=λu. Assume B0≥λI and that the λ-eigenspace of A0 is one-dimensional. Then

\[
 \boxed{M_4(u)\ne0.}
\tag{4.1}
\]

In particular, a simple even ground at the global pole-neutral bottom has nonzero M4 even if the odd bottom equals it.

### Proof

Suppose M4(u)=0. By (3.11),

\[
 \langle(B_0-\lambda I)Du,Du\rangle=0.
\]

Positive semidefiniteness implies (B0−λI)Du=0.

Take the adjoint of (3.10):

\[
 D_0^*B_0-A_0D_0^*=S_0^*g_0^*.
\]

Apply this to Du. Since g0*Du=M4(u)=0,

\[
 A_0H_0u=\lambda H_0u,\qquad H_0=D_0^*D_0.
\]

Simplicity gives H0u=cu for a real c. On the other hand D²u is already in E0: it is even, its zeroth and second moments are M2(u)=0 and M4(u)=0, and

\[
 h^*D^2u=M_0(u)-a h^*u=0.
\]

Hence H0u=D²u. Therefore D²u=cu. The support of u is confined to one squared index n²=c. Evenness forces equal coefficients at ±n, and M0(u)=0 then forces both to vanish. The case n=0 is also killed by M0. This contradicts u≠0. ∎

### Necessary qualifications

Simplicity cannot be removed from this statement. At K≥4, choose A0=B0=−I on their respective pole-neutral spaces. The intertwining has S0=0, and there are nonzero M4-null vectors in the degenerate even ground. Three such controls are included as exact rational checks.

At a tie the theorem does not imply S0(u)≠0, and it does not make B0−λI invertible. Those stronger claims remain unjustified.

A selected minimal deep-threshold state has the needed simplicity in each selected parity when its predecessor is strictly above the selected eigenvalue. Two independent eigenvectors at the selected eigenvalue would have a nonzero linear combination in the codimension-one predecessor, contradicting that strict predecessor bound. This can handle an even/odd tie while retaining simplicity within each parity.

---

## 5. The original trial has a residual, not a forbidden ground equation

**Status: PAPER.** The following is the direct same-trial form of the adapter. It avoids minimizing before using the detector's moment information.

For arbitrary u∈E0 and real λ put

\[
 r=(A_0-\lambda I)u.
\]

Equation (3.10) becomes

\[
 (B_0-\lambda I)Du=D_0r+g_0S_0(u).
\tag{5.1}
\]

If δ=μo−λ>0, taking the real quadratic pairing and using Cauchy–Schwarz gives

\[
 \boxed{
 \delta\|Du\|^2
 \le |S_0(u)|\,|M_4(u)|+\|D_0r\|\,\|Du\|.}
\tag{5.2}
\]

For an exactly M4-null nonzero trial,

\[
 \|D_0r\|\ge\delta\|Du\|.
\]

Since ||D0||≤K and ||Du||≥||u||/2,

\[
 \boxed{\|r\|\ge\frac{\delta}{2K}\|u\|.}
\tag{5.3}
\]

This is the precise alternative to the failed trial/ground identification. A high-jet original detector with M4=0 can be negative. If its Rayleigh level is below the odd pole-neutral bottom, then it must have the residual in (5.3). If the opposite bottom is at or below its Rayleigh level, there is no positive δ and this particular inequality gives no exclusion.

The remaining mathematical attack would be to bound this **same r** independently from the native arithmetic/source construction strongly enough to contradict (5.2). The original A/B/C interfaces identify relevant prime forcing and stable error terms, but no estimate in the inspected source package supplies the required small residual uniformly on the generated tail. Replacing r by an unrelated smooth-source output would repeat the source mismatch.

---

## 6. A sharper deep-threshold construction

**Status: PAPER.** This is a sufficient selector tailored to the predecessor inverse actually needed. It does not promise separation from every higher eigenvalue.

The earlier paper avoids the complete spectra at every cutoff up to Kd, a population of

\[
 M=(K_d-2)(K_d-1),
\]

and obtains an inverse estimate proportional to (M+1)/D for a trial depth D. That broader construction is valid for its stronger task. A smaller selection task gives a better bound for the predecessor alone.

Suppose the pole-neutral carriers are nested at fixed L, and let λK be the global bottom over both parities at cutoff K, for K=3,…,Kd. Assume λKd≤−D with D>0. The sequence λK is nonincreasing by the min–max principle.

There are n=Kd−2 relevant bottom values. Insert the numbers −λK lying inside (D/3,D/2) into that interval. They cut an interval of length D/6 into at most n+1 gaps. Choose η at the midpoint of a longest gap. Then

\[
 \eta\in(D/3,D/2),\qquad
 |\lambda_K+\eta|\ge g:=\frac{D}{12(K_d-1)}
\tag{6.1}
\]

for every K; values outside the interval also lie at least this far from η.

Let Kη be the least K with λK<−η. Then

\[
 \lambda_{K_\eta}\le-\eta-g,
 \qquad \lambda_{K_\eta-1}\ge-\eta+g
\tag{6.2}
\]

when the predecessor exists. If λ=λKη and P is its parity predecessor,

\[
 P-\lambda I\ge2gI,
 \qquad
 \boxed{\|(P-\lambda I)^{-1}\|
 \le\frac{6(K_d-1)}D.}
\tag{6.3}
\]

The first nonempty cutoff Kη=3 has an empty pole-neutral predecessor and is treated without taking the inverse of an empty spectrum.

This selection also gives simplicity within each selected parity by codimension-one interlacing, including a parity tie. It does not guarantee that the selected parity is even. Thus Section 4 covers the even and tied-even branches; it is not a complete branch-exclusion theorem.

For Kd≈L⁴ and depth D≈e^{δL}, (6.3) replaces an O(L⁸e^{−δL}) predecessor inverse budget by O(L⁴e^{−δL}). The gain is polynomial, not exponential.

### Closing attempt with this stronger budget

A crude native prime-coupling bound remains of order poly(L)e^{L/2}. Squaring such a coupling and multiplying by (6.3) gives only a budget of order poly(L)e^{(1−δ)L}. For the relevant small positive δ, that is not smaller than an e^{δL} negative-depth scale. The improved selector does not repair the missing signed cancellation.

The bound can nevertheless matter in a later arithmetic estimate: it removes a superfluous factor of Kd without changing the source or requiring a gap to the entire spectral population.

---

## 7. Exact pole-neutral modified-prime falsification

**Status:** universal PAPER construction with exact symbolic/rational checks. **NON-ZETA.**

This tests whether the new constraints themselves provide a sign obstruction. They do not.

Choose

\[
 K=3,\qquad L_*=\frac43\log2,
 \qquad\omega_2=1-\frac{\log2}{L_*}=\frac14,
 \qquad a=\left(\frac{L_*}{4\pi}\right)^2.
\]

Then 2<e^{L*}<3, so only the first prime atom is active, and 0<a<1.

Set

\[
 e_1=(0,1,-4,6,-4,1,0),\qquad
 e_2=(1,0,-9,16,-9,0,1),
\]

\[
 u=6(a+4)e_1-(a+9)e_2.
\tag{7.1}
\]

Direct calculation gives

\[
 M_0(u)=M_2(u)=h^*u=0,
 \qquad (Dh)^*Du=0,
 \qquad M_4(u)=-720.
\tag{7.2}
\]

Both pole-neutral parity spaces have dimension one. Thus u and Du, after normalization, are the actual respective constrained ground vectors for every real symmetric parity-preserving source matrix at this L and K.

The unweighted native prime source atom at ω=1/4 has entries

\[
 Q_{nm}=\frac{\sin(\pi m/2)-\sin(\pi n/2)}{\pi(m-n)}\quad(n\ne m),
 \qquad Q_{nn}=\tfrac12\cos(\pi n/2).
\tag{7.3}
\]

Its exact quadratic values are

\[
 u^*Qu=\frac4{5\pi}N_E(a,\pi),\qquad
 (Du)^*Q(Du)=-\frac{48}{5\pi}N_O(a,\pi),
\tag{7.4}
\]

where

\[
 N_E=(205\pi-644)a^2+(1128-360\pi)a+2316-720\pi,
\]

\[
 N_O=(15\pi-47)a^2+(120\pi-386)a+240\pi-667.
\]

Using 3<π<22/7 and 0<a≤1,

\[
 N_E\ge-29-\frac{24}7+\frac{372}7=\frac{145}7>0,
\]

\[
 N_O\ge-2-26+53=25>0.
\tag{7.5}
\]

The first inequality is obtained by lower-bounding each coefficient and allowing each negative coefficient its worst a or a² value. The positive constant supplies the displayed margin. The second works in the same way. No decimal sign test is used.

Now modify the actual canonical matrix by increasing the positive coefficient of this one native prime atom:

\[
 M_\tau=M_{\mathrm{native}}-\tau Q,\qquad\tau>0.
\tag{7.6}
\]

For sufficiently large τ, equations (7.4) imply

\[
 \lambda_{e,0}(M_\tau)<0<\lambda_{o,0}(M_\tau).
\tag{7.7}
\]

The modified system retains legal carrier constraints, elementary-pole neutrality, an actual strict-even constrained ground, an odd-positive constrained sector, and the source-atom rank-one structure. The positive small-aperture base before the first prime is unchanged. Higher powers of 2 may be modified coherently without affecting this aperture, since they are inactive here.

This is stronger than an unrelated-matrix control and stronger than a control that omits pole neutrality. It falsifies a closure that uses only those structural conditions and positivity of prime weights.

It is **not** a countermodel to the complete actual-zeta source package. Altering the coefficient at 2 breaks

\[
 N*\Pi=(\log n)N
\tag{7.8}
\]

already at n=2. The true von Mangoldt coefficient is fixed, not an adjustable positive parameter. The control therefore identifies a genuinely surviving attack surface: use the native arithmetic compatibility that this control cannot retain.

---

## 8. Where A, B and C enter the attempted closure

### 8.1 Path A: the same residual and the actual divisor law

For the original fixed source, the supplied papers define

\[
 N=\sum_{n\ge1}n^{-1/2}\delta_{\log n},\quad
 \Pi=\sum_{n\ge2}\Lambda(n)n^{-1/2}\delta_{\log n},\quad
 X=\Pi*j_s,
\]

\[
 U=((\log n)N)*j_s,\qquad N*X=U.
\tag{8.1}
\]

The actual integer drive has the stated rapid Gevrey tail. The adaptive mask, complete-small-divisor cancellation, small rough-core estimates and controlled near-gap sector remove genuine terms. Their remaining signed interaction is still an actual unbounded arithmetic quantity, not a freely assignable error.

Section 5 gives a finite target into which an upper bound for the matched projected forcing could be inserted. It does not show that the global arithmetic quantity bounds the exact finite residual with a favorable constant at the selected aperture and scale. All adapters, phase conventions and norm losses must still be retained.

### 8.2 Path B: the positive forward completion is not an inverse

The constructive package's positive kernel

\[
 a_\triangle(t)=e^{-3t/2}\lfloor e^t\rfloor
 (\lfloor e^t\rfloor+1-e^t),\qquad t\ge0,
\]

has mass below 605/621 and transform

\[
 A_\triangle(p)=\frac{p-1/2}{(p+1/2)(p+3/2)}\zeta(p+1/2).
\tag{8.2}
\]

The forward operator is contractive. Its symbol still has precisely the native zero obstruction in the relevant region. The adjoint iteration tends to the unresolved adjoint-kernel projection; nothing in (3.12) or (6.3) shows that projection is zero.

Therefore the attempted inference “contractive native completion plus a rigid even ground implies stable inverse” is not valid. The actual input range/jet obstruction must be excluded, not normalized away.

### 8.3 Path C: constrained sources and exterior responses

The original-detector and contact papers retain compact inverses of pole killing and explicitly record the normal multipliers in constrained Euler equations. Section 3 is a finite counterpart: it identifies the extra pole-normal source contribution rather than replacing constrained stationarity by unrestricted stationarity.

The full-contact exterior lower law and native residue observability are lower obstructions. Contraction of a source quotient does not by itself supply the opposing exterior upper bound, because unstable native modes can be invisible to the forward multiplier at its zeros. Full finite or continuous source provenance must remain attached.

The tie-safe moment lemma reduces one local branch ambiguity. It is not a global compact-source uniqueness theorem, and no finite ground is silently declared to be a continuous full-contact kernel vector.

### 8.4 Exact stopping point of this attempt

The strongest new same-ground constraint is (3.12), with the correction S0. The strongest new same-trial constraint is (5.2). A closing theorem must establish an independent incompatible upper bound or sign using the **unchanged** source and cover the relevant parity alternatives.

The inspected Steps 1–3 provide the off-line-generated trial, its visibility and exact transports. The supplied A/B/C papers identify and narrow the remaining arithmetic/range/exterior terms. Neither set of inputs proves the opposing inequality in (3.12) or the small-residual upper bound needed against (5.2).

The modified-prime control demonstrates why a generic structural sign claim cannot fill that gap. It does not rule out a genuinely native arithmetic or analytic proof.

---

## 9. Executed validation and falsification

The included finite checks report:

| Check | Executed result | Authority |
|---|---|---|
| Reconstruct uploaded Git tree | Exact match, 1,712 files | Byte/mode provenance |
| Pole-neutral geometry | 280 exact assertions across 28 rational geometries | Finite symbolic/rational validation |
| Modified-prime control | 15 exact assertions | Exact formulas and rational sign margins |
| Threshold selection and degenerate-tie controls | 1,173 exact assertions; 192 selectors, three tie controls | Finite exact validation |
| Native source adapter | 15 cases, K=3,4,5; Q=2,9,13,14,15 | Floating-point diagnostic only |

The algebraic finite assertions total 1,468. They do not prove a universal theorem merely by their count.

For the native diagnostic, the largest normalized corrected rank-one residual is approximately 4.27×10⁻¹⁶, and the largest ground energy identity discrepancy is approximately 1.33×10⁻¹⁵. Using the uncorrected source instead produces a normalized discrepancy up to approximately 0.0805. These observations support the implementation and falsify the uncorrected substitution at numerical precision; the universal corrected identity is justified by the paper proof above.

The diagnostic reconstructs the numerical source row S by projecting the native commutator onto the known cubic defect vector and separately measures the remaining rank-one defect. It does not independently evaluate the explicit Lean source-functional formula. The PAPER argument uses the existing exact source identity, not this fitted row. The corrected projection identity is then checked on the unchanged native matrices.

The native floating-point routine is the repository's source-normalized matrix builder, not its historical printed normalization. Native positive signs in this diagnostic are not interval certificates. No RH conclusion depends on them.

The new universal arguments were self-reviewed for: complex phase, projector signs, K3/empty-predecessor cases, parity ties, non-isometric D, cutoff growth, trial/ground mismatch, and altered native arithmetic. They have not received independent external review or Lean verification.

---

## 10. Post-green research pass

### What became formally true

The exact #290 scoped Lean surfaces survived their attached formal gates. Their premises remain visible: source/radius conditions, the M51 input, actual selected strict-even residual state, and supplied K3 windows. The quarter-factor centered-index norm bound is inherited formal authority. No new theorem in this local research note has compiler authority.

### Workflow harvest

All 19 attached workflows and all 53 latest jobs are enumerated in `WORKFLOW_HARVEST.md` and its JSON. There are 51 successes and two skips. Formal, regression and research roles are distinguished. Frozen falsifications and unresolved dispositions are not converted into new positive theorems. D2 is explicitly deferred, not silently passed. The harvest states where source/metadata inspection, rather than a fresh artifact-by-artifact numerical diff, is the limit of the comparison.

### What changed

The proposed use of #290 can now be made pole-neutral with one corrected scalar source, rather than an omitted multiplier or an arbitrary higher-rank error. Simple even grounds cannot hide in M4=0 even at a parity tie. Original M4-null trials are handled by an exact residual inequality. The deep-threshold predecessor inverse loses only one power of the terminal cutoff instead of two.

### Upstream implications

Promote the pole-neutral carrier, its elementary normal and the corrected functional as explicit mathematical objects before selecting new grounds. Do not make the universal detector's smoothness or pole zeros a hidden property of a later minimizer. Reuse the existing Poincare theorem instead of reopening an already solved norm-transfer issue.

### Downstream implications

The retained detector's arithmetic forcing can be tested against (5.2) on the original vector. The selected-state branch can instead use (3.12) and the exact secular determinant. The tie lemma removes M4-null simple even states from that branch. The improved selector strengthens a future Schur capacity estimate without demanding complete spectral separation.

### Resurrected routes

The moment-null detector idea is not a direct contradiction, but it is now a legitimate residual-size problem on the same trial. The tie branch is partially reopened through simplicity rather than an illegal odd inverse. Pole-neutral selected rays are now definable with the corrected source. A generic positivity-of-prime-weights route remains defeated by the matched control.

### New RH-relevant clues

**LEAD / HYPOTHESIS:** use the exact native divisor compatibility to restrict the corrected source or the original-trial residual; this is a condition the new modified-prime control fails at n=2. Another legitimate target is a source-specific strict inequality for S0(xλ) on the actual negative selected-ray class. Neither hypothesis is established.

### Falsification checks

The correction was challenged on actual native matrices; omission produces a visible discrepancy. The moment nonvanishing statement was challenged at a degenerate tie; simplicity is essential. The generic sign mechanism was challenged with a positive modified first-prime coefficient; it fails even on the actual one-dimensional pole-neutral ground. The improved inverse budget was challenged by its exponential scaling; it does not absorb a crude prime-coupling bound.

### Highest-leverage next moves

The most informative next mathematical task is an independently derived bound for the **actual corrected source or exact original-trial residual**, using native integer–prime compatibility before taking absolute values. Formalizing the finite adapter and the simple-ground tie lemma would stabilize this proof interface. Extending the four unresolved bounded K3 layers is useful numerical work, but it cannot alone settle the unbounded generated-witness quantifiers.

---

## 11. Source register and reproduction

The source register is `SOURCE_REGISTER.json`, with reviewed local source hashes. Primary repository locators are pinned to the final #290 head. The user-supplied paper packages and the newer Drive even-sector study are kept distinct from Lean authority.

Key repository sources:

- `Zeta23/CCM/ParitySourceMomentFourRigidity.lean` and its imported source-moment/intertwining modules.
- `Zeta23/CCM/CanonicalCenteredIndexPoincare.lean`.
- `Zeta23/CCM/GlobalBottomStrictEvenShiftedRay.lean`.
- `Zeta23/CCM/ReciprocalApertureConcavity.lean`.
- `Zeta23/CCM/K2EvenBottomGluing.lean` and `K3BottomWindowRecord.lean`.
- `Zeta23/CCM/CanonicalGlobalF04.lean` and `CanonicalSecularResolvent.lean`.
- `Zeta23/ExceptionalZero/FiniteNegativeObstruction.lean`, `ApertureFreedom.lean` and the detector/radius chain.
- `research/RHRC/integration/post287/PR290_SCOPE_OVERRIDE_AND_HANDOFF.md`, `NUMERICAL_AUTHORITY_CORRECTION.md`, `WP4_GATE_DISPOSITION.md`, `WP5_WP6_FINITE_RESEARCH_HARVEST.md`, and `POST_GREEN_RESEARCH.md`.

Paper inputs:

- *Paths A, B and C: Step 4* (13 October 2026), joint arithmetic, range and exterior source interfaces.
- *Step 4 with the original detector retained* (13 October 2026), phase growth, pole-neutral deep state, compact inverse, source residual and high-jet finite carrier.
- *Constructing the missing objects* (13 October 2026), positive native completion and precise inverse/arithmetic residual limits.
- *RH Even Sector Pole Moment Hierarchy* (13 October 2026), obtained from the user-specified Drive research folder, including its constraints and finite controls.
- The supplied historical assessment, used as a source map rather than current CI authority.

See `README.md` for the executed check commands. The release contains no font files, secret credentials, repository mutations or externally uploaded research outputs.
