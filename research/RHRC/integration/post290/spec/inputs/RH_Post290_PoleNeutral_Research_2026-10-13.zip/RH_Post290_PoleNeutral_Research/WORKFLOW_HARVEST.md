# Final-head workflow harvest: PR #290

Head `e95501ab71edb8243d2ee2abf6ceb7a1532d5e59`; merged tree `188d1e0ae3a22e66d512c5c807687c6f2fc8d0e0`.

**19 successful workflows; 53 jobs: 51 successful and two skipped.** A skipped check is not a passed theorem or completed numerical cover.

## Coverage and comparison limit

Live run/job metadata and workflow source inspected. Selected logs, proof statements and source-pinned research receipts examined. This is NOT an independent replay or complete numerical artifact-by-artifact diff of all 53 jobs. Historical dispositions below identify the frozen assertion the successful replay preserves; no uninspected artifact values are presented as freshly recomputed.

Formal validity takes precedence over stale prose/receipts. The final focused log reports four separate compiler passes and a **438-file** promoted proof-escape scan. Its declarations print only the admitted standard axioms. The exact synthetic checkout has the same independently fetched tree as the final head and uploaded ZIP.

## What changed versus earlier recorded states

The failed draft build is superseded by final-head compiler success. The final source retains four OPEN registry claims. Older centre-only and NaN-dropping interval evidence stays invalid; corrected source-pinned evidence is not retroactively rebound to the final head. Guarded K2-even 1,310 intervals and K2-odd 350 intervals survive within their scope. The guarded full K3 campaign is still 26/30 complete layers, with 35 unresolved subintervals in Q9/Q13/Q14/Q15 even layers. The frozen 18-box SECOND gate passes; that is why the FOURTH alternative is skipped. The separate full-K3 job is skipped under the revised scope.

WP5 preserves a NON-ZETA crossing control. WP6 preserves opposite signed-source outcomes on a larger negative-shifted ray class; it does not test only actual selected negative grounds. Neither closes the selected-source sign obligation. The new pole-neutral control in RESEARCH_NOTE.md strengthens the structural falsification without changing the historical receipts.

The historical replay dispositions below remain useful after #290: a new exact selected-ray identity does not repair a failed unrestricted sign law or prove an unresolved arithmetic representation. A fresh full artifact-content comparison of every historical job was not performed in this review.

## Every attached run and job

### RHRC post-282 contact calculus — run 38414164467
Workflow: `.github/workflows/rhrc_post282_contact_calculus.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| contact-calculus-complete / `115374330475` | SUCCESS | REGRESSION GATE | Aggregate of required dependency jobs; supplies no additional independent theorem or numerical estimate. |
| arb-contact-balance / `115373780762` | SUCCESS | RESEARCH-PRODUCING CHECK | Bounded contact/frontier research checker under its frozen protocol; not global contact or saturation exclusion. |
| lean-compressed-calculus / `115354786083` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| lean-contact-completion / `115354785954` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| research-calibration / `115354785921` | SUCCESS | RESEARCH-PRODUCING CHECK | Contact/source calibration or generated-frontier research under the existing protocol; independent exclusion remains OPEN. |

### RHRC parallel closure campaign — run 38414163395
Workflow: `.github/workflows/rhrc_closure_campaign.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| campaign-complete / `115369031949` | SUCCESS | REGRESSION GATE | Aggregate of required dependency jobs; supplies no additional independent theorem or numerical estimate. |
| fast-integrity / `115354764316` | SUCCESS | REGRESSION GATE | Parallel-closure integrity/research ledger harvest; terminal RH_OPEN and no all-track closure. |
| lean-b / `115354764297` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| lean-c / `115354764204` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| lean-contact / `115354764101` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| lean-d-bindings / `115354764014` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| lean-strength-audit / `115354763934` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| lean-first-crossing / `115354763842` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| lean-a / `115354763591` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |

### RHRC post287 WP2 and WP4 interval research — run 38414163589
Workflow: `.github/workflows/rhrc_post287_numerical.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| wp4-k3-fourth-order-alternative / `115365453195` | SKIPPED | RESEARCH-PRODUCING CHECK | Not executed: the frozen SECOND feasibility gate passes, so its predeclared FOURTH alternative is not activated. |
| wp2-k2-transcript / `115354766007` | SUCCESS | RESEARCH-PRODUCING CHECK | Guarded K2 even finite transcript checker replay; finite evidence does not supply Lean hM51. |
| wp4-k3-frozen-feasibility / `115354765945` | SUCCESS | RESEARCH-PRODUCING CHECK | Corrected 384-bit final-head replay of all 18 frozen feasibility boxes; not full K3 coverage. |
| wp4-k2-odd-prerequisite / `115354765604` | SUCCESS | RESEARCH-PRODUCING CHECK | Guarded K2 odd prerequisite checker; finite-window scope only. |

### RHRC post268 complete audit replay — run 38414164051
Workflow: `.github/workflows/rhrc_post268_audit.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| Complete 44-check execution harvest / `115363215081` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Extended audit shard 1 / `115354773008` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Extended audit shard 6 / `115354772970` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Extended audit shard 2 / `115354772914` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Extended audit shard 3 / `115354772774` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Extended audit shard 7 / `115354772765` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Extended audit shard 0 / `115354772721` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Audit runner adversarial regressions / `115354772714` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Extended audit shard 4 / `115354772555` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |
| Extended audit shard 5 / `115354772469` | SUCCESS | REGRESSION GATE | Frozen extended 44-check audit or its runner/shard; maintains scoped historical conclusions, not 44 new mathematical results. |

### RHRC post-281 generated contact frontier — run 38414163223
Workflow: `.github/workflows/rhrc_post281_generated_contact_frontier.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| generated-contact-complete / `115361623780` | SUCCESS | REGRESSION GATE | Aggregate of required dependency jobs; supplies no additional independent theorem or numerical estimate. |
| arb-generated-contact / `115355418462` | SUCCESS | RESEARCH-PRODUCING CHECK | Bounded contact/frontier research checker under its frozen protocol; not global contact or saturation exclusion. |
| lean-production-contact / `115354759094` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |
| research-generated-contact / `115354758864` | SUCCESS | RESEARCH-PRODUCING CHECK | Contact/source calibration or generated-frontier research under the existing protocol; independent exclusion remains OPEN. |
| lean-generated-contact / `115354758730` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |

### RHRC post-284 source inertia campaign — run 38414164310
Workflow: `.github/workflows/rhrc_post284_source_inertia.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post287-full-k3 / `115355571754` | SKIPPED | RESEARCH-PRODUCING CHECK | Not executed: full continuous K3 is outside the revised #290 merge scope; D2 remains OPEN. |
| source-falsifier-research / `115355570050` | SUCCESS | RESEARCH-PRODUCING CHECK | Source-inertia/falsifier tests; generic sign substitutes remain rejected. No global source domination. |
| lean-source-inertia / `115355569769` | SUCCESS | FORMAL VALIDITY GATE | Named theorem/interface build at final tree; its explicit assumptions and claim limits remain. See stored workflow steps and the exact Lean sources. |

### RHRC research and Lean checks — run 38414163904
Workflow: `.github/workflows/rhrc.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| rhkg-compiler-receipt / `115355416184` | SUCCESS | FORMAL VALIDITY GATE | Compiler identity / dependency binding validation; graph authority is derived, not new mathematics. |
| r003-normalization-audit / `115355416052` | SUCCESS | REGRESSION GATE | Canonical normalization and historical interface regressions, not a new sign law. |
| python-rhrc / `115355415951` | SUCCESS | REGRESSION GATE | RHRC / graph / source-integrity checks; checked-in products validated before regeneration, not theorem discovery. |
| lean / `115355415384` | SUCCESS | FORMAL VALIDITY GATE | Repository Lean build and its configured proof-validity gates; no new unconditional RH conclusion. |

### RHRC post-196 Q14 residual cell replay — run 38414164451
Workflow: `.github/workflows/rhrc_post196_q14_residual_cell_replay.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post196-q14-residual-cell-replay / `115354787529` | SUCCESS | REGRESSION GATE | GLOBAL_MONOTONE_ORIENTATION and J_POSITIVE in frozen residual-cell scope only. |

### RHRC post-214 kernel dual geometry — run 38414163833
Workflow: `.github/workflows/rhrc_post214_kernel_dual_geometry.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post214-kernel-dual-geometry / `115354781962` | SUCCESS | REGRESSION GATE | FULL_SPACE_DUAL_INDEPENDENCE_CERTIFIED / full-space sign-indefiniteness in frozen scope; not a contact-conditioned exclusion. |

### RHRC post-202 Q14 composite parity gap — run 38414163535
Workflow: `.github/workflows/rhrc_post202_q14_composite_parity_gap.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post202-q14-composite-parity-gap / `115354781759` | SUCCESS | REGRESSION GATE | COMPOSITE_PARITY_GAP_PATTERN_FALSIFIED retained; a successful replay of a falsification. |

### RHRC post-200 Q14 discrepancy mechanism — run 38414163994
Workflow: `.github/workflows/rhrc_post200_q14_discrepancy_mechanism.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post200-q14-discrepancy-mechanism / `115354778978` | SUCCESS | REGRESSION GATE | DISCREPANCY_REPRESENTATION_DEPENDENCY_UNRESOLVED retained. |

### RHRC post-222 bi-regular zero-shift scalar — run 38414163922
Workflow: `.github/workflows/rhrc_post222_biregular_zero_shift_scalar.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post222-biregular-zero-shift-scalar / `115354768922` | SUCCESS | REGRESSION GATE | NO_FROZEN_CELL_MINIMAL_BIREGULAR_STATE_CERTIFIED retained. |

### RHRC post-194 parity trajectory sharp enclosure — run 38414163940
Workflow: `.github/workflows/rhrc_post194_parity_trajectory_sharp_enclosure.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post194-parity-trajectory-sharp-enclosure / `115354767019` | SUCCESS | REGRESSION GATE | PARTIAL_TRAJECTORY_ORIENTATION (historical frozen certified fraction 63/64); not a universal orientation theorem. |

### RHRC post-198 Q14 parity source mechanism — run 38414163261
Workflow: `.github/workflows/rhrc_post198_q14_parity_source_mechanism.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post198-q14-source-mechanism / `115354764070` | SUCCESS | REGRESSION GATE | SOURCE_DECOMPOSITION_DEPENDENCY_UNRESOLVED retained. |

### RHRC post-192 parity trajectory rigidity — run 38414163639
Workflow: `.github/workflows/rhrc_post192_parity_trajectory_rigidity.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post192-parity-trajectory-rigidity / `115354761441` | SUCCESS | REGRESSION GATE | TRAJECTORY_RIGIDITY_UNRESOLVED preserved by frozen regression semantics. |

### Permansson v0.1.6 formal verification — run 38414163540
Workflow: `.github/workflows/permansson-formal.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| lean-permansson / `115354759440` | SUCCESS | FORMAL VALIDITY GATE | Permansson component Lean gate; no additional RH theorem authority. |

### RHRC post287 bounded signed-ray probe — run 38414163579
Workflow: `.github/workflows/rhrc_post287_wp6.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| wp6-source-specific-signed-ray / `115354758901` | SUCCESS | RESEARCH-PRODUCING CHECK | Opposite signs of the complete source observable on admissible negative-shifted K2 rays; unrestricted sign law FALSIFIED, actual selected-ground exclusion OPEN. |

### RHRC post287 focused Step3 checks — run 38414163411
Workflow: `.github/workflows/rhrc_post287_focused.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| wp5-modified-prime / `115354758494` | SUCCESS | RESEARCH-PRODUCING CHECK | NON-ZETA modified-prime separated endpoint signs and continuity crossing. Not firstness, whole-bracket odd positivity, or an RH counterexample. |
| lean-step3 / `115354758110` | SUCCESS | FORMAL VALIDITY GATE | Four exact theorem roots compile separately (reciprocal concavity, K2 gluing, K3 window, selected strict-even ray). Axiom printouts are standard admitted axioms; promoted proof-escape scan PASS (438 files). Premises remain. |

### RHRC post-190 canonical realizability audit — run 38414163037
Workflow: `.github/workflows/rhrc_post190_canonical_realizability.yml`. Run result: **SUCCESS**.

| Job / ID | Result | Classification | Mathematical disposition |
|---|---|---|---|
| post190-canonical-realizability / `115354755684` | SUCCESS | REGRESSION GATE | Frozen canonical-realizability / H1 finite-scope replay; not actual-zeta crossing exclusion. |

## Research consequence

The all-green integration state makes the scoped formal identities usable. It does not remove the actual-source upper-bound obligation. The next proof attempt must use the corrected source functional on a pole-neutral ground, or bound the original detector’s exact residual; numerical non-detection and a successful regression cannot provide that estimate.
