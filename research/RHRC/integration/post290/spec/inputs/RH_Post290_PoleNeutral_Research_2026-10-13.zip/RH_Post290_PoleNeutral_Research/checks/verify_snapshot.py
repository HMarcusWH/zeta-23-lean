#!/usr/bin/env python3
"""Reconstruct Git blob/tree hashes from a GitHub source ZIP, without Git writes."""
from __future__ import annotations
import argparse,hashlib,json,stat,zipfile
from pathlib import Path
EXPECTED='188d1e0ae3a22e66d512c5c807687c6f2fc8d0e0'
def object_id(kind:bytes,data:bytes)->bytes:
 return hashlib.sha1(kind+b' '+str(len(data)).encode()+b'\0'+data).digest()
def main():
 p=argparse.ArgumentParser();p.add_argument('zip_path',type=Path);args=p.parse_args()
 files=[];root={}
 with zipfile.ZipFile(args.zip_path) as z:
  comment=z.comment.decode();prefix=z.namelist()[0].split('/')[0]+'/'
  for zi in z.infolist():
   if zi.is_dir():continue
   path=zi.filename.removeprefix(prefix);data=z.read(zi);mode=(zi.external_attr>>16)
   gitmode='120000' if stat.S_ISLNK(mode) else ('100755' if mode&0o111 else '100644')
   oid=object_id(b'blob',data);node=root;parts=path.split('/')
   for c in parts[:-1]:node=node.setdefault(c,{})
   node[parts[-1]]=(gitmode,oid)
   files.append({'path':path,'mode':gitmode,'git_blob':oid.hex()})
 def tree_id(node):
  records=[]
  for name,val in node.items():
   if isinstance(val,dict):mode,oid='40000',tree_id(val);key=name.encode()+b'/'
   else:mode,oid=val;key=name.encode()
   records.append((key,mode.encode()+b' '+name.encode()+b'\0'+oid))
  return object_id(b'tree',b''.join(r[1] for r in sorted(records)))
 actual=tree_id(root).hex()
 result={'archive':str(args.zip_path),'sha256':hashlib.sha256(args.zip_path.read_bytes()).hexdigest(),
  'zip_commit_comment':comment,'file_count':len(files),'computed_git_tree':actual,'expected_live_git_tree':EXPECTED,
  'tree_match':actual==EXPECTED,'files':files}
 out=Path(__file__).resolve().parents[1]/'evidence'/'snapshot_verification.json'
 out.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k!='files'}))
 if actual!=EXPECTED:raise SystemExit('Tree mismatch: inspect modes, export attributes and files before claiming equality')
if __name__=='__main__':main()
