#!/usr/bin/env python3
"""Finite exact controls for threshold selection and the simplicity hypothesis.
The universal arguments are PAPER proofs in RESEARCH_NOTE.md, not these tests.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import json, random
import sympy as s
from verify_pole_neutral_geometry import geometry


def select_threshold(bottoms: list[F], depth: F):
    if not bottoms or depth <= 0 or any(x < y for x,y in zip(bottoms,bottoms[1:])) or bottoms[-1] > -depth:
        raise ValueError('Need a nonincreasing nonempty bottom list ending <= -depth, depth > 0')
    lo,hi=depth/3,depth/2
    marks=sorted({lo,hi}|{-x for x in bottoms if lo < -x < hi})
    left,right=max(zip(marks,marks[1:]),key=lambda z:z[1]-z[0])
    eta=(left+right)/2
    gap=depth/(12*(len(bottoms)+1))
    first=next(i for i,x in enumerate(bottoms) if x < -eta)
    return eta,gap,first


def main():
    rng=random.Random(290)
    count=0; rows=[]
    for n in range(1,65):
        depth=F(3,2)
        for replicate in range(3):
            vals=sorted([F(rng.randint(-180,90),90) for _ in range(n-1)]+[-depth], reverse=True)
            eta,gap,j=select_threshold(vals,depth)
            tests=[depth/3<eta<depth/2, all(abs(x+eta)>=gap for x in vals), vals[j]<=-eta-gap,
                   j==0 or vals[j-1]>=-eta+gap, j==0 or vals[j-1]-vals[j]>=2*gap,
                   1/(2*gap)==6*(n+1)/depth]
            assert all(tests)
            count+=len(tests)
            rows.append({'n_bottoms':n,'replicate':replicate,'eta':str(eta),'gap':str(gap),'first_index':j})
    tie=[]
    for K in (4,5,6):
        d=geometry(K,s.Rational(1));Qe,Qo,D,n=(d[k] for k in ('Qe','Qo','D','n'))
        raw=s.Matrix.hstack(*Qe.columnspace())
        coeff=(n.applyfunc(lambda x:x**4).T*raw).nullspace()[0]
        u=raw*coeff
        A=-Qe;B=-Qo
        # Degenerate global tie, valid zero-defect intertwining, M4-null nonzero eigenvector.
        tests=[u!=s.zeros(2*K+1,1),A*u==-u,B*D*u==-D*u,
               B*D*Qe-D*A==s.zeros(2*K+1),
               (n.applyfunc(lambda x:x**4).T*u)[0]==0,
               Qe*D*D*u==D*D*u,
               s.Matrix.hstack(u,D*D*u).rank()==2]
        assert all(tests);count+=len(tests)
        tie.append({'K':K,'dimension_even':K-2,'tests':len(tests),
                    'M4_null_vector':[str(x) for x in u],
                    'conclusion':'Without even-ground simplicity, M4 nonvanishing is false.'})
    report={'status':'PASS','assertion_count':count,'threshold_cases':len(rows),'tie_cases':tie,
            'scope':'192 finite rational threshold selections and 3 degenerate scalar countermodels',
            'RH_status':'OPEN','not_a_Lean_proof':True,'threshold_rows':rows}
    path=Path(__file__).resolve().parents[1]/'evidence'/'selection_and_tie_controls.json'
    path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('threshold_rows','tie_cases')}))
if __name__=='__main__': main()
