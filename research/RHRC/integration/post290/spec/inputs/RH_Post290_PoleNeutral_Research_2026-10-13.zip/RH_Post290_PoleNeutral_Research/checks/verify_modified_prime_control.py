#!/usr/bin/env python3
"""Exact algebra for a POLE-NEUTRAL modified-prime control (NOT actual zeta).
The universal existence argument is in RESEARCH_NOTE.md. Checks below are
symbolic identities and rational inequalities; no native RH claim is made.
"""
from __future__ import annotations
import json
from pathlib import Path
import sympy as s
from verify_pole_neutral_geometry import geometry

def main():
 a,p=s.symbols('a p',positive=True);idx=list(range(-3,4));D=s.diag(*idx)
 e1=s.Matrix([0,1,-4,6,-4,1,0]);e2=s.Matrix([1,0,-9,16,-9,0,1])
 u=6*(a+4)*e1-(a+9)*e2;du=D*u
 h=s.Matrix([1/(a+n*n) for n in idx])
 Q=s.Matrix(7,7,lambda i,j:s.Rational(1,2)*s.cos(s.pi*idx[i]/2) if i==j
       else (s.sin(s.pi*idx[j]/2)-s.sin(s.pi*idx[i]/2))/(p*(idx[j]-idx[i])))
 NE=205*a*a*p-644*a*a-360*a*p+1128*a-720*p+2316
 NO=15*a*a*p-47*a*a+120*a*p-386*a+240*p-667
 checks={
  'M0_zero':s.simplify(sum(u))==0,
  'M2_zero':s.simplify(sum(idx[i]**2*u[i] for i in range(7)))==0,
  'elementary_even_pole_zero':s.simplify((h.T*u)[0])==0,
  'elementary_odd_pole_zero':s.simplify(((D*h).T*du)[0])==0,
  'M4_exact':s.simplify(sum(idx[i]**4*u[i] for i in range(7)))==-720,
  'even_atom_formula':s.simplify((u.T*Q*u)[0]-4*NE/(5*p))==0,
  'odd_atom_formula':s.simplify((du.T*Q*du)[0]+48*NO/(5*p))==0,
  'norm_formula':s.expand(u.dot(u)-84*(11*a*a+18*a+21))==0,
  'index_norm_formula':s.expand(du.dot(du)-36*(21*a*a+98*a+181))==0,
  'even_numerator_lower_bound':-29-s.Rational(24,7)+s.Rational(372,7)==s.Rational(145,7),
  'odd_numerator_lower_bound':-2-26+53==25,
  'bounds_strictly_positive':s.Rational(145,7)>0 and 25>0,
  'one_prime_window':16<27,
 }
 # An exact finite matrix check that a positive source-atom increment preserves
 # the rank-one commutator, and the corrected PN source, at rational a=1.
 d=geometry(3,s.Rational(1));E,O,Qe,Qo,g,g0,ve,b=[d[k] for k in ('E','O','Qe','Qo','g','g0','ve','b')]
 M=s.eye(7)-Q;A=E*M*E;B=O*M*O
 R=B*D*E-D*A;S=g.T*R/g.dot(g)
 alpha=ve.T*A/ve.dot(ve);S0=(S-b*alpha)*Qe
 simplifyzero=lambda M: all(s.simplify(x)==0 for x in M)
 checks['modified_atom_original_rank_one']=simplifyzero(R-g*S)
 checks['modified_atom_corrected_rank_one']=simplifyzero(Qo*M*Qo*D*Qe-D*Qe*M*Qe-g0*S0)
 assert all(checks.values()), checks
 checks={k:bool(v) for k,v in checks.items()}
 report={'status':'PASS','assertion_count':len(checks),'checks':checks,
  'scope':'Exact K=3 symbolic pole-neutral prime-atom formulas; positivity for 0<a<=1, 3<pi<22/7.',
  'control_changes_von_Mangoldt_coefficient':True,'control_is_actual_zeta':False,
  'RH_status':'OPEN','native_first_prime_aperture':'L=(4/3) log(2), so omega=1/4 and 2<exp(L)<3',
  'M4':'-720','even_numerator_lower_bound':'145/7','odd_numerator_lower_bound':'25'}
 path=Path(__file__).resolve().parents[1]/'evidence'/'modified_prime_control.json'
 path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
