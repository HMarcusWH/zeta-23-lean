#!/usr/bin/env python3
"""Exact finite checks for the paper-level pole-neutral compression lemma.

No numerical approximation, zeta positivity assumption, or Lean authority.
All assertions are over rational matrices; their finite scope is recorded.
"""
from __future__ import annotations
import json
from pathlib import Path
import sympy as s


def geometry(K: int, a: s.Rational) -> dict:
    if K < 3 or a <= 0:
        raise ValueError('K >= 3 and a > 0 required')
    size = 2*K + 1
    n = s.Matrix(range(-K,K+1))
    ones = s.ones(size,1)
    D = s.diag(*n)
    J = s.zeros(size)
    for j in range(size): J[j,size-1-j] = 1
    n2 = n.applyfunc(lambda x:x*x)
    N = n2 - ones*(ones.dot(n2)/size)
    nu = N.dot(N)
    E = (s.eye(size)+J)/2 - ones*ones.T/size - N*N.T/nu
    O = (s.eye(size)-J)/2 - n*n.T/n.dot(n)
    h = n.applyfunc(lambda x: 1/(a+x*x))
    ve, vo = E*h, O*D*h
    Qe = E - ve*ve.T/ve.dot(ve)
    Qo = O - vo*vo.T/vo.dot(vo)
    g = O*n.applyfunc(lambda x:x**3)
    b = h.dot(N)/nu
    g0 = Qo*g
    return locals()


def check(K: int, a: s.Rational) -> dict:
    d = geometry(K,a)
    E,O,D,h,ve,vo,Qe,Qo,g,b,N,nu,n,g0 = (d[x] for x in
        ['E','O','D','h','ve','vo','Qe','Qo','g','b','N','nu','n','g0'])
    z = s.zeros(2*K+1)
    checks = {
        'D_maps_even_to_odd': O*D*E == D*E,
        'pole_moments_intertwine': vo.T*D*E == -a*ve.T,
        'D_maps_pole_neutral': Qo*D*Qe == D*Qe,
        'cubic_pairing_is_M4': g.T*D*E == n.applyfunc(lambda t:t**4).T*E,
        'projected_pole_channel_collapses': Qo*D*ve == -b*g0,
        'corrected_adjoint_pole_channel': ve.T*D*D*Qe == -b*g.T*D*Qe,
        'pole_vector_nonzero': ve != s.zeros(2*K+1,1) and vo != s.zeros(2*K+1,1),
        'pole_neutral_dimensions': s.trace(Qe) == K-2 and s.trace(Qo) == K-2,
        'projectors': Qe*Qe == Qe and Qo*Qo == Qo and Qe.T==Qe and Qo.T==Qo,
        'b_negative': bool(b < 0),
    }
    if not all(checks.values()):
        raise AssertionError((K,a,checks))
    return {'K':K,'a':str(a),'b':str(b),'dimension_each':K-2,
            'g0_nonzero': g0 != s.zeros(2*K+1,1),'assertions':checks}


def main() -> None:
    rows = [check(K,a) for K in range(3,10)
            for a in (s.Rational(1,16),s.Rational(1,3),s.Rational(1),s.Rational(7))]
    report={'status':'PASS','scope':'28 finite rational geometries, K=3..9, four positive rational a values',
            'assertion_count':sum(len(r['assertions']) for r in rows),
            'not_a_Lean_proof':True,'RH_status':'OPEN','rows':rows}
    out=Path(__file__).resolve().parents[1]/'evidence'/'pole_neutral_geometry.json'
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='rows'}))

if __name__=='__main__':main()
